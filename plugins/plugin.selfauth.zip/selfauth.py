"""自助授权插件：签到攒积分，积分兑换机器人授权，支持直接购买。

发授权动作经发行方网关（POST /issue）中转完成：插件只持有网关访问令牌，
Nathan-Auth 的管理员凭据与发卡逻辑都在网关侧。积分扣减先行（operation_id
幂等），网关调用失败时按同一 operation_id 镜像退回，保证账本一致。
"""

from __future__ import annotations

import json
import time
import uuid
from datetime import datetime
from decimal import Decimal
from pathlib import Path
from typing import Any

import httpx

from runtime.models import Button, Card

PLUGIN_ID = "plugin.selfauth"
PLUGIN_VERSION = "1.2.0"
DAY_LABELS = {"7": "7 天", "30": "30 天", "90": "90 天", "365": "365 天", "0": "永久授权"}

DEFAULT_CONFIG = {
    "gateway_url": "https://v.567.wiki",
    "issue_token": "",
    "app_id": "1",
    "daily_reward": "20",
    "daily_exchange_limit": "3",
    "recharge_rate": "0.01",
    "prices": {"7": "500", "30": "1800", "90": "4500", "365": "15000", "0": "30000"},
}


def setup(context: Any) -> SelfAuthPlugin:
    plugin = SelfAuthPlugin(context)
    context.register_command(
        "auth", plugin.handle_auth, category="selfauth",
        description="自助授权主入口（菜单/签到/绑定/兑换/充值/查单）",
    )
    context.register_task("snapshot", 300, plugin.snapshot_task)
    return plugin


class SelfAuthPlugin:
    def __init__(self, context: Any) -> None:
        self.context = context
        self.data_dir = Path(context.data_dir) if getattr(context, "data_dir", None) else Path(".")
        self.data_dir.mkdir(parents=True, exist_ok=True)
        # 首次运行把生效配置写入 config.json，管理台面板即可直接编辑。
        config_dir = getattr(self.context, "config_dir", None)
        if config_dir:
            seed = Path(config_dir) / "config.json"
            if not seed.exists():
                try:
                    seed.parent.mkdir(parents=True, exist_ok=True)
                    seed.write_text(
                        json.dumps(self._load_config(), ensure_ascii=False, indent=2),
                        encoding="utf-8",
                    )
                except OSError:
                    pass
        self.config = self._load_config()
        self._write_page_snapshot()

    # ---------- 存储辅助 ----------

    def _load_config(self) -> dict[str, Any]:
        config: dict[str, Any] = dict(DEFAULT_CONFIG)
        config_dir = getattr(self.context, "config_dir", None)
        if config_dir:
            path = Path(config_dir) / "config.json"
            try:
                stored = json.loads(path.read_text(encoding="utf-8"))
                if isinstance(stored, dict):
                    prices = stored.pop("prices", None)
                    config.update({k: v for k, v in stored.items() if v not in (None, "")})
                    if isinstance(prices, dict) and prices:
                        config["prices"] = {**DEFAULT_CONFIG["prices"], **{
                            str(k): str(v) for k, v in prices.items()
                        }}
            except (OSError, ValueError):
                pass
        return config

    def _load_json(self, name: str, default: Any) -> Any:
        path = self.data_dir / name
        try:
            return json.loads(path.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            return default

    def _write_json(self, name: str, data: Any) -> None:
        (self.data_dir / name).write_text(
            json.dumps(data, ensure_ascii=False, indent=1), encoding="utf-8"
        )

    def _bindings(self) -> dict[str, dict[str, str]]:
        return self._load_json("bindings.json", {})

    def _ledger(self) -> list[dict[str, Any]]:
        return self._load_json("ledger.json", [])

    def _record(self, entry: dict[str, Any]) -> None:
        ledger = self._ledger()
        ledger.append({**entry, "time": datetime.now().isoformat(timespec="seconds")})
        self._write_json("ledger.json", ledger[-500:])

    def _points(self):
        return getattr(self.context, "points", None)

    # ---------- 指令入口 ----------

    async def handle_auth(self, ctx: Any, args: list[str]) -> Any:
        sub = (args[0] if args else "").strip().lower()
        if sub in {"", "menu", "帮助", "help"}:
            return await self._menu_card(ctx)
        if sub in {"签到", "sign"}:
            return await self._daily(ctx)
        if sub in {"bind", "绑定"}:
            return await self._bind(ctx, args[1:])
        if sub in {"tiers", "档位"}:
            return self._tiers_card()
        if sub in {"buy", "兑换"}:
            return await self._exchange(ctx, args[1:])
        if sub in {"query", "查询"}:
            return await self._query_card(ctx, args[1:])
        if sub in {"check", "查单"}:
            return await self._check_order(ctx, args[1:])
        if sub in {"充值", "recharge", "pay"}:
            return await self._recharge(ctx, args[1:])
        if sub in {"admin", "管理"}:
            return await self._admin(ctx, args[1:])
        return "未知子命令。发送 /auth 查看主菜单。"

    async def _menu_card(self, ctx: Any) -> Card:
        points = self._points()
        balance_line = ""
        if points is not None:
            balance_line = f"我的积分：{await points.balance(ctx.sender_id)}\n\n"
        price_line = "，".join(
            f"{DAY_LABELS[k]} {v}" for k, v in self.config["prices"].items()
        )
        return Card(
            title="自助授权",
            markdown=(
                f"插件版本 v{PLUGIN_VERSION}\n"
                "**积分兑换机器人授权**\n\n"
                f"{balance_line}"
                "① `/auth bind <你的机器人AppID> [主人QQ]` 完成绑定\n"
                "② `/auth 签到` 每日领积分，或直接购买充值\n"
                "③ `/auth buy <档位>` 或点下方按钮兑换\n\n"
                f"价目（积分）：{price_line}\n"
                f"充值比例：1 元 ≈ {int(1 / max(float(self.config.get('recharge_rate', '0.01')), 0.0001))} 积分\n"
                "绑定后兑换即时生效，机器人重启无需重新授权。"
            ),
            rows=[
                [Button(label="每日签到", command="/auth 签到"),
                 Button(label="充值积分", command="/auth 充值")],
                [Button(label="兑换档位", command="/auth tiers"),
                 Button(label="授权查询", command="/auth query")],
                [Button(label="管理", command="/auth admin")],
            ],
        )

    def _tiers_card(self) -> Card:
        price_line = "\n".join(
            f"{DAY_LABELS[k]}：{v} 积分" for k, v in sorted(
                self.config["prices"].items(), key=lambda kv: int(kv[0])
            )
        )
        return Card(
            title="兑换档位",
            markdown=f"选择要兑换的档位（积分）：\n{price_line}",
            rows=[
                [Button(label="7 天", command="/auth buy 7"),
                 Button(label="30 天", command="/auth buy 30"),
                 Button(label="90 天", command="/auth buy 90")],
                [Button(label="365 天", command="/auth buy 365"),
                 Button(label="永久授权", command="/auth buy 0")],
                [Button(label="主菜单", command="/auth")],
            ],
        )

    async def _daily(self, ctx: Any) -> str:
        self.config = self._load_config()
        points = self._points()
        if points is None:
            return "当前环境未接入积分服务。"
        reward = self.config.get("daily_reward", "20")
        operation_id = f"{PLUGIN_ID}:daily:{ctx.sender_id}:{datetime.now().date()}"
        before = await points.balance(ctx.sender_id)
        await points.credit(
            ctx.sender_id, str(reward),
            reason=f"{PLUGIN_ID}.daily", actor=PLUGIN_ID, operation_id=operation_id,
        )
        after = await points.balance(ctx.sender_id)
        if after == before:
            return f"今日签到已领过啦，当前余额 {after}，明天再来～"
        return f"签到成功，{reward} 积分到账，当前余额 {after}。"

    async def _bind(self, ctx: Any, args: list[str]) -> Any:
        if not args or not args[0].isdigit():
            return Card(
                title="绑定机器人",
                markdown=(
                    "用法：`/auth bind <机器人AppID> [主人QQ]`\n\n"
                    "机器人 AppID 即 QQ 开放平台机器人管理页的 ID；"
                    "主人 QQ 用于授权站档案，缺省时与机器人 ID 相同。"
                ),
                rows=[],
            )
        robot = args[0].strip()
        master = (args[1].strip() if len(args) > 1 and args[1].strip() else robot)
        bindings = self._bindings()
        bindings[ctx.sender_id] = {"robot": robot, "master": master}
        self._write_json("bindings.json", bindings)
        return Card(
            title="绑定成功",
            markdown=(
                f"已绑定机器人 `{robot}`（主人 {master}）。\n"
                "之后 `/auth buy <天数>` 的兑换将直接为这台机器人开通授权。"
            ),
            rows=[[Button(label="去兑换", command="/auth buy 30")]],
        )

    async def _exchange(self, ctx: Any, args: list[str]) -> Any:
        self.config = self._load_config()
        points = self._points()
        if points is None:
            return "当前环境未接入积分服务。"
        days_key = (args[0] if args else "").strip().lstrip("vV")
        if days_key == "永久":
            days_key = "0"
        prices = {str(k): str(v) for k, v in (self.config.get("prices") or {}).items()}
        if days_key not in prices:
            valid = "、".join(sorted(prices, key=lambda x: int(x)))
            return f"可用档位：{valid}（0=永久）。用法：/auth buy <档位>"
        price = prices[days_key]
        label = DAY_LABELS.get(days_key, f"{days_key} 天")

        bindings = self._bindings()
        binding = bindings.get(ctx.sender_id)
        if not binding:
            return "请先绑定机器人：`/auth bind <机器人AppID> [主人QQ]`"
        robot, master = binding["robot"], binding["master"]

        today = datetime.now().date().isoformat()
        limit = int(self.config.get("daily_exchange_limit", "3"))
        issued_today = sum(
            1 for entry in self._ledger()
            if entry.get("openid") == ctx.sender_id
            and entry.get("status") == "issued"
            and str(entry.get("time", "")).startswith(today)
        )
        if issued_today >= limit:
            return f"今日兑换次数已达上限（{limit} 次），明天再来。"

        balance = await points.balance(ctx.sender_id)
        if balance < Decimal(price):
            return f"积分不足：需要 {price}，当前余额 {balance}。可通过签到或购买充值。"

        debit_op = f"{PLUGIN_ID}:debit:{ctx.sender_id}:{days_key}:{uuid.uuid4().hex[:8]}"
        await points.debit(
            ctx.sender_id, price,
            reason=f"{PLUGIN_ID}.exchange", actor=PLUGIN_ID, operation_id=debit_op,
        )

        result = await self._call_issue(robot, master, int(days_key), order_id=debit_op)
        if not result.get("ok"):
            await points.credit(
                ctx.sender_id, price,
                reason=f"{PLUGIN_ID}.refund", actor=PLUGIN_ID, operation_id=f"{debit_op}:refund",
            )
            self._record({
                "openid": ctx.sender_id, "robot": robot, "days": days_key,
                "points": price, "status": "failed", "msg": str(result.get("msg", ""))[:160],
            })
            return f"兑换失败，{price} 积分已退回。原因：{str(result.get('msg', '未知'))[:120]}"

        self._record({
            "openid": ctx.sender_id, "robot": robot, "days": days_key,
            "points": price, "status": "issued", "order": debit_op,
        })
        self._write_page_snapshot()
        return Card(
            title=f"兑换成功：{label}",
            markdown=(
                f"已为机器人 `{robot}` 开通{label}授权（永久授权立即生效）。\n"
                "在你的 Runtime 上重连或重启一次即可读取新授权。"
            ),
            rows=[[Button(label="授权查询", command="/auth query")]],
        )

    async def _query_card(self, ctx: Any, args: list[str]) -> Any:
        """授权查询：用户输入机器人 AppID，实时查授权站。"""

        if not args or not args[0].strip():
            return Card(
                title="授权查询",
                markdown=(
                    "用法：`/auth query <机器人AppID>`\n"
                    "点下方按钮填入指令，补上机器人 AppID 发送即可实时查询授权状态。"
                ),
                rows=[
                    [Button(label="查询授权", command="/auth query ", enter=False, action_type=2)],
                    [Button(label="主菜单", command="/auth")],
                ],
            )
        robot = args[0].strip()
        if not robot.isdigit():
            return "机器人 AppID 必须是纯数字。"
        result = await self._call_admin("/auth_query", {"qq": robot})
        gateway = result.get("gateway") or {}
        data = gateway.get("data") or {}
        again = [Button(label="再查一个", command="/auth query ", enter=False, action_type=2)]
        if gateway.get("authorized") is True:
            features = data.get("features") or []
            packages = data.get("packages") or []
            package_line = "，".join(
                str(p.get("name") or p.get("title") or p) for p in packages[:3]
            ) if packages else "-"
            feature_names = "、".join(
                str(f.get("name") or f.get("key") or f) for f in features[:8]
            )
            return Card(
                title=f"查询结果：{robot}",
                markdown=(
                    "✅ **该机器人已有授权**\n"
                    f"授权期限：{data.get('authdate', '-')}\n"
                    f"主人：`{data.get('master', '-')}`\n"
                    f"权益包：{package_line}\n"
                    f"激活权益：{len(features)} 项\n"
                    + (f"（{feature_names}…）" if len(features) > 8 else (f"（{feature_names}）" if feature_names else ""))
                ),
                rows=[again, [Button(label="主菜单", command="/auth")]],
            )
        if gateway.get("authorized") is False:
            return Card(
                title=f"查询结果：{robot}",
                markdown=(
                    "⚠️ **授权站未查到该机器人的有效授权。**\n"
                    f"{str(gateway.get('msg', ''))[:100]}\n如已购买，请联系发行方核对。"
                ),
                rows=[again],
            )
        raw = json.dumps(result.get("gateway"), ensure_ascii=False)[:200] if result.get("gateway") else ""
        return f"查询失败：{str(result.get('msg') or '网关暂时无响应，请稍后重试')[:120]}" + (f"｜{raw}" if raw else "")

    async def _call_issue(self, robot: str, master: str, days: int, order_id: str = "") -> dict[str, Any]:
        """经网关 /issue 创建授权。返回归一化结果 {ok, code, msg}。"""

        self.config = self._load_config()  # 面板改配置后无需重启
        issue_token = str(self.config.get("issue_token") or "")
        gateway_url = str(self.config.get("gateway_url") or "").rstrip("/")
        if not issue_token or not gateway_url:
            return {"ok": False, "msg": "兑换服务未配置"}
        try:
            async with httpx.AsyncClient(timeout=25) as client:
                response = await client.post(
                    f"{gateway_url}/issue",
                    json={
                        "appid": str(self.config.get("app_id", "1")),
                        "qq": robot,
                        "master": master,
                        "days": days,
                        "order_id": order_id,
                    },
                    headers={"X-Issue-Token": issue_token},
                )
        except (httpx.HTTPError, ValueError) as error:
            return {
                "ok": False,
                "msg": f"网关连接失败：{type(error).__name__}: {str(error)[:80]}",
                "gateway": {"error": f"{type(error).__name__}: {str(error)[:120]}"},
            }
        if response.status_code != 200:
            try:
                payload = response.json()
            except ValueError:
                payload = {}
            return {
                "ok": False,
                "msg": str(payload.get("msg") or f"网关返回 HTTP {response.status_code}")[:160],
                "gateway": {"http_status": response.status_code, "body": str(payload)[:200]},
            }
        try:
            result = response.json()
        except ValueError:
            return {"ok": False, "msg": "网关响应无效"}
        result = result if isinstance(result, dict) else {}
        return {"ok": bool(result.get("ok")), "msg": str(result.get("msg", ""))[:160], "gateway": result}

    async def _recharge(self, ctx: Any, args: list[str]) -> Any:
        """充值积分（参考绘图插件）：按 元/积分 比例创建支付订单，支付成功自动到账。"""
        self.config = self._load_config()
        pay = self.context.builtin("runtime.pay")
        if pay is None or not hasattr(pay, "create_payment"):
            return "支付插件尚未启用，暂时无法充值。"
        try:
            rate = float(self.config.get("recharge_rate", "0.01"))
        except (TypeError, ValueError):
            rate = 0.01
        rate = min(max(rate, 0.01), 100.0)

        if not args or not args[0].strip().isdigit():
            per_yuan = int(1 / max(rate, 0.0001))
            return Card(
                title="充值积分",
                markdown=(
                    f"当前比例：1 元 ≈ {per_yuan} 积分\n"
                    "点下方快捷档位直接下单；自定义金额点「自定义金额」后输入数量\n"
                    "支付成功后积分自动到账，`/auth buy <档位>` 完成兑换。"
                ),
                rows=[
                    [Button(label="充 500 积分", command="/auth 充值 500"),
                     Button(label="充 1800 积分", command="/auth 充值 1800")],
                    [Button(label="充 4500 积分", command="/auth 充值 4500"),
                     Button(label="自定义金额", command="/auth 充值 ", enter=False, action_type=2)],
                ],
            )

        count = int(args[0].strip())
        if count < 1 or count > 100000:
            return "积分数量需为 1-100000。"
        yuan = count * rate
        total = f"{yuan:.2f}"
        external_id = f"{PLUGIN_ID}:{count}:{ctx.sender_id}:{int(time.time())}"
        try:
            intent = await pay.create_payment(
                source_plugin=PLUGIN_ID,
                external_id=external_id,
                owner_key=ctx.sender_id,
                subject=f"授权积分 {count} 点",
                amount=total,
                points=str(count),
            )
        except ValueError as error:
            if "active payment limit" in str(error):
                return "你有未支付订单达到上限，请先完成支付或等旧订单过期后再试。"
            if "商户" in str(error):
                return f"创建支付失败：{error}（管理员需先在支付设置中绑定商户）。"
            return f"创建支付失败：{error}"
        except Exception:
            return "创建支付失败，请稍后重试。"
        order_id = str(intent.get("order_id") or intent.get("id") or intent.get("reference") or "-")
        link = str(intent.get("pay_info") or intent.get("pay_url") or "")
        self._record({
            "openid": ctx.sender_id, "robot": "-", "days": "-",
            "points": count, "status": "recharge", "order": order_id,
        })
        rows = [[Button(label="授权查询", command="/auth query")]]
        if link:
            return Card(
                title=f"充值订单已创建：{total} 元 / {count} 积分",
                markdown=(
                    f"订单号：`{order_id}`\n"
                    "点击下方按钮跳转支付，支付成功后积分自动到账。\n"
                    "到账后 `/auth buy <档位>` 完成兑换。"
                ),
                rows=[[Button(label="去支付", command=link, action_type=0, visited_label="跳转支付")], rows[0]],
            )
        return Card(
            title=f"充值订单已创建：{total} 元 / {count} 积分",
            markdown=(
                f"订单号：`{order_id}`\n"
                "支付成功后积分自动到账，`/auth buy <档位>` 完成兑换。"
            ),
            rows=rows,
        )

    async def _check_order(self, ctx: Any, args: list[str]) -> str:
        pay = self.context.builtin("runtime.pay")
        if pay is None or not hasattr(pay, "query_payment"):
            return "当前环境未启用内置插件桥。"
        if not args:
            return "用法：/auth check <订单号>"
        order = await pay.query_payment(args[0])
        status = str(order.get("local_status") or order.get("status") or "unknown")
        mark = {"paid": "✅ 已支付，积分已自动到账，/auth buy <档位> 完成兑换",
                "pending": "⏳ 待支付"}.get(status, status)
        return f"订单 {args[0]}：{mark}"

    # ---------- 管理员菜单（主人/管理员） ----------

    async def _admin(self, ctx: Any, args: list[str]) -> Any:
        if not getattr(ctx, "is_admin", False):
            return "该菜单仅机器人的主人和管理员可用。"
        action = (args[0] if args else "").strip().lower()
        if action in {"", "menu", "菜单"}:
            return self._admin_menu_card()
        if action in {"add", "加"}:
            return await self._admin_adjust(ctx, args[1:], grant=True)
        if action in {"sub", "扣"}:
            return await self._admin_adjust(ctx, args[1:], grant=False)
        if action in {"issue", "发授权"}:
            return await self._admin_issue(ctx, args[1:])
        if action in {"freeze", "封禁"}:
            return await self._admin_key_rpc(ctx, args[1:], "freeze")
        if action in {"unfreeze", "解封"}:
            return await self._admin_key_rpc(ctx, args[1:], "unfreeze")
        if action in {"delete", "删除"}:
            return await self._admin_key_rpc(ctx, args[1:], "delete")

        return (
            "管理子命令：\n"
            "- add/sub <openid> <积分>\n"
            "- issue <机器人AppID> <天数> [主人QQ]\n"
            "- freeze <机器人AppID> <原因>（封禁）\n"
            "- unfreeze <机器人AppID>（解封）\n"
            "- delete <机器人AppID> 确认（删除授权，需带 确认 二字）"
        )

    def _admin_menu_card(self) -> Card:
        def fill(label: str, command: str) -> Button:
            return Button(
                label=label, command=command, enter=False, action_type=2,
                permission=1, permission_message="此操作仅主人与管理员可用。",
            )

        def send(label: str, command: str) -> Button:
            return Button(label=label, command=command, permission=1)
        return Card(
            title="授权管理（仅主人/管理员）",
            markdown=(
                "点按钮会把指令填入输入框，补上参数后发送。\n\n"
                "`/auth admin add <openid> <积分>` — 加积分\n"
                "`/auth admin sub <openid> <积分>` — 扣积分\n"
                "`/auth admin issue <机器人AppID> <天数> [主人QQ]` — 直接开通授权（0=永久）\n"
                "`/auth admin freeze <机器人AppID> <原因>` — 封禁\n"
                "`/auth admin unfreeze <机器人AppID>` — 解封\n"
                "`/auth admin delete <机器人AppID> 确认` — 删除授权（不可恢复）\n"
                "查询授权：`/auth query <机器人AppID>`（授权站实时）\n\n"
                "openid 可在对方使用 /id 或兑换记录中获取。"
            ),
            rows=[
                [fill("➕ 加积分", "/auth admin add "),
                 fill("➖ 扣积分", "/auth admin sub ")],
                [fill("发授权", "/auth admin issue "),
                 fill("封禁", "/auth admin freeze ")],
                [fill("解封", "/auth admin unfreeze "),
                 fill("删除授权", "/auth admin delete ")],
                [fill("授权查询", "/auth query "),
                 send("刷新菜单", "/auth")],
                [Button(label="主菜单", command="/auth")],
            ],
        )

    async def _admin_adjust(self, ctx: Any, args: list[str], *, grant: bool) -> str:
        points = self._points()
        if points is None:
            return "当前环境未接入积分服务。"
        if len(args) < 2 or not args[1].lstrip("-").isdigit():
            verb = "加" if grant else "扣"
            return f"用法：/auth admin {'add' if grant else 'sub'} <openid> <积分>"
        openid = args[0].strip()
        amount = int(args[1])
        if amount <= 0:
            return "积分数量必须为正整数。"
        verb = "增加" if grant else "扣减"
        op = f"{PLUGIN_ID}:admin:{'grant' if grant else 'deduct'}:{openid}:{amount}:{uuid.uuid4().hex[:8]}"
        try:
            if grant:
                await points.credit(
                    openid, str(amount),
                    reason=f"{PLUGIN_ID}.admin.grant", actor=PLUGIN_ID, operation_id=op,
                )
            else:
                await points.debit(
                    openid, str(amount),
                    reason=f"{PLUGIN_ID}.admin.deduct", actor=PLUGIN_ID, operation_id=op,
                )
        except Exception as error:
            return f"操作失败：{str(error)[:120]}"
        return f"已为 {openid} {verb} {amount} 积分。"

    async def _admin_issue(self, ctx: Any, args: list[str]) -> Any:
        if len(args) < 2 or not args[0].isdigit() or not args[1].lstrip("-").isdigit():
            return "用法：/auth admin issue <机器人AppID> <天数> [主人QQ]（0=永久）"
        robot = args[0].strip()
        days = int(args[1])
        master = args[2].strip() if len(args) > 2 and args[2].strip() else robot
        if not robot.isdigit():
            return "机器人 AppID 必须是纯数字。"
        if not 0 <= days <= 36500:
            return "天数范围 0-36500（0=永久）。"
        result = await self._call_issue(robot, master, days, order_id=f"{PLUGIN_ID}:admin:{uuid.uuid4().hex[:8]}")
        self._record({
            "openid": ctx.sender_id, "robot": robot, "days": days,
            "points": 0, "status": "admin_issued" if result.get("ok") else "admin_failed",
            "msg": str(result.get("msg", ""))[:160],
        })
        self._write_page_snapshot()
        if not result.get("ok"):
            return f"发授权失败：{str(result.get('msg', '未知'))[:120]}"
        label = DAY_LABELS.get(str(days), f"{days} 天")
        return Card(
            title="已直接开通授权",
            markdown=f"机器人 `{robot}` 已开通 {label} 授权（不走积分）。",
            rows=[[Button(label="主菜单", command="/auth")]],
        )

    async def _call_admin(self, path: str, payload: dict[str, Any]) -> dict[str, Any]:
        self.config = self._load_config()  # 面板改配置后无需重启
        gateway_url = str(self.config.get("gateway_url") or "").rstrip("/")
        issue_token = str(self.config.get("issue_token") or "")
        if not gateway_url or not issue_token:
            return {"ok": False, "msg": "兑换服务未配置"}
        try:
            async with httpx.AsyncClient(timeout=25) as client:
                response = await client.post(
                    f"{gateway_url}{path}", json=payload,
                    headers={"X-Issue-Token": issue_token},
                )
        except (httpx.HTTPError, ValueError) as error:
            return {
                "ok": False,
                "msg": f"网关连接失败：{type(error).__name__}: {str(error)[:80]}",
                "gateway": {"error": f"{type(error).__name__}: {str(error)[:120]}"},
            }
        if response.status_code != 200:
            try:
                payload = response.json()
            except ValueError:
                payload = {}
            return {
                "ok": False,
                "msg": str(payload.get("msg") or f"网关返回 HTTP {response.status_code}")[:160],
                "gateway": {"http_status": response.status_code, "body": str(payload)[:200]},
            }
        try:
            result = response.json()
        except ValueError:
            return {"ok": False, "msg": "网关响应无效"}
        result = result if isinstance(result, dict) else {}
        return {"ok": bool(result.get("ok")), "msg": str(result.get("msg", ""))[:160], "gateway": result}

    async def _admin_key_rpc(self, ctx: Any, args: list[str], action: str) -> Any:
        app_id = str(self.config.get("app_id", "1"))
        if action == "freeze":
            if len(args) < 2 or not args[0].isdigit():
                return "用法：/auth admin freeze <机器人AppID> <原因>"
            robot, reason = args[0].strip(), " ".join(args[1:]).strip()
            payload = {"appid": app_id, "qq": robot, "reason": reason}
            verb = "封禁"
        elif action == "unfreeze":
            if not args or not args[0].isdigit():
                return "用法：/auth admin unfreeze <机器人AppID>"
            payload = {"appid": app_id, "qq": args[0].strip()}
            verb = "解封"
        else:
            if len(args) < 2 or not args[0].isdigit() or args[1].strip() != "确认":
                return "⚠️ 删除授权不可恢复。用法：/auth admin delete <机器人AppID> 确认"
            payload = {"appid": app_id, "qq": args[0].strip()}
            verb = "删除"
        result = await self._call_admin(f"/{action}", payload)
        self._record({
            "openid": ctx.sender_id, "robot": payload.get("qq", "-"), "days": "-",
            "points": 0, "status": f"{action}_{'ok' if result.get('ok') else 'failed'}",
            "msg": str(result.get("msg", ""))[:160],
        })
        self._write_page_snapshot()
        if not result.get("ok"):
            return f"{verb}授权失败：{str(result.get('msg', '未知'))[:120]}"
        return f"已{verb}机器人 {payload.get('qq')} 的授权。"

    # ---------- 面板快照 ----------

    def save_config(self, payload: dict[str, Any]) -> dict[str, Any]:
        for k, v in (payload or {}).items():
            if k == "issue_token" and str(v).strip() in {"", "******"}:
                continue
            if k in DEFAULT_CONFIG:
                self.config[k] = v
        config_dir = getattr(self.context, "config_dir", None)
        if config_dir:
            path = Path(config_dir) / "config.json"
            try:
                path.write_text(json.dumps(self.config, ensure_ascii=False, indent=2), encoding="utf-8")
            except Exception:
                pass
        self._write_page_snapshot()
        return {"success": True, "config": self.config}

    async def on_page_action(self, action: str, payload: dict[str, Any]) -> Any:
        if action == "save_config":
            return self.save_config(payload)
        if action == "refresh":
            self._write_page_snapshot()
            return {"success": True}
        raise ValueError(f"未知操作: {action}")

    def snapshot_task(self) -> None:
        self._write_page_snapshot()

    def _write_page_snapshot(self, extra: dict[str, Any] | None = None) -> None:
        ledger = self._ledger()
        issued = [entry for entry in ledger if entry.get("status") == "issued"]
        token_set = bool(str(self.config.get("issue_token") or "").strip())
        snapshot = {
            "updated_at": datetime.now().isoformat(timespec="seconds"),
            "issued_total": len(issued),
            "points_spent": sum(int(entry.get("points", 0)) for entry in issued),
            "recent": list(reversed(issued[-10:])),
            "config": {
                "gateway_url": str(self.config.get("gateway_url", "https://v.567.wiki")),
                "issue_token": "" if not token_set else "******",
                "issue_token_configured": token_set,
                "app_id": str(self.config.get("app_id", "1")),
                "daily_reward": int(self.config.get("daily_reward", 20)),
                "daily_exchange_limit": int(self.config.get("daily_exchange_limit", 3)),
                "recharge_rate": float(self.config.get("recharge_rate", 0.01)),
            },
            "schema": {
                "gateway_url": {"type": "str", "default": "https://v.567.wiki"},
                "issue_token": {"type": "str", "default": ""},
                "app_id": {"type": "str", "default": "1"},
                "daily_reward": {"type": "int", "min": 1, "max": 10000, "default": 20},
                "daily_exchange_limit": {"type": "int", "min": 1, "max": 100, "default": 3},
                "recharge_rate": {"type": "float", "min": 0.001, "max": 10.0, "default": 0.01},
            },
            "labels": {
                "gateway_url": "发行网关地址",
                "issue_token": "网关访问令牌 (Token)",
                "app_id": "Nathan-Auth 应用 ID",
                "daily_reward": "每日签到赠送积分",
                "daily_exchange_limit": "每日最多兑换次数",
                "recharge_rate": "充值比例（1 积分 = ? 元）",
            },
            "stats": {
                "累计发卡总数": len(issued),
                "累计消耗积分": sum(int(entry.get("points", 0)) for entry in issued),
                "当前绑定用户数": len(self._bindings()),
            },
            "service": {
                "网关状态": "已配置令牌" if token_set else "未配置令牌",
                "插件版本": PLUGIN_VERSION,
            },
        }
        if extra:
            snapshot.update(extra)
        (self.data_dir / "page_overview.json").write_text(
            json.dumps(snapshot, ensure_ascii=False, indent=1), encoding="utf-8"
        )
