"""New API 用户中心外部插件（plugin.na）。

支持用户绑定系统访问令牌、用量与余额查询、模型统计、日志报表、
API 令牌自服务管理、低余额/高消费/连续失败主动提醒与原生管理台集成。
"""

from __future__ import annotations

import asyncio
import contextlib
import datetime as dt
import json
import logging
import math
import os
import secrets
import time
from collections import defaultdict
from pathlib import Path
from typing import Any
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

import httpx

from runtime.models import Button, Card, MessageContext

logger = logging.getLogger("plugin.na")
PLUGIN_VERSION = "1.0.1"
CONFIG_DEFAULTS: dict[str, Any] = {
    "newapi_base_url": "",
    "service_display_name": "New API",
    "enable_qq_cards": True,
    "enable_topup_history": True,
    "enable_account_security": True,
    "enable_checkin": False,
    "enable_subscription": False,
    "request_timeout_sec": 15,
    "network_error_message": "New API 当前不可用，请稍后重试。",
    "quota_per_unit": 500000.0,
    "models_cache_ttl_sec": 3600,
    "groups_cache_ttl_sec": 3600,
    "tokens_cache_ttl_sec": 300,
    "query_rate_limit_sec": 5,
    "group_query_concurrency": 5,
    "delete_confirm_ttl_sec": 120,
    "model_table_max_columns": 3,
    "alert_check_interval_sec": 300,
    "alert_repeat_cooldown_sec": 86400,
    "stats_timezone": "Asia/Shanghai",
    "stats_max_logs": 1000,
}

# ``/na config`` 允许管理员修改的键及其类型和边界。
CONFIG_SPEC: dict[str, tuple[str, tuple[float, float]]] = {
    "newapi_base_url": ("str", (0, 200)),
    "service_display_name": ("str", (1, 40)),
    "network_error_message": ("str", (0, 200)),
    "stats_timezone": ("str", (1, 60)),
    "enable_qq_cards": ("bool", (0, 0)),
    "enable_topup_history": ("bool", (0, 0)),
    "enable_account_security": ("bool", (0, 0)),
    "enable_checkin": ("bool", (0, 0)),
    "enable_subscription": ("bool", (0, 0)),
    "request_timeout_sec": ("int", (3, 60)),
    "quota_per_unit": ("float", (0.000001, 1e12)),
    "models_cache_ttl_sec": ("int", (0, 86400)),
    "groups_cache_ttl_sec": ("int", (0, 86400)),
    "tokens_cache_ttl_sec": ("int", (0, 86400)),
    "query_rate_limit_sec": ("int", (0, 600)),
    "group_query_concurrency": ("int", (1, 10)),
    "delete_confirm_ttl_sec": ("int", (30, 600)),
    "model_table_max_columns": ("int", (1, 3)),
    "alert_check_interval_sec": ("int", (60, 86400)),
    "alert_repeat_cooldown_sec": ("int", (0, 2592000)),
    "stats_max_logs": ("int", (100, 5000)),
}

SUBCOMMAND_ALIASES = {
    "帮助": "help", "菜单": "menu", "绑定": "bind", "登录": "bind", "login": "bind",
    "我的": "me", "充值记录": "topups", "签到": "checkin", "签到状态": "checkinstatus",
    "我的订阅": "subscriptions", "订阅套餐": "plans", "余额": "quota", "用量": "quota",
    "模型": "models", "分组": "groups", "日志": "logs", "模型日志": "logsmodel",
    "今日": "today", "统计": "stats", "本周": "week", "模型统计": "modelstats",
    "报表": "report", "定时报表": "digest", "消费提醒": "spendalert",
    "关闭消费提醒": "spendalertoff", "消费提醒状态": "spendalertstatus",
    "失败提醒": "failalert", "关闭失败提醒": "failalertoff", "失败提醒状态": "failalertstatus",
    "失败检查": "failcheck", "提醒检查": "alertcheck", "令牌": "token",
    "创建令牌": "tokenadd", "启用令牌": "tokenenable", "禁用令牌": "tokendisable",
    "删除令牌": "tokendelete", "确认删除": "tokenconfirm", "令牌额度提醒": "tokenalert",
    "关闭令牌额度提醒": "tokenalertoff", "令牌额度提醒状态": "tokenalertstatus",
    "兑换": "redeem", "提醒": "alert", "关闭提醒": "alertoff", "提醒状态": "alertstatus",
    "校准": "calibrate", "诊断": "diagnose", "退出": "unbind", "解绑": "unbind",
    "配置": "config",
}


def _cell(value: Any, limit: int) -> str:
    text = str(value).replace("|", "\\|").replace("\n", " ").strip()
    return text if len(text) <= limit else text[: limit - 1] + "…"


def _button(
    label: str,
    command: str,
    action_type: int | None = None,
    permission: int | None = None,
    enter: bool = False,
    expires_after_seconds: int = 600,
    click_limit: int | None = None,
) -> Button:
    cmd = command.strip()
    is_input = command.endswith(" ")
    if action_type is None:
        action_type = 2 if is_input else 1

    if permission is None:
        if any(cmd.startswith(p) for p in ("/na menu admin", "/na config", "/na diagnose", "/na calibrate")):
            permission = 1
        elif any(cmd.startswith(p) for p in ("/na menu", "/na help", "/na models", "/na groups", "/na plans")):
            permission = 0
        else:
            permission = 2

    if click_limit is None:
        click_limit = 30 if permission == 0 else 10

    return Button(
        label[:10],
        command,
        action_type=action_type,
        enter=enter,
        permission=permission,
        click_limit=click_limit,
        expires_after_seconds=expires_after_seconds,
        expired_message="此操作按钮已过期，请重新打开菜单。",
        permission_message="此操作需要管理员权限。" if permission == 1 else "此操作为专属用户操作。",
    )


def _menu_markdown(title: str, content: str, limit: int = 3300) -> str:
    text = str(content or "无数据").strip()
    if len(text) > limit:
        text = text[:limit].rsplit("\n", 1)[0].rstrip() + "\n\n> 内容较长，已截短。"
    return f"# {str(title)[:80]}\n\n{text}"[:4000]



CONFIG_LABELS = {
    "newapi_base_url": "New API 基础地址",
    "service_display_name": "服务显示名称",
    "network_error_message": "网络异常提示语",
    "stats_timezone": "统计时区",
    "enable_qq_cards": "启用 QQ Markdown 卡片",
    "enable_topup_history": "允许查看充值记录",
    "enable_account_security": "启用账号安全检查",
    "enable_checkin": "启用签到功能",
    "enable_subscription": "启用订阅套餐查询",
    "request_timeout_sec": "API 请求超时（秒）",
    "quota_per_unit": "单位额度换算比例（默认 500000/$1）",
    "models_cache_ttl_sec": "模型列表缓存时间（秒）",
    "groups_cache_ttl_sec": "用户分组缓存时间（秒）",
    "tokens_cache_ttl_sec": "API 令牌缓存时间（秒）",
    "query_rate_limit_sec": "查询冷却限制（秒）",
    "group_query_concurrency": "分组查询并发数",
    "delete_confirm_ttl_sec": "删除二次确认有效时间（秒）",
    "model_table_max_columns": "模型表格列数（1-3）",
    "alert_check_interval_sec": "告警巡检最小间隔（秒）",
    "alert_repeat_cooldown_sec": "同一告警重复冷却时间（秒）",
    "stats_max_logs": "统计最大拉取日志条数",
}

CONFIG_SCHEMA: dict[str, dict[str, Any]] = {}
for _k, (kind, (_low, _high)) in CONFIG_SPEC.items():
    _def = CONFIG_DEFAULTS.get(_k)
    CONFIG_SCHEMA[_k] = {
        "type": kind,
        "default": _def,
        "min": _low if kind in ("int", "float") else None,
        "max": _high if kind in ("int", "float") else None,
    }


class NewApiPlugin:
    def __init__(self, context: Any = None) -> None:
        self.context = context
        self.data_dir = Path(getattr(context, "data_dir", None) or "./data")
        self.config_dir = Path(getattr(context, "config_dir", None) or self.data_dir)
        self.data_dir.mkdir(parents=True, exist_ok=True)
        self.config_dir.mkdir(parents=True, exist_ok=True)
        self.store_path = self.data_dir / "na_accounts.json"
        self.config_path = self.config_dir / "config.json"
        self.snapshot_path = self.data_dir / "page_overview.json"
        self._config_mtime: float = 0.0
        self.config: dict[str, Any] = {}
        self.accounts: dict[str, dict[str, Any]] = self._load()
        self.cache: dict[str, tuple[float, str]] = {}
        self.last_query: dict[str, float] = {}
        self.pending_actions: dict[str, tuple[float, int, str]] = {}
        self.pending_codes: dict[str, str] = {}
        self._transport: httpx.AsyncBaseTransport | None = None
        self._last_alert_run = 0.0
        self._stopping = False
        self._load_config()
        self._write_page_snapshot()

    def set_gateway(self, gateway: Any) -> None:
        self.context = gateway

    def _load_config(self) -> None:
        current_mtime = 0.0
        if self.config_path.exists():
            with contextlib.suppress(OSError):
                current_mtime = self.config_path.stat().st_mtime
        if current_mtime != self._config_mtime or not self.config:
            loaded = dict(CONFIG_DEFAULTS)
            if self.config_path.exists():
                try:
                    data = json.loads(self.config_path.read_text(encoding="utf-8"))
                    if isinstance(data, dict):
                        loaded.update(data)
                except Exception as err:
                    logger.warning("读取配置文件失败: %s", err)
            else:
                # 尝试从 SQLite 提取历史设置
                db = getattr(self.context, "database", None)
                if db and hasattr(db, "cursor"):
                    try:
                        with db.cursor() as cur:
                            cur.execute("SELECT key, value FROM settings WHERE key LIKE 'na.%'")
                            migrated = {}
                            for k, v in cur.fetchall():
                                sub = k[3:]
                                if sub in CONFIG_DEFAULTS:
                                    if isinstance(CONFIG_DEFAULTS[sub], bool):
                                        migrated[sub] = str(v).lower() in ("true", "1", "yes")
                                    elif isinstance(CONFIG_DEFAULTS[sub], (int, float)):
                                        try:
                                            migrated[sub] = type(CONFIG_DEFAULTS[sub])(v)
                                        except (ValueError, TypeError):
                                            pass
                                    else:
                                        migrated[sub] = v
                            if migrated:
                                loaded.update(migrated)
                                self.config = loaded
                                self._save_config_file()
                                logger.info("从数据库迁移了 %d 项 na 旧配置", len(migrated))
                    except Exception as err:
                        logger.warning("尝试从数据库迁移 na 配置失败: %s", err)
            self.config = loaded
            self._config_mtime = current_mtime

    def _save_config_file(self) -> None:
        temp = self.config_path.with_suffix(".tmp")
        temp.write_text(json.dumps(self.config, ensure_ascii=False, indent=2), encoding="utf-8")
        temp.replace(self.config_path)
        with contextlib.suppress(OSError):
            self._config_mtime = self.config_path.stat().st_mtime

    def _write_page_snapshot(self) -> None:
        try:
            cfg = {k: self._cfg(k) for k in CONFIG_DEFAULTS}
            data = {
                "plugin_id": "plugin.na",
                "name": "New API 用户中心",
                "version": PLUGIN_VERSION,
                "config": cfg,
                "schema": CONFIG_SCHEMA,
                "labels": CONFIG_LABELS,
                "config_public": cfg,
                "config_schema": CONFIG_SCHEMA,
                "config_labels": CONFIG_LABELS,
                "stats": {
                    "accounts_count": len(self.accounts),
                    "bound_count": sum(
                        1
                        for a in self.accounts.values()
                        if isinstance(a, dict) and (a.get("access_token") or a.get("token"))
                    ),
                    "cached_queries": len(self.cache),
                },
                "updated_at": dt.datetime.now(self._stats_tz()).isoformat(),
            }
            temp = self.snapshot_path.with_suffix(".tmp")
            temp.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
            temp.replace(self.snapshot_path)
        except Exception as err:
            logger.warning("写入控制台快照失败: %s", err)

    async def reload_config(self) -> None:
        self._load_config()
        self._write_page_snapshot()

    def _cfg(self, key: str) -> Any:
        self._load_config()
        return self.config.get(key, CONFIG_DEFAULTS.get(key))

    async def set_config(self, key: str, value: Any) -> None:
        if key not in CONFIG_SPEC:
            raise ValueError(f"未知配置项: {key}")
        self._load_config()
        kind, _ = CONFIG_SPEC[key]
        if kind == "bool" and isinstance(value, str):
            val = value.lower() in ("true", "1", "on", "开")
        elif kind == "int" and isinstance(value, str):
            val = int(value)
        elif kind == "float" and isinstance(value, str):
            val = float(value)
        else:
            val = value
        self.config[key] = val
        self._save_config_file()
        self._write_page_snapshot()

    def page_overview_data(self) -> dict[str, Any]:
        """Return the complete, non-secret NA configuration for the native UI."""
        return {
            "config": {key: self._cfg(key) for key in CONFIG_DEFAULTS},
            "management": {
                "permission": "plugin.na.manage",
                "requests_per_minute": 30,
                "button_ttl_seconds": 300,
                "admin_source": "Runtime 角色与机器人主人",
            },
            "schema": {
                key: {"type": kind, "min": low, "max": high, "default": default}
                for key, (kind, (low, high)) in CONFIG_SPEC.items()
                for default in [CONFIG_DEFAULTS[key]]
            },
        }

    def page_data(self) -> dict[str, Any]:
        """Return safe account summaries for the native data panel."""
        accounts = []
        for owner_key, account in self.accounts.items():
            if not isinstance(account, dict):
                continue
            accounts.append({
                "owner_key": owner_key,
                "display_name": account.get("display_name") or owner_key,
                "token_count": len(account.get("tokens", [])) if isinstance(account.get("tokens"), list) else 0,
                "bound": bool(account.get("access_token") or account.get("token")),
                "last_query": self.last_query.get(owner_key),
            })
        return {"accounts": accounts[:500], "logs": []}

    async def page_delete_account(self, owner_key: str) -> dict[str, Any]:
        owner_key = str(owner_key or "").strip()
        if not owner_key or owner_key not in self.accounts:
            raise ValueError("未找到该 New API 账户")
        self.accounts.pop(owner_key, None)
        self.cache.pop(owner_key, None)
        self.last_query.pop(owner_key, None)
        self._save()
        return self.page_data()

    async def page_save_config(self, payload: dict[str, Any]) -> dict[str, Any]:
        """Validate and persist values submitted by the native management page."""
        if not isinstance(payload, dict):
            raise ValueError("请求格式错误")
        self._load_config()
        applied: dict[str, Any] = {}
        for key, raw in payload.items():
            if key not in CONFIG_SPEC:
                continue
            kind, (low, high) = CONFIG_SPEC[key]
            if kind == "bool":
                if isinstance(raw, bool):
                    value = raw
                elif str(raw).lower() in {"true", "1", "on", "开"}:
                    value = True
                elif str(raw).lower() in {"false", "0", "off", "关"}:
                    value = False
                else:
                    continue
                self.config[key] = value
                applied[key] = value
            elif kind == "int":
                try:
                    number = int(raw)
                except (TypeError, ValueError):
                    continue
                if low <= number <= high:
                    self.config[key] = number
                    applied[key] = number
            elif kind == "float":
                try:
                    fnumber = float(raw)
                except (TypeError, ValueError):
                    continue
                if low <= fnumber <= high:
                    self.config[key] = fnumber
                    applied[key] = fnumber
            else:
                text = str(raw or "").strip()
                if low <= len(text) <= high:
                    self.config[key] = text
                    applied[key] = text
        self._save_config_file()
        self._write_page_snapshot()
        return {"ok": True, "saved": True, "applied": applied, **self.page_overview_data()}

    async def on_page_action(self, *args: Any, **kwargs: Any) -> Any:
        """Handle Action RPC calls from the Runtime management interface."""
        if len(args) >= 2:
            action_name, payload = args[0], args[1]
        elif len(args) == 1:
            if isinstance(args[0], dict) and "action" in args[0]:
                action_name = args[0].get("action")
                payload = args[0].get("payload", args[0])
            else:
                action_name = "save_config"
                payload = args[0]
        else:
            action_name = kwargs.get("action_name", "save_config")
            payload = kwargs.get("payload", {})

        action = str(action_name or "").strip()
        payload = payload if isinstance(payload, dict) else {}

        if action in ("save_config", "config"):
            return await self.page_save_config(payload)
        elif action in ("page_data", "data", "list_accounts"):
            return self.page_data()
        elif action in ("page_delete", "delete_account"):
            ident = str(payload.get("identifier") or payload.get("owner_key") or "").strip()
            return await self.page_delete_account(ident)
        elif action == "svc_create_token":
            return await self.svc_create_token(
                str(payload.get("owner_key") or ""),
                str(payload.get("name") or ""),
                str(payload.get("group") or ""),
                int(payload.get("quota") or 0),
            )
        elif action == "svc_delete_token":
            return await self.svc_delete_token(
                str(payload.get("owner_key") or ""),
                str(payload.get("name") or ""),
            )
        elif action == "svc_list_groups":
            return await self.svc_list_groups(
                str(payload.get("owner_key") or ""),
            )
        return {"ok": False, "error": f"未知 Action: {action}"}

    def _load(self) -> dict[str, dict[str, Any]]:
        try:
            if self.store_path.exists():
                data = json.loads(self.store_path.read_text(encoding="utf-8"))
                if isinstance(data, dict) and data:
                    return data
        except (OSError, ValueError):
            pass

        # 检查是否可以从旧内置版的统一数据目录迁移 na_accounts.json
        candidate_paths = [
            self.data_dir.parent.parent / "na_accounts.json",
            Path(os.environ.get("RUNTIME_DATA_DIR", "data")) / "na_accounts.json",
            Path("./data/na_accounts.json"),
            Path("/app/data/na_accounts.json"),
        ]
        for path in candidate_paths:
            try:
                if path.exists() and path.is_file():
                    data = json.loads(path.read_text(encoding="utf-8"))
                    if isinstance(data, dict) and data:
                        logger.info("检测到旧 na 账号数据 (%s)，自动迁移导入 %d 个账号", path, len(data))
                        self.accounts = data
                        self._save()
                        return data
            except Exception as err:
                logger.warning("尝试从旧路径 %s 迁移 na 账号数据失败: %s", path, err)
        return {}

    def _save(self) -> None:
        self.data_dir.mkdir(parents=True, exist_ok=True)
        temporary = self.store_path.with_suffix(".tmp")
        temporary.write_text(json.dumps(self.accounts, ensure_ascii=False, indent=2), encoding="utf-8")
        os.chmod(temporary, 0o600)
        temporary.replace(self.store_path)
        os.chmod(self.store_path, 0o600)
        self._write_page_snapshot()

    async def close(self) -> None:
        # 保留 accounts（磁盘即持久层）；只清空易失缓存和待确认操作。
        self._stopping = True
        self.cache.clear()
        self.last_query.clear()
        self.pending_actions.clear()
        self.pending_codes.clear()

    # ---------- context helpers ----------

    @staticmethod
    def _user_key(context: MessageContext) -> str:
        return f"{context.platform or 'unknown'}:{context.sender_id}"

    @staticmethod
    def _is_private(context: MessageContext) -> bool:
        return context.conversation_type == "private"

    @staticmethod
    def _notify_ref(context: MessageContext) -> dict[str, str]:
        return {
            "conversation_id": context.conversation_id,
            "scene": context.scene or context.conversation_type or "c2c",
        }

    def _clear_user_cache(self, context: MessageContext) -> None:
        prefix = f"{self._user_key(context)}:"
        for key in list(self.cache):
            if key.startswith(prefix):
                self.cache.pop(key, None)

    # ---------- config helpers ----------

    def _base_url(self) -> str:
        return str(self._cfg("newapi_base_url") or "").strip().rstrip("/")

    def _display(self, text: Any) -> str:
        name = str(self._cfg("service_display_name") or "New API").strip()
        return str(text).replace("New API", name)

    def _timeout(self) -> float:
        return float(self._cfg("request_timeout_sec"))

    def _network_error(self) -> str:
        return str(self._cfg("network_error_message") or CONFIG_DEFAULTS["network_error_message"])

    def _quota_per_unit(self) -> float:
        return max(0.000001, float(self._cfg("quota_per_unit")))

    def _cache_ttl(self, name: str) -> int:
        defaults = {"models": 3600, "groups": 3600, "tokens": 300}
        category = name.split(":", 1)[0]
        return max(0, int(self._cfg(f"{category}_cache_ttl_sec") or defaults[category]))

    def _group_concurrency(self) -> int:
        return max(1, min(10, int(self._cfg("group_query_concurrency"))))

    def _cache_key(self, context: MessageContext, name: str) -> str:
        return f"{self._user_key(context)}:{name}"

    def _cached(self, context: MessageContext, name: str) -> str | None:
        item = self.cache.get(self._cache_key(context, name))
        if item and item[0] > time.monotonic():
            return item[1]
        return None

    def _set_cached(self, context: MessageContext, name: str, value: str) -> str:
        ttl = self._cache_ttl(name)
        if ttl > 0:
            self.cache[self._cache_key(context, name)] = (time.monotonic() + ttl, value)
        return value

    def _limited(self, context: MessageContext, command: str) -> int:
        interval = max(0, int(self._cfg("query_rate_limit_sec")))
        key = f"{self._user_key(context)}:{command}"
        now = time.monotonic()
        remaining = interval - (now - self.last_query.get(key, 0))
        if remaining > 0:
            return max(1, int(remaining + 0.999))
        self.last_query[key] = now
        return 0

    def _stats_tz(self) -> dt.tzinfo:
        try:
            return ZoneInfo(str(self._cfg("stats_timezone") or "Asia/Shanghai"))
        except ZoneInfoNotFoundError:
            return dt.timezone(dt.timedelta(hours=8))

    # ---------- HTTP ----------

    async def _request(self, account: dict[str, Any], method: str, path: str, **kwargs: Any) -> httpx.Response:
        headers = dict(kwargs.pop("headers", {}) or {})
        headers["Authorization"] = f"Bearer {account['token']}"
        if account.get("user_id") is not None:
            headers["New-Api-User"] = str(account["user_id"])
        async with httpx.AsyncClient(base_url=self._base_url(), timeout=self._timeout(), follow_redirects=False, transport=self._transport) as client:
            return await client.request(method, path, headers=headers, **kwargs)

    @staticmethod
    def _json(response: httpx.Response) -> Any:
        try:
            return response.json()
        except ValueError:
            return {}

    @staticmethod
    def _payload(data: Any) -> dict[str, Any]:
        if not isinstance(data, dict):
            return {}
        for key in ("data", "user"):
            if isinstance(data.get(key), dict):
                return data[key]
        return data

    @staticmethod
    def _message(data: Any) -> str:
        return str(data.get("message") or data.get("msg") or data.get("error") or "请求失败") if isinstance(data, dict) else "请求失败"

    @staticmethod
    def _items(data: Any) -> list[Any]:
        if isinstance(data, list):
            return data
        if not isinstance(data, dict):
            return []
        for key in ("items", "models", "groups", "logs", "data"):
            value = data.get(key)
            if isinstance(value, list):
                return value
            if isinstance(value, dict):
                nested = NewApiPlugin._items(value)
                if nested:
                    return nested
        return []

    @staticmethod
    def _mapping_items(data: Any) -> list[tuple[str, Any]]:
        if not isinstance(data, dict):
            return []
        for key in ("data", "models", "groups"):
            value = data.get(key)
            if isinstance(value, dict):
                return list(value.items())
        return list(data.items())

    @staticmethod
    def _model_names(data: Any) -> list[str]:
        names: list[str] = []

        def collect(value: Any) -> None:
            if isinstance(value, str):
                name = value
            elif isinstance(value, dict):
                name = value.get("id") or value.get("name") or value.get("model") or value.get("model_name")
                if not name:
                    for key in ("data", "models", "items"):
                        if key in value:
                            collect(value[key])
                    return
            elif isinstance(value, list):
                for item in value:
                    collect(item)
                return
            else:
                return
            if name and str(name) not in names:
                names.append(str(name))

        collect(data)
        return names

    @staticmethod
    def _short_token(token: str) -> str:
        return f"{token[:4]}...{token[-4:]}" if len(token) > 10 else "已保存"

    @staticmethod
    def _normalize_system_token(value: str) -> str:
        token = (value or "").strip()
        if token.lower().startswith("bearer "):
            token = token[7:].strip()
        if len(token) >= 2 and token[0] == token[-1] and token[0] in {'"', "'"}:
            token = token[1:-1].strip()
        return token

    @staticmethod
    def _valid_system_token(token: str) -> bool:
        return bool(token) and len(token) <= 4096 and not any(ord(character) < 32 for character in token)

    @staticmethod
    def _positive_number(value: str) -> float | None:
        try:
            number = float(str(value).strip())
            return number if math.isfinite(number) and number > 0 else None
        except (TypeError, ValueError):
            return None

    def _quota_value(self, value: Any) -> str:
        if value is None:
            return "未知"
        try:
            return f"{float(value) / self._quota_per_unit():.6f}"
        except (TypeError, ValueError):
            return str(value)

    @staticmethod
    def _time_value(value: Any) -> str:
        if value in (None, "", -1, "-1"):
            return "永不过期"
        try:
            return dt.datetime.fromtimestamp(float(value), tz=dt.UTC).strftime("%Y-%m-%d")
        except (TypeError, ValueError, OSError):
            return str(value)

    @staticmethod
    def _event_time(value: Any) -> str:
        if value in (None, ""):
            return "无数据"
        try:
            return dt.datetime.fromtimestamp(float(value), tz=dt.UTC).strftime("%Y-%m-%d %H:%M")
        except (TypeError, ValueError, OSError):
            return str(value)[:20]

    @staticmethod
    def _token_status(value: Any) -> str:
        try:
            status = int(value)
        except (TypeError, ValueError):
            return "未知"
        return {1: "启用", 2: "禁用", 3: "已过期", 4: "已耗尽"}.get(status, "未知")

    @staticmethod
    def _topup_status(value: Any) -> str:
        text = str(value or "").strip().lower()
        if text in {"1", "success", "succeeded", "completed", "paid"}:
            return "已到账"
        if text in {"0", "pending", "created", "processing"}:
            return "待支付"
        if text in {"2", "failed", "failure", "cancelled", "canceled", "expired"}:
            return "失败"
        return "未知"

    @staticmethod
    def _enabled_text(value: Any) -> str:
        return "已启用" if value is True else "未启用" if value is False else "未知"

    @staticmethod
    def _masked_ip(value: Any) -> str:
        text = str(value or "").strip()
        if not text:
            return "未知"
        if "." in text:
            parts = text.split(".")
            return f"{parts[0]}.{parts[1]}.*.*" if len(parts) == 4 and all(part.isdigit() for part in parts) else "已脱敏"
        if ":" in text:
            parts = [part for part in text.split(":") if part]
            return f"{parts[0]}:***:{parts[-1]}" if len(parts) >= 2 else "已脱敏"
        return "已脱敏"

    def _login_device_lines(self, user: dict[str, Any]) -> list[str]:
        devices: list[dict[str, Any]] = []
        for key in ("login_devices", "devices", "sessions"):
            value = user.get(key)
            if isinstance(value, list):
                devices = [item for item in value if isinstance(item, dict)]
                break
        if not devices:
            return ["登录设备：当前接口未提供"]
        lines = [f"登录设备：{len(devices)} 个"]
        for index, device in enumerate(devices[:3], start=1):
            ip = self._masked_ip(device.get("ip") or device.get("ip_address") or device.get("last_ip"))
            seen = device.get("last_seen") or device.get("last_active_at") or device.get("updated_at")
            lines.append(f"设备 {index}：IP {ip}，最近活动 {self._event_time(seen)}")
        return lines

    def _model_table(self, names: list[str]) -> list[str]:
        shown = names[:80]
        max_columns = max(1, min(3, int(self._cfg("model_table_max_columns"))))
        longest = max((len(name) for name in shown), default=1)
        columns = min(max_columns, len(shown), 3 if longest <= 30 else 2 if longest <= 50 else 1)
        lines = ["| " + " | ".join("模型" for _ in range(columns)) + " |", "|" + "---|" * columns]
        for offset in range(0, len(shown), columns):
            row = [_cell(name, 60) for name in shown[offset : offset + columns]]
            row.extend("" for _ in range(columns - len(row)))
            lines.append("| " + " | ".join(row) + " |")
        return lines

    # ---------- help ----------

    def _usage(self, command: str) -> str:
        usages = {
            "bind": "绑定教程：先在 New API 网页的个人设置 → 安全设置中创建系统访问令牌，再私聊发送：\n/na bind <系统访问令牌>\n示例：/na bind sk-你的系统访问令牌",
            "logsmodel": "按模型查询日志需要模型名称。\n用法：/na logsmodel <模型> [范围] [页码]\n示例：/na logsmodel gpt-4o today 1",
            "digest": "定时报表需要设置模式。\n日报：/na digest daily <HH:MM>\n周报：/na digest weekly <1-7> <HH:MM>\n示例：/na digest daily 09:00\n查看或关闭：/na digest status | /na digest off",
            "spendalert": "今日消费提醒需要正数阈值。\n用法：/na spendalert <阈值>\n示例：/na spendalert 10",
            "failalert": "连续失败提醒需要 2-100 的整数次数。\n用法：/na failalert <连续失败次数>\n示例：/na failalert 3",
            "tokenadd": "创建令牌需要一个不含空格的名称，分组可选。\n用法：/na tokenadd <名称> [分组]\n示例：/na tokenadd mytoken default",
            "tokenenable": "启用令牌需要唯一令牌名称。\n用法：/na tokenenable <名称>\n示例：/na tokenenable mytoken",
            "tokendisable": "禁用令牌需要唯一令牌名称。\n用法：/na tokendisable <名称>\n示例：/na tokendisable mytoken",
            "tokendelete": "删除令牌需要唯一令牌名称，并会返回二次确认码。\n用法：/na tokendelete <名称>\n示例：/na tokendelete mytoken",
            "tokenconfirm": "确认删除需要先执行 /na tokendelete <名称> 获取确认码。\n用法：/na tokenconfirm <确认码>\n示例：/na tokenconfirm 123456",
            "tokenalert": "令牌额度提醒需要唯一令牌名称和正数阈值。\n用法：/na tokenalert <名称> <阈值>\n示例：/na tokenalert mytoken 5",
            "tokenalertoff": "关闭令牌额度提醒需要唯一令牌名称。\n用法：/na tokenalertoff <名称>\n示例：/na tokenalertoff mytoken",
            "redeem": "兑换额度需要兑换码，且只能在私聊提交。\n用法：/na redeem <兑换码>\n示例：/na redeem 你的兑换码",
            "alert": "低余额提醒需要正数阈值。\n用法：/na alert <余额阈值>\n示例：/na alert 5",
            "calibrate": "管理员校准需要填写网页显示的正数余额。\n用法：/na calibrate <网页余额>\n示例：/na calibrate 12.5",
        }
        return usages[command]

    def _help(self, category: str = "") -> str:
        category = (category or "").strip().lower()
        aliases = {"账户": "account", "用量": "usage", "令牌": "token", "提醒": "alerts", "设置": "settings", "个人设置": "settings", "可选": "optional", "管理员": "admin"}
        category = aliases.get(category, category)
        sections = {
            "account": ("账户", ["/na bind <系统访问令牌>  — 私聊绑定或替换自己的令牌", "/na me  — 查看账户概览", "/na quota  — 查看余额与个人用量", "/na models [分组名称]  — 查看可用模型", "/na groups  — 查看当前用户分组", "/na unbind  — 清除自己的绑定"]),
            "usage": ("用量与报表", ["/na logs [today|yesterday|daybefore|3d|7d|30d] [页码]  — 调用记录", "/na logsmodel <模型> [范围] [页码]  — 按模型日志", "/na today / na stats <范围> / na week  — 用量总览和趋势", "/na modelstats [范围]  — 模型用量汇总", "/na report <today|week>  — 立即生成报表", "/na digest daily <HH:MM> / weekly <1-7> <HH:MM> / status / off  — 定时报表"]),
            "token": ("API 令牌", ["/na token [页码]  — 分页查看令牌摘要", "/na tokenadd <名称> [分组]  — 私聊创建无限额度令牌", "/na tokenenable <名称> / tokendisable <名称>  — 改变令牌状态", "/na tokendelete <名称> / tokenconfirm <确认码>  — 私聊二次确认删除", "/na tokenalert <名称> <阈值> / tokenalertoff <名称> / tokenalertstatus  — 额度提醒"]),
            "alerts": ("提醒", ["/na alert <余额阈值> / alertoff / alertstatus  — 低余额提醒", "/na spendalert <今日消费阈值> / spendalertoff / spendalertstatus  — 今日消费提醒", "/na failalert <连续失败次数> / failalertoff / failalertstatus / failcheck  — 按模型失败提醒", "/na alertcheck  — 立即检查所有主动提醒"]),
            "settings": ("个人设置", ["/na bind <系统访问令牌>  — 私聊绑定或替换账户", "/na digest daily|weekly ...  — 配置定时报表", "/na alert <阈值> / spendalert <阈值> / failalert <次数>  — 配置提醒", "/na tokenadd <名称> [分组] / tokenalert <名称> <阈值>  — 配置 API 令牌", "/na redeem <兑换码>  — 私聊兑换额度"]),
            "admin": ("管理员", ["/na diagnose  — 私聊检查功能、配置和只读接口状态", "/na calibrate <网页余额>  — 校准全局额度换算", "/na config [键] [值]  — 查看或修改插件配置"]),
        }
        optional = []
        if self._cfg("enable_topup_history"):
            optional.append("/na topups [页码]  — 私聊充值记录")
        if self._cfg("enable_checkin"):
            optional.extend(["/na checkin  — 私聊签到", "/na checkinstatus  — 私聊签到状态"])
        if self._cfg("enable_subscription"):
            optional.extend(["/na subscriptions  — 私聊我的订阅", "/na plans  — 查看订阅套餐"])
        if category == "optional":
            return "可选功能：\n" + ("\n".join(optional) if optional else "当前没有管理员启用的可选功能。")
        if category in sections:
            title, lines = sections[category]
            return f"{title}：\n" + "\n".join(lines) + "\n\n分类帮助：/na help account|usage|token|alerts|settings|optional|admin"
        lines = [
            f"{self._display('New API')} 用户中心（系统访问令牌）",
            "/na 或 /na menu [分类]  — QQ 官方卡片菜单（私聊和群聊）",
            "/na help [分类]  — 本完整清单；分类：account|usage|token|alerts|settings|optional|admin",
            "",
            "账户：",
            "/na bind <系统访问令牌>  — 私聊绑定自己的令牌",
            "/na me  — 查看我的账户",
            "/na quota  — 查看余额与个人用量",
            "/na models [分组名称]  — 查看可用模型",
            "/na groups  — 查看当前用户分组",
            "/na unbind  — 清除本人的绑定",
        ]
        if optional:
            lines.extend(["", "管理员启用的可选功能：", *optional])
        lines.extend([
            "",
            "用量与报表：",
            "/na logs [today|yesterday|daybefore|3d|7d|30d] [页码]  — 详细调用记录",
            "/na logsmodel <模型> [范围] [页码]  — 按模型查询",
            "/na today  — 今日用量总览",
            "/na stats [today|yesterday|daybefore|3d|7d|30d]  — 指定范围总览",
            "/na week  — 近 7 天趋势",
            "/na modelstats [today|yesterday|daybefore|3d|7d|30d]  — 模型用量汇总",
            "/na report <today|week>  — 立即生成日报或周报",
            "/na digest daily <HH:MM>  — 设置每日私聊报表",
            "/na digest weekly <1-7> <HH:MM>  — 设置每周私聊报表",
            "/na digest off|status  — 关闭或查看定时报表",
            "",
            "API 令牌：",
            "/na token [页码]  — 分页查看令牌摘要",
            "/na tokenadd <名称> [分组]  — 私聊创建无限额度令牌",
            "/na tokenenable <名称>  — 启用自己的令牌",
            "/na tokendisable <名称>  — 禁用自己的令牌",
            "/na tokendelete <名称>  — 申请删除并获取确认码",
            "/na tokenconfirm <确认码>  — 私聊确认删除",
            "/na tokenalert <名称> <阈值>  — API 令牌额度提醒",
            "/na tokenalertoff <名称>  — 关闭指定令牌提醒",
            "/na tokenalertstatus  — 查看 API 令牌提醒",
            "",
            "提醒：",
            "/na alert <余额阈值>  — 私聊启用低余额提醒",
            "/na alertoff  — 关闭低余额提醒",
            "/na alertstatus  — 查看提醒状态",
            "/na spendalert <今日消费阈值>  — 今日消费提醒",
            "/na spendalertoff  — 关闭今日消费提醒",
            "/na spendalertstatus  — 查看今日消费提醒",
            "/na failalert <连续失败次数>  — 按模型失败提醒",
            "/na failalertoff  — 关闭失败提醒",
            "/na failalertstatus  — 查看失败提醒",
            "/na failcheck  — 立即检查连续失败",
            "/na alertcheck  — 立即检查所有主动提醒",
            "/na redeem <兑换码>  — 私聊兑换额度",
            "",
            "管理员：",
            "/na calibrate <网页余额>  — 校准额度换算",
            "/na diagnose  — 检查功能、配置和只读接口状态",
            "/na config [键] [值]  — 查看或修改插件配置",
            "",
            "系统访问令牌：New API 网页 → 个人设置 → 安全设置生成。",
        ])
        return "\n".join(lines)

    # ---------- cards ----------

    def _menu_card(self, context: MessageContext, category: str = "") -> Card | None:
        if not self._cfg("enable_qq_cards"):
            return None
        category = (category or "").strip().lower()
        aliases = {"账户": "account", "用量": "usage", "令牌": "token", "提醒": "alerts", "设置": "settings", "个人设置": "settings", "可选": "optional", "管理员": "admin"}
        category = aliases.get(category, category)
        menus = {
            "account": ("账户", "账户与基础查询", [[_button("账户概览", "/na me"), _button("用量统计", "/na quota")], [_button("模型列表", "/na models"), _button("模型分组", "/na groups")], [_button("重新绑定", "/na bind "), _button("返回主菜单", "/na menu")]]),
            "usage": ("用量与报表", "查看调用、统计和定时报表", [[_button("今日日志", "/na logs today"), _button("今日统计", "/na today")], [_button("近7天趋势", "/na week"), _button("模型统计", "/na modelstats today")], [_button("定时报表", "/na digest status"), _button("返回主菜单", "/na menu")]]),
            "token": ("API 令牌", "令牌查询和私聊安全操作", [[_button("令牌列表", "/na token"), _button("额度提醒", "/na tokenalertstatus")], [_button("创建令牌", "/na tokenadd "), _button("删除令牌", "/na tokendelete ")], [_button("返回主菜单", "/na menu")]]),
            "alerts": ("提醒", "私聊配置账户和用量提醒", [[_button("低余额状态", "/na alertstatus"), _button("消费提醒", "/na spendalertstatus")], [_button("失败提醒", "/na failalertstatus"), _button("立即检查", "/na alertcheck")], [_button("返回主菜单", "/na menu")]]),
            "settings": ("个人设置", "填写参数以配置账户、报表、提醒和令牌", [[_button("绑定账户", "/na bind "), _button("定时报表", "/na digest ")], [_button("低余额提醒", "/na alert "), _button("消费提醒", "/na spendalert ")], [_button("失败提醒", "/na failalert "), _button("令牌提醒", "/na tokenalert ")], [_button("创建令牌", "/na tokenadd "), _button("兑换额度", "/na redeem ")], [_button("返回主菜单", "/na menu")]]),
            "admin": ("管理员", "管理员专用诊断与校准", [[_button("运行诊断", "/na diagnose"), _button("额度校准", "/na calibrate ")], [_button("查看配置", "/na config"), _button("返回主菜单", "/na menu")]]),
        }
        if category == "optional":
            rows: list[list[Button]] = [[_button("返回主菜单", "/na menu")]]
            if self._cfg("enable_topup_history"):
                rows.insert(0, [_button("充值记录", "/na topups 1")])
            if self._cfg("enable_checkin"):
                rows.insert(0, [_button("签到状态", "/na checkinstatus"), _button("立即签到", "/na checkin")])
            if self._cfg("enable_subscription"):
                rows.insert(0, [_button("我的订阅", "/na subscriptions"), _button("订阅套餐", "/na plans")])
            return Card("可选功能", _menu_markdown("可选功能", self._help("optional")), rows)
        if category in menus:
            title, text, rows = menus[category]
            return Card(title, _menu_markdown(title, text), rows)
        rows = [[_button("账户", "/na menu account"), _button("用量报表", "/na menu usage")], [_button("API令牌", "/na menu token"), _button("提醒", "/na menu alerts")], [_button("可选功能", "/na menu optional"), _button("管理员", "/na menu admin")], [_button("个人设置", "/na menu settings"), _button("完整帮助", "/na help")]]
        return Card(self._display("New API 用户中心"), _menu_markdown(
            self._display("New API 用户中心"),
            "选择功能分类。充值、签到、订阅和账户安全等隐私信息仅在私聊中展示。\n\n"
            "按钮会填入指令，确认后执行；完整指令清单见 /na help。",
        ), rows)

    def _result_card(self, title: str, result: str, page: int = 1, range_name: str = "") -> Card | None:
        if not self._cfg("enable_qq_cards"):
            return None
        rows: list[list[Button]] = []
        if title == "调用日志":
            previous = max(1, page - 1)
            suffix = f" {range_name}" if range_name else ""
            rows.append([
                _button("上一页", f"/na logs{suffix} {previous}"),
                _button("跳页", f"/na logs{suffix} "),
                _button("下一页", f"/na logs{suffix} {page + 1}"),
            ])
            rows.append([
                _button("今日日志", "/na logs today"),
                _button("用量菜单", "/na menu usage"),
            ])
        elif title == "充值记录":
            rows.append([
                _button("上一页", f"/na topups {max(1, page - 1)}"),
                _button("跳页", "/na topups "),
                _button("下一页", f"/na topups {page + 1}"),
            ])
            rows.append([
                _button("账户菜单", "/na menu account"),
            ])
        elif title == "API 令牌":
            rows.append([
                _button("上一页", f"/na token {max(1, page - 1)}"),
                _button("跳页", "/na token "),
                _button("下一页", f"/na token {page + 1}"),
            ])
            rows.append([
                _button("创建令牌", "/na tokenadd "),
                _button("账户菜单", "/na menu account"),
            ])
        elif title == "账户概览":
            rows.extend([[_button("用量统计", "/na quota"), _button("模型列表", "/na models")], [_button("API 令牌", "/na token"), _button("刷新概览", "/na me")], [_button("返回账户菜单", "/na menu account")]])
        elif title == "用量统计":
            rows.extend([[_button("今日统计", "/na today"), _button("近7天趋势", "/na week")], [_button("账户概览", "/na me"), _button("刷新统计", "/na quota")], [_button("返回账户菜单", "/na menu account")]])
        else:
            rows.append([_button("账户菜单", "/na menu"), _button("刷新", {"API 令牌": "/na token"}.get(title, "/na menu"))])
        return Card(title, _menu_markdown(title, self._display(result)), rows)

    # ---------- command entry ----------

    async def command(self, context: MessageContext, args: list[str]) -> str | Card:
        raw = (args[0] if args else "").strip()
        sub = SUBCOMMAND_ALIASES.get(raw.lower(), raw.lower())
        rest = args[1:]
        if not sub or sub in {"menu", "菜单"}:
            category = rest[0] if rest else ""
            return self._menu_card(context, category) or self._display(self._help(category))
        if sub == "help":
            return self._display(self._help(rest[0] if rest else ""))
        if sub == "bind":
            token = " ".join(rest).strip()
            if not token:
                return self._display(self._usage("bind"))
            if not self._is_private(context):
                return self._display("系统访问令牌只能通过私聊绑定。请私聊机器人执行 /na bind <令牌>。")
            return self._display(await self._bind(context, self._normalize_system_token(token)))
        if sub == "me":
            if remaining := self._limited(context, "me"):
                return self._display(f"查询过于频繁，请 {remaining} 秒后重试。")
            result = await self._me(context)
            return self._result_card("账户概览", result) or self._display(result)
        if sub == "topups":
            page = self._page_arg(rest)
            if remaining := self._limited(context, f"topups:{page}"):
                return self._display(f"查询过于频繁，请 {remaining} 秒后重试。")
            result = await self._topups(context, page)
            return self._result_card("充值记录", result, page) or self._display(result)
        if sub == "checkin":
            return self._display(await self._checkin(context))
        if sub == "checkinstatus":
            result = await self._checkin_status(context)
            return self._result_card("签到状态", result) or self._display(result)
        if sub == "subscriptions":
            result = await self._subscriptions(context)
            return self._result_card("我的订阅", result) or self._display(result)
        if sub == "plans":
            result = await self._subscription_plans(context)
            return self._result_card("订阅套餐", result) or self._display(result)
        if sub == "quota":
            if remaining := self._limited(context, "quota"):
                return self._display(f"查询过于频繁，请 {remaining} 秒后重试。")
            result = await self._quota(context)
            return self._result_card("用量统计", result) or self._display(result)
        if sub == "models":
            group = (rest[0] if rest else "").strip()
            if remaining := self._limited(context, f"models:{group}"):
                return self._display(f"查询过于频繁，请 {remaining} 秒后重试。")
            result = await self._models(context, group)
            return self._result_card("可用模型", result) or self._display(result)
        if sub == "groups":
            if remaining := self._limited(context, "groups"):
                return self._display(f"查询过于频繁，请 {remaining} 秒后重试。")
            result = await self._groups(context)
            return self._result_card("模型分组", result) or self._display(result)
        if sub in {"logs", "logsmodel"}:
            if sub == "logsmodel" and not (rest and rest[0].strip()):
                return self._display(self._usage("logsmodel"))
            model = (rest[0].strip() if sub == "logsmodel" else "")
            tail = rest[1:] if sub == "logsmodel" else rest
            range_name = (tail[0] if tail else "").strip().lower()
            page = 1
            if range_name.isdigit() and len(tail) < 2:
                page, range_name = int(range_name), ""
            elif len(tail) >= 2 and tail[1].strip().isdigit():
                page = int(tail[1])
            if remaining := self._limited(context, f"{sub}:{model}:{range_name}:{page}"):
                return self._display(f"查询过于频繁，请 {remaining} 秒后重试。")
            result = await self._logs(context, range_name, page, model)
            title = "模型调用日志" if sub == "logsmodel" else "调用日志"
            return self._result_card(title, result, page, range_name) or self._display(result)
        if sub == "today":
            if remaining := self._limited(context, "today"):
                return self._display(f"查询过于频繁，请 {remaining} 秒后重试。")
            result = await self._usage_summary(context, "today")
            return self._result_card("今日用量", result) or self._display(result)
        if sub == "stats":
            range_name = (rest[0] if rest else "today").strip().lower() or "today"
            if remaining := self._limited(context, f"stats:{range_name}"):
                return self._display(f"查询过于频繁，请 {remaining} 秒后重试。")
            result = await self._usage_summary(context, range_name)
            return self._result_card("用量统计", result) or self._display(result)
        if sub == "week":
            if remaining := self._limited(context, "week"):
                return self._display(f"查询过于频繁，请 {remaining} 秒后重试。")
            result = await self._week_summary(context)
            return self._result_card("近 7 天趋势", result) or self._display(result)
        if sub == "modelstats":
            range_name = (rest[0] if rest else "today").strip().lower() or "today"
            if remaining := self._limited(context, f"modelstats:{range_name}"):
                return self._display(f"查询过于频繁，请 {remaining} 秒后重试。")
            result = await self._model_stats(context, range_name)
            return self._result_card("模型用量统计", result) or self._display(result)
        if sub == "report":
            period = (rest[0] if rest else "today").strip().lower()
            if period in {"today", "今天"}:
                return self._display(await self._usage_summary(context, "today"))
            if period in {"week", "weekly", "周", "本周"}:
                return self._display(await self._week_summary(context))
            return "报表范围只支持 today 或 week。"
        if sub == "digest":
            mode = rest[0] if rest else ""
            value = rest[1] if len(rest) > 1 else ""
            send_time = rest[2] if len(rest) > 2 else ""
            if not str(mode).strip():
                return self._display(self._usage("digest"))
            return self._display(self._digest_config(context, str(mode), str(value), str(send_time)))
        if sub == "spendalert":
            number = self._positive_number(" ".join(rest))
            if number is None:
                return self._display(self._usage("spendalert"))
            return self._display(self._spend_alert_enable(context, number))
        if sub == "spendalertoff":
            return self._display(self._rule_disable(context, "spend_alert", "今日消费提醒"))
        if sub == "spendalertstatus":
            return self._display(self._spend_alert_status(context))
        if sub == "failalert":
            threshold = " ".join(rest).strip()
            try:
                count = int(threshold)
            except (TypeError, ValueError):
                count = 0
            if str(count) != threshold or not 2 <= count <= 100:
                return self._display(self._usage("failalert"))
            return self._display(self._fail_alert_enable(context, count))
        if sub == "failalertoff":
            return self._display(self._rule_disable(context, "failure_alert", "连续失败提醒"))
        if sub == "failalertstatus":
            return self._display(self._fail_alert_status(context))
        if sub == "failcheck":
            return self._display(await self._failure_check_text(context))
        if sub == "alertcheck":
            return self._display(await self._manual_alert_check(context))
        if sub == "token":
            page = max(1, self._page_arg(rest))
            if remaining := self._limited(context, f"tokens:{page}"):
                return self._display(f"查询过于频繁，请 {remaining} 秒后重试。")
            result = await self._tokens(context, page)
            return self._result_card("API 令牌", result, page) or self._display(result)
        if sub == "tokenadd":
            name = rest[0] if rest else ""
            group = rest[1] if len(rest) > 1 else ""
            if not str(name).strip():
                return self._display(self._usage("tokenadd"))
            return self._display(await self._token_add(context, str(name), str(group)))
        if sub == "tokenenable":
            name = " ".join(rest)
            if not name.strip():
                return self._display(self._usage("tokenenable"))
            return self._display(await self._token_status_change(context, name, 1))
        if sub == "tokendisable":
            name = " ".join(rest)
            if not name.strip():
                return self._display(self._usage("tokendisable"))
            return self._display(await self._token_status_change(context, name, 2))
        if sub == "tokendelete":
            name = " ".join(rest)
            if not name.strip():
                return self._display(self._usage("tokendelete"))
            return self._display(await self._token_delete_prepare(context, name))
        if sub == "tokenconfirm":
            code = " ".join(rest)
            if not code.strip():
                return self._display(self._usage("tokenconfirm"))
            return self._display(await self._token_delete_confirm(context, code))
        if sub == "tokenalert":
            name = rest[0] if rest else ""
            number = self._positive_number(rest[1] if len(rest) > 1 else "")
            if not str(name).strip() or number is None:
                return self._display(self._usage("tokenalert"))
            return self._display(await self._token_alert_enable(context, str(name), number))
        if sub == "tokenalertoff":
            name = " ".join(rest)
            if not name.strip():
                return self._display(self._usage("tokenalertoff"))
            return self._display(self._token_alert_disable(context, name))
        if sub == "tokenalertstatus":
            return self._display(self._token_alert_status(context))
        if sub == "redeem":
            redemption = " ".join(rest)
            if not redemption.strip():
                return self._display(self._usage("redeem"))
            return self._display(await self._redeem(context, redemption))
        if sub == "alert":
            number = self._positive_number(" ".join(rest))
            if number is None:
                return self._display(self._usage("alert"))
            return self._display(self._alert_enable(context, number))
        if sub == "alertoff":
            return self._display(self._alert_disable(context))
        if sub == "alertstatus":
            return self._display(self._alert_status(context))
        if sub == "calibrate":
            number = self._positive_number(" ".join(rest))
            if number is None:
                return self._display(self._usage("calibrate"))
            return self._display(await self._calibrate(context, number))
        if sub == "diagnose":
            if remaining := self._limited(context, "diagnose"):
                return self._display(f"查询过于频繁，请 {remaining} 秒后重试。")
            return self._display(await self._diagnose(context))
        if sub == "unbind":
            return self._display(self._unbind(context))
        if sub == "config":
            return await self._config_command(context, rest)
        return self._display(self._help())

    @staticmethod
    def _page_arg(rest: list[str]) -> int:
        try:
            return int(rest[0]) if rest else 1
        except (TypeError, ValueError):
            return 1

    # ---------- account commands ----------

    async def _bind(self, context: MessageContext, token: str) -> str:
        if not self._valid_system_token(token):
            return "没有读取到有效令牌。用法：/na bind <系统访问令牌>"
        if not self._base_url():
            return "插件尚未配置 New API 地址，请联系管理员使用 /na config newapi_base_url <地址>。"
        account: dict[str, Any] = {"token": token, "created_at": int(time.time())}
        try:
            response = await self._request(account, "GET", "/api/user/self")
        except httpx.HTTPError:
            return self._network_error()
        data = self._json(response)
        if response.status_code >= 400:
            return f"系统访问令牌验证失败：{self._message(data)}"
        user = self._payload(data)
        account["user_id"] = user.get("id") or user.get("user_id")
        account["username"] = user.get("username") or user.get("display_name") or "未知用户"
        account["notify"] = self._notify_ref(context)
        self.accounts[self._user_key(context)] = account
        self._save()
        self._clear_user_cache(context)
        return f"绑定成功：{account['username']}（系统访问令牌 {self._short_token(token)}）。"

    async def _get_for_user(self, context: MessageContext, path: str, **kwargs: Any) -> tuple[dict[str, Any] | None, httpx.Response | None]:
        account = self.accounts.get(self._user_key(context))
        if not account:
            return None, None
        try:
            return account, await self._request(account, "GET", path, **kwargs)
        except httpx.HTTPError:
            return account, None

    async def _me(self, context: MessageContext) -> str:
        account = self.accounts.get(self._user_key(context))
        if not account:
            return "你还没有绑定。私聊发送 /na bind <系统访问令牌>。"
        try:
            response = await self._request(account, "GET", "/api/user/self")
        except httpx.HTTPError:
            return self._network_error()
        if response.status_code in {401, 403}:
            return "系统访问令牌已失效，请重新 /na bind <令牌>。"
        data = self._payload(self._json(response))
        if response.status_code >= 400:
            return f"查询失败：{self._message(data)}"
        values = [
            ("用户", data.get("username") or data.get("display_name") or account.get("username", "未知")),
            ("用户编号", data.get("id") or data.get("user_id") or account.get("user_id", "未知")),
            ("用户分组", data.get("group") or data.get("group_name") or "未知"),
            ("可用余额", self._quota_value(data.get("quota") if data.get("quota") is not None else data.get("balance"))),
        ]
        lines = ["| 项目 | 内容 |", "|---|---|", *(f"| {name} | {_cell(value, 80)} |" for name, value in values)]
        if self._is_private(context) and self._cfg("enable_account_security"):
            (passkey, passkey_error), (two_factor, two_factor_error) = await asyncio.gather(
                self._security_status(account, "/api/user/passkey"),
                self._security_status(account, "/api/user/2fa/status"),
            )
            security = [("系统访问令牌", self._short_token(account["token"])), ("Passkey", self._enabled_text(passkey.get("enabled")) if not passkey_error else "查询失败"), ("双重验证", (self._enabled_text(two_factor.get("enabled")) if not two_factor_error else "查询失败") + ("（已锁定）" if two_factor.get("locked") else ""))]
            lines.extend(f"| {name} | {value} |" for name, value in security)
            lines.extend(["", *self._login_device_lines(data)])
        return "\n".join(lines)

    async def _security_status(self, account: dict[str, Any], path: str) -> tuple[dict[str, Any], str]:
        try:
            response = await self._request(account, "GET", path)
        except httpx.HTTPError:
            return {}, self._network_error()
        data = self._json(response)
        if response.status_code >= 400 or (isinstance(data, dict) and data.get("success") is False):
            return {}, self._message(data)
        return self._payload(data), ""

    async def _topups(self, context: MessageContext, page: int) -> str:
        if not self._cfg("enable_topup_history"):
            return "充值记录功能未由管理员启用。"
        if not self._is_private(context):
            return "充值记录只能在私聊中查看。"
        account = self.accounts.get(self._user_key(context))
        if not account:
            return "你还没有绑定。私聊发送 /na bind <系统访问令牌>。"
        page = max(1, page)
        try:
            response = await self._request(account, "GET", "/api/user/topup/self", params={"p": page, "page_size": 10})
        except httpx.HTTPError:
            return self._network_error()
        raw = self._json(response)
        if response.status_code >= 400 or (isinstance(raw, dict) and raw.get("success") is False):
            return f"查询充值记录失败：{self._message(raw)}"
        payload = self._payload(raw)
        items = [item for item in self._items(raw) if isinstance(item, dict)]
        if not items:
            return "当前没有充值记录。"
        lines = ["充值记录：", "", "| 时间 | 支付金额 | 状态 |", "|---|---:|---|"]
        for item in items[:10]:
            timestamp = item.get("created_at") or item.get("create_time") or item.get("created_time") or item.get("time")
            amount = item.get("money") if item.get("money") is not None else item.get("amount")
            status = item.get("status") if item.get("status") is not None else item.get("state")
            lines.append(f"| {_cell(self._event_time(timestamp), 20)} | {_cell(amount if amount is not None else '无数据', 16)} | {self._topup_status(status)} |")
        try:
            total = int(payload.get("total") or 0)
        except (TypeError, ValueError):
            total = 0
        if total:
            pages = max(1, (total + 9) // 10)
            lines.extend(["", f"第 {page}/{pages} 页，共 {total} 条。"])
        lines.extend(["", "> 充值记录接口不返回到账额度。待支付表示支付尚未完成；已到账表示该笔充值已成功记入账户。"])
        return "\n".join(lines)

    async def _checkin_data(self, context: MessageContext, method: str) -> tuple[dict[str, Any], str]:
        if not self._cfg("enable_checkin"):
            return {}, "签到功能未由管理员启用。"
        if not self._is_private(context):
            return {}, "签到功能只能在私聊中使用。"
        account = self.accounts.get(self._user_key(context))
        if not account:
            return {}, "你还没有绑定。私聊发送 /na bind <系统访问令牌>。"
        try:
            response = await self._request(account, method, "/api/user/checkin")
        except httpx.HTTPError:
            return {}, self._network_error()
        raw = self._json(response)
        if response.status_code >= 400 or (isinstance(raw, dict) and raw.get("success") is False):
            return {}, self._message(raw)
        return self._payload(raw), ""

    async def _checkin(self, context: MessageContext) -> str:
        data, error = await self._checkin_data(context, "POST")
        if error:
            return f"签到失败：{error}"
        return "\n".join([
            "签到成功。",
            f"签到日期：{data.get('checkin_date') or '未知'}",
            f"获得额度：{self._quota_value(data.get('quota_awarded'))}",
        ])

    async def _checkin_status(self, context: MessageContext) -> str:
        data, error = await self._checkin_data(context, "GET")
        if error:
            return f"签到状态查询失败：{error}"
        stats = data.get("stats") if isinstance(data.get("stats"), dict) else {}
        return "\n".join([
            "签到状态：",
            f"今日已签到：{'是' if stats.get('checked_in_today') else '否'}",
            f"本月签到：{int(stats.get('checkin_count') or 0)} 次",
            f"累计签到：{int(stats.get('total_checkins') or 0)} 次",
            f"累计奖励：{self._quota_value(stats.get('total_quota'))}",
            f"单次奖励范围：{self._quota_value(data.get('min_quota'))} - {self._quota_value(data.get('max_quota'))}",
        ])

    async def _subscription_response(self, context: MessageContext, path: str) -> tuple[Any, str]:
        if not self._cfg("enable_subscription"):
            return {}, "订阅功能未由管理员启用。"
        account = self.accounts.get(self._user_key(context))
        if not account:
            return {}, "你还没有绑定。私聊发送 /na bind <系统访问令牌>。"
        try:
            response = await self._request(account, "GET", path)
        except httpx.HTTPError:
            return {}, self._network_error()
        raw = self._json(response)
        if response.status_code >= 400 or (isinstance(raw, dict) and raw.get("success") is False):
            return {}, self._message(raw)
        return raw.get("data") if isinstance(raw, dict) else raw, ""

    @staticmethod
    def _duration_text(plan: dict[str, Any]) -> str:
        value = int(plan.get("duration_value") or 0)
        unit = {"year": "年", "month": "个月", "day": "天", "hour": "小时"}.get(str(plan.get("duration_unit") or ""), "")
        return f"{value}{unit}" if value and unit else "自定义"

    async def _subscription_plans(self, context: MessageContext) -> str:
        data, error = await self._subscription_response(context, "/api/subscription/plans")
        if error:
            return f"订阅套餐查询失败：{error}"
        items = data if isinstance(data, list) else []
        plans = [item.get("plan") for item in items if isinstance(item, dict) and isinstance(item.get("plan"), dict)]
        if not plans:
            return "当前没有可用订阅套餐。"
        lines = ["可用订阅套餐：", "", "| 套餐 | 价格 | 有效期 | 总额度 |", "|---|---:|---:|---:|"]
        for plan in plans[:30]:
            currency = str(plan.get("currency") or "USD")
            price = float(plan.get("price_amount") or 0)
            total = "不限" if not int(plan.get("total_amount") or 0) else self._quota_value(plan.get("total_amount"))
            lines.append(f"| {_cell(plan.get('title') or '未命名', 36)} | {price:.2f} {_cell(currency, 8)} | {self._duration_text(plan)} | {total} |")
        return "\n".join(lines)

    async def _subscriptions(self, context: MessageContext) -> str:
        if not self._cfg("enable_subscription"):
            return "订阅功能未由管理员启用。"
        if not self._is_private(context):
            return "个人订阅只能在私聊中查看。"
        self_result, plans_result = await asyncio.gather(
            self._subscription_response(context, "/api/subscription/self"),
            self._subscription_response(context, "/api/subscription/plans"),
        )
        data, error = self_result
        plans_data, plans_error = plans_result
        if error:
            return f"订阅查询失败：{error}"
        subscriptions = data.get("all_subscriptions") if isinstance(data, dict) else []
        if not isinstance(subscriptions, list) or not subscriptions:
            return "当前没有订阅。"
        plan_names: dict[str, str] = {}
        if not plans_error and isinstance(plans_data, list):
            for item in plans_data:
                plan = item.get("plan") if isinstance(item, dict) else None
                if isinstance(plan, dict) and plan.get("id") is not None:
                    plan_names[str(plan["id"])] = str(plan.get("title") or "未知套餐")
        lines = ["我的订阅：", "", "| 套餐 | 状态 | 剩余额度 | 到期时间 |", "|---|---|---:|---|"]
        for item in subscriptions[:30]:
            sub = item.get("subscription") if isinstance(item, dict) else None
            if not isinstance(sub, dict):
                continue
            total = int(sub.get("amount_total") or 0)
            used = int(sub.get("amount_used") or 0)
            remaining = "不限" if total <= 0 else self._quota_value(max(0, total - used))
            status = {"active": "生效中", "expired": "已过期", "cancelled": "已取消"}.get(str(sub.get("status") or ""), "未知")
            lines.append(f"| {_cell(plan_names.get(str(sub.get('plan_id')), '未知套餐'), 36)} | {status} | {remaining} | {self._event_time(sub.get('end_time'))} |")
        return "\n".join(lines) if len(lines) > 4 else "当前没有订阅。"

    async def _quota(self, context: MessageContext) -> str:
        account, response = await self._get_for_user(context, "/api/log/self/stat")
        if not account:
            return "你还没有绑定。私聊发送 /na bind <系统访问令牌>。"
        if response is None:
            return self._network_error()
        data = self._payload(self._json(response))
        if response.status_code >= 400:
            return f"查询用量失败：{self._message(data)}"
        values = data.get("data") if isinstance(data.get("data"), dict) else data
        if not isinstance(values, dict):
            values = {}
        quota = values.get("quota", values.get("total_quota", values.get("used_quota")))
        rpm = values.get("rpm", "未知")
        tpm = values.get("tpm", "未知")
        return "\n".join([
            "| 项目 | 数值 |",
            "|---|---:|",
            f"| 消耗额度 | {self._quota_value(quota)} |",
            f"| 当前请求速率 | {rpm} RPM |",
            f"| 当前 Token 速率 | {tpm} TPM |",
            "",
            "> RPM 和 TPM 是查询瞬间的实时速率；没有正在处理的请求时可能为 0。此接口不返回成功或失败次数，详细调用情况请查看今日统计或近 7 天趋势。",
        ])

    async def _models(self, context: MessageContext, group: str = "") -> str:
        cache_name = f"models:{group}" if group else "models"
        if cached := self._cached(context, cache_name):
            return cached
        params = {"group": group} if group else None
        account, response = await self._get_for_user(context, "/api/user/models", params=params)
        if not account:
            return "你还没有绑定。私聊发送 /na bind <系统访问令牌>。"
        if response is None:
            return self._network_error()
        data = self._json(response)
        if response.status_code >= 400:
            return f"查询模型失败：{self._message(data)}"
        names = self._model_names(data)
        if not names:
            return "当前没有返回可用模型。"
        title = f"分组 `{_cell(group, 40)}` 的可用模型：" if group else "可用模型："
        lines = [title, "", *self._model_table(names)]
        if len(names) > 80:
            lines.extend(["", f"仅显示前 80 个，共 {len(names)} 个模型。"])
        return self._set_cached(context, cache_name, "\n".join(lines))

    async def _groups(self, context: MessageContext) -> str:
        if cached := self._cached(context, "groups"):
            return cached
        account, response = await self._get_for_user(context, "/api/user/self/groups")
        if not account:
            return "你还没有绑定。私聊发送 /na bind <系统访问令牌>。"
        if response is None:
            return self._network_error()
        data = self._json(response)
        if response.status_code >= 400:
            return f"查询分组失败：{self._message(data)}"
        groups = self._items(data)
        group_names = []
        for group in groups:
            name = group.get("name") or group.get("group") or group.get("id") if isinstance(group, dict) else str(group)
            if name and str(name) not in group_names:
                group_names.append(str(name))
        if not group_names:
            group_names = [str(key) for key, _ in self._mapping_items(data)]
        if not group_names:
            return "当前没有返回用户分组。"
        selected = group_names[:40]
        semaphore = asyncio.Semaphore(self._group_concurrency())

        async def query(group: str) -> tuple[str, str, list[str]]:
            async with semaphore:
                _, group_response = await self._get_for_user(context, "/api/user/models", params={"group": group})
            if group_response is None:
                return group, "连接失败", []
            if group_response.status_code >= 400:
                return group, f"HTTP {group_response.status_code}", []
            names = self._model_names(self._json(group_response))
            return group, "正常" if names else "无可用模型", names

        results = await asyncio.gather(*(query(group) for group in selected))
        lines = ["可用模型分组：", "", "| 分组 | 状态 | 可用模型 |", "|---|---|---|"]
        for group, status, model_names in results:
            models_text = ", ".join(model_names[:30]) if model_names else "-"
            lines.append(f"| {_cell(group, 24)} | {status} | {_cell(models_text, 240)} |")
        if len(group_names) > 40:
            lines.extend(["", f"仅显示前 40 个分组，共 {len(group_names)} 个。"])
        return self._set_cached(context, "groups", "\n".join(lines))

    # ---------- tokens ----------

    async def _tokens(self, context: MessageContext, page: int = 1) -> str:
        cache_name = f"tokens:{page}"
        if cached := self._cached(context, cache_name):
            return cached
        account = self.accounts.get(self._user_key(context))
        if not account:
            return "你还没有绑定。私聊发送 /na bind <系统访问令牌>。"
        try:
            response = await self._request(account, "GET", "/api/token/", params={"p": page, "page_size": 10})
        except httpx.HTTPError:
            return self._network_error()
        data = self._json(response)
        if response.status_code >= 400:
            return f"查询 API 令牌失败：{self._message(data)}"
        items = [item for item in self._items(data) if isinstance(item, dict)]
        if not items:
            return "当前没有 API 令牌。"
        fields = [
            ("状态", lambda item: self._token_status(item.get("status"))),
            ("已使用额度", lambda item: self._quota_value(item.get("used_quota"))),
            ("剩余额度", lambda item: "不限" if item.get("unlimited_quota") else self._quota_value(item.get("remain_quota"))),
            ("分组", lambda item: item.get("group") or "默认"),
            ("过期时间", lambda item: self._time_value(item.get("expired_time"))),
        ]
        active_fields = [(title, getter) for title, getter in fields if any(getter(item) not in {"未知", "默认"} for item in items if isinstance(item, dict))]
        lines = ["我的 API 令牌：", "", "| 名称 | " + " | ".join(title for title, _ in active_fields) + " |", "|---|" + "---|" * len(active_fields)]
        for item in items:
            values = [_cell(getter(item), 32) for _, getter in active_fields]
            lines.append("| " + " | ".join([_cell(item.get("name") or "未命名", 24), *values]) + " |")
        payload = self._payload(data)
        try:
            total = int(payload.get("total") or data.get("total") or 0) if isinstance(payload, dict) else 0
        except (TypeError, ValueError):
            total = 0
        if total:
            pages = max(1, (total + 9) // 10)
            lines.extend(["", f"第 {page}/{pages} 页，共 {total} 个令牌。"])
        return self._set_cached(context, cache_name, "\n".join(lines))

    async def _token_items(self, context: MessageContext) -> tuple[dict[str, Any] | None, list[dict[str, Any]], str]:
        account = self.accounts.get(self._user_key(context))
        if not account:
            return None, [], "你还没有绑定。私聊发送 /na bind <系统访问令牌>。"
        try:
            response = await self._request(account, "GET", "/api/token/", params={"p": 1, "page_size": 100})
        except httpx.HTTPError:
            return account, [], self._network_error()
        data = self._json(response)
        if response.status_code >= 400 or (isinstance(data, dict) and data.get("success") is False):
            return account, [], f"查询 API 令牌失败：{self._message(data)}"
        return account, [item for item in self._items(data) if isinstance(item, dict)], ""

    async def _token_by_name(self, context: MessageContext, name: str) -> tuple[dict[str, Any] | None, dict[str, Any] | None, str]:
        account, items, error = await self._token_items(context)
        if error:
            return account, None, error
        matches = [item for item in items if str(item.get("name") or "").casefold() == name.casefold()]
        if not matches:
            return account, None, f"没有找到名称为 `{_cell(name, 40)}` 的 API 令牌。"
        if len(matches) > 1:
            return account, None, "存在多个同名令牌，无法安全操作。请先在 New API 网页修改为唯一名称。"
        return account, matches[0], ""

    async def _account_token_items(self, account: dict[str, Any]) -> tuple[list[dict[str, Any]], str]:
        collected: list[dict[str, Any]] = []
        page = 1
        while len(collected) < 1000:
            try:
                response = await self._request(account, "GET", "/api/token/", params={"p": page, "page_size": 100})
            except httpx.HTTPError:
                return [], self._network_error()
            data = self._json(response)
            if response.status_code >= 400 or (isinstance(data, dict) and data.get("success") is False):
                return [], self._message(data)
            items = [item for item in self._items(data) if isinstance(item, dict)]
            collected.extend(items)
            payload = self._payload(data)
            try:
                total = int(payload.get("total") or data.get("total") or 0) if isinstance(payload, dict) else 0
            except (TypeError, ValueError):
                total = 0
            if not items or len(items) < 100 or (total and len(collected) >= total):
                break
            page += 1
        return collected[:1000], ""

    async def _token_add(self, context: MessageContext, name: str, group: str) -> str:
        if not self._is_private(context):
            return "创建 API 令牌只能在私聊中执行。"
        name = name.strip()
        group = group.strip()
        if not name or len(name) > 50 or " " in name:
            return "令牌名称长度必须为 1-50 个字符，且不能包含空格。"
        account, items, error = await self._token_items(context)
        if error:
            return error
        if any(str(item.get("name") or "").casefold() == name.casefold() for item in items):
            return "已存在同名令牌，请使用其他名称。"
        payload = {
            "name": name,
            "expired_time": -1,
            "remain_quota": 0,
            "unlimited_quota": True,
            "model_limits_enabled": False,
            "model_limits": "",
            "group": group,
        }
        try:
            response = await self._request(account, "POST", "/api/token/", json=payload)
        except httpx.HTTPError:
            return self._network_error()
        data = self._json(response)
        if response.status_code >= 400 or (isinstance(data, dict) and data.get("success") is False):
            return f"创建 API 令牌失败：{self._message(data)}"
        _, created, error = await self._token_by_name(context, name)
        if error or not created or not created.get("id"):
            self._clear_user_cache(context)
            return "令牌已创建，但无法读取完整 Key。请前往 New API 网页查看。"
        try:
            key_response = await self._request(account, "POST", f"/api/token/{int(created['id'])}/key")
        except (httpx.HTTPError, TypeError, ValueError):
            self._clear_user_cache(context)
            return "令牌已创建，但读取完整 Key 失败。请前往 New API 网页查看。"
        key_data = self._json(key_response)
        key_payload = self._payload(key_data)
        key = key_payload.get("key") if isinstance(key_payload, dict) else None
        self._clear_user_cache(context)
        if key_response.status_code >= 400 or not key:
            return "令牌已创建，但读取完整 Key 失败。请前往 New API 网页查看。"
        full_key = str(key)
        if not full_key.startswith("sk-"):
            full_key = f"sk-{full_key}"
        return f"API 令牌创建成功。完整 Key 仅显示本次，请立即保存：\n{full_key}"

    async def _token_status_change(self, context: MessageContext, name: str, status: int) -> str:
        if not self._is_private(context):
            return "启用或禁用 API 令牌只能在私聊中执行。"
        account, token, error = await self._token_by_name(context, name.strip())
        if error:
            return error
        payload = {"id": token.get("id"), "status": status}
        try:
            response = await self._request(account, "PUT", "/api/token/", params={"status_only": "true"}, json=payload)
        except httpx.HTTPError:
            return self._network_error()
        data = self._json(response)
        if response.status_code >= 400 or (isinstance(data, dict) and data.get("success") is False):
            return f"更新 API 令牌失败：{self._message(data)}"
        self._clear_user_cache(context)
        return f"已{('启用' if status == 1 else '禁用')} API 令牌 `{_cell(name, 40)}`。"

    async def _token_delete_prepare(self, context: MessageContext, name: str) -> str:
        if not self._is_private(context):
            return "删除 API 令牌只能在私聊中执行。"
        _, token, error = await self._token_by_name(context, name.strip())
        if error:
            return error
        code = secrets.token_hex(3).upper()
        ttl = max(30, min(600, int(self._cfg("delete_confirm_ttl_sec")) or 120))
        user_key = self._user_key(context)
        self.pending_actions[user_key] = (time.monotonic() + ttl, int(token["id"]), str(token.get("name") or name))
        self.pending_codes[user_key] = code
        return f"即将删除 API 令牌 `{_cell(token.get('name') or name, 40)}`。{ttl} 秒内私聊发送：/na tokenconfirm {code}"

    async def _token_delete_confirm(self, context: MessageContext, code: str) -> str:
        if not self._is_private(context):
            return "删除确认只能在私聊中执行。"
        key = self._user_key(context)
        pending = self.pending_actions.get(key)
        if not pending or pending[0] <= time.monotonic():
            self.pending_actions.pop(key, None)
            self.pending_codes.pop(key, None)
            return "没有待确认的删除操作，或确认已过期。"
        expected_code = self.pending_codes.get(key)
        if not expected_code or not secrets.compare_digest(expected_code, code.strip().upper()):
            return "确认码错误。"
        expires_at, token_id, name = pending
        account = self.accounts.get(key)
        if not account:
            return "绑定已被清除，请重新绑定后再操作。"
        try:
            response = await self._request(account, "DELETE", f"/api/token/{token_id}")
        except httpx.HTTPError:
            remaining = max(1, int(expires_at - time.monotonic() + 0.999))
            return f"{self._network_error()} 删除尚未执行，确认码仍有效，可在 {remaining} 秒内重试。"
        data = self._json(response)
        if response.status_code >= 400 or (isinstance(data, dict) and data.get("success") is False):
            remaining = max(1, int(expires_at - time.monotonic() + 0.999))
            return f"删除 API 令牌失败：{self._message(data)}。确认码仍有效，可在 {remaining} 秒内重试。"
        self.pending_actions.pop(key, None)
        self.pending_codes.pop(key, None)
        alerts = account.get("token_alerts") if isinstance(account.get("token_alerts"), dict) else {}
        alerts.pop(str(token_id), None)
        self._clear_user_cache(context)
        self._save()
        return f"已删除 API 令牌 `{_cell(name, 40)}`。"

    async def _token_alert_enable(self, context: MessageContext, name: str, threshold: float) -> str:
        account, error = self._private_rule_account(context)
        if error:
            return error
        if not math.isfinite(threshold) or threshold <= 0:
            return "API 令牌额度阈值必须大于 0。"
        _, token, error = await self._token_by_name(context, name.strip())
        if error:
            return error
        if token.get("unlimited_quota"):
            return "无限额度 API 令牌不需要额度提醒。"
        try:
            token_id = str(int(token["id"]))
            remaining = float(token.get("remain_quota") or 0)
        except (KeyError, TypeError, ValueError):
            return "该 API 令牌缺少可用的额度信息，无法设置提醒。"
        if not math.isfinite(remaining):
            return "该 API 令牌缺少可用的额度信息，无法设置提醒。"
        alerts = account.setdefault("token_alerts", {})
        alerts[token_id] = {
            "name": str(token.get("name") or name),
            "threshold": float(threshold),
            "below": False,
            "last_alert_at": 0,
        }
        self._save()
        return f"API 令牌额度提醒已启用：`{_cell(token.get('name') or name, 40)}` 低于 {threshold:.6f} 时私聊提醒。当前剩余 {self._quota_value(remaining)}。"

    def _token_alert_disable(self, context: MessageContext, name: str) -> str:
        if not self._is_private(context):
            return "API 令牌额度提醒只能在私聊中配置。"
        account = self.accounts.get(self._user_key(context))
        alerts = account.get("token_alerts") if account else None
        if not isinstance(alerts, dict):
            return "当前没有启用 API 令牌额度提醒。"
        matches = [token_id for token_id, rule in alerts.items() if isinstance(rule, dict) and str(rule.get("name") or "").casefold() == name.strip().casefold()]
        if not matches:
            return f"没有找到 API 令牌 `{_cell(name, 40)}` 的额度提醒。"
        for token_id in matches:
            alerts.pop(token_id, None)
        self._save()
        return f"已关闭 API 令牌 `{_cell(name, 40)}` 的额度提醒。"

    def _token_alert_status(self, context: MessageContext) -> str:
        if not self._is_private(context):
            return "API 令牌额度提醒状态只能在私聊中查看。"
        account = self.accounts.get(self._user_key(context))
        alerts = account.get("token_alerts") if account else None
        rules = [rule for rule in alerts.values() if isinstance(rule, dict)] if isinstance(alerts, dict) else []
        if not rules:
            return "API 令牌额度提醒：关闭"
        lines = ["API 令牌额度提醒：", "", "| 令牌名称 | 阈值 | 当前低额度 |", "|---|---:|---|"]
        for rule in sorted(rules, key=lambda item: str(item.get("name") or "").casefold())[:50]:
            try:
                threshold = float(rule.get("threshold") or 0)
            except (TypeError, ValueError):
                threshold = 0
            lines.append(f"| {_cell(rule.get('name') or '未命名', 32)} | {threshold:.6f} | {'是' if rule.get('below') else '否'} |")
        return "\n".join(lines)

    # ---------- redeem / alerts ----------

    @staticmethod
    def _raw_balance(data: Any) -> float | None:
        payload = NewApiPlugin._payload(data)
        value = payload.get("quota") if payload.get("quota") is not None else payload.get("balance")
        try:
            return float(value)
        except (TypeError, ValueError):
            return None

    async def _account_balance(self, account: dict[str, Any]) -> tuple[float | None, str]:
        try:
            response = await self._request(account, "GET", "/api/user/self")
        except httpx.HTTPError:
            return None, self._network_error()
        data = self._json(response)
        if response.status_code >= 400:
            return None, self._message(data)
        return self._raw_balance(data), ""

    async def _redeem(self, context: MessageContext, redemption: str) -> str:
        if not self._is_private(context):
            return "兑换码只能通过私聊提交。"
        code = (redemption or "").strip()
        if not code or len(code) > 256 or any(character.isspace() for character in code):
            return "兑换码格式不正确。用法：/na redeem <兑换码>"
        account = self.accounts.get(self._user_key(context))
        if not account:
            return "你还没有绑定。私聊发送 /na bind <系统访问令牌>。"
        before, _ = await self._account_balance(account)
        try:
            response = await self._request(account, "POST", "/api/user/topup", json={"key": code})
        except httpx.HTTPError:
            return self._network_error()
        data = self._json(response)
        failed = response.status_code >= 400 or (isinstance(data, dict) and data.get("success") is False)
        if isinstance(data, dict) and str(data.get("message") or "").lower() == "error":
            failed = True
        if failed:
            detail = data.get("data") if isinstance(data, dict) and isinstance(data.get("data"), str) else self._message(data)
            return f"兑换失败：{detail}"
        after, _ = await self._account_balance(account)
        if before is not None and after is not None:
            credited = max(0.0, after - before)
            return f"兑换成功，到账额度：{self._quota_value(credited)}，当前余额：{self._quota_value(after)}。"
        credited = data.get("data") if isinstance(data, dict) and isinstance(data.get("data"), (int, float)) else None
        return f"兑换成功，到账额度：{self._quota_value(credited)}。" if credited is not None else "兑换成功，请使用 /na me 查看余额。"

    def _alert_enable(self, context: MessageContext, threshold: float) -> str:
        if not self._is_private(context):
            return "余额提醒只能在私聊中启用。"
        if threshold <= 0:
            return "提醒阈值必须大于 0。用法：/na alert <余额阈值>"
        account = self.accounts.get(self._user_key(context))
        if not account:
            return "你还没有绑定。私聊发送 /na bind <系统访问令牌>。"
        account["notify"] = self._notify_ref(context)
        account["alert"] = {
            "enabled": True,
            "threshold": float(threshold),
            "last_alert_at": 0,
            "below": False,
        }
        self._save()
        return f"低余额提醒已启用：余额低于 {threshold:.6f} 时私聊提醒。"

    def _alert_disable(self, context: MessageContext) -> str:
        account = self.accounts.get(self._user_key(context))
        if not account or not isinstance(account.get("alert"), dict) or not account["alert"].get("enabled"):
            return "当前没有启用低余额提醒。"
        account["alert"]["enabled"] = False
        self._save()
        return "低余额提醒已关闭。"

    def _alert_status(self, context: MessageContext) -> str:
        account = self.accounts.get(self._user_key(context))
        alert = account.get("alert") if account else None
        if not isinstance(alert, dict) or not alert.get("enabled"):
            return "低余额提醒：关闭"
        return "\n".join([
            "低余额提醒：开启",
            f"阈值：{float(alert.get('threshold', 0)):.6f}",
            f"当前低余额状态：{'是' if alert.get('below') else '否'}",
        ])

    @staticmethod
    def _valid_clock(value: str) -> bool:
        try:
            hour, minute = (int(part) for part in value.split(":"))
            return 0 <= hour <= 23 and 0 <= minute <= 59 and len(value.split(":")) == 2
        except (TypeError, ValueError):
            return False

    @staticmethod
    def _weekday_name(value: Any) -> str:
        try:
            weekday = int(value)
        except (TypeError, ValueError):
            return "未知"
        return {1: "周一", 2: "周二", 3: "周三", 4: "周四", 5: "周五", 6: "周六", 7: "周日"}.get(weekday, "未知")

    def _private_rule_account(self, context: MessageContext) -> tuple[dict[str, Any] | None, str]:
        if not self._is_private(context):
            return None, "主动提醒只能在私聊中配置。"
        account = self.accounts.get(self._user_key(context))
        if not account:
            return None, "你还没有绑定。私聊发送 /na bind <系统访问令牌>。"
        account["notify"] = self._notify_ref(context)
        return account, ""

    def _digest_config(self, context: MessageContext, mode: str, value: str, send_time: str) -> str:
        account, error = self._private_rule_account(context)
        if error:
            return error
        mode = (mode or "").strip().lower()
        digest = account.setdefault("digest", {})
        if mode in {"status", "状态"}:
            daily = digest.get("daily") if isinstance(digest.get("daily"), dict) else {}
            weekly = digest.get("weekly") if isinstance(digest.get("weekly"), dict) else {}
            return "\n".join([
                "定时报表状态：",
                f"日报：{daily.get('time') if daily.get('enabled') else '关闭'}",
                f"周报：{self._weekday_name(weekly.get('weekday'))} {weekly.get('time')}" if weekly.get("enabled") else "周报：关闭",
                f"时区：{self._cfg('stats_timezone')}",
            ])
        if mode in {"off", "关闭"}:
            digest["daily"] = {"enabled": False}
            digest["weekly"] = {"enabled": False}
            self._save()
            return "日报和周报均已关闭。"
        if mode in {"daily", "日报"}:
            clock = value.strip()
            if not self._valid_clock(clock):
                return "时间格式应为 HH:MM，例如：/na digest daily 20:00"
            digest["daily"] = {"enabled": True, "time": clock, "last_period": ""}
            self._save()
            return f"日报已启用：每天 {clock} 私聊发送。"
        if mode in {"weekly", "周报"}:
            try:
                weekday = int(value)
            except (TypeError, ValueError):
                weekday = 0
            clock = send_time.strip()
            if weekday not in range(1, 8) or not self._valid_clock(clock):
                return "用法：/na digest weekly <1-7> <HH:MM>，1 表示周一。"
            digest["weekly"] = {"enabled": True, "weekday": weekday, "time": clock, "last_period": ""}
            self._save()
            return f"周报已启用：每{self._weekday_name(weekday)} {clock} 私聊发送。"
        return "用法：/na digest daily <HH:MM>、weekly <1-7> <HH:MM>、status 或 off。"

    def _spend_alert_enable(self, context: MessageContext, threshold: float) -> str:
        account, error = self._private_rule_account(context)
        if error:
            return error
        if threshold <= 0:
            return "今日消费阈值必须大于 0。"
        account["spend_alert"] = {"enabled": True, "threshold": float(threshold), "last_date": "", "alerted": False}
        self._save()
        return f"今日消费提醒已启用：当日消费达到 {threshold:.6f} 时私聊提醒。"

    def _spend_alert_status(self, context: MessageContext) -> str:
        account = self.accounts.get(self._user_key(context))
        rule = account.get("spend_alert") if account else None
        if not isinstance(rule, dict) or not rule.get("enabled"):
            return "今日消费提醒：关闭"
        return f"今日消费提醒：开启\n阈值：{float(rule.get('threshold', 0)):.6f}\n今日已提醒：{'是' if rule.get('alerted') else '否'}"

    def _fail_alert_enable(self, context: MessageContext, threshold: int) -> str:
        account, error = self._private_rule_account(context)
        if error:
            return error
        if threshold < 2 or threshold > 100:
            return "连续失败阈值范围为 2-100。"
        account["failure_alert"] = {"enabled": True, "threshold": int(threshold), "notified": {}}
        self._save()
        return f"按模型连续失败提醒已启用：同一模型连续失败 {threshold} 次时私聊提醒。"

    def _fail_alert_status(self, context: MessageContext) -> str:
        account = self.accounts.get(self._user_key(context))
        rule = account.get("failure_alert") if account else None
        if not isinstance(rule, dict) or not rule.get("enabled"):
            return "按模型连续失败提醒：关闭"
        return f"按模型连续失败提醒：开启\n阈值：{int(rule.get('threshold', 0))} 次\n已触发模型：{len(rule.get('notified') or {})} 个"

    def _rule_disable(self, context: MessageContext, key: str, label: str) -> str:
        account = self.accounts.get(self._user_key(context))
        rule = account.get(key) if account else None
        if not isinstance(rule, dict) or not rule.get("enabled"):
            return f"{label}当前未启用。"
        rule["enabled"] = False
        self._save()
        return f"{label}已关闭。"

    # ---------- proactive sends ----------

    async def _send_active(self, account: dict[str, Any], text: str, notification_kind: str = "alert") -> bool:
        notify = account.get("notify") if isinstance(account.get("notify"), dict) else {}
        conversation_id = str(notify.get("conversation_id") or "")
        scene = str(notify.get("scene") or "")
        if not conversation_id or not scene or self.context is None:
            return False
        if self._cfg("enable_qq_cards"):
            report = notification_kind in {"daily", "weekly"}
            rows = [[_button("提醒状态", "/na alertstatus"), _button("个人设置", "/na menu settings")]]
            if report:
                rows = [[_button("今日统计", "/na today"), _button("近7天趋势", "/na week"), _button("报表设置", "/na menu settings")]]
            titles = {
                "daily": "今日用量日报",
                "weekly": "近 7 天用量周报",
                "balance": "低余额提醒",
                "spend": "今日消费提醒",
                "failure": "连续失败提醒",
                "token": "API 令牌额度提醒",
            }
            card = Card(titles.get(notification_kind, "主动提醒"), _menu_markdown(titles.get(notification_kind, "主动提醒"), self._display(text)), rows)
            if hasattr(self.context, "send_card"):
                try:
                    await self.context.send_card(conversation_id, scene, card)
                    return True
                except Exception:
                    pass
        if hasattr(self.context, "send_text"):
            try:
                await self.context.send_text(conversation_id, scene, self._display(text))
                return True
            except Exception:
                return False
        return False

    # ---------- logs & stats ----------

    def _time_range(self, range_name: str) -> tuple[int, int, str] | None:
        now = dt.datetime.now(self._stats_tz())
        end = int(now.timestamp())
        normalized = {
            "今天": "today",
            "yesterday": "yesterday",
            "昨天": "yesterday",
            "daybefore": "daybefore",
            "前天": "daybefore",
            "三天": "3d",
        }.get(range_name, range_name)
        if not normalized:
            return 0, 0, "最近"
        if normalized == "today":
            start = now.replace(hour=0, minute=0, second=0, microsecond=0)
            return int(start.timestamp()), end, "今日"
        if normalized in {"yesterday", "daybefore"}:
            days_ago = 1 if normalized == "yesterday" else 2
            start = (now - dt.timedelta(days=days_ago)).replace(hour=0, minute=0, second=0, microsecond=0)
            finish = start + dt.timedelta(days=1) - dt.timedelta(seconds=1)
            return int(start.timestamp()), int(finish.timestamp()), "昨天" if days_ago == 1 else "前天"
        if normalized in {"3d", "7d", "30d"}:
            days = int(normalized[:-1])
            start = (now - dt.timedelta(days=days - 1)).replace(hour=0, minute=0, second=0, microsecond=0)
            return int(start.timestamp()), end, f"近 {days} 天"
        return None

    @staticmethod
    def _other(item: dict[str, Any]) -> dict[str, Any]:
        value = item.get("other")
        if isinstance(value, dict):
            return value
        if isinstance(value, str) and value:
            try:
                parsed = json.loads(value)
                return parsed if isinstance(parsed, dict) else {}
            except ValueError:
                return {}
        return {}

    @staticmethod
    def _nested_number(data: Any, keys: set[str]) -> float | None:
        if isinstance(data, dict):
            for key, value in data.items():
                if key.lower() in keys:
                    try:
                        return float(value)
                    except (TypeError, ValueError):
                        pass
                found = NewApiPlugin._nested_number(value, keys)
                if found is not None:
                    return found
        elif isinstance(data, list):
            for value in data:
                found = NewApiPlugin._nested_number(value, keys)
                if found is not None:
                    return found
        return None

    def _log_values(self, item: dict[str, Any]) -> dict[str, Any]:
        other = self._other(item)
        cached = self._nested_number(other, {"cached_tokens", "cache_read_input_tokens", "cache_tokens", "cached"})
        prompt = float(item.get("prompt_tokens") or 0)
        return {
            "time": int(item.get("created_at") or 0),
            "model": str(item.get("model_name") or item.get("model") or "未知模型"),
            "input": int(prompt),
            "output": int(item.get("completion_tokens") or 0),
            "cached": int(cached) if cached is not None else None,
            "quota": float(item.get("quota") or 0),
            "duration": float(item.get("use_time") or 0),
            "success": int(item.get("type") or 0) != 5,
            "type": int(item.get("type") or 0),
        }

    async def _log_page(
        self, context: MessageContext, range_name: str, page: int, model: str = "", page_size: int = 10
    ) -> tuple[list[dict[str, Any]], int, str]:
        period = self._time_range(range_name)
        if period is None:
            return [], 0, "范围支持 today、yesterday、daybefore、3d、7d 或 30d。"
        start, end, _ = period
        params: dict[str, Any] = {"p": max(1, page), "page_size": page_size}
        if start:
            params.update({"start_timestamp": start, "end_timestamp": end})
        if model:
            params["model_name"] = model
        account, response = await self._get_for_user(context, "/api/log/self", params=params)
        if not account:
            return [], 0, "你还没有绑定。私聊发送 /na bind <系统访问令牌>。"
        if response is None:
            return [], 0, self._network_error()
        raw = self._json(response)
        if response.status_code >= 400 or (isinstance(raw, dict) and raw.get("success") is False):
            return [], 0, f"查询日志失败：{self._message(raw)}"
        payload = self._payload(raw)
        total = int(payload.get("total") or raw.get("total") or 0) if isinstance(payload, dict) else 0
        return [item for item in self._items(raw) if isinstance(item, dict)], total, ""

    async def _logs(self, context: MessageContext, range_name: str = "", page: int = 1, model: str = "") -> str:
        if page < 1:
            return "页码必须大于等于 1。"
        logs, total, error = await self._log_page(context, range_name, page, model)
        if error:
            return error
        if not logs:
            return "当前筛选条件没有调用记录。"
        rows = [self._log_values(item) for item in logs]
        optional = [
            ("输入", "input", any(row["input"] for row in rows)),
            ("输出", "output", any(row["output"] for row in rows)),
            ("缓存", "cached", any(row["cached"] is not None for row in rows)),
            ("缓存率", "cache_rate", any(row["cached"] is not None and row["input"] > 0 for row in rows)),
            ("耗时", "duration", any(row["duration"] for row in rows)),
        ]
        columns = [("时间", "time"), ("模型", "model"), *[(title, key) for title, key, show in optional if show], ("消耗", "quota"), ("状态", "status")]
        period = self._time_range(range_name)
        title = f"{period[2] if period else '最近'}调用记录"
        if model:
            title += f" · {_cell(model, 40)}"
        lines = [f"{title}（第 {page} 页）：", "", "| " + " | ".join(title for title, _ in columns) + " |", "|" + "---|" * len(columns)]
        for row in rows:
            values = {
                "time": dt.datetime.fromtimestamp(row["time"], self._stats_tz()).strftime("%m-%d %H:%M:%S") if row["time"] else "未知",
                "model": _cell(row["model"], 36),
                "input": str(row["input"]),
                "output": str(row["output"]),
                "cached": str(row["cached"] if row["cached"] is not None else "未知"),
                "cache_rate": f"{row['cached'] / row['input']:.1%}" if row["cached"] is not None and row["input"] > 0 else "无数据",
                "duration": f"{row['duration']:.2f}s",
                "quota": self._quota_value(row["quota"]),
                "status": "成功" if row["success"] else "失败",
            }
            lines.append("| " + " | ".join(values[key] for _, key in columns) + " |")
        if total:
            pages = max(1, (total + 9) // 10)
            lines.extend(["", f"共 {total} 条，第 {page}/{pages} 页。"])
        return "\n".join(lines)

    async def _range_logs(self, context: MessageContext, range_name: str) -> tuple[list[dict[str, Any]], bool, str]:
        maximum = max(100, min(5000, int(self._cfg("stats_max_logs"))))
        collected: list[dict[str, Any]] = []
        page = 1
        total = 0
        while len(collected) < maximum:
            items, total, error = await self._log_page(context, range_name, page, page_size=100)
            if error:
                return [], False, error
            collected.extend(items)
            if not items or len(collected) >= total:
                break
            page += 1
        return collected[:maximum], total > maximum, ""

    async def _account_range_logs(self, account: dict[str, Any], range_name: str, maximum: int | None = None) -> tuple[list[dict[str, Any]], bool, str]:
        period = self._time_range(range_name)
        if period is None:
            return [], False, "不支持的统计范围"
        limit = maximum or max(100, min(5000, int(self._cfg("stats_max_logs"))))
        collected: list[dict[str, Any]] = []
        page = 1
        total = 0
        while len(collected) < limit:
            params: dict[str, Any] = {"p": page, "page_size": min(100, limit - len(collected))}
            if period[0]:
                params.update({"start_timestamp": period[0], "end_timestamp": period[1]})
            try:
                response = await self._request(account, "GET", "/api/log/self", params=params)
            except httpx.HTTPError:
                return [], False, self._network_error()
            raw = self._json(response)
            if response.status_code >= 400 or (isinstance(raw, dict) and raw.get("success") is False):
                return [], False, self._message(raw)
            items = [item for item in self._items(raw) if isinstance(item, dict)]
            payload = self._payload(raw)
            total = int(payload.get("total") or raw.get("total") or 0) if isinstance(payload, dict) else 0
            collected.extend(items)
            if not items or len(collected) >= total:
                break
            page += 1
        return collected[:limit], total > limit, ""

    @staticmethod
    def _log_values_static(item: dict[str, Any]) -> dict[str, Any]:
        other = NewApiPlugin._other(item)
        cached = NewApiPlugin._nested_number(other, {"cached_tokens", "cache_read_input_tokens", "cache_tokens", "cached"})
        return {
            "time": int(item.get("created_at") or 0),
            "model": str(item.get("model_name") or item.get("model") or "未知模型"),
            "input": int(item.get("prompt_tokens") or 0),
            "cached": int(cached) if cached is not None else None,
            "quota": float(item.get("quota") or 0),
            "success": int(item.get("type") or 0) != 5,
            "type": int(item.get("type") or 0),
        }

    @staticmethod
    def _aggregate(logs: list[dict[str, Any]]) -> dict[str, Any]:
        rows = [NewApiPlugin._log_values_static(item) for item in logs]
        models: dict[str, dict[str, float]] = defaultdict(lambda: {"requests": 0, "quota": 0, "cached": 0, "prompt": 0, "failed": 0})
        total_quota = 0.0
        failed = 0
        cached_total = 0.0
        prompt_total = 0.0
        for row in rows:
            if row["type"] not in {2, 5}:
                continue
            stats = models[row["model"]]
            stats["requests"] += 1
            stats["quota"] += row["quota"]
            total_quota += row["quota"]
            if not row["success"]:
                stats["failed"] += 1
                failed += 1
            if row["cached"] is not None:
                stats["cached"] += row["cached"]
                stats["prompt"] += row["input"]
                cached_total += row["cached"]
                prompt_total += row["input"]
        requests = sum(int(value["requests"]) for value in models.values())
        return {"models": models, "requests": requests, "quota": total_quota, "failed": failed, "cached": cached_total, "prompt": prompt_total}

    def _summary_lines(self, title: str, summary: dict[str, Any], limit: int = 8) -> list[str]:
        models = sorted(summary["models"].items(), key=lambda item: item[1]["quota"], reverse=True)
        most_used = max(models, key=lambda item: item[1]["requests"])[0] if models else "无"
        top_cost = models[0][0] if models else "无"
        success_rate = (summary["requests"] - summary["failed"]) / summary["requests"] if summary["requests"] else 0
        cache_rate = summary["cached"] / summary["prompt"] if summary["prompt"] else None
        lines = [
            title,
            "",
            "| 请求数 | 总消耗 | 成功率 | 缓存率 | 最常用模型 | 消耗最高模型 |",
            "|---:|---:|---:|---:|---|---|",
            f"| {summary['requests']} | {self._quota_value(summary['quota'])} | {success_rate:.1%} | {cache_rate:.1%} | {_cell(most_used, 30)} | {_cell(top_cost, 30)} |" if cache_rate is not None else f"| {summary['requests']} | {self._quota_value(summary['quota'])} | {success_rate:.1%} | 无数据 | {_cell(most_used, 30)} | {_cell(top_cost, 30)} |",
        ]
        if models:
            lines.extend(["", "| 模型 | 请求数 | 消耗 | 占比 | 缓存率 |", "|---|---:|---:|---:|---:|"])
            for model, stats in models[:limit]:
                share = stats["quota"] / summary["quota"] if summary["quota"] else 0
                model_cache = stats["cached"] / stats["prompt"] if stats["prompt"] else None
                lines.append(f"| {_cell(model, 36)} | {int(stats['requests'])} | {self._quota_value(stats['quota'])} | {share:.1%} | {model_cache:.1%} |" if model_cache is not None else f"| {_cell(model, 36)} | {int(stats['requests'])} | {self._quota_value(stats['quota'])} | {share:.1%} | 无数据 |")
        return lines

    async def _usage_summary(self, context: MessageContext, range_name: str) -> str:
        period = self._time_range(range_name)
        if period is None or not range_name:
            return "范围支持 today、yesterday、daybefore、3d、7d 或 30d。"
        logs, truncated, error = await self._range_logs(context, range_name)
        if error:
            return error
        summary = self._aggregate(logs)
        lines = self._summary_lines(f"{period[2]}用量总览：", summary)
        if truncated:
            lines.extend(["", "数据量超过统计扫描上限，结果为抽样上限内汇总。"])
        return "\n".join(lines)

    async def _model_stats(self, context: MessageContext, range_name: str) -> str:
        if self._time_range(range_name) is None or not range_name:
            return "范围支持 today、yesterday、daybefore、3d、7d 或 30d。"
        logs, truncated, error = await self._range_logs(context, range_name)
        if error:
            return error
        summary = self._aggregate(logs)
        models = sorted(summary["models"].items(), key=lambda item: item[1]["quota"], reverse=True)
        if not models:
            return "当前范围没有消费或错误日志。"
        lines = [f"{self._time_range(range_name)[2]}模型统计：", "", "| 模型 | 请求数 | 总消耗 | 平均消耗 | 缓存率 | 失败数 |", "|---|---:|---:|---:|---:|---:|"]
        for model, stats in models[:15]:
            average = stats["quota"] / stats["requests"] if stats["requests"] else 0
            cache_rate = stats["cached"] / stats["prompt"] if stats["prompt"] else None
            lines.append(f"| {_cell(model, 36)} | {int(stats['requests'])} | {self._quota_value(stats['quota'])} | {self._quota_value(average)} | {cache_rate:.1%} | {int(stats['failed'])} |" if cache_rate is not None else f"| {_cell(model, 36)} | {int(stats['requests'])} | {self._quota_value(stats['quota'])} | {self._quota_value(average)} | 无数据 | {int(stats['failed'])} |")
        if truncated:
            lines.extend(["", "数据量超过统计扫描上限，结果为抽样上限内汇总。"])
        return "\n".join(lines)

    def _week_lines(self, logs: list[dict[str, Any]], title: str = "近 7 天用量总览：") -> list[str]:
        summary = self._aggregate(logs)
        daily: dict[str, list[dict[str, Any]]] = defaultdict(list)
        for item in logs:
            timestamp = int(item.get("created_at") or 0)
            if timestamp:
                daily[dt.datetime.fromtimestamp(timestamp, self._stats_tz()).strftime("%m-%d")].append(item)
        lines = self._summary_lines(title, summary, limit=5)
        lines.extend(["", "| 日期 | 请求数 | 消耗 | 缓存率 | 主要模型 |", "|---|---:|---:|---:|---|"])
        for day in sorted(daily):
            stats = self._aggregate(daily[day])
            models = sorted(stats["models"].items(), key=lambda item: item[1]["requests"], reverse=True)
            cache_rate = stats["cached"] / stats["prompt"] if stats["prompt"] else None
            lines.append(f"| {day} | {stats['requests']} | {self._quota_value(stats['quota'])} | {cache_rate:.1%} | {_cell(models[0][0] if models else '无', 30)} |" if cache_rate is not None else f"| {day} | {stats['requests']} | {self._quota_value(stats['quota'])} | 无数据 | {_cell(models[0][0] if models else '无', 30)} |")
        return lines

    async def _week_summary(self, context: MessageContext) -> str:
        logs, truncated, error = await self._range_logs(context, "7d")
        if error:
            return error
        lines = self._week_lines(logs)
        if truncated:
            lines.extend(["", "数据量超过统计扫描上限，结果为抽样上限内汇总。"])
        return "\n".join(lines)

    # ---------- admin ----------

    async def _calibrate(self, context: MessageContext, actual_balance: float) -> str:
        if not context.is_admin:
            return "只有管理员可以校准全局额度换算。"
        if actual_balance <= 0:
            return "网页真实余额必须大于 0。用法：/na calibrate <网页显示余额>"
        account = self.accounts.get(self._user_key(context))
        if not account:
            return "请先绑定你的系统访问令牌，再执行校准。"
        try:
            response = await self._request(account, "GET", "/api/user/self")
        except httpx.HTTPError:
            return self._network_error()
        raw = self._json(response)
        if response.status_code >= 400:
            return f"读取原始余额失败：{self._message(raw)}"
        data = self._payload(raw)
        raw_balance = data.get("quota") if data.get("quota") is not None else data.get("balance")
        try:
            raw_number = float(raw_balance)
        except (TypeError, ValueError):
            return "New API 没有返回可用于校准的原始余额。"
        if raw_number <= 0:
            return "当前原始余额必须大于 0，无法校准。"
        quota_per_unit = raw_number / actual_balance
        await self.set_config("quota_per_unit", f"{quota_per_unit:.6f}")
        self.cache.clear()
        return f"校准完成：quota_per_unit = {quota_per_unit:.6f}，当前余额 = {actual_balance:.6f}。"

    async def _config_command(self, context: MessageContext, rest: list[str]) -> str:
        if not context.is_admin:
            return "只有管理员可以查看或修改插件配置。"
        if not rest:
            lines = ["插件配置（na.*）："]
            for key in CONFIG_SPEC:
                current = self._config_cache.get(key, _format_default(CONFIG_DEFAULTS[key]))
                lines.append(f"{key} = {current}")
            lines.extend(["", "修改：/na config <键> <值>"])
            return "\n".join(lines)
        if len(rest) == 1:
            key = rest[0].strip()
            if key not in CONFIG_SPEC:
                return f"未知的配置项：{key}"
            current = self._config_cache.get(key, _format_default(CONFIG_DEFAULTS[key]))
            return f"{key} = {current}"
        key = rest[0].strip()
        value = " ".join(rest[1:]).strip()
        kind, (low, high) = CONFIG_SPEC[key]
        try:
            if kind == "bool":
                if value.lower() not in {"true", "false", "1", "0", "on", "off", "开", "关"}:
                    raise ValueError
                stored = "true" if value.lower() in {"true", "1", "on", "开"} else "false"
            elif kind == "int":
                number = int(value)
                if not low <= number <= high:
                    return f"{key} 需在 {low:.0f}-{high:.0f} 之间。"
                stored = str(number)
            elif kind == "float":
                number = float(value)
                if not low <= number <= high:
                    return f"{key} 需在 {low} - {high} 之间。"
                stored = repr(number)
            else:
                if not low <= len(value) <= high:
                    return f"{key} 长度需在 {low:.0f}-{high:.0f} 之间。"
                stored = value
        except ValueError:
            return f"{key} 的值无效（需要 {kind}）。"
        await self.set_config(key, stored)
        return f"已设置 {key} = {stored}。"

    @staticmethod
    def _diagnostic_network_error(error: httpx.HTTPError) -> str:
        if isinstance(error, httpx.ConnectTimeout):
            return "连接超时"
        if isinstance(error, httpx.ReadTimeout):
            return "读取超时"
        if isinstance(error, httpx.WriteTimeout):
            return "写入超时"
        if isinstance(error, httpx.PoolTimeout):
            return "连接池超时"
        if isinstance(error, httpx.ConnectError):
            cause = str(error.__cause__ or error).lower()
            if "certificate" in cause or "ssl" in cause or "tls" in cause:
                return "TLS 连接失败"
            if "name or service not known" in cause or "nodename nor servname" in cause or "getaddrinfo" in cause:
                return "DNS 解析失败"
            return "连接失败"
        return "网络请求失败"

    async def _diagnostic_probe(self, account: dict[str, Any], path: str, params: dict[str, Any] | None = None) -> str:
        started = time.monotonic()
        try:
            response = await self._request(account, "GET", path, params=params)
        except httpx.HTTPError as error:
            return f"{self._diagnostic_network_error(error)}（{(time.monotonic() - started) * 1000:.0f}ms）"
        elapsed = f"（{(time.monotonic() - started) * 1000:.0f}ms）"
        data = self._json(response)
        if response.status_code < 200 or response.status_code >= 300:
            return f"HTTP {response.status_code}{elapsed}"
        if isinstance(data, dict) and data.get("success") is False:
            return f"接口拒绝{elapsed}"
        if path == "/api/user/checkin" and isinstance(data, dict) and data.get("data") is None:
            return f"正常（站点未启用）{elapsed}"
        return f"正常{elapsed}"

    async def _diagnose(self, context: MessageContext) -> str:
        if not context.is_admin:
            return "只有管理员可以执行诊断。"
        if not self._is_private(context):
            return "管理员诊断只能在私聊中执行。"
        if not self._base_url():
            return "插件尚未配置 New API 地址。"
        account = self.accounts.get(self._user_key(context))
        if not account:
            return "请先绑定你的系统访问令牌，再执行诊断。"
        features = [
            ("充值记录", "enable_topup_history", "/api/user/topup/self", {"p": 1, "page_size": 1}),
            ("账户安全", "enable_account_security", "/api/user/passkey", None),
            ("签到", "enable_checkin", "/api/user/checkin", None),
            ("订阅套餐", "enable_subscription", "/api/subscription/plans", None),
            ("个人订阅", "enable_subscription", "/api/subscription/self", None),
        ]
        enabled = [(name, path, params) for name, key, path, params in features if self._cfg(key)]
        statuses = await asyncio.gather(*(self._diagnostic_probe(account, path, params) for _, path, params in enabled))
        result = {name: status for (name, _, _), status in zip(enabled, statuses, strict=True)}
        lines = [
            "管理员诊断（仅只读 GET）：",
            f"基础账户接口：{await self._diagnostic_probe(account, '/api/user/self')}",
            "",
            "功能开关与接口：",
        ]
        for name, _, _, _ in features:
            key = next(item_key for label, item_key, _, _ in features if label == name)
            active = bool(self._cfg(key))
            lines.append(f"{name}：{'开启，' + result[name] if active else '关闭，未探测'}")
        lines.extend([
            "",
            "运行配置：",
            f"请求超时：{self._timeout():.0f} 秒",
            f"查询限流：{self._cfg('query_rate_limit_sec')} 秒",
            f"缓存 TTL：模型 {self._cache_ttl('models')} 秒，分组 {self._cache_ttl('groups')} 秒，令牌 {self._cache_ttl('tokens')} 秒",
            f"分组查询并发：{self._group_concurrency()}",
            f"提醒检查周期：{self._cfg('alert_check_interval_sec')} 秒",
            f"统计时区：{self._cfg('stats_timezone')}",
            "诊断不会执行签到、支付、购买、兑换或令牌写操作，也不会显示令牌、账户数据、接口正文或站点地址。",
        ])
        return "\n".join(lines)

    def _unbind(self, context: MessageContext) -> str:
        key = self._user_key(context)
        if self.accounts.pop(key, None) is None:
            return "当前没有已绑定的系统访问令牌。"
        self.pending_actions.pop(key, None)
        self.pending_codes.pop(key, None)
        self._save()
        self._clear_user_cache(context)
        return "已清除你的系统访问令牌绑定。"

    # ---------- scheduled rules / alert task ----------

    @staticmethod
    def _failure_sequences(logs: list[dict[str, Any]]) -> dict[str, dict[str, Any]]:
        sequences: dict[str, dict[str, Any]] = {}
        stopped: set[str] = set()
        ordered = sorted(logs, key=lambda item: int(item.get("created_at") or 0), reverse=True)
        for item in ordered:
            model = str(item.get("model_name") or item.get("model") or "未知模型")
            if model in stopped:
                continue
            log_type = int(item.get("type") or 0)
            if log_type == 2:
                stopped.add(model)
                continue
            if log_type != 5:
                continue
            sequence = sequences.setdefault(model, {"count": 0, "latest": 0, "first": 0})
            timestamp = int(item.get("created_at") or 0)
            sequence["count"] += 1
            sequence["latest"] = max(sequence["latest"], timestamp)
            sequence["first"] = timestamp if not sequence["first"] else min(sequence["first"], timestamp)
        return sequences

    async def _process_scheduled_rules(self, account: dict[str, Any], now: dt.datetime) -> tuple[bool, list[str]]:
        changed = False
        results: list[str] = []
        digest = account.get("digest") if isinstance(account.get("digest"), dict) else {}
        for kind in ("daily", "weekly"):
            rule = digest.get(kind) if isinstance(digest.get(kind), dict) else {}
            if not rule.get("enabled") or not rule.get("time"):
                continue
            due = now.strftime("%H:%M") >= str(rule["time"])
            period_key = now.strftime("%Y-%m-%d") if kind == "daily" else f"{now.isocalendar().year}-W{now.isocalendar().week}"
            if kind == "weekly":
                due = due and now.isoweekday() == int(rule.get("weekday") or 0)
            if not due or rule.get("last_period") == period_key:
                continue
            logs, truncated, error = await self._account_range_logs(account, "today" if kind == "daily" else "7d")
            if error:
                results.append(f"{'日报' if kind == 'daily' else '周报'}检查失败")
                continue
            if kind == "daily":
                lines = self._summary_lines("今日用量日报：", self._aggregate(logs), limit=5)
            else:
                lines = self._week_lines(logs, "近 7 天用量周报：")
            if truncated:
                lines.extend(["", "数据超过统计扫描上限，本报表基于扫描上限内日志。"])
            if await self._send_active(account, "\n".join(lines), kind):
                rule["last_period"] = period_key
                changed = True
                results.append(f"{'日报' if kind == 'daily' else '周报'}已发送")

        spend = account.get("spend_alert") if isinstance(account.get("spend_alert"), dict) else {}
        today_key = now.strftime("%Y-%m-%d")
        if spend.get("enabled"):
            if spend.get("last_date") != today_key:
                spend["last_date"] = today_key
                spend["alerted"] = False
                changed = True
            logs, _, error = await self._account_range_logs(account, "today")
            if not error:
                summary = self._aggregate(logs)
                threshold = float(spend.get("threshold") or 0)
                actual = summary["quota"] / self._quota_per_unit()
                if actual >= threshold and not spend.get("alerted"):
                    text = "\n".join(self._summary_lines(f"今日消费提醒：已消费 {actual:.6f}，达到阈值 {threshold:.6f}。", summary, limit=5))
                    if await self._send_active(account, text, "spend"):
                        spend["alerted"] = True
                        changed = True
                        results.append("今日消费提醒已触发")
                else:
                    results.append(f"今日消费 {actual:.6f}/{threshold:.6f}")

        failure = account.get("failure_alert") if isinstance(account.get("failure_alert"), dict) else {}
        if failure.get("enabled"):
            logs, _, error = await self._account_range_logs(account, "3d", maximum=500)
            if not error:
                sequences = self._failure_sequences(logs)
                notified = failure.setdefault("notified", {})
                for model in list(notified):
                    if model not in sequences or str(sequences[model]["first"]) != str(notified.get(model)):
                        notified.pop(model, None)
                        changed = True
                threshold = int(failure.get("threshold") or 3)
                for model, sequence in sequences.items():
                    if sequence["count"] < threshold or model in notified:
                        continue
                    first = dt.datetime.fromtimestamp(sequence["first"], self._stats_tz()).strftime("%m-%d %H:%M:%S")
                    latest = dt.datetime.fromtimestamp(sequence["latest"], self._stats_tz()).strftime("%m-%d %H:%M:%S")
                    text = f"模型连续失败提醒\n\n模型：{_cell(model, 50)}\n连续失败：{sequence['count']} 次\n首次失败：{first}\n最近失败：{latest}"
                    if await self._send_active(account, text, "failure"):
                        notified[model] = str(sequence["first"])
                        changed = True
                        results.append(f"{model} 连续失败提醒已触发")
                if not sequences:
                    results.append("当前没有连续失败模型")

        token_alerts = account.get("token_alerts") if isinstance(account.get("token_alerts"), dict) else {}
        if token_alerts:
            tokens, error = await self._account_token_items(account)
            if error:
                results.append("API 令牌额度检查失败")
            else:
                token_map = {str(item.get("id")): item for item in tokens if item.get("id") is not None}
                cooldown = max(0, int(self._cfg("alert_repeat_cooldown_sec")))
                now_timestamp = int(now.timestamp())
                for token_id in list(token_alerts):
                    rule = token_alerts.get(token_id)
                    token = token_map.get(str(token_id))
                    if not isinstance(rule, dict) or not token or token.get("unlimited_quota"):
                        token_alerts.pop(token_id, None)
                        changed = True
                        continue
                    name = str(token.get("name") or rule.get("name") or "未命名")
                    if rule.get("name") != name:
                        rule["name"] = name
                        changed = True
                    try:
                        remaining = float(token.get("remain_quota") or 0)
                        threshold = float(rule.get("threshold") or 0)
                    except (TypeError, ValueError):
                        continue
                    if not math.isfinite(remaining) or not math.isfinite(threshold) or threshold <= 0:
                        continue
                    below = remaining < threshold * self._quota_per_unit()
                    if not below:
                        if rule.get("below"):
                            rule["below"] = False
                            changed = True
                        results.append(f"API 令牌 {name} 额度正常")
                        continue
                    last_alert = int(rule.get("last_alert_at") or 0)
                    should_send = not rule.get("below") or (cooldown > 0 and now_timestamp - last_alert >= cooldown)
                    if not rule.get("below"):
                        rule["below"] = True
                        changed = True
                    if not should_send:
                        results.append(f"API 令牌 {name} 仍低于阈值")
                        continue
                    text = f"API 令牌额度提醒\n\n令牌名称：{_cell(name, 50)}\n当前剩余：{self._quota_value(remaining)}\n提醒阈值：{threshold:.6f}"
                    if await self._send_active(account, text, "token"):
                        rule["last_alert_at"] = now_timestamp
                        changed = True
                        results.append(f"API 令牌 {name} 额度提醒已触发")
        return changed, results

    async def _failure_check_text(self, context: MessageContext) -> str:
        account = self.accounts.get(self._user_key(context))
        if not account:
            return "你还没有绑定。私聊发送 /na bind <系统访问令牌>。"
        logs, _, error = await self._account_range_logs(account, "3d", maximum=500)
        if error:
            return f"失败检查未完成：{error}"
        sequences = self._failure_sequences(logs)
        if not sequences:
            return "当前没有按模型连续失败记录。"
        rule = account.get("failure_alert") if isinstance(account.get("failure_alert"), dict) else {}
        notified = rule.get("notified") if isinstance(rule.get("notified"), dict) else {}
        lines = ["按模型连续失败检查：", "", "| 模型 | 连续失败 | 首次失败 | 最近失败 | 提醒状态 |", "|---|---:|---|---|---|"]
        for model, sequence in sorted(sequences.items(), key=lambda item: item[1]["count"], reverse=True)[:20]:
            first = dt.datetime.fromtimestamp(sequence["first"], self._stats_tz()).strftime("%m-%d %H:%M")
            latest = dt.datetime.fromtimestamp(sequence["latest"], self._stats_tz()).strftime("%m-%d %H:%M")
            lines.append(f"| {_cell(model, 36)} | {sequence['count']} | {first} | {latest} | {'已提醒' if model in notified else '未提醒'} |")
        return "\n".join(lines)

    async def _manual_alert_check(self, context: MessageContext) -> str:
        if not self._is_private(context):
            return "主动提醒检查只能在私聊中执行。"
        account = self.accounts.get(self._user_key(context))
        if not account:
            return "你还没有绑定。私聊发送 /na bind <系统访问令牌>。"
        account["notify"] = self._notify_ref(context)
        changed, results = await self._process_scheduled_rules(account, dt.datetime.now(self._stats_tz()))
        balance, balance_error = await self._account_balance(account)
        if balance_error:
            results.append("余额检查失败")
        elif balance is not None:
            alert = account.get("alert") if isinstance(account.get("alert"), dict) else {}
            threshold = float(alert.get("threshold") or 0)
            results.append(f"当前余额 {self._quota_value(balance)}" + (f"，低余额阈值 {threshold:.6f}" if alert.get("enabled") else "，低余额提醒未启用"))
        if changed:
            self._save()
        return "提醒检查完成：\n- " + "\n- ".join(results) if results else "提醒检查完成：当前没有启用的主动规则。"

    async def alert_tick(self) -> None:
        """注册表任务入口：按 alert_check_interval_sec 节流的告警/报表巡检。"""
        interval = max(60, int(self._cfg("alert_check_interval_sec") or 300))
        now = time.monotonic()
        if now - self._last_alert_run < interval or self._stopping:
            return
        self._last_alert_run = now
        changed = False
        timestamp = int(time.time())
        cooldown = max(0, int(self._cfg("alert_repeat_cooldown_sec")))
        for account in list(self.accounts.values()):
            try:
                rule_changed, _ = await self._process_scheduled_rules(account, dt.datetime.now(self._stats_tz()))
                changed = changed or rule_changed
            except Exception:
                continue
            alert = account.get("alert")
            if not isinstance(alert, dict) or not alert.get("enabled") or not isinstance(account.get("notify"), dict):
                continue
            balance, error = await self._account_balance(account)
            if error or balance is None:
                continue
            try:
                threshold_raw = float(alert.get("threshold", 0)) * self._quota_per_unit()
            except (TypeError, ValueError):
                continue
            below = balance < threshold_raw
            if not below:
                if alert.get("below"):
                    alert["below"] = False
                    changed = True
                continue
            last_alert = int(alert.get("last_alert_at", 0) or 0)
            should_send = not alert.get("below") or (cooldown > 0 and timestamp - last_alert >= cooldown)
            if not alert.get("below"):
                alert["below"] = True
                changed = True
            if not should_send:
                continue
            text = (
                f"{self._cfg('service_display_name')} 余额提醒：当前余额 {self._quota_value(balance)}，"
                f"已低于阈值 {float(alert.get('threshold', 0)):.6f}。"
            )
            try:
                if await self._send_active(account, text, "balance"):
                    alert["last_alert_at"] = timestamp
                    changed = True
            except Exception:
                continue
        if changed:
            self._save()

    # ---------- cross-plugin service API ----------

    async def svc_create_token(self, owner_key: str, name: str, group: str = "", quota: int = 0) -> dict[str, Any]:
        """为已绑定用户创建一个 New API 令牌并返回完整 Key。"""
        account = self.accounts.get(owner_key)
        if not account:
            return {"ok": False, "error": "该用户尚未绑定 New API 系统访问令牌（请先 /na bind）。"}
        name = str(name).strip()
        group = str(group or "").strip()
        if not name or len(name) > 50 or " " in name:
            return {"ok": False, "error": "令牌名称需为 1-50 个字符且不含空格。"}
        items, error = await self._account_token_items(account)
        if error:
            return {"ok": False, "error": error}
        if any(str(item.get("name") or "").casefold() == name.casefold() for item in items):
            return {"ok": False, "error": "已存在同名令牌，请先删除或解绑后再试。"}
        payload = {
            "name": name,
            "expired_time": -1,
            "remain_quota": 0,
            "unlimited_quota": True,
            "model_limits_enabled": False,
            "model_limits": "",
            "group": group,
        }
        try:
            quota_value = int(quota or 0)
        except (TypeError, ValueError):
            quota_value = 0
        if quota_value > 0:
            payload["unlimited_quota"] = False
            payload["remain_quota"] = quota_value
        try:
            response = await self._request(account, "POST", "/api/token/", json=payload)
        except httpx.HTTPError:
            return {"ok": False, "error": self._network_error()}
        data = self._json(response)
        if response.status_code >= 400 or (isinstance(data, dict) and data.get("success") is False):
            return {"ok": False, "error": self._message(data)}
        items_after, error_after = await self._account_token_items(account)
        if error_after:
            return {"ok": False, "error": "令牌已创建，但无法重新读取令牌列表以定位其编号。"}
        created = next((item for item in items_after if str(item.get("name") or "") == name), None)
        if not created or not created.get("id"):
            return {"ok": False, "error": "令牌已创建，但无法定位其编号以读取完整 Key。"}
        try:
            key_response = await self._request(account, "POST", f"/api/token/{int(created['id'])}/key")
        except (httpx.HTTPError, TypeError, ValueError):
            return {"ok": False, "error": "令牌已创建，但读取完整 Key 失败，请前往 New API 网页查看。"}
        key_data = self._json(key_response)
        key_payload = self._payload(key_data)
        key = key_payload.get("key") if isinstance(key_payload, dict) else None
        if key_response.status_code >= 400 or not key:
            return {"ok": False, "error": "令牌已创建，但读取完整 Key 失败，请前往 New API 网页查看。"}
        full_key = str(key)
        if not full_key.startswith("sk-"):
            full_key = f"sk-{full_key}"
        return {"ok": True, "api_key": full_key, "token_name": name, "base_url": self._base_url()}

    async def svc_delete_token(self, owner_key: str, name: str) -> dict[str, Any]:
        """删除已绑定用户的指定名称 New API 令牌。"""
        account = self.accounts.get(owner_key)
        if not account:
            return {"ok": False, "error": "该用户尚未绑定 New API 系统访问令牌。"}
        items, error = await self._account_token_items(account)
        if error:
            return {"ok": False, "error": error}
        matches = [item for item in items if str(item.get("name") or "").casefold() == str(name).casefold() and item.get("id")]
        if not matches:
            return {"ok": False, "error": "没有找到同名令牌（可能已在网页删除）。"}
        try:
            response = await self._request(account, "DELETE", f"/api/token/{int(matches[0]['id'])}")
        except httpx.HTTPError:
            return {"ok": False, "error": self._network_error()}
        data = self._json(response)
        if response.status_code >= 400 or (isinstance(data, dict) and data.get("success") is False):
            return {"ok": False, "error": self._message(data)}
        return {"ok": True, "token_name": str(name)}

    async def svc_list_groups(self, owner_key: str) -> dict[str, Any]:
        """列出已绑定用户的可用分组名称。"""
        account = self.accounts.get(owner_key)
        if not account:
            return {"ok": False, "error": "该用户尚未绑定 New API 系统访问令牌。"}
        try:
            response = await self._request(account, "GET", "/api/user/self/groups")
        except httpx.HTTPError:
            return {"ok": False, "error": self._network_error()}
        data = self._json(response)
        if response.status_code >= 400:
            return {"ok": False, "error": self._message(data)}
        names: list[str] = []
        for group in self._items(data):
            name = group.get("name") or group.get("group") or group.get("id") if isinstance(group, dict) else str(group)
            if name and str(name) not in names:
                names.append(str(name))
        if not names:
            names = [str(key) for key, _ in self._mapping_items(data)]
        return {"ok": True, "groups": names[:40]}


def _format_default(value: Any) -> str:
    if isinstance(value, bool):
        return "true" if value else "false"
    return str(value)



async def setup(context: Any) -> NewApiPlugin:
    plugin = NewApiPlugin(context)
    if hasattr(context, "register_command"):
        context.register_command("na", plugin.command, category="utility", description="New API 用户中心主指令及卡片交互菜单")
    if hasattr(context, "register_task"):
        context.register_task("alerts", 60, plugin.alert_tick)
    if hasattr(context, "register_action"):
        context.register_action("save_config", plugin.on_page_action)
        context.register_action("page_data", plugin.on_page_action)
        context.register_action("page_delete", plugin.on_page_action)
        context.register_action("svc_create_token", plugin.on_page_action)
        context.register_action("svc_delete_token", plugin.on_page_action)
        context.register_action("svc_list_groups", plugin.on_page_action)
    plugin._write_page_snapshot()
    logger.info("plugin.na %s 初始化成功", PLUGIN_VERSION)
    return plugin
