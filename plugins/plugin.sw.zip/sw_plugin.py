"""Steam 监控独立外部插件 (plugin.sw).

具备完整的 Steam 玩家状态监控、好友码/个人资料链接解析、分群与全局订阅推送、
开播/停播通知与游玩时长评价、分级交互卡片菜单、二次确认安全机制与管理台原生声明式 UI 通信能力。
遵循标准普通外部插件规范，运行于沙箱隔离环境中，配置与数据均存储于插件专属目录。
"""

from __future__ import annotations

import asyncio
import datetime
import json
import logging
import re
import shutil
import time
import uuid
from pathlib import Path
from typing import Any

import httpx

from runtime.models import Button, Card, MessageContext

logger = logging.getLogger("plugin.sw")
PLUGIN_VERSION = "1.3.5"

DEFAULT_CONFIG: dict[str, Any] = {
    "steam_web_api_key": "",
    "poll_interval_sec": 60,
    "request_timeout_sec": 10,
    "request_retries": 2,
    "request_retry_delay_sec": 2.0,
    "proxy_url": "",
    "debug_log": False,
    "menu_style": 1,
    "render_as_image": False,
    "render_image_in_notify": False,
    "image_prefer_game_bg": True,
    "image_default_bg_url": "",
    "image_width": 1080,
    "image_height": 608,
    "image_padding": 44,
    "image_font_size": 30,
    "image_line_spacing": 10,
    "image_overlay_alpha": 145,
    "image_text_color": "#F2F5F8",
    "image_font_path": "",
    "image_auto_download_font": False,
    "image_font_dir": "fonts/steamwatch",
    "image_card_alpha": 160,
    "image_card_blur": 12,
    "image_card_padding": 28,
    "image_card_margin": 44,
    "verify_ssl": True,
    "image_font_builtin": True,
    "show_csgo_friend_code": False,
    "use_localized_game_name": False,
    "game_name_language": "schinese",
    "game_name_cache_ttl_sec": 86400,
    "steamids": [],
    "bindings": [],
    "binding_meta": [],
    "notify_targets": [],
    "default_platform_id": "qq_official",
    "default_message_type": "group",
    "notify_group_enabled": False,
    "notify_groups": [],
    "steamid_groups": [],
    "notify_on_stop": False,
    "show_stop_playtime_comment": True,
    "enable_qq_card": True,
    "recall_interaction_card_on_use": False,
    "confirm_destructive": True,
}

CONFIG_LABELS: dict[str, str] = {
    "steam_web_api_key": "Steam Web API 密钥",
    "poll_interval_sec": "监控轮询间隔 (秒)",
    "request_timeout_sec": "网络请求超时 (秒)",
    "request_retries": "网络请求重试次数",
    "proxy_url": "HTTP/Socks 代理地址",
    "verify_ssl": "验证 SSL 证书",
    "notify_group_enabled": "启用分群独立订阅",
    "notify_on_stop": "推送停止游戏 (下播) 通知",
    "show_stop_playtime_comment": "下播附带游玩时长评价",
    "enable_qq_card": "启用 QQ 原生卡片与按钮",
    "confirm_destructive": "关键操作开启二次确认",
    "use_localized_game_name": "游戏名称使用中文本地化",
    "game_name_language": "游戏名称首选语言代码",
    "show_csgo_friend_code": "展示 CS:GO 好友代码",
    "render_as_image": "以磨砂图片形式渲染查询",
    "render_image_in_notify": "通知推送同时渲染图片",
    "debug_log": "打印详细调试日志",
}

CONFIG_SCHEMA: dict[str, dict[str, Any]] = {
    "steam_web_api_key": {
        "type": "string",
        "label": "Steam Web API 密钥",
        "description": "用于请求 Steam 官方 API 获取玩家状态及游戏资料的秘钥 (必填)",
    },
    "poll_interval_sec": {
        "type": "number",
        "label": "监控轮询间隔 (秒)",
        "description": "周期性检查监控号池玩家状态的时间间隔，建议 60",
    },
    "request_timeout_sec": {
        "type": "number",
        "label": "网络请求超时 (秒)",
        "description": "请求 Steam API 与代理的超时时间，建议 10",
    },
    "request_retries": {
        "type": "number",
        "label": "网络请求重试次数",
        "description": "连接失败时的重试次数，建议 2",
    },
    "proxy_url": {
        "type": "string",
        "label": "HTTP/Socks 代理地址",
        "description": "可选的代理服务地址，例如 http://172.17.0.1:7890",
    },
    "verify_ssl": {
        "type": "boolean",
        "label": "验证 SSL 证书",
        "description": "请求时是否严格校验 SSL 证书",
    },
    "notify_group_enabled": {
        "type": "boolean",
        "label": "启用分群独立订阅",
        "description": "按群独立建立监控分组与推送关系，不同群互不干扰",
    },
    "notify_on_stop": {
        "type": "boolean",
        "label": "推送停止游戏通知",
        "description": "玩家退出游戏（下播）时是否发送提示",
    },
    "show_stop_playtime_comment": {
        "type": "boolean",
        "label": "下播附带游玩时长评价",
        "description": "玩家下播时根据单次游玩时长自动附带毒舌或鼓励短评",
    },
    "enable_qq_card": {
        "type": "boolean",
        "label": "启用 QQ 原生卡片与按钮",
        "description": "使用官方 Markdown 卡片与快捷按钮构建交互菜单",
    },
    "confirm_destructive": {
        "type": "boolean",
        "label": "关键操作开启二次确认",
        "description": "移除监控、解除绑定、取消订阅等操作需二次确认",
    },
    "use_localized_game_name": {
        "type": "boolean",
        "label": "游戏名称使用中文本地化",
        "description": "从 Steam 商店拉取中文游戏译名并缓存",
    },
    "render_as_image": {
        "type": "boolean",
        "label": "以磨砂图片形式渲染查询",
        "description": "查询状态时以游戏头图为背景合成磨砂玻璃卡片 (需 Pillow)",
    },
    "debug_log": {
        "type": "boolean",
        "label": "打印详细调试日志",
        "description": "遇到解析与网络异常时输出更详细的堆栈",
    },
}


class SteamWatchPlugin:
    """Steam 监控外部独立插件核心业务类。"""

    PLUGIN_VERSION = PLUGIN_VERSION
    PAGE_BUTTON_TTL = 300
    STEAMID64_BASE = 76561197960265728
    PROFILE_ID_RE = re.compile(r"steamcommunity\.com/profiles/(\d{17})", re.I)
    VANITY_ID_RE = re.compile(r"steamcommunity\.com/id/([^/]+)/?", re.I)
    CSGO_FRIEND_CODE_RE = re.compile(r"^[A-Z0-9]{5}-[A-Z0-9]{4}$")
    FRIEND_CODE_ALPHABET = "ABCDEFGHJKLMNOPQRSTUVWXYZ23456789"
    PERSONA_STATE_TEXT = {0: "离线", 1: "在线", 2: "忙碌", 3: "离开", 4: "打盹", 5: "想交易", 6: "想玩"}
    _ME_WORDS = {"me", "self", "我", "自己"}
    _MODULE_TITLES = {"manage": "管理", "notify": "通知", "query": "查询", "bind": "绑定", "net": "网络"}
    _MODULE_MENUS = {
        "manage": [
            "【管理】监控列表与轮询",
            "/sw add <目标> [分组]  添加监控",
            "/sw remove <目标> [分组]  移除监控",
            "/sw list [页码]  查看监控列表",
            "/sw interval <秒>  设置轮询间隔",
            "/sw status  查看监控状态",
            "/sw preset  应用推荐配置",
        ],
        "notify": [
            "【通知】订阅/分组/清理",
            "/sw sub [分组]  订阅当前会话",
            "/sw unsub [分组]  取消订阅",
            "/sw subinfo  当前会话订阅信息",
            "/sw groupinfo [分组] [页码]  分组详情",
            "/sw grouplist [页码]  分组列表",
            "/sw subclean  清理无效订阅（管理员）",
            "/sw comment on|off  停止推送时长评价",
            "/sw notify_on_stop on|off  停止游戏推送开关",
        ],
        "query": [
            "【查询】查询/解析/状态",
            "/sw query <目标>  快速查询",
            "/sw info <目标>  详细资料（时长/成就）",
            "/sw me  查询自己的绑定",
            "/sw resolve <目标>  解析为 SteamID64/好友码",
        ],
        "bind": [
            "【绑定】绑定/解绑/我的",
            "/sw bind <steamid64|好友码|资料链接|自定义ID>",
            "/sw unbind  解除绑定",
            "/sw me  查询自己的绑定",
        ],
        "net": [
            "【网络】连通性测试",
            "/sw test  Steam API 访问测试",
            "/sw proxytest  代理连通测试",
        ],
    }
    _MODULE_BUTTONS: dict[str, list[tuple[str, str, int, bool]]] = {
        "manage": [
            ("监控状态", "/sw status", 1, True),
            ("监控列表", "/sw list", 1, True),
            ("推荐配置", "/sw preset", 1, True),
            ("设置轮询", "/sw interval ", 2, False),
        ],
        "notify": [
            ("订阅本会话", "/sw sub", 1, True),
            ("取消订阅", "/sw unsub", 1, True),
            ("订阅信息", "/sw subinfo", 1, True),
            ("分组列表", "/sw grouplist", 1, True),
            ("订阅分组", "/sw sub ", 2, False),
        ],
        "query": [
            ("查询自己", "/sw query me", 1, True),
            ("我的资料", "/sw info me", 1, True),
            ("解析目标", "/sw resolve ", 2, False),
            ("查询他人", "/sw query ", 2, False),
            ("详细资料", "/sw info ", 2, False),
        ],
        "bind": [
            ("我的绑定", "/sw me", 1, True),
            ("解除绑定", "/sw unbind", 1, True),
            ("绑定账号", "/sw bind ", 2, False),
        ],
        "net": [
            ("API 测试", "/sw test", 1, True),
            ("代理测试", "/sw proxytest", 1, True),
        ],
    }

    def __init__(self, context: Any) -> None:
        self.context = context
        self.config_dir = getattr(context, "config_dir", Path("config"))
        self.data_dir = getattr(context, "data_dir", Path("data"))
        self.cache_dir = self.data_dir / "cache"
        self.cache_dir.mkdir(parents=True, exist_ok=True)
        self.config: dict[str, Any] = dict(DEFAULT_CONFIG)
        self._load_config()

        self._last_state: dict[str, tuple[bool, str, str | None]] = {}
        self._session_start: dict[str, float] = {}
        self._app_name_cache: dict[str, tuple[str, float]] = {}
        self._last_poll_at = 0.0
        self._confirm_tokens: dict[str, dict[str, Any]] = {}
        self._consumed_confirm_tokens: dict[str, float] = {}
        self._transport: httpx.AsyncBaseTransport | None = None

    def _load_config(self) -> None:
        self.config_dir.mkdir(parents=True, exist_ok=True)
        cfg_file = self.config_dir / "config.json"
        if cfg_file.is_file():
            try:
                mtime = cfg_file.stat().st_mtime
                if mtime != getattr(self, "_config_mtime", 0.0):
                    loaded = json.loads(cfg_file.read_text(encoding="utf-8"))
                    if isinstance(loaded, dict):
                        for k, v in loaded.items():
                            if k in DEFAULT_CONFIG:
                                self.config[k] = v
                        self._config_mtime = mtime
            except Exception as e:
                logger.warning("读取 SteamWatch config.json 失败: %s", e)

    def _cfg(self, key: str) -> Any:
        self._load_config()
        return self.config.get(key, DEFAULT_CONFIG.get(key))

    def _save_config(self) -> None:
        self.config_dir.mkdir(parents=True, exist_ok=True)
        cfg_file = self.config_dir / "config.json"
        try:
            cfg_file.write_text(json.dumps(self.config, ensure_ascii=False, indent=2), encoding="utf-8")
        except Exception as e:
            logger.warning("保存 SteamWatch config.json 失败: %s", e)

    async def set_config(self, key: str, value: Any) -> None:
        self.config[key] = value
        self._save_config()
        await self._write_page_snapshot()

    # ---------- 原生 UI 快照与动作 ----------

    async def _write_page_snapshot(self) -> None:
        """导出声明式原生 UI 控制台所需的快照数据。"""
        out_dir = self.data_dir
        out_dir.mkdir(parents=True, exist_ok=True)
        snapshot_file = out_dir / "page_overview.json"
        nested = self.data_dir / "plugin-data"
        if nested.is_dir():
            shutil.rmtree(nested, ignore_errors=True)

        bindings_list = []
        for raw in self._cfg("bindings"):
            parts = str(raw).split(":")
            if len(parts) >= 2 and parts[-1]:
                bindings_list.append({"owner": self._bare_user(":".join(parts[:-1])), "steamid": parts[-1]})

        steamids = [str(item) for item in self._cfg("steamids")]
        notify_targets = [str(item) for item in self._cfg("notify_targets")]
        groups = self._notify_groups()
        has_key = bool(str(self._cfg("steam_web_api_key") or "").strip())

        service_status = "configured" if has_key else "missing_key"
        snapshot = {
            "updated_at": datetime.datetime.now(datetime.UTC).isoformat(),
            "config": dict(self.config),
            "schema": CONFIG_SCHEMA,
            "labels": CONFIG_LABELS,
            "stats": {
                "监控玩家数": len(steamids),
                "全局订阅会话": len(notify_targets),
                "订阅分组数": len(groups),
                "已绑定用户": len(bindings_list),
            },
            "service": {
                "服务状态": "正常连接" if has_key else "未配置 Key",
                "轮询周期": f"{self._cfg('poll_interval_sec')} 秒",
                "代理配置": "已启用代理" if bool(self._cfg("proxy_url")) else "未配置代理",
            },
            "bindings": bindings_list,
            "steamids": steamids,
            "notify_targets": notify_targets,
            "groups": {name: len(members) for name, members in groups.items()},
        }
        try:
            snapshot_file.write_text(json.dumps(snapshot, ensure_ascii=False, indent=2), encoding="utf-8")
        except Exception as e:
            logger.warning("写入 plugin.sw page_overview.json 失败: %s", e)

    async def on_page_action(self, action: str, payload: dict[str, Any]) -> dict[str, Any]:
        """处理原生 UI 页面提交的配置或操作。"""
        if action in {"save_config", "config"}:
            updates = payload.get("config") or payload
            if isinstance(updates, dict):
                for k, v in updates.items():
                    if k in DEFAULT_CONFIG:
                        self.config[k] = v
                self._save_config()
                await self._write_page_snapshot()
                return {"saved": True, "config": self.config}
        if action in {"page_data", "data"}:
            bindings_list = []
            for item in self._cfg("bindings") or []:
                if isinstance(item, str) and ":" in item:
                    owner, sid = item.split(":", 1)
                    bindings_list.append({"owner": owner.strip(), "steamid": sid.strip()})
                elif isinstance(item, dict):
                    bindings_list.append(item)
            return {
                "bindings": bindings_list,
                "steamids": list(self._cfg("steamids") or []),
                "notify_targets": list(self._cfg("notify_targets") or []),
            }

        if action in {"rebind", "bind"}:
            owner = str(payload.get("owner") or "").strip()
            steamid_raw = str(payload.get("steamid") or "").strip()
            parsed = self._steamid(steamid_raw)
            if not owner or not parsed:
                return {"success": False, "error": "用户标识或 SteamID 无效"}
            bindings = [item for item in self._cfg("bindings") if self._binding_owner(item) != self._bare_user(owner)]
            bindings.append(f"{self._bare_user(owner)}:{parsed}")
            await self.set_config("bindings", bindings)
            await self._write_page_snapshot()
            return {"success": True, "bindings": self._cfg("bindings")}

        if action in {"remove_binding", "unbind"}:
            owner = self._bare_user(str(payload.get("owner") or "").strip())
            if not owner:
                return {"success": False, "error": "用户标识无效"}
            bindings = [item for item in self._cfg("bindings") if self._binding_owner(item) != owner]
            await self.set_config("bindings", bindings)
            await self._write_page_snapshot()
            return {"success": True, "bindings": bindings}

        if action in {"add_notify_target", "sub"}:
            target = str(payload.get("target") or "").strip()
            if not target:
                return {"success": False, "error": "订阅目标不能为空"}
            targets = list(self._cfg("notify_targets") or [])
            if target not in targets:
                targets.append(target)
                await self.set_config("notify_targets", targets)
                await self._write_page_snapshot()
            return {"success": True, "notify_targets": targets}

        if action in {"remove_notify_target", "unsub"}:
            target = str(payload.get("target") or "").strip()
            if not target:
                return {"success": False, "error": "目标不能为空"}
            targets = [t for t in (self._cfg("notify_targets") or []) if t != target]
            await self.set_config("notify_targets", targets)
            await self._write_page_snapshot()
            return {"success": True, "notify_targets": targets}

        if action in {"add_steamid", "add_target"}:
            steamid_raw = str(payload.get("steamid") or "").strip()
            parsed = self._steamid(steamid_raw)
            if not parsed:
                return {"success": False, "error": "SteamID 无效"}
            sids = list(self._cfg("steamids") or [])
            if parsed not in sids:
                sids.append(parsed)
                await self.set_config("steamids", sids)
                await self._write_page_snapshot()
            return {"success": True, "steamids": sids}

        if action in {"remove_steamid", "remove_target"}:
            target = str(payload.get("steamid") or "").strip()
            sids = [s for s in (self._cfg("steamids") or []) if s != target]
            await self.set_config("steamids", sids)
            await self._write_page_snapshot()
            return {"success": True, "steamids": sids}

        if action in {"page_delete"}:
            kind = str(payload.get("kind") or "")
            identifier = str(payload.get("identifier") or payload.get("id") or "").strip()
            if kind == "binding":
                bindings = [item for item in self._cfg("bindings") if self._binding_owner(item) != self._bare_user(identifier)]
                await self.set_config("bindings", bindings)
                await self._write_page_snapshot()
                return {"success": True, "deleted": identifier}
            elif kind == "notify_target":
                targets = [t for t in (self._cfg("notify_targets") or []) if t != identifier]
                await self.set_config("notify_targets", targets)
                await self._write_page_snapshot()
                return {"success": True, "deleted": identifier}
            elif kind == "steamid":
                sids = [s for s in (self._cfg("steamids") or []) if s != identifier]
                await self.set_config("steamids", sids)
                await self._write_page_snapshot()
                return {"success": True, "deleted": identifier}
            return {"success": False, "error": f"未知删除类型: {kind}"}

        if action in {"test_api", "test"}:
            try:
                players = await self._summaries([])
                return {"success": True, "message": f"Steam API 正常，连接成功。"}
            except Exception as error:
                return {"success": False, "error": str(error)}

        return {"error": f"未知操作: {action}"}

    # ---------- Steam ID / 好友码 / 账号辅助解析 ----------

    @staticmethod
    def _steamid(value: str) -> str | None:
        text = str(value or "").strip()
        if text.isdigit() and len(text) >= 16:
            return text
        if text.isdigit():
            number = int(text)
            return str(number + SteamWatchPlugin.STEAMID64_BASE) if number < 76561197960265728 else text
        return None

    @staticmethod
    def _account_id(steamid: str) -> str:
        try:
            return str(int(steamid) - SteamWatchPlugin.STEAMID64_BASE)
        except (ValueError, TypeError):
            return str(steamid)

    @classmethod
    def _decode_friend_code(cls, code: str) -> str:
        text = code.replace("-", "").upper()
        if len(text) != 9:
            raise ValueError("length")
        steamid = 0
        for index, char in enumerate(reversed(text)):
            digit = cls.FRIEND_CODE_ALPHABET.find(char)
            if digit < 0:
                raise ValueError("character")
            steamid += digit << (index * 5)
        return str(steamid + cls.STEAMID64_BASE)

    @staticmethod
    def _bare_user(value: str) -> str:
        text = str(value or "").strip()
        return text[len("qq_official:"):] if text.startswith("qq_official:") else text

    def _binding_owner(self, raw: str) -> str:
        parts = str(raw).split(":")
        return self._bare_user(":".join(parts[:-1])) if len(parts) >= 2 else ""

    def _bindings(self) -> dict[str, str]:
        result: dict[str, str] = {}
        for raw in self._cfg("bindings"):
            parts = str(raw).split(":")
            if len(parts) < 2 or not parts[-1]:
                continue
            result[self._bare_user(":".join(parts[:-1]))] = parts[-1]
        return result

    def _binding_meta(self) -> dict[str, str]:
        result: dict[str, str] = {}
        for raw in self._cfg("binding_meta"):
            parts = str(raw).split(":", 1)
            if len(parts) == 2:
                result[self._bare_user(parts[0])] = parts[1]
        return result

    def _user_keys(self, context: MessageContext) -> list[str]:
        keys: list[str] = []
        for k in (context.sender_id, getattr(context, "user_id", None), getattr(context, "member_openid", None)):
            val = str(k or "").strip()
            if val and val not in keys:
                keys.append(val)
        return keys

    def _user_key(self, context: MessageContext) -> str:
        keys = self._user_keys(context)
        return keys[0] if keys else (context.sender_id or "")

    def _get_user_binding(self, context: MessageContext) -> str | None:
        bindings = self._bindings()
        for key in self._user_keys(context):
            steamid = bindings.get(self._bare_user(key))
            if steamid:
                return steamid
        return None

    def _notify_groups(self) -> dict[str, list[str]]:
        result: dict[str, list[str]] = {}
        for raw in self._cfg("notify_groups"):
            parts = str(raw).split(":", 1)
            if len(parts) == 2 and parts[0]:
                result.setdefault(parts[0], []).append(parts[1])
        return result

    def _steamid_groups(self) -> dict[str, list[str]]:
        result: dict[str, list[str]] = {}
        for raw in self._cfg("steamid_groups"):
            parts = str(raw).split(":", 1)
            if len(parts) == 2 and parts[0]:
                if parts[1] not in result.setdefault(parts[0], []):
                    result[parts[0]].append(parts[1])
        return result

    @staticmethod
    def _valid_group_name(name: str) -> bool:
        return bool(name) and ":" not in name

    @staticmethod
    def _paginate(items: list, page: int, size: int) -> tuple[int, list, int]:
        pages = max(1, (len(items) + size - 1) // size)
        page = min(max(1, page), pages)
        start = (page - 1) * size
        return page, items[start:start + size], pages

    @staticmethod
    def _page_arg(args: list[str]) -> int:
        for index, value in enumerate(args):
            if value in {"--page", "-p"} and index + 1 < len(args):
                try:
                    return max(1, int(args[index + 1]))
                except ValueError:
                    return 1
        try:
            return max(1, int(args[-1])) if args else 1
        except ValueError:
            return 1

    def _mention_candidate_ids(self, context: MessageContext, raw: str) -> list[str]:
        candidates: list[str] = []
        for item in getattr(context, "mentions", []):
            if not isinstance(item, dict):
                continue
            for id_field in ("id", "user_id", "user_openid", "member_openid", "openid"):
                identifier = str(item.get(id_field) or "").strip()
                if identifier and identifier not in {getattr(context, "bot_id", ""), "unknown_selfid"} and identifier not in candidates:
                    candidates.append(identifier)
        match = re.search(r"<@!?([A-Za-z0-9_-]{6,64})>", raw or "")
        if match and match.group(1) not in candidates:
            candidates.append(match.group(1))
        return candidates

    async def _resolve_target(self, context: MessageContext, raw: str) -> tuple[str | None, str | None]:
        text = str(raw or "").strip()
        if not text:
            return None, "用法：<steamid64|profile_url|vanity|好友码|me|@用户>"
        if text.startswith(("@", "＠", "<@")):
            candidate_ids = self._mention_candidate_ids(context, text)
            clean_name = re.sub(r"^[@＠<!]+", "", text).rstrip(">").strip()
            bindings = self._bindings()
            binding_meta = self._binding_meta()

            for uid in candidate_ids:
                steamid = bindings.get(self._bare_user(uid))
                if steamid:
                    return steamid, None

            if clean_name:
                nick_matches = [uid for uid, nick in binding_meta.items() if nick == clean_name]
                for uid in nick_matches:
                    steamid = bindings.get(self._bare_user(uid))
                    if steamid:
                        return steamid, None

            for item in getattr(context, "mentions", []):
                if isinstance(item, dict):
                    m_nick = str(item.get("nickname") or item.get("username") or item.get("nick") or "").strip()
                    if m_nick:
                        nick_matches = [uid for uid, nick in binding_meta.items() if nick == m_nick]
                        for uid in nick_matches:
                            steamid = bindings.get(self._bare_user(uid))
                            if steamid:
                                return steamid, None

            target_display = clean_name or (candidate_ids[0] if candidate_ids else text)
            return None, f"未找到用户 {target_display} 的绑定记录。请先让该用户使用 /sw bind 绑定。"

        if text.lower() in self._ME_WORDS:
            steamid = self._get_user_binding(context)
            if steamid:
                return steamid, None
            return None, "你还未绑定 SteamID。使用 /sw bind 进行绑定。"
        if text.isdigit() and len(text) == 17:
            return text, None
        profile = self.PROFILE_ID_RE.search(text)
        if profile:
            return profile.group(1), None
        if self.CSGO_FRIEND_CODE_RE.match(text.upper()):
            try:
                return self._decode_friend_code(text), None
            except ValueError:
                return None, "好友码无效。"
        if text.isdigit() and len(text) <= 10:
            return str(int(text) + self.STEAMID64_BASE), None
        vanity = self.VANITY_ID_RE.search(text)
        if vanity:
            return await self._resolve_vanity(vanity.group(1))
        if "/" in text:
            candidate = text.rstrip("/")
            candidate = candidate.split("/")[-1] if candidate else ""
            if candidate:
                return self._steamid(candidate), None
        steamid = self._steamid(text)
        return (steamid, None) if steamid else (None, "无法解析 SteamID。")

    async def _resolve_vanity(self, vanity: str) -> tuple[str | None, str | None]:
        key = str(self._cfg("steam_web_api_key") or "")
        if not key:
            return None, "解析自定义链接需要 Steam Web API Key。"
        try:
            async with self._http_client(10, follow_redirects=True) as client:
                response = await client.get(
                    "https://api.steampowered.com/ISteamUser/ResolveVanityURL/v0001/",
                    params={"key": key, "vanityurl": vanity},
                )
            data = response.json().get("response", {}) if response.status_code == 200 else {}
            if data.get("success") == 1 and data.get("steamid"):
                return str(data["steamid"]), None
        except (httpx.HTTPError, ValueError):
            return None, "解析自定义链接失败。"
        return None, "无法解析自定义链接。"

    def _http_client(self, timeout: float, *, follow_redirects: bool = False) -> httpx.AsyncClient:
        options: dict[str, Any] = {
            "timeout": timeout,
            "verify": bool(self._cfg("verify_ssl")),
            "follow_redirects": follow_redirects,
        }
        if self._transport is not None:
            options["transport"] = self._transport
        else:
            options["proxy"] = str(self._cfg("proxy_url") or "") or None
        return httpx.AsyncClient(**options)

    async def _summaries(self, ids: list[str]) -> list[dict[str, Any]]:
        key = str(self._cfg("steam_web_api_key") or "")
        if not key:
            raise ValueError("尚未配置 Steam Web API Key")
        params = {"key": key, "steamids": ",".join(ids), "format": "json"}
        retries = max(2, max(0, int(self._cfg("request_retries") or 0)))
        delay = max(1.0, float(self._cfg("request_retry_delay_sec") or 1.0))
        last_error: Exception | None = None
        for attempt in range(retries + 1):
            try:
                async with self._http_client(float(self._cfg("request_timeout_sec"))) as client:
                    response = await client.get(
                        "https://api.steampowered.com/ISteamUser/GetPlayerSummaries/v0002/", params=params
                    )
                if response.status_code != 200:
                    raise ValueError(f"Steam API HTTP {response.status_code}")
                data = response.json()
                players = data.get("response", {}).get("players", []) if isinstance(data, dict) else []
                return [item for item in players if isinstance(item, dict)]
            except (httpx.HTTPError, ValueError) as error:
                last_error = error
                if attempt < retries:
                    await asyncio.sleep(delay * (attempt + 1))
        hint = "（代理连接失败，请检查 proxy_url 是否稳定）" if self._cfg("proxy_url") else ""
        raise ValueError(f"Steam API 连接失败{hint}（{type(last_error).__name__}）") from last_error

    # ---------- 菜单与交互卡片 ----------

    @staticmethod
    def _button_rows(quick: list[tuple[str, str, int, bool]], ttl: int) -> list[list[Button]]:
        width = 3
        rows: list[list[Button]] = []
        for start in range(0, len(quick), width):
            row = []
            for label, command, action_type, enter in quick[start:start + width]:
                row.append(Button(label, command, action_type=action_type, enter=enter, expires_after_seconds=ttl))
            rows.append(row)
        return rows

    def _module_menu_card(self, module: str) -> Card:
        order = ["manage", "notify", "query", "bind", "net"]
        titles = self._MODULE_TITLES
        index = order.index(module)
        rows: list[list[Button]] = self._button_rows(self._MODULE_BUTTONS.get(module, []), self.PAGE_BUTTON_TTL)
        body_lines = [f"**SteamWatch · {titles[module]}模块**", "", *self._MODULE_MENUS[module]]
        key_state = "" if self._cfg("steam_web_api_key") else "\n\n> ⚠️ 尚未配置 Steam Web API Key"
        rows.append([
            Button("« 主菜单", "/sw", action_type=1, expires_after_seconds=self.PAGE_BUTTON_TTL),
            Button(f"« {titles[order[(index - 1) % len(order)]]}", f"/sw menu {order[(index - 1) % len(order)]}", action_type=1, expires_after_seconds=self.PAGE_BUTTON_TTL),
            Button(f"{titles[order[(index + 1) % len(order)]]} »", f"/sw menu {order[(index + 1) % len(order)]}", action_type=1, expires_after_seconds=self.PAGE_BUTTON_TTL),
        ])
        return Card(f"SteamWatch {titles[module]}", "\n".join(body_lines) + key_state, rows=rows)

    def _menu_hierarchy_card(self) -> Card:
        rows = [
            [
                Button("📊 状态查询", "/sw menu query", action_type=1, expires_after_seconds=self.PAGE_BUTTON_TTL),
                Button("🔔 订阅推送", "/sw menu notify", action_type=1, expires_after_seconds=self.PAGE_BUTTON_TTL),
                Button("🔗 账号绑定", "/sw menu bind", action_type=1, expires_after_seconds=self.PAGE_BUTTON_TTL),
            ],
            [
                Button("⚙️ 监控管理", "/sw menu manage", action_type=1, expires_after_seconds=self.PAGE_BUTTON_TTL),
                Button("🌐 网络连通", "/sw menu net", action_type=1, expires_after_seconds=self.PAGE_BUTTON_TTL),
                Button("📖 完整帮助", "/sw fullmenu", action_type=1, expires_after_seconds=self.PAGE_BUTTON_TTL),
            ],
            [
                Button("👤 我的状态", "/sw me", action_type=1, expires_after_seconds=self.PAGE_BUTTON_TTL),
                Button("📋 详细资料", "/sw info me", action_type=1, expires_after_seconds=self.PAGE_BUTTON_TTL),
                Button("🔗 绑定账号", "/sw bind ", action_type=2, enter=False, expires_after_seconds=self.PAGE_BUTTON_TTL),
            ],
            [
                Button("📜 监控列表", "/sw list", action_type=1, expires_after_seconds=self.PAGE_BUTTON_TTL),
                Button("📢 当前订阅", "/sw subinfo", action_type=1, expires_after_seconds=self.PAGE_BUTTON_TTL),
                Button("➕ 添加监控", "/sw add ", action_type=2, enter=False, expires_after_seconds=self.PAGE_BUTTON_TTL),
            ],
        ]
        key_state = "已配置 API Key" if self._cfg("steam_web_api_key") else "未配置 API Key"
        group_state = "分组订阅已启用" if self._cfg("notify_group_enabled") else "分组订阅未启用"
        return Card(
            "SteamWatch",
            "## SteamWatch 菜单\n\n"
            "**目标格式**：steamid64 / 好友码 / 资料链接 / 自定义ID / me / @绑定用户\n\n"
            f"**状态**：{key_state}；{group_state}\n\n"
            "点击顶部模块按钮进入分级子菜单，或使用下方快捷按钮快速操作。",
            rows=rows,
        )

    def _query_card(self, title: str, text: str, steamid: str, *, detailed: bool) -> Card:
        rows = [
            [
                Button("👤 简要状态" if detailed else "📋 详细资料", f"/sw query {steamid}" if detailed else f"/sw info {steamid}", action_type=1, expires_after_seconds=self.PAGE_BUTTON_TTL),
                Button("🔄 刷新", f"/sw info {steamid}" if detailed else f"/sw query {steamid}", action_type=1, expires_after_seconds=self.PAGE_BUTTON_TTL),
                Button("🔍 查其他人", "/sw query ", action_type=2, enter=False, expires_after_seconds=self.PAGE_BUTTON_TTL),
            ],
            [
                Button("« 主菜单", "/sw", action_type=1, expires_after_seconds=self.PAGE_BUTTON_TTL),
            ],
        ]
        return Card(title, f"## {title}\n\n{text}", rows=rows)

    def _full_menu_text(self) -> str:
        lines = [
            "========== SteamWatch 菜单 ==========",
            "简化入口：/sw <模块>",
            "模块列表：manage / notify / query / bind / net",
            "--------------------------------------",
            "目标格式：steamid64 | 好友码 | 资料链接 | 自定义ID | me | @绑定用户",
            "--------------------------------------",
            *self._MODULE_MENUS["manage"],
            *self._MODULE_MENUS["notify"],
            *self._MODULE_MENUS["query"],
            *self._MODULE_MENUS["bind"],
            *self._MODULE_MENUS["net"],
            "--------------------------------------",
            "示例：/sw query me",
        ]
        return "\n".join(lines)

    # ---------- 二次确认 ----------

    _CONFIRM_TTL_SEC = 300

    def _store_confirmation(self, context: MessageContext, action: str, args: list[str], *, admin: bool) -> str:
        now = time.time()
        self._confirm_tokens = {k: v for k, v in self._confirm_tokens.items() if float(v.get("expires", 0)) > now}
        self._consumed_confirm_tokens = {k: exp for k, exp in self._consumed_confirm_tokens.items() if exp > now}
        nonce = uuid.uuid4().hex[:20]
        target = f"{getattr(context, 'scene', '') or getattr(context, 'conversation_type', '')}:{context.conversation_id}"
        self._confirm_tokens[nonce] = {
            "action": action,
            "args": [str(item) for item in args],
            "actor": self._user_key(context),
            "target": target,
            "admin": bool(admin),
            "expires": now + self._CONFIRM_TTL_SEC,
        }
        return nonce

    def _consume_confirmation(self, context: MessageContext, nonce: str) -> tuple[dict[str, Any] | None, str]:
        now = time.time()
        self._confirm_tokens = {k: v for k, v in self._confirm_tokens.items() if float(v.get("expires", 0)) > now}
        self._consumed_confirm_tokens = {k: exp for k, exp in self._consumed_confirm_tokens.items() if exp > now}
        nonce = str(nonce or "").strip()
        record = self._confirm_tokens.get(nonce)
        if not record:
            if nonce in self._consumed_confirm_tokens:
                return None, "replayed"
            return None, "expired_or_unknown"
        if float(record.get("expires", 0)) <= now:
            self._confirm_tokens.pop(nonce, None)
            return None, "expired"
        actor = self._user_key(context)
        if str(record.get("actor")) != str(actor):
            return None, "wrong_clicker"
        target = f"{getattr(context, 'scene', '') or getattr(context, 'conversation_type', '')}:{context.conversation_id}"
        if str(record.get("target")) != target:
            return None, "wrong_conversation"
        if record.get("admin") and not getattr(context, "is_admin", False):
            return None, "unauthorized"
        self._confirm_tokens.pop(nonce, None)
        self._consumed_confirm_tokens[nonce] = now + self._CONFIRM_TTL_SEC
        return record, ""

    def _confirmation_reply(self, error: str) -> str:
        replies = {
            "replayed": "该确认凭据已被使用过，请重新发起操作。",
            "expired": "确认已超时，请重新发起操作。",
            "wrong_clicker": "这条确认指令不是发给你的。",
            "wrong_conversation": "请回到发起操作的会话中完成确认。",
            "unauthorized": "该确认指令需要管理员权限。",
        }
        return replies.get(error, "确认凭据无效或已过期，请重新发起操作。")

    def _confirm_card(self, title: str, text: str, nonce: str) -> Card | str:
        if not bool(self._cfg("enable_qq_card")):
            return f"需要二次确认。请在 5 分钟内发送：/sw confirm {nonce}"
        rows = [[
            Button("确认执行", f"/sw confirm {nonce}", action_type=1, enter=True, expires_after_seconds=self._CONFIRM_TTL_SEC),
            Button("取消", "/sw", action_type=1, expires_after_seconds=self._CONFIRM_TTL_SEC),
        ]]
        return Card(title, f"**{title}**\n\n{text}\n\n> 该确认 5 分钟内有效，仅限你本人点击。", rows=rows)

    async def _execute_confirmed_action(self, context: MessageContext, record: dict[str, Any]) -> str:
        action = str(record.get("action") or "")
        args = [str(item) for item in record.get("args", [])]
        if action == "remove":
            return await self._remove_steamid(context, args[0] if args else "", args[1] if len(args) > 1 else "", confirmed=True)
        if action == "unbind":
            return await self._unbind(context, confirmed=True)
        if action == "unsubscribe":
            return await self._subscribe(context, "unsubscribe", args[0] if args else "", confirmed=True)
        if action == "subclean":
            return await self._subclean(context, confirmed=True)
        return "确认操作无效。"

    # ---------- 命令入口与清洗 ----------

    def _clean_args(self, context: MessageContext, args: list[str]) -> list[str]:
        values = [str(item) for item in args if str(item)]
        bot_id = getattr(context, "bot_id", "")
        if getattr(context, "mentions", None) and bot_id:
            for index, item in enumerate(values):
                normalized = item.lstrip("/").lower()
                if normalized in {"sw", "steamwatch"} or normalized.startswith("steamwatch_"):
                    values = values[index:]
                    break
        return values

    async def command(self, context: MessageContext, args: list[str]) -> Any:
        args = self._clean_args(context, args)
        command_parts = str(context.text or "").lstrip().split(maxsplit=1)
        invoked = command_parts[0].lstrip("/").lower() if command_parts else ""

        alias_actions = {
            "steamwatch_add": "add", "steamwatch_remove": "remove", "steamwatch_list": "list",
            "steamwatch_interval": "interval", "steamwatch_subscribe": "subscribe",
            "steamwatch_unsubscribe": "unsubscribe", "steamwatch_query": "query", "steamwatch_info": "info",
            "steamwatch_test": "test", "steamwatch_status": "status", "steamwatch_bind": "bind",
            "steamwatch_unbind": "unbind", "steamwatch_me": "me", "steamwatch_menu": "menu",
            "steamwatch_comment": "comment", "steamwatch_subinfo": "subinfo",
            "steamwatch_groupinfo": "groupinfo", "steamwatch_grouplist": "grouplist", "steamwatch_subclean": "subclean",
            "steamwatch_resolve": "resolve", "steamwatch_proxytest": "proxytest", "steamwatch_preset": "preset",
            "steamwatch_sub": "sub", "steamwatch_unsub": "unsub",
            "steamwatch_notify_on_stop": "notify_on_stop", "steamwatch_confirm": "confirm",
        }
        if invoked in alias_actions:
            action, rest = alias_actions[invoked], args
        else:
            action = args[0].lower() if args else "menu"
            rest = args[1:]

        if action in {"menu", "help"}:
            if rest and rest[0] in self._MODULE_TITLES:
                return self._module_menu_card(rest[0])
            return self._menu_hierarchy_card()

        if action in {"manage", "notify", "query", "bind", "net"} and not rest:
            return self._module_menu_card(action)

        if action in {"bind"}:
            target_text = rest[0] if rest else ""
            if not target_text:
                if self._cfg("enable_qq_card"):
                    rows = [
                        [
                            Button("🔗 填入绑定指令", "/sw bind ", action_type=2, enter=False, expires_after_seconds=self.PAGE_BUTTON_TTL),
                            Button("📖 绑定说明", "/sw menu bind", action_type=1, expires_after_seconds=self.PAGE_BUTTON_TTL),
                        ],
                        [
                            Button("« 主菜单", "/sw", action_type=1, expires_after_seconds=self.PAGE_BUTTON_TTL),
                        ],
                    ]
                    return Card("绑定 Steam 账号", "用法：`/sw bind <steamid64|profile_url|vanity|好友码>`\n\n点击下方按钮填入指令并补充参数。", rows=rows)
                return "用法：/sw bind <steamid64|profile_url|vanity|好友码>"
            steamid, error = await self._resolve_target(context, target_text)
            if not steamid:
                return error or "无法解析 SteamID。"
            nickname = getattr(context, "sender_name", "") or ""
            user_keys = self._user_keys(context)
            user_keys_bare = {self._bare_user(k) for k in user_keys}
            meta_entries = [item for item in self._cfg("binding_meta") if self._bare_user(str(item).split(":", 1)[0]) not in user_keys_bare]
            if nickname:
                for uk in user_keys:
                    meta_entries.append(f"{uk}:{nickname}")
            await self.set_config("binding_meta", meta_entries)
            others = [f"{self._binding_owner(item)}:{str(item).split(':')[-1]}"
                      for item in self._cfg("bindings") if self._binding_owner(item) and self._binding_owner(item) not in user_keys_bare]
            new_bindings = [*others]
            for uk in user_keys:
                new_bindings.append(f"{uk}:{steamid}")
            await self.set_config("bindings", new_bindings)
            suffix = f"（好友码 {self._account_id(steamid)}）" if self._cfg("show_csgo_friend_code") else ""
            if self._cfg("enable_qq_card"):
                rows = [
                    [
                        Button("👤 我的状态", "/sw me", action_type=1, expires_after_seconds=self.PAGE_BUTTON_TTL),
                        Button("📋 详细资料", "/sw info me", action_type=1, expires_after_seconds=self.PAGE_BUTTON_TTL),
                    ],
                    [
                        Button("« 主菜单", "/sw", action_type=1, expires_after_seconds=self.PAGE_BUTTON_TTL),
                    ],
                ]
                return Card("Steam 绑定成功", f"已绑定 SteamID：**{steamid}**{suffix}。\n\n现在你可以随时查看自己的游戏状态和详细数据。", rows=rows)
            return f"已绑定 SteamID：{steamid}{suffix}"

        if action in {"confirm", "确认"}:
            nonce = rest[0] if rest else ""
            record, error = self._consume_confirmation(context, nonce)
            if record is None:
                return self._confirmation_reply(error)
            return await self._execute_confirmed_action(context, record)

        if action == "unbind":
            return await self._unbind(context)

        if action == "me":
            steamid = self._get_user_binding(context)
            if not steamid:
                if self._cfg("enable_qq_card"):
                    rows = [
                        [
                            Button("🔗 立即绑定账号", "/sw bind ", action_type=2, enter=False, expires_after_seconds=self.PAGE_BUTTON_TTL),
                            Button("📖 绑定说明", "/sw menu bind", action_type=1, expires_after_seconds=self.PAGE_BUTTON_TTL),
                        ],
                        [
                            Button("« 主菜单", "/sw", action_type=1, expires_after_seconds=self.PAGE_BUTTON_TTL),
                        ],
                    ]
                    return Card(
                        "未绑定 Steam 账号",
                        "你还没有绑定 SteamID。\n\n绑定后可通过 `/sw me` 随时查看游戏状态与在线情况。\n支持 SteamID64、个人主页链接、自定义 URL 或好友码。",
                        rows=rows,
                    )
                return "你还没有绑定 SteamID。"
            result = await self._query(steamid, detailed=False)
            if self._cfg("enable_qq_card") and not result.startswith(("Steam 查询失败", "没有找到", "请输入")):
                return self._query_card("Steam 状态查询", result, steamid, detailed=False)
            return result

        if action == "query":
            steamid, error = await self._resolve_target(context, rest[0] if rest else "me")
            if not steamid:
                return error or "无法解析 SteamID。"
            result = await self._query(steamid, detailed=False)
            if self._cfg("enable_qq_card") and not result.startswith(("Steam 查询失败", "没有找到", "请输入")):
                return self._query_card("Steam 状态查询", result, steamid, detailed=False)
            return result

        if action == "info":
            steamid, error = await self._resolve_target(context, rest[0] if rest else "me")
            if not steamid:
                return error or "无法解析 SteamID。"
            result = await self._query(steamid, detailed=True)
            if self._cfg("enable_qq_card") and not result.startswith(("Steam 查询失败", "没有找到", "请输入")):
                return self._query_card("Steam 详细资料", result, steamid, detailed=True)
            return result

        if action in {"add", "remove", "list"}:
            if not getattr(context, "is_admin", False):
                return "只有管理员可以修改监控列表。"
            if action in {"add", "list"}:
                return await self._add_or_list(context, action, rest)
            steamid, error = await self._resolve_target(context, rest[0] if rest else "")
            if not steamid:
                return error or "请输入有效 SteamID。"
            group = str(rest[1]).strip() if len(rest) > 1 else ""
            return await self._remove_steamid(context, steamid, group)

        if action == "interval":
            if not getattr(context, "is_admin", False):
                return "只有管理员可以修改轮询间隔。"
            try:
                seconds = int(rest[0])
            except (IndexError, ValueError):
                return f"当前轮询间隔：{self._cfg('poll_interval_sec')} 秒。"
            if seconds < 30 or seconds > 86400:
                return "轮询间隔需在 30-86400 秒之间。"
            await self.set_config("poll_interval_sec", seconds)
            return f"轮询间隔已设置为 {seconds} 秒。"

        if action in {"subscribe", "sub", "unsubscribe", "unsub"}:
            sub_action = "subscribe" if action in {"subscribe", "sub"} else "unsubscribe"
            return await self._subscribe(context, sub_action, str(rest[0]).strip() if rest else "")

        if action in {"subinfo", "sub_info"}:
            scene = getattr(context, "scene", None) or getattr(context, "conversation_type", None) or "group"
            target = f"{scene}:{context.conversation_id}"
            lines = []
            if target in [str(item) for item in self._cfg("notify_targets")]:
                lines.append("本会话已订阅全局通知。")
            for group, members in self._notify_groups().items():
                if target in members:
                    lines.append(f"本会话已订阅分组：{group}")
            return "\n".join(lines) if lines else "当前会话没有订阅。"

        if action in {"groupinfo", "group_info"}:
            groups = self._notify_groups()
            if not groups:
                return "当前没有分组订阅。"
            name = str(rest[0]).strip() if rest else ""
            if name:
                members = groups.get(name)
                if members is None:
                    return f"分组 {name} 不存在。"
                page, items, pages = self._paginate(members, self._page_arg(rest[1:]), 8)
                return f"分组 {name}（{page}/{pages}）：\n" + "\n".join(f"- {item}" for item in items)
            page, names, pages = self._paginate(sorted(groups), self._page_arg(rest), 8)
            return f"分组列表（{page}/{pages}）：\n" + "\n".join(f"- {name}（{len(groups[name])} 个会话）" for name in names)

        if action in {"grouplist", "group_list"}:
            groups = self._notify_groups()
            if not groups:
                return "当前没有分组订阅。"
            page, names, pages = self._paginate(sorted(groups), self._page_arg(rest), 8)
            lines = [f"分组订阅（{page}/{pages}）："]
            for name in names:
                members = groups[name]
                steamids = sorted(sid for sid, member in self._steamid_groups().items() if name in member)
                lines.append(f"- {name}：{len(members)} 个会话，监控 {len(steamids)} 个账号")
            return "\n".join(lines)

        if action in {"subclean", "sub_clean"}:
            return await self._subclean(context)

        if action == "resolve":
            steamid, error = await self._resolve_target(context, rest[0] if rest else "")
            if not steamid:
                return error or "无法解析 SteamID。"
            lines = [f"SteamID64：{steamid}", f"好友码：{self._account_id(steamid)}"]
            return "\n".join(lines)

        if action == "status":
            ids = [str(item) for item in self._cfg("steamids")]
            group_enabled = bool(self._cfg("notify_group_enabled"))
            group_count = len(self._notify_groups())
            return (
                f"Steam 监控：{'已配置 Key' if self._cfg('steam_web_api_key') else '未配置 Key'}，"
                f"监控 {len(ids)} 个账号，轮询间隔 {self._cfg('poll_interval_sec')} 秒，"
                f"分群订阅：{'开启' if group_enabled else '关闭'}（{group_count} 个分组），"
                f"全局订阅 {len([i for i in self._cfg('notify_targets') if str(i)])} 个会话，"
                f"停止推送：{'开启' if self._cfg('notify_on_stop') else '关闭'}。"
            )

        if action in {"notify_on_stop", "stopnotify"}:
            if not getattr(context, "is_admin", False):
                return "只有管理员可以修改停止游戏推送。"
            if not rest:
                return f"停止游戏推送：{'开启' if self._cfg('notify_on_stop') else '关闭'}。用法：/sw notify_on_stop on|off"
            value = str(rest[0]).lower() in {"1", "true", "on", "yes", "开启", "开"}
            await self.set_config("notify_on_stop", value)
            return "停止游戏推送已开启。" if value else "停止游戏推送已关闭。"

        if action in {"comment", "review"}:
            if not getattr(context, "is_admin", False):
                return "只有管理员可以修改停止游戏评价。"
            if not rest:
                return f"停止游戏评价：{'开启' if self._cfg('show_stop_playtime_comment') else '关闭'}"
            value = str(rest[0]).lower() in {"1", "true", "on", "yes", "开启", "开"}
            await self.set_config("show_stop_playtime_comment", value)
            return "停止游戏评价已开启。" if value else "停止游戏评价已关闭。"

        if action in {"proxytest", "proxy_test"}:
            try:
                async with httpx.AsyncClient(timeout=8, proxy=str(self._cfg("proxy_url") or "") or None, verify=bool(self._cfg("verify_ssl"))) as client:
                    response = await client.get("https://api.steampowered.com/ISteamWebAPIUtil/GetSupportedAPIList/v0001/")
                return f"代理连通正常（HTTP {response.status_code}）。"
            except httpx.HTTPError as error:
                return f"代理连通失败：{str(error)[:160]}"

        if action == "preset":
            if not getattr(context, "is_admin", False):
                return "只有管理员可以应用推荐配置。"
            await self.set_config("poll_interval_sec", 60)
            await self.set_config("request_timeout_sec", 10)
            await self.set_config("request_retries", 2)
            await self.set_config("request_retry_delay_sec", 2)
            return "Steam 推荐配置已应用。"

        if action == "test":
            try:
                players = await self._summaries([])
                return f"Steam API 正常，连通性测试通过。"
            except (httpx.HTTPError, ValueError) as error:
                return f"Steam API 检查失败：{str(error)[:200]}"

        return self._full_menu_text()

    # ---------- 增删改查具体实现 ----------

    async def _unbind(self, context: MessageContext, *, confirmed: bool = False) -> str:
        user_keys = self._user_keys(context)
        user_keys_bare = {self._bare_user(k) for k in user_keys}
        primary_key = user_keys[0] if user_keys else context.sender_id
        if not confirmed and bool(self._cfg("confirm_destructive")):
            nonce = self._store_confirmation(context, "unbind", [], admin=False)
            return self._confirm_card("解除绑定确认", f"确认解除用户 {primary_key} 的 Steam 绑定？", nonce)
        bindings = self._bindings()
        if not any(k in bindings for k in user_keys_bare):
            return "未找到绑定记录。"
        others = [f"{self._binding_owner(item)}:{str(item).split(':')[-1]}"
                  for item in self._cfg("bindings") if self._binding_owner(item) and self._binding_owner(item) not in user_keys_bare]
        await self.set_config("bindings", others)
        meta_entries = [item for item in self._cfg("binding_meta") if self._bare_user(str(item).split(":", 1)[0]) not in user_keys_bare]
        await self.set_config("binding_meta", meta_entries)
        return "已解除 Steam 绑定。"

    async def _remove_steamid(self, context: MessageContext, steamid: str, group: str, *, confirmed: bool = False) -> str:
        steamid = str(steamid or "").strip()
        group = str(group or "").strip()
        if not steamid:
            return "用法：/sw remove <目标> [分组]"
        if group and not self._valid_group_name(group):
            return "分组名称不能包含冒号（:）。"
        if not group and self._cfg("notify_group_enabled"):
            group = self._current_group(context)
        if bool(self._cfg("confirm_destructive")) and not confirmed:
            args = [steamid] + ([group] if group else [])
            nonce = self._store_confirmation(context, "remove", args, admin=True)
            label = f"{steamid}" + (f" 的分组 {group}" if group else "")
            return self._confirm_card("移除监控确认", f"确认移除 {label}？", nonce)
        ids = [str(item) for item in self._cfg("steamids")]
        if steamid not in ids:
            return f"{steamid} 不在监控列表中。"
        if group:
            groups = self._steamid_groups()
            member_groups = groups.get(steamid, [])
            if group in member_groups:
                member_groups.remove(group)
                await self.set_config("steamid_groups", self._flatten_steamid_groups(groups))
                if member_groups:
                    return f"已将 {steamid} 移出分组 {group}。剩余分组：{'、'.join(member_groups)}"
                ids = [item for item in ids if item != steamid]
                await self.set_config("steamids", ids)
                return f"已将 {steamid} 移出分组 {group}，无剩余分组，已移出监控号池。"
            return f"{steamid} 不在分组 {group} 中。"
        ids = [item for item in ids if item != steamid]
        groups = self._steamid_groups()
        if steamid in groups:
            del groups[steamid]
            await self.set_config("steamid_groups", self._flatten_steamid_groups(groups))
        await self.set_config("steamids", ids)
        self._last_state.pop(steamid, None)
        self._session_start.pop(steamid, None)
        return f"已从监控号池移除 {steamid}。"

    async def _subscribe(self, context: MessageContext, sub_action: str, group: str, *, confirmed: bool = False) -> str:
        if not getattr(context, "is_admin", False):
            return "只有管理员可以修改订阅。"
        scene = getattr(context, "scene", None) or getattr(context, "conversation_type", None) or "group"
        target = f"{scene}:{context.conversation_id}"
        group = str(group or "").strip()
        if group and not self._valid_group_name(group):
            return "分组名称不能包含冒号（:）。"
        if sub_action == "unsubscribe" and not confirmed and bool(self._cfg("confirm_destructive")):
            args = [group] if group else []
            nonce = self._store_confirmation(context, "unsubscribe", args, admin=True)
            text = "确认取消当前会话" + (f"的 {group} 分组" if group else "的全局通知") + "？"
            return self._confirm_card("取消订阅确认", text, nonce)
        if group:
            groups = self._notify_groups()
            members = groups.setdefault(group, [])
            if sub_action == "subscribe":
                if target in members:
                    return f"当前会话已订阅分组：{group}"
                members.append(target)
                await self.set_config("notify_group_enabled", True)
                await self.set_config("notify_groups", self._flatten_notify_groups(groups))
                return f"已订阅分组：{group}"
            if target not in members:
                return f"当前会话未订阅分组：{group}"
            members.remove(target)
            if not members:
                del groups[group]
            await self.set_config("notify_groups", self._flatten_notify_groups(groups))
            return f"已取消订阅分组：{group}"
        targets = [str(item) for item in self._cfg("notify_targets") if str(item)]
        if sub_action == "subscribe":
            if target in targets:
                return "当前会话已订阅通知。"
            targets.append(target)
            await self.set_config("notify_targets", targets)
            return "已订阅 Steam 状态通知。"
        if target not in targets:
            return "当前会话未订阅通知。"
        targets = [item for item in targets if item != target]
        await self.set_config("notify_targets", targets)
        return "已取消 Steam 状态通知。"

    async def _subclean(self, context: MessageContext, *, confirmed: bool = False) -> str:
        if not getattr(context, "is_admin", False):
            return "只有管理员可以清理订阅。"
        if not confirmed and bool(self._cfg("confirm_destructive")):
            nonce = self._store_confirmation(context, "subclean", [], admin=True)
            return self._confirm_card("清理订阅确认", "确认清理无效订阅记录？", nonce)
        targets = sorted(dict.fromkeys(str(item).strip() for item in self._cfg("notify_targets") if str(item).strip()))
        await self.set_config("notify_targets", targets)
        groups = self._notify_groups()
        cleaned = {name: members for name, members in groups.items() if members}
        removed = sum(len(members) for name, members in groups.items() if name not in cleaned)
        await self.set_config("notify_groups", self._flatten_notify_groups(cleaned))
        return f"订阅清理完成，保留 {len(targets)} 个全局目标，移除 {removed} 个无效分组会话。"

    async def _add_or_list(self, context: MessageContext, action: str, rest: list[str]) -> str:
        ids = [str(item) for item in self._cfg("steamids")]
        if action == "list":
            if not ids:
                return "监控列表为空。"
            page, items, pages = self._paginate(ids, self._page_arg(rest), 8)
            bindings = self._bindings()
            meta = self._binding_meta()
            groups = self._steamid_groups()
            lines = [f"监控列表（{page}/{pages}）："]
            for sid in items:
                owner = next((uid for uid, bound in bindings.items() if bound == sid), "")
                group_text = "、".join(groups.get(sid, []))
                suffix = ""
                if owner:
                    nick = meta.get(owner, "").strip()
                    suffix = f"（{nick or owner}）"
                if group_text:
                    suffix += f"（分组：{group_text}）"
                lines.append(f"- {sid}{suffix}")
            return "\n".join(lines)
        steamid, error = await self._resolve_target(context, rest[0] if rest else "")
        if not steamid:
            return error or "请输入有效 SteamID。"
        group = str(rest[1]).strip() if len(rest) > 1 else ""
        if not group and self._cfg("notify_group_enabled"):
            group = self._current_group(context)
        if steamid in ids:
            if group:
                groups = self._steamid_groups()
                if group not in groups.setdefault(steamid, []):
                    groups[steamid].append(group)
                    await self.set_config("steamid_groups", self._flatten_steamid_groups(groups))
                    return f"{steamid} 已在监控号池中，已加入分组：{group}。"
                return f"{steamid} 已在监控号池中，且已属于分组：{group}。"
            return f"{steamid} 已在监控号池中。"
        ids.append(steamid)
        await self.set_config("steamids", ids)
        if group:
            groups = self._steamid_groups()
            if group not in groups.setdefault(steamid, []):
                groups[steamid].append(group)
            await self.set_config("steamid_groups", self._flatten_steamid_groups(groups))
            return f"已添加 {steamid} 到监控号池。分组：{group}"
        return f"已添加 {steamid} 到监控号池。"

    async def _query(self, steamid: str, *, detailed: bool) -> str:
        if not steamid:
            return "请输入 SteamID。"
        try:
            players = await self._summaries([steamid])
        except (httpx.HTTPError, ValueError) as error:
            return f"Steam 查询失败：{str(error)[:200]}"
        if not players:
            return "没有找到该 Steam 用户，或资料未公开。"
        player = players[0]
        playing = bool(player.get("gameid"))
        appid_raw = str(player.get("gameid") or "")
        game_name = str(player.get("gameextrainfo") or "")
        display_name = await self._localized_game_name(int(appid_raw) if appid_raw.isdigit() else None, game_name or "某个游戏")
        friend_code = self._account_id(steamid)
        lines = [f"昵称：{player.get('personaname') or steamid}", f"好友码：{friend_code}", f"SteamID64：{steamid}"]
        persona = self.PERSONA_STATE_TEXT.get(player.get("personastate"))
        if persona:
            lines.append(f"状态：{persona}")
        if detailed:
            if player.get("realname"):
                lines.append(f"实名：{player['realname']}")
            if player.get("profileurl"):
                lines.append(f"主页：{player['profileurl']}")
            if player.get("timecreated"):
                try:
                    lines.append(f"注册时间：{time.strftime('%Y-%m-%d', time.gmtime(int(player['timecreated'])))}")
                except (ValueError, OverflowError):
                    pass
            country = player.get("loccountrycode")
            if country:
                lines.append(f"地区：{country}")
        if playing:
            appid_text = appid_raw or "未知"
            lines.append(f"正在玩：{display_name}（appid: {appid_text}）！")
        else:
            lines.append("当前未在游戏中。")
        if detailed and playing and appid_raw.isdigit():
            playtime = await self._fetch_playtime(steamid, int(appid_raw))
            if playtime is not None:
                lines.append(f"该游戏总时长：{playtime} 小时")
            achievements = await self._fetch_achievement_progress(steamid, int(appid_raw))
            if achievements:
                lines.append(f"成就进度：{achievements}")
        return "\n".join(lines)

    async def _fetch_playtime(self, steamid: str, appid: int) -> int | None:
        key = str(self._cfg("steam_web_api_key") or "")
        if not key:
            return None
        try:
            async with self._http_client(float(self._cfg("request_timeout_sec"))) as client:
                response = await client.get(
                    "https://api.steampowered.com/IPlayerService/GetOwnedGames/v0001/",
                    params={
                        "key": key, "steamid": steamid, "include_appinfo": 0,
                        "include_played_free_games": 1, "appids_filter[0]": appid,
                    },
                )
            games = response.json().get("response", {}).get("games", []) if response.status_code == 200 else []
            if not games:
                return None
            return max(0, int(games[0].get("playtime_forever", 0) // 60))
        except (httpx.HTTPError, ValueError):
            return None

    async def _fetch_achievement_progress(self, steamid: str, appid: int) -> str | None:
        key = str(self._cfg("steam_web_api_key") or "")
        if not key:
            return None
        try:
            async with self._http_client(float(self._cfg("request_timeout_sec"))) as client:
                response = await client.get(
                    "https://api.steampowered.com/ISteamUserStats/GetPlayerAchievements/v0001/",
                    params={"key": key, "steamid": steamid, "appid": appid},
                )
            achievements = response.json().get("playerstats", {}).get("achievements", []) if response.status_code == 200 else []
            if not achievements:
                return None
            achieved = sum(1 for item in achievements if item.get("achieved") == 1)
            return f"{achieved}/{len(achievements)}"
        except (httpx.HTTPError, ValueError):
            return None

    async def _localized_game_name(self, appid: int | None, fallback: str) -> str:
        if not appid or not self._cfg("use_localized_game_name"):
            return fallback
        lang = str(self._cfg("game_name_language") or "schinese")
        ttl = int(self._cfg("game_name_cache_ttl_sec") or 86400)
        cache_key = f"{appid}:{lang}"
        cached = self._app_name_cache.get(cache_key)
        if cached and time.time() - cached[1] < ttl:
            return cached[0]
        try:
            async with self._http_client(float(self._cfg("request_timeout_sec")), follow_redirects=True) as client:
                response = await client.get("https://store.steampowered.com/api/appdetails", params={"appids": str(appid), "l": lang})
            item = response.json().get(str(appid), {}) if response.status_code == 200 else {}
            if isinstance(item, dict) and item.get("success"):
                name = str(item.get("data", {}).get("name") or "").strip()
                if name:
                    self._app_name_cache[cache_key] = (name, time.time())
                    return name
        except (httpx.HTTPError, ValueError):
            pass
        return fallback

    @staticmethod
    def _playtime_taunt(minutes: int) -> str:
        if minutes <= 5:
            return "杂鱼，这就不行了？"
        if minutes <= 15:
            return "才这么点？要不要我给你计时器？"
        if minutes <= 30:
            return "勉强及格，下次再坚持点。"
        if minutes <= 60:
            return "还行吧，但离强还差点。"
        if minutes <= 120:
            return "不错，继续保持。"
        return "今天挺猛的，给你点个赞。"

    def _current_group(self, context: MessageContext) -> str:
        scene = getattr(context, "scene", None) or getattr(context, "conversation_type", None) or "group"
        target = f"{scene}:{context.conversation_id}"
        for group, members in self._notify_groups().items():
            if target in members:
                return group
        return ""

    @staticmethod
    def _flatten_notify_groups(groups: dict[str, list[str]]) -> list[str]:
        return [f"{name}:{member}" for name, members in sorted(groups.items()) for member in members]

    @staticmethod
    def _flatten_steamid_groups(groups: dict[str, list[str]]) -> list[str]:
        return [f"{sid}:{name}" for sid, names in sorted(groups.items()) for name in names]

    # ---------- 周期性轮询与通知 ----------

    async def poll_tick(self) -> None:
        interval = max(30, int(self._cfg("poll_interval_sec") or 60))
        now = time.monotonic()
        if now - self._last_poll_at < interval:
            return
        self._last_poll_at = now
        ids = [str(item) for item in self._cfg("steamids") if str(item)]
        if not ids or not self._cfg("steam_web_api_key"):
            return
        for offset in range(0, len(ids), 100):
            try:
                players = await self._summaries(ids[offset:offset + 100])
            except (httpx.HTTPError, ValueError) as error:
                logger.warning("Steam 监控轮询失败 (%s); 保留旧状态", error)
                return
            for player in players:
                steamid = str(player.get("steamid") or "")
                if not steamid:
                    continue
                playing = bool(player.get("gameid"))
                appid_raw = str(player.get("gameid") or "")
                game_name = str(player.get("gameextrainfo") or "")
                appid = int(appid_raw) if appid_raw.isdigit() else None
                display_name = await self._localized_game_name(appid, game_name or "某个游戏")
                nickname = str(player.get("personaname") or steamid)
                previous = self._last_state.get(steamid)
                if previous is None:
                    self._last_state[steamid] = (playing, game_name, appid_raw or None)
                    if playing:
                        self._session_start[steamid] = time.time()
                    continue
                was_playing, last_game, last_appid = previous
                if playing and not was_playing:
                    self._session_start[steamid] = time.time()
                    await self._notify_by_steamid(steamid, f"{nickname} 正在玩 {display_name}！")
                elif self._cfg("notify_on_stop") and was_playing and not playing:
                    minutes = max(0, int((time.time() - self._session_start.get(steamid, time.time())) // 60))
                    self._session_start.pop(steamid, None)
                    last_appid_int = int(last_appid) if (last_appid or "").isdigit() else None
                    last_display = await self._localized_game_name(last_appid_int, last_game or "某个游戏")
                    message = f"{nickname} 已停止游戏 {last_display}。本次游玩 {minutes} 分钟。"
                    if self._cfg("show_stop_playtime_comment"):
                        message += f"\n评价：{self._playtime_taunt(minutes)}"
                    await self._notify_by_steamid(steamid, message)
                self._last_state[steamid] = (playing, game_name, appid_raw or None)

    async def _notify_by_steamid(self, steamid: str, message: str) -> None:
        targets: list[str] = []
        if self._cfg("notify_group_enabled"):
            steamid_groups = self._steamid_groups()
            for group in steamid_groups.get(steamid, []):
                for member in self._notify_groups().get(group, []):
                    if member not in targets:
                        targets.append(member)
        if not targets:
            targets = [str(item) for item in self._cfg("notify_targets") if str(item) and ":" in item]
        for target in targets:
            scene, conversation = target.split(":", 1)
            try:
                qq_gw = getattr(self.context, "qq", None)
                if qq_gw and hasattr(qq_gw, "send_text"):
                    await qq_gw.send_text(conversation, scene, message)
                elif hasattr(self.context, "chat") and hasattr(self.context.chat, "send"):
                    await self.context.chat.send(target, message)
            except Exception as e:
                logger.warning("SteamWatch 发送通知给 %s 失败: %s", target, e)


async def setup(context: Any) -> None:
    """外部插件 worker 启动入口。"""
    plugin = SteamWatchPlugin(context)

    # 注册命令
    commands = (
        "sw", "steamwatch", "steamwatch_add", "steamwatch_remove", "steamwatch_list",
        "steamwatch_interval", "steamwatch_subscribe", "steamwatch_unsubscribe",
        "steamwatch_subinfo", "steamwatch_groupinfo", "steamwatch_grouplist",
        "steamwatch_resolve", "steamwatch_subclean", "steamwatch_status",
        "steamwatch_bind", "steamwatch_unbind", "steamwatch_me",
        "steamwatch_notify_on_stop", "steamwatch_confirm", "steamwatch_query",
        "steamwatch_info", "steamwatch_test", "steamwatch_proxytest", "steamwatch_preset",
    )
    if hasattr(context, "register_command"):
        for cmd in commands:
            try:
                context.register_command(cmd, plugin.command, category="utility", description="Steam 监控")
            except Exception as e:
                logger.debug("注册命令 %s 异常: %s", cmd, e)

    # 注册定时任务 (60秒轮询)
    if hasattr(context, "register_task"):
        try:
            context.register_task("poll", 60, plugin.poll_tick)
        except TypeError:
            try:
                context.register_task("poll", plugin.poll_tick)
            except Exception as e:
                logger.warning("注册 poll 定时任务失败: %s", e)
        except Exception as e:
            logger.warning("注册 poll 定时任务失败: %s", e)

    # 注册原生页面与通用动作
    if hasattr(context, "register_page_action"):
        context.register_page_action("home", plugin.on_page_action)
        context.register_page_action("save_config", plugin.on_page_action)
    if hasattr(context, "register_action"):
        context.register_action("save_config", plugin.on_page_action)
        context.register_action("page_data", plugin.on_page_action)
        context.register_action("rebind", plugin.on_page_action)
        context.register_action("remove_binding", plugin.on_page_action)

    await plugin._write_page_snapshot()
    logger.info("plugin.sw %s 已成功初始化加载", PLUGIN_VERSION)
