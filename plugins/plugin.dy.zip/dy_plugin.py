"""抖音音视频解析独立外部插件 (plugin.dy).

具备完整的抖音视频、作品解析、下载、音频提取（以作品标题命名）、
3x3 交互卡片菜单、任务/文件分页管理、接口连通性检查与管理台原生声明式 UI 通信能力。
遵循标准普通外部插件规范，运行于沙箱隔离环境中，配置与缓存均存储于插件专属目录。
"""

from __future__ import annotations

import asyncio
import datetime
import io
import json
import logging
import re
import shutil
import struct
import tempfile
import time
import uuid
from pathlib import Path
from typing import Any
from urllib.parse import quote

import httpx

logger = logging.getLogger("plugin.dy")
PLUGIN_VERSION = "0.6.7"


def parse_image_dimensions(b: bytes) -> tuple[int, int] | None:
    if len(b) < 16:
        return None
    # 1. PNG
    if b.startswith(b"\x89PNG\r\n\x1a\n") and len(b) >= 24:
        return struct.unpack(">II", b[16:24])
    # 2. GIF
    if b.startswith((b"GIF87a", b"GIF89a")) and len(b) >= 10:
        return struct.unpack("<HH", b[6:10])
    # 3. WEBP
    if len(b) >= 30 and b[:4] == b"RIFF" and b[8:12] == b"WEBP":
        chunk = b[12:16]
        if chunk == b"VP8X" and len(b) >= 30:
            w = 1 + struct.unpack("<I", b[24:27] + b"\x00")[0]
            h = 1 + struct.unpack("<I", b[27:30] + b"\x00")[0]
            return w, h
        elif chunk == b"VP8 " and len(b) >= 30:
            idx = b.find(b"\x9d\x01\x2a")
            if idx != -1 and idx + 7 <= len(b):
                w = struct.unpack("<H", b[idx+3:idx+5])[0] & 0x3fff
                h = struct.unpack("<H", b[idx+5:idx+7])[0] & 0x3fff
                return w, h
        elif chunk == b"VP8L" and len(b) >= 25:
            b0, b1, b2, b3 = b[21], b[22], b[23], b[24]
            w = 1 + (((b1 & 0x3f) << 8) | b0)
            h = 1 + (((b3 & 0x0f) << 10) | (b2 << 2) | ((b1 & 0xc0) >> 6))
            return w, h
    # 4. JPEG
    if b.startswith(b"\xff\xd8"):
        idx = 2
        while idx < len(b) - 8:
            if b[idx] != 0xff:
                idx += 1
                continue
            marker = b[idx+1]
            if marker in (0xc0, 0xc1, 0xc2, 0xc3, 0xc5, 0xc6, 0xc7, 0xc9, 0xca, 0xcb, 0xcd, 0xce, 0xcf):
                h, w = struct.unpack(">HH", b[idx+5:idx+9])
                return w, h
            length = struct.unpack(">H", b[idx+2:idx+4])[0]
            idx += 2 + length
    return None

DEFAULT_CONFIG: dict[str, Any] = {
    "douyin_api_base_url": "",
    "douyin_api_token": "",
    "douyin_cookie": "",
    "qq_admin_openids": [],
    "qq_callback_ttl_sec": 600,
    "recall_interaction_card_on_use": False,
    "enable_auto_detect": True,
    "enable_video_output": False,
    "enable_manual_video_output": True,
    "video_quality_index": 0,
    "max_image_count": 9,
    "api_timeout_sec": 20,
    "video_poll_interval_sec": 1.0,
    "video_download_timeout_sec": 180,
    "download_cooldown_sec": 180,
    "max_active_downloads": 2,
    "max_video_file_size_mb": 30,
    "max_video_duration_sec": 180,
    "show_cover": True,
    "debug_log": False,
}

CONFIG_LABELS: dict[str, str] = {
    "douyin_api_base_url": "解析服务地址",
    "douyin_api_token": "API 访问令牌",
    "douyin_cookie": "抖音 Cookie",
    "enable_auto_detect": "自动识别抖音链接",
    "enable_video_output": "解析后自动发送视频",
    "enable_manual_video_output": "允许手动下载视频",
    "video_quality_index": "视频清晰度索引",
    "max_image_count": "图集最大发送张数",
    "show_cover": "卡片显示视频封面",
    "max_video_file_size_mb": "最大视频文件体积 (MB)",
    "max_video_duration_sec": "最大视频时长 (秒)",
    "api_timeout_sec": "接口超时时间 (秒)",
    "video_download_timeout_sec": "下载超时时间 (秒)",
    "download_cooldown_sec": "下载冷却时间 (秒)",
    "debug_log": "开启调试日志",
}

CONFIG_SCHEMA: dict[str, dict[str, Any]] = {
    "douyin_api_base_url": {
        "type": "string",
        "label": "解析服务地址",
        "description": "外部自建抖音解析服务地址，例如 http://172.17.0.1:8001",
    },
    "douyin_api_token": {
        "type": "string",
        "label": "API 访问令牌",
        "description": "外部解析服务配置的 X-API-Token 访问令牌（可选）",
    },
    "douyin_cookie": {
        "type": "string",
        "label": "抖音 Cookie",
        "description": "用于解析无水印高清内容或作品详情的 Cookie",
    },
    "enable_auto_detect": {
        "type": "boolean",
        "label": "自动识别抖音链接",
        "description": "接收到包含抖音分享链接的消息时自动解析",
    },
    "enable_video_output": {
        "type": "boolean",
        "label": "解析后自动发送视频",
        "description": "视频解析成功后是否自动下载并发送视频文件",
    },
    "enable_manual_video_output": {
        "type": "boolean",
        "label": "允许手动下载视频",
        "description": "卡片中提供下载视频、发送语音与获取音频文件按钮",
    },
    "video_quality_index": {
        "type": "number",
        "label": "视频清晰度索引",
        "description": "0 表示最高可用画质，数字越大清晰度越低",
    },
    "max_image_count": {
        "type": "number",
        "label": "图集最大发送张数",
        "description": "单次发送图集的最大图片数量（防止频控，建议 9）",
    },
    "show_cover": {
        "type": "boolean",
        "label": "显示封面图片",
        "description": "在解析卡片中展示抖音视频/图集封面",
    },
    "max_video_file_size_mb": {
        "type": "number",
        "label": "最大视频文件体积 (MB)",
        "description": "超过该体积限制将拒绝下载以保护带宽，建议 30",
    },
    "max_video_duration_sec": {
        "type": "number",
        "label": "最大视频时长 (秒)",
        "description": "限制过长视频的下载，0 表示不限制",
    },
    "api_timeout_sec": {
        "type": "number",
        "label": "接口超时时间 (秒)",
        "description": "请求外部服务时的网络超时时间",
    },
    "video_download_timeout_sec": {
        "type": "number",
        "label": "下载超时时间 (秒)",
        "description": "轮询等待服务下载完成的最大时长",
    },
    "download_cooldown_sec": {
        "type": "number",
        "label": "下载冷却时间 (秒)",
        "description": "相同会话防刷频下载冷却时长",
    },
    "debug_log": {
        "type": "boolean",
        "label": "调试日志",
        "description": "打印更详细的解析与排查日志",
    },
}


def _sanitize_filename(name: str) -> str:
    """清理文件名中的非法字符以安全用于 QQ 媒体上传。"""
    clean = re.sub(r'[/\\:*?"<>|\r\n\t]+', "_", name).strip(". ")
    return clean[:120] if len(clean) > 120 else (clean or "douyin_audio")


def _format_count(value: Any) -> str:
    try:
        val = int(value or 0)
    except (ValueError, TypeError):
        return "0"
    if val >= 10000:
        return f"{val / 10000:.1f}万"
    return str(val)


def _https_url(url: str | None) -> str:
    raw = str(url or "").strip()
    if raw.startswith("//"):
        return f"https:{raw}"
    if raw.startswith("http://"):
        return f"https://{raw[7:]}"
    return raw


def make_button(
    label: str,
    action: str,
    *,
    type: int = 1,
    permission: int = 0,
    style: str = "normal",
    permission_message: str = "",
    enter: bool = False,
) -> dict[str, Any]:
    btn: dict[str, Any] = {
        "label": label,
        "action": action,
        "command": action,
        "type": type,
        "action_type": type,
        "permission": permission,
        "style": style,
        "enter": enter,
    }
    if permission_message:
        btn["permission_message"] = permission_message
    return btn


def make_card(title: str, content: str, rows: list[list[dict[str, Any]]] | None = None) -> dict[str, Any]:
    return {
        "title": title,
        "content": content,
        "markdown": content,
        "rows": rows or [],
    }


class DyPlugin:
    """抖音解析外部插件实现。"""

    URL_RE = re.compile(r"https?://(?:[a-z0-9-]+\.)*douyin\.com/[^\s<>]+", re.I)

    def __init__(self, context: Any) -> None:
        self.context = context
        self.config_dir: Path = Path(context.config_dir) if getattr(context, "config_dir", None) else (Path("/app/data/plugin-config/plugin.dy") if Path("/app/data").is_dir() else Path(tempfile.gettempdir()) / "config")
        self.data_dir: Path = Path(context.data_dir) if getattr(context, "data_dir", None) else (Path("/app/data/plugin-data/plugin.dy") if Path("/app/data").is_dir() else Path(tempfile.gettempdir()) / "data")
        self.config_dir.mkdir(parents=True, exist_ok=True)
        self.data_dir.mkdir(parents=True, exist_ok=True)
        self.config_file = self.config_dir / "config.json"

        self.cache_dir = self.data_dir / "cache"
        self.cache_dir.mkdir(parents=True, exist_ok=True)
        self.downloads_dir = self.data_dir / "downloads"
        self.downloads_dir.mkdir(parents=True, exist_ok=True)

        self._in_flight_tasks: set[tuple[str, str, Any]] = set()
        self._recently_sent: dict[tuple[str, str, Any], float] = {}
        self._media_cache: dict[tuple[str, bool, int], tuple[float, Path]] = {}
        self._info_cache: dict[str, tuple[float, dict[str, Any]]] = {}
        self._last_album_url: dict[str, str] = {}
        self._image_dim_cache: dict[str, tuple[int, int]] = {}

        self.config: dict[str, Any] = dict(DEFAULT_CONFIG)
        self._load_config()
        self._sync_sqlite_and_external_config()

    async def _resolve_image_dimension(self, url: str) -> tuple[int, int] | None:
        if not url:
            return None
        if url in self._image_dim_cache:
            return self._image_dim_cache[url]
        try:
            async with httpx.AsyncClient(timeout=5.0, follow_redirects=True) as client:
                async with client.stream("GET", url, headers={"User-Agent": "Mozilla/5.0"}) as resp:
                    if resp.status_code in {200, 206}:
                        buf = bytearray()
                        async for chunk in resp.aiter_bytes(chunk_size=8192):
                            buf.extend(chunk)
                            dims = parse_image_dimensions(bytes(buf))
                            if dims:
                                self._image_dim_cache[url] = dims
                                return dims
                            if len(buf) >= 65536:
                                break
                        try:
                            from PIL import Image
                            im = Image.open(io.BytesIO(buf))
                            self._image_dim_cache[url] = im.size
                            return im.size
                        except Exception:
                            pass
        except Exception:
            pass
        return None

    def _compute_card_dimension(self, w: int, h: int, target_w: int = 720) -> str:
        if not w or not h or w <= 0 or h <= 0:
            return f"#{target_w}px #{target_w}px"
        target_h = max(200, min(1440, int(round(target_w * (h / w)))))
        return f"#{target_w}px #{target_h}px"

    def _resolve_card_dimension(self, url: str, data: dict[str, Any], index: int = 0, is_video: bool = False) -> str:
        target_w = 720
        # 1. 检查 API 数据是否自带真实宽高
        if is_video:
            video = data.get("video")
            if isinstance(video, dict):
                vw, vh = video.get("width"), video.get("height")
                if vw and vh:
                    try:
                        return self._compute_card_dimension(int(vw), int(vh), target_w)
                    except (ValueError, TypeError):
                        pass
        else:
            raw_list = data.get("images") or data.get("image_list") or []
            if isinstance(raw_list, list) and 0 <= index < len(raw_list):
                item = raw_list[index]
                if isinstance(item, dict):
                    iw, ih = item.get("width"), item.get("height")
                    if iw and ih:
                        try:
                            return self._compute_card_dimension(int(iw), int(ih), target_w)
                        except (ValueError, TypeError):
                            pass
        # 2. 检查缓存
        if url and url in self._image_dim_cache:
            w, h = self._image_dim_cache[url]
            return self._compute_card_dimension(w, h, target_w)

        # 3. 兜底默认值
        if is_video:
            return f"#{target_w}px #405px"
        return f"#{target_w}px #960px"

    def _load_config(self) -> None:
        if self.config_file.is_file():
            try:
                mtime = self.config_file.stat().st_mtime
                if mtime != getattr(self, "_config_mtime", 0.0):
                    data = json.loads(self.config_file.read_text(encoding="utf-8"))
                    if isinstance(data, dict):
                        self.config.update(data)
                        self._config_mtime = mtime
            except Exception as e:
                logger.warning("加载 plugin.dy config.json 失败: %s", e)

    def _save_config(self) -> None:
        try:
            self.config_file.write_text(json.dumps(self.config, ensure_ascii=False, indent=2), encoding="utf-8")
        except Exception as e:
            logger.error("写入 plugin.dy config.json 失败: %s", e)

    def _sync_sqlite_and_external_config(self) -> None:
        """双向同步 SQLite 原配置与外部插件配置。"""
        db_path = self.data_dir / "runtime.sqlite3"
        if not db_path.is_file():
            return
        import sqlite3

        try:
            con = sqlite3.connect(str(db_path), timeout=5.0)
            cur = con.cursor()
            cur.execute("SELECT key, value FROM settings WHERE key LIKE 'dy.%'")
            sqlite_rows = dict(cur.fetchall())
            con.close()

            updated = False
            for k, val_str in sqlite_rows.items():
                field = k.removeprefix("dy.")
                if field in DEFAULT_CONFIG and (field not in self.config or not self.config[field]):
                    spec_type = type(DEFAULT_CONFIG[field])
                    if spec_type is bool:
                        self.config[field] = val_str.strip().lower() in {"true", "1", "yes", "on"}
                    elif spec_type is int:
                        try:
                            self.config[field] = int(val_str)
                        except Exception:
                            pass
                    elif spec_type is float:
                        try:
                            self.config[field] = float(val_str)
                        except Exception:
                            pass
                    else:
                        self.config[field] = val_str
                    updated = True

            if updated:
                self._save_config()
        except Exception as e:
            logger.debug("同步 SQLite dy 配置至外部插件跳过: %s", e)

    def _cfg(self, key: str, default: Any = None) -> Any:
        self._load_config()
        return self.config.get(key, DEFAULT_CONFIG.get(key, default))

    def _clean_media_cache(self) -> None:
        now = time.monotonic()
        expired = [k for k, (exp, p) in self._media_cache.items() if now > exp or not p.is_file()]
        for k in expired:
            _, p = self._media_cache.pop(k, (0, Path("")))
            p.unlink(missing_ok=True)
        if len(self._media_cache) > 15:
            sorted_items = sorted(self._media_cache.items(), key=lambda item: item[1][0])
            for k, (_, p) in sorted_items[: len(self._media_cache) - 15]:
                self._media_cache.pop(k, None)
                p.unlink(missing_ok=True)

    def _task_key(self, conversation_id: str, source_url: str, audio_only: Any = False, as_file: bool = False) -> tuple[str, str, Any]:
        match = self.URL_RE.search(source_url or "")
        url_key = match.group(0).lower() if match else str(source_url or "").strip().lower()
        kind = (bool(audio_only), True) if as_file else (audio_only if isinstance(audio_only, tuple) else bool(audio_only))
        return (str(conversation_id or ""), url_key, kind)

    def _service_headers(self) -> dict[str, str]:
        token = str(self._cfg("douyin_api_token") or "").strip()
        return {"X-API-Token": token} if token else {}

    async def _request_status(self, path: str, method: str = "GET", **kwargs: Any) -> tuple[int, dict[str, Any]]:
        base = str(self._cfg("douyin_api_base_url") or "").rstrip("/")
        if not base:
            return 400, {"message": "尚未配置抖音解析服务地址"}
        headers = dict(kwargs.pop("headers", {}) or {})
        headers.update(self._service_headers())
        url = base + path if path.startswith("/") else f"{base}/{path}"
        try:
            async with httpx.AsyncClient(timeout=float(self._cfg("api_timeout_sec") or 20), follow_redirects=True) as client:
                response = await client.request(method.upper(), url, headers=headers, **kwargs)
                try:
                    data = response.json()
                except Exception:
                    data = {"text": response.text}
                return response.status_code, data if isinstance(data, dict) else {"data": data}
        except Exception as e:
            return 500, {"error": str(e)}

    async def _request(self, path: str, **kwargs: Any) -> dict[str, Any]:
        status, data = await self._request_status(path, **kwargs)
        if status >= 400:
            raise ValueError(f"抖音解析服务 HTTP {status}: {data.get('message') or data.get('error') or ''}")
        return data

    async def _download_http_file(self, url: str, target: Path, headers: dict[str, str], max_bytes: int) -> tuple[Path | None, str]:
        try:
            target.parent.mkdir(parents=True, exist_ok=True)
            async with httpx.AsyncClient(timeout=120.0, follow_redirects=True) as client:
                async with client.stream("GET", url, headers=headers) as response:
                    if response.status_code >= 400:
                        return None, f"HTTP {response.status_code}"
                    total = 0
                    with open(target, "wb") as f:
                        async for chunk in response.aiter_bytes(chunk_size=65536):
                            total += len(chunk)
                            if max_bytes > 0 and total > max_bytes:
                                return None, f"文件体积超过限制 ({max_bytes // 1024 // 1024}MB)"
                            f.write(chunk)
            return target, ""
        except Exception as e:
            target.unlink(missing_ok=True)
            return None, str(e)

    # ================= 菜单与卡片 =================
    def _menu_card(self) -> dict[str, Any]:
        rows = [
            [
                make_button("解析作品", "/dy ", type=2),
                make_button("下载视频", "/dy dl ", type=2),
                make_button("图集打包", "/dy zip ", type=2),
            ],
            [
                make_button("提取音频", "/dy audio ", type=2),
                make_button("任务列表", "/dy task", type=1),
                make_button("文件列表", "/dy file", type=1),
            ],
            [
                make_button("Cookie 登录", "/dy login", type=1, permission=1),
                make_button("接口状态", "/dy net", type=1, permission=1),
                make_button("配置说明", "/dy config", type=1, permission=1),
            ],
        ]
        configured = "已配置解析服务" if self._cfg("douyin_api_base_url") else "未配置下载服务"
        return make_card(
            "抖音解析",
            "## 抖音解析\n\n支持抖音分享链接解析、视频下载、图集翻页/打包与音频提取。\n\n"
            f"当前状态：{configured}。\n\n"
            "直接发送 `/dy <抖音链接>` 解析作品；视频下载 `/dy dl <链接>`；图集打包 `/dy zip <链接>`；图集支持 Markdown 分页卡片翻页浏览。",
            rows,
        )

    def _submenu_card(self, module: str) -> dict[str, Any]:
        module_lower = module.casefold()
        content = {
            "parse": "发送 `/dy <抖音链接>` 解析作品；下载视频使用 `/dy dl <链接>`；图集支持原地切页浏览、点击输入框跳页及 `/dy zip <链接>` 一键打包下载。",
            "config": "配置项请在管理台的抖音解析设置页修改：解析服务地址、令牌、Cookie、自动识别和媒体输出。",
            "net": "使用 `/dy net` 检查解析服务、令牌和 Cookie 登录状态。",
        }.get(module_lower, "发送 `/dy <抖音链接>` 开始解析。")
        permission = 1 if module_lower in {"config", "net"} else 0
        rows = [
            [
                make_button("返回菜单", "/dy", type=1),
                make_button("任务列表", "/dy task", type=1),
                make_button("文件列表", "/dy file", type=1),
            ],
            [
                make_button("执行入口", f"/dy {module_lower}", type=1, permission=permission),
            ],
        ]
        return make_card(f"抖音解析 · {module_lower}", content, rows)

    def _build_info_card(self, data: dict[str, Any], url: str, conversation_id: str = "") -> dict[str, Any]:
        # 1. 创作者解析
        raw_author = data.get("author")
        author_dict = raw_author if isinstance(raw_author, dict) else (data.get("user") if isinstance(data.get("user"), dict) else {})
        author_name = ""
        author_id = ""
        if isinstance(raw_author, str) and raw_author.strip():
            author_name = raw_author.strip()
        elif author_dict:
            author_name = str(author_dict.get("nickname") or author_dict.get("name") or "").strip()
            author_id = str(author_dict.get("unique_id") or author_dict.get("short_id") or author_dict.get("douyin_id") or "").strip()
        if not author_name:
            author_name = str(data.get("author_name") or data.get("nickname") or data.get("user_name") or data.get("creator") or "").strip() or "未知"

        # 2. 标题与文案
        raw_desc = str(data.get("desc") or data.get("description") or data.get("remark") or "").strip()
        raw_title = str(data.get("title") or "").strip()
        title = raw_title or raw_desc or "抖音作品"
        remark = raw_desc if raw_desc and (raw_desc != title and raw_desc != raw_title) else ""

        # 3. 时长与时间
        raw_duration = data.get("duration") or ((data.get("video") or {}).get("duration") if isinstance(data.get("video"), dict) else None)
        duration_str = ""
        if raw_duration:
            try:
                sec = int(raw_duration)
                if sec > 1000:
                    sec = round(sec / 1000)
                m, s = divmod(sec, 60)
                duration_str = f"{m:02d}:{s:02d}"
            except Exception:
                pass

        raw_time = data.get("create_time") or data.get("create_timestamp") or data.get("time") or data.get("publish_time")
        create_time_str = ""
        if raw_time:
            try:
                t_val = int(raw_time)
                if t_val > 10000000000:
                    t_val = t_val // 1000
                dt = datetime.datetime.fromtimestamp(t_val, datetime.timezone(datetime.timedelta(hours=8)))
                create_time_str = dt.strftime("%Y-%m-%d %H:%M:%S")
            except Exception:
                pass

        # 4. 背景音乐
        raw_music = data.get("music") or data.get("music_info") or data.get("audio")
        bgm_str = ""
        if isinstance(raw_music, dict):
            m_title = str(raw_music.get("title") or raw_music.get("name") or "").strip()
            m_author = str(raw_music.get("author") or raw_music.get("owner") or "").strip()
            if m_title and m_author and m_author not in m_title:
                bgm_str = f"{m_title} - {m_author}"
            else:
                bgm_str = m_title or m_author
        elif isinstance(raw_music, str) and raw_music.strip():
            bgm_str = raw_music.strip()

        # 5. 互动统计
        stat = data.get("statistics") if isinstance(data.get("statistics"), dict) else (data.get("stat") if isinstance(data.get("stat"), dict) else {})
        digg_cnt = _format_count(stat.get("digg_count") or stat.get("like") or stat.get("like_count") or stat.get("likes") or 0)
        comment_cnt = _format_count(stat.get("comment_count") or stat.get("comment") or stat.get("comments") or 0)
        collect_cnt = _format_count(stat.get("collect_count") or stat.get("favorite") or stat.get("favorites") or stat.get("collect") or 0)
        share_cnt = _format_count(stat.get("share_count") or stat.get("share") or stat.get("shares") or 0)
        play_cnt = _format_count(stat.get("play_count") or stat.get("view_count") or stat.get("views") or 0)

        # 6. 图集检测
        content_type = str(data.get("content_type") or data.get("type") or "").lower()
        raw_images = data.get("images") or data.get("image_urls") or data.get("image_list") or []
        is_image_set = content_type in {"image", "images", "note", "picture"} or bool(raw_images)
        if is_image_set:
            if conversation_id and url:
                self._last_album_url[str(conversation_id)] = url
            return self._build_image_set_page_card(data, url, current_page=1)

        # 7. 视频作品 Markdown 与封面
        markdown_lines = []
        cover = _https_url(data.get("cover") or data.get("cover_url") or data.get("dynamic_cover") or ((data.get("video") or {}).get("cover") if isinstance(data.get("video"), dict) else None))
        if self._cfg("show_cover") and cover:
            dim_str = self._resolve_card_dimension(cover, data, index=0, is_video=True)
            markdown_lines.append(f"![封面 {dim_str}]({cover})\n")

        markdown_lines.append(f"### {title[:200]}")

        creator_line = f"👤 **创作者**：{author_name}"
        if author_id:
            creator_line += f" (抖音号: {author_id})"
        markdown_lines.append(creator_line)
        extra_meta = []
        if duration_str:
            extra_meta.append(f"⏱️ **时长**：{duration_str}")
        if create_time_str:
            extra_meta.append(f"🕒 **发布时间**：{create_time_str}")
        if extra_meta:
            markdown_lines.append(" · ".join(extra_meta))
        if bgm_str:
            markdown_lines.append(f"🎵 **背景音乐**：{bgm_str}")
        if remark:
            markdown_lines.append(f"> 📝 **作品文案**：{remark[:300]}")
        stat_parts = []
        if digg_cnt != "0":
            stat_parts.append(f"👍 {digg_cnt}")
        if comment_cnt != "0":
            stat_parts.append(f"💬 {comment_cnt}")
        if collect_cnt != "0":
            stat_parts.append(f"⭐ {collect_cnt}")
        if share_cnt != "0":
            stat_parts.append(f"↗️ {share_cnt}")
        if play_cnt != "0":
            stat_parts.append(f"👁️ {play_cnt}")
        if stat_parts:
            markdown_lines.append(f"📊 **数据**：{' · '.join(stat_parts)}")

        rows = []
        if self._cfg("douyin_api_base_url"):
            rows.append([
                make_button("下载视频", f"/dy dl {url}", type=1, permission=0),
                make_button("发送语音", f"/dy audio {url}", type=1, permission=0),
                make_button("音频文件", f"/dy audio_file {url}", type=1, permission=0),
            ])
            rows.append([
                make_button("网页打开", url, type=0),
                make_button("抖音菜单", "/dy", type=1, permission=0),
            ])
        return make_card("抖音视频解析", "\n\n".join(markdown_lines), rows)

    def _extract_image_urls(self, data: dict[str, Any]) -> list[str]:
        """提取图集作品中所有图片的直接下载 URL 列表。"""
        img_urls: list[str] = []
        raw_list = data.get("image_urls") or data.get("images") or data.get("image_list") or []
        if isinstance(raw_list, list):
            for item in raw_list:
                if isinstance(item, str) and item.strip():
                    img_urls.append(_https_url(item.strip()))
                elif isinstance(item, dict):
                    urls = item.get("url_list") or item.get("download_url_list") or []
                    if urls and isinstance(urls, list):
                        img_urls.append(_https_url(urls[0]))
                    elif isinstance(item.get("url"), str) and item["url"].strip():
                        img_urls.append(_https_url(item["url"].strip()))
        return img_urls

    def _build_image_set_page_card(
        self,
        data: dict[str, Any],
        url: str,
        current_page: int = 1,
    ) -> dict[str, Any]:
        """构建图集专属的 Markdown 图文分页浏览卡片。"""
        title = str(data.get("title") or data.get("desc") or "抖音图集").strip()
        author = data.get("author") if isinstance(data.get("author"), dict) else {}
        author_name = str(author.get("nickname") or author.get("name") or "抖音创作者").strip()
        author_id = str(author.get("unique_id") or author.get("short_id") or "").strip()
        remark = str(data.get("desc") or title).strip()

        # 统计指标
        stat = data.get("statistics") if isinstance(data.get("statistics"), dict) else (data.get("stat") if isinstance(data.get("stat"), dict) else {})
        digg_cnt = _format_count(stat.get("digg_count") or stat.get("like") or stat.get("likes") or 0)
        comment_cnt = _format_count(stat.get("comment_count") or stat.get("comment") or stat.get("comments") or 0)
        collect_cnt = _format_count(stat.get("collect_count") or stat.get("favorite") or stat.get("collect") or 0)

        img_urls = self._extract_image_urls(data)
        total_pages = len(img_urls)
        if total_pages == 0:
            return make_card("抖音图集解析", f"### 🖼️【抖音图集】{title[:180]}\n\n未检测到图集图片列表。", [])

        page = max(1, min(current_page, total_pages))
        current_img = img_urls[page - 1]

        markdown_lines = []
        if self._cfg("show_cover") and current_img:
            dim_str = self._resolve_card_dimension(current_img, data, index=page - 1, is_video=False)
            markdown_lines.append(f"![图集第 {page}/{total_pages} 张 {dim_str}]({current_img})\n")

        markdown_lines.append(f"### 🖼️【抖音图集】{title[:180]}")
        markdown_lines.append(f"📸 **图集浏览**：第 **{page}** / {total_pages} 张 (可点击下方翻页浏览)")

        creator_line = f"👤 **创作者**：{author_name}"
        if author_id:
            creator_line += f" (抖音号: {author_id})"
        markdown_lines.append(creator_line)

        if remark and remark != title:
            markdown_lines.append(f"> 📝 **作品文案**：{remark[:200]}")

        stat_parts = []
        if digg_cnt != "0":
            stat_parts.append(f"👍 {digg_cnt}")
        if comment_cnt != "0":
            stat_parts.append(f"💬 {comment_cnt}")
        if collect_cnt != "0":
            stat_parts.append(f"⭐ {collect_cnt}")
        if stat_parts:
            markdown_lines.append(f"📊 **数据**：{' · '.join(stat_parts)}")

        rows = []
        # 第 1 行：翻页导航
        nav_row = []
        if page > 1:
            nav_row.append(make_button("⬅️ 上一张", f"/dy page {url} {page - 1}", type=1, permission=0))
        
        # 中间显示当前页数并回传指令到用户输入框（action_type=2, enter=False），用户输入目标页码即可快速跳页
        jump_label = f"跳页 {page}/{total_pages}"
        if len(jump_label) > 10:
            jump_label = f"{page}/{total_pages}"
        nav_row.append(
            make_button(
                jump_label,
                f"/dy page {url} ",
                type=2,
                permission=0,
                enter=False,
            )
        )
        if page < total_pages:
            nav_row.append(make_button("下一张 ➡️", f"/dy page {url} {page + 1}", type=1, permission=0))
        rows.append(nav_row)

        # 检测图集是否包含背景音乐
        raw_music = data.get("music") or data.get("music_info") or data.get("audio")
        has_bgm = False
        if isinstance(raw_music, dict):
            play_info = raw_music.get("play_url") if isinstance(raw_music.get("play_url"), dict) else {}
            u_list = play_info.get("url_list") or raw_music.get("url_list") or []
            if u_list or raw_music.get("play_url"):
                has_bgm = True
        elif isinstance(raw_music, str) and raw_music.strip():
            has_bgm = True

        # 第 2 行：打包发送 (ZIP) 与音频提取（已移除逐张直发）
        action_row = [
            make_button("📦 打包发送", f"/dy zip {url}", type=1, permission=0),
        ]
        if has_bgm:
            action_row.append(make_button("🎵 提取音频", f"/dy audio {url}", type=1, permission=0))
        rows.append(action_row)

        # 第 3 行：直达与返回
        rows.append([
            make_button("网页打开", url, type=0),
            make_button("抖音菜单", "/dy", type=1, permission=0),
        ])

        return make_card(f"抖音图集 ({page}/{total_pages})", "\n\n".join(markdown_lines), rows)

    # ================= 音频转码 =================
    async def _convert_audio_to_mp3(self, source_path: Path) -> Path:
        """Convert audio/video container file to genuine mp3 for QQ voice/audio compatibility."""
        ffmpeg_bin = shutil.which("ffmpeg") or ("/app/data/bin/ffmpeg" if Path("/app/data/bin/ffmpeg").is_file() else None)
        if not ffmpeg_bin:
            return source_path
        mp3_path = source_path.with_suffix(".mp3")
        if mp3_path.resolve() == source_path.resolve():
            mp3_path = source_path.parent / f"{source_path.stem}_transcoded.mp3"
        cmd = [
            str(ffmpeg_bin),
            "-y",
            "-i", str(source_path),
            "-vn",
            "-c:a", "libmp3lame",
            "-q:a", "2",
            str(mp3_path),
        ]
        try:
            proc = await asyncio.create_subprocess_exec(
                *cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )
            await proc.communicate()
            if proc.returncode == 0 and mp3_path.is_file() and mp3_path.stat().st_size > 0:
                source_path.unlink(missing_ok=True)
                return mp3_path
        except Exception as e:
            logger.warning("抖音音频转码为 MP3 失败 (%s)，保持原文件", e)
        return source_path

    # ================= 媒体发送与下载 =================
    async def _send_file_to_qq(self, context: Any, file_path: Path, file_type: int) -> tuple[bool, str]:
        qq = getattr(self.context, "qq", None)
        media = getattr(self.context, "media", None)
        if not qq:
            return False, "QQ 网关不可用"
        scene = getattr(context, "scene", None) or getattr(context, "conversation_type", "group")
        conversation_id = str(
            getattr(context, "conversation_id", "")
            or getattr(context, "group_openid", "")
            or getattr(context, "openid", "")
            or ""
        ).strip()
        if not conversation_id:
            return False, "缺少 conversation_id"

        if not media or not hasattr(media, "prepare"):
            return False, "Runtime 媒体服务不可用"

        effective_file_type = file_type
        if effective_file_type == 3 and file_path.suffix.lower() not in {".silk", ".mp3", ".wav", ".ogg"}:
            effective_file_type = 4

        async def _do_upload_and_send(target_type: int) -> tuple[bool, str]:
            req = await media.prepare(scene, conversation_id, target_type, file_path)
            up = await qq.upload_media_file(req, file_path)
            f_info = up.get("file_info") if isinstance(up, dict) else str(up)
            if not f_info:
                return False, "未获取到上传后的 file_info"
            m_id = getattr(context, "message_id", None)
            if not isinstance(m_id, str) or not m_id.strip() or (len(m_id) == 36 and m_id.count("-") == 4):
                m_id = None
            try:
                if m_id:
                    await qq.send_media(conversation_id, scene, str(f_info), msg_id=m_id)
                else:
                    await qq.send_media(conversation_id, scene, str(f_info))
            except Exception as s_err:
                if m_id:
                    logger.warning("带 msg_id 发送媒体失败 (%s)，回退主动发送...", s_err)
                    await qq.send_media(conversation_id, scene, str(f_info))
                else:
                    raise
            return True, ""

        if effective_file_type == 3:
            try:
                ok, err = await _do_upload_and_send(3)
                if ok:
                    return True, ""
                logger.warning("QQ 语音/音频发送未成功 (%s)，自动降级为普通文件 (file_type=4)...", err)
            except Exception as audio_err:
                logger.warning("QQ 语音/音频发送异常 (%s)，自动降级为普通文件 (file_type=4)...", audio_err)
            return await _do_upload_and_send(4)

        return await _do_upload_and_send(effective_file_type)

    async def _download_and_send(self, context: Any, source_url: str, audio_only: bool = False, as_file: bool = False) -> str:
        base = str(self._cfg("douyin_api_base_url") or "").rstrip("/")
        if not base:
            return "尚未配置抖音解析服务地址。"
        try:
            quality = max(0, int(self._cfg("video_quality_index") or 0))
        except Exception:
            quality = 0

        # 1. 尝试获取作品详情与背景音乐
        work_title = ""
        is_image_set = False
        direct_music_url = None
        try:
            status, data = await self._fetch_aweme_data(source_url)
            if status < 400 and isinstance(data, dict):
                work_title = str(data.get("title") or data.get("desc") or "").strip()
                content_type = str(data.get("content_type") or data.get("type") or "").lower()
                raw_images = data.get("images") or data.get("image_urls") or data.get("image_list") or []
                is_image_set = content_type in {"image", "images", "note", "picture"} or bool(raw_images)

                raw_music = data.get("music") or data.get("music_info") or data.get("audio")
                if isinstance(raw_music, dict):
                    play_info = raw_music.get("play_url") if isinstance(raw_music.get("play_url"), dict) else {}
                    u_list = play_info.get("url_list") or raw_music.get("url_list") or []
                    if u_list and isinstance(u_list, list) and u_list[0]:
                        direct_music_url = _https_url(str(u_list[0]).strip())
                    elif isinstance(raw_music.get("play_url"), str) and raw_music["play_url"].strip():
                        direct_music_url = _https_url(raw_music["play_url"].strip())
        except Exception:
            pass

        # 2. 检查缓存
        cache_key = (source_url.strip(), bool(audio_only), quality)
        cached_entry = self._media_cache.get(cache_key)
        if cached_entry:
            expire_at, cached_path = cached_entry
            if time.monotonic() < expire_at and cached_path.is_file() and cached_path.stat().st_size > 0:
                file_type = 4 if (audio_only and as_file) else (3 if audio_only else 2)
                ok, err = await self._send_file_to_qq(context, cached_path, file_type)
                if ok:
                    return ""
                logger.warning("抖音缓存文件发送失败，将重新请求下载: %s", err)

        # 3. 针对音频提取：如果存在原生音乐直链，直接快速下载并发送（绕过转码与图集在 /api/video/download 报 422 的缺陷）
        if audio_only and direct_music_url:
            raw_limit = max(0, int(self._cfg("max_video_file_size_mb") or 30)) * 1024 * 1024
            limit = min(raw_limit, 28 * 1024 * 1024) if raw_limit > 0 else (28 * 1024 * 1024)
            target = self.downloads_dir / f"{uuid.uuid4().hex}.mp3"
            target, error = await self._download_http_file(direct_music_url, target, self._service_headers(), limit)
            if target and target.is_file() and target.stat().st_size > 0:
                target = await self._convert_audio_to_mp3(target)
                if work_title:
                    safe_title = _sanitize_filename(work_title)
                    if safe_title:
                        friendly_target = self.downloads_dir / f"{safe_title}.mp3"
                        try:
                            if friendly_target.resolve() != target.resolve():
                                friendly_target.unlink(missing_ok=True)
                                target = target.rename(friendly_target)
                        except Exception:
                            pass
                try:
                    cached_target = self.cache_dir / f"cache_{uuid.uuid4().hex}{target.suffix}"
                    shutil.copy2(target, cached_target)
                    self._clean_media_cache()
                    self._media_cache[cache_key] = (time.monotonic() + 600.0, cached_target)
                except Exception:
                    pass

                file_type = 4 if as_file else 3
                ok, err = await self._send_file_to_qq(context, target, file_type)
                if not ok:
                    return f"抖音音频已下载，但 QQ 发送失败：{err}"
                return ""

        # 4. 图集作品如果没有任何背景音乐，直接阻断，避免调用 /api/video/download 报 422
        if is_image_set and audio_only:
            return "该图集作品未配置背景音乐，无法提取音频。"

        params = {"url": source_url, "quality_index": str(quality)}
        if audio_only:
            params["audio_only"] = "true"

        status, payload = await self._request_status("/api/video/download", method="POST", params=params)
        task_id = str(payload.get("task_id") or payload.get("id") or "") if isinstance(payload, dict) else ""
        if status >= 400 or not task_id:
            return self._format_aweme_error(status, payload if isinstance(payload, dict) else None)

        timeout = max(0, int(self._cfg("video_download_timeout_sec") or 180))
        deadline = time.monotonic() + timeout if timeout else None
        filename = ""
        download_url = ""
        while deadline is None or time.monotonic() < deadline:
            poll_status, poll_payload = await self._request_status(f"/api/tasks/{quote(task_id, safe='')}")
            task = poll_payload.get("task") if isinstance(poll_payload, dict) and isinstance(poll_payload.get("task"), dict) else poll_payload
            if isinstance(task, dict):
                state = str(task.get("status") or task.get("state") or "").lower()
                filename = str(task.get("filename") or task.get("file_name") or "")
                download_url = str(task.get("download_url") or task.get("file_url") or "")
                if state in {"failed", "error", "canceled", "cancelled", "stopped"}:
                    return f"抖音资源下载失败：{task.get('message') or state}"
                if state in {"completed", "complete", "success", "done", "已完成"}:
                    break
            if poll_status in {404, 410}:
                return "抖音下载任务不存在，可能已被服务端清理。"
            await asyncio.sleep(max(0.5, float(self._cfg("video_poll_interval_sec") or 1)))
        else:
            return "抖音下载等待超时。"

        if not download_url:
            if not filename:
                return "抖音任务已完成，但服务端没有返回文件名。"
            download_url = f"{base}/api/files/{quote(Path(filename).name, safe='')}"

        raw_limit = max(0, int(self._cfg("max_video_file_size_mb") or 30)) * 1024 * 1024
        limit = min(raw_limit, 28 * 1024 * 1024) if raw_limit > 0 else (28 * 1024 * 1024)
        ext = ".mp3" if audio_only else ".mp4"
        target = self.downloads_dir / f"{uuid.uuid4().hex}{ext}"
        target, error = await self._download_http_file(download_url, target, self._service_headers(), limit)
        if not target:
            return f"抖音文件下载失败：{error}"

        # 若为音频模式，使用 ffmpeg 提取出纯音频 mp3 文件
        if audio_only:
            target = await self._convert_audio_to_mp3(target)

        # 若为音频文件模式且获取到了作品标题，重命名为标题以使 QQ 显示真实歌名/标题
        if audio_only and work_title:
            safe_title = _sanitize_filename(work_title)
            if safe_title:
                friendly_target = self.downloads_dir / f"{safe_title}.mp3"
                try:
                    if friendly_target.resolve() != target.resolve():
                        friendly_target.unlink(missing_ok=True)
                        target = target.rename(friendly_target)
                except Exception as copy_err:
                    logger.warning("重命名抖音音频文件为标题失败: %s", copy_err)

        try:
            cached_target = self.cache_dir / f"cache_{uuid.uuid4().hex}{target.suffix}"
            shutil.copy2(target, cached_target)
            self._clean_media_cache()
            self._media_cache[cache_key] = (time.monotonic() + 600.0, cached_target)
        except Exception as cache_err:
            logger.warning("缓存抖音媒体失败: %s", cache_err)

        file_type = 4 if (audio_only and as_file) else (3 if audio_only else 2)
        ok, err = await self._send_file_to_qq(context, target, file_type)
        if not ok:
            return f"抖音媒体已下载，但 QQ 媒体发送失败：{err}"
        return ""

    async def _async_download_and_send(self, context: Any, source_url: str, audio_only: bool = False, as_file: bool = False) -> None:
        key = self._task_key(context.conversation_id, source_url, audio_only=audio_only, as_file=as_file)
        if key in self._in_flight_tasks:
            return
        if time.monotonic() - self._recently_sent.get(key, 0) < 30:
            return
        self._in_flight_tasks.add(key)
        try:
            result = await self._download_and_send(context, source_url, audio_only=audio_only, as_file=as_file)
            if not result:
                self._recently_sent[key] = time.monotonic()
            else:
                qq = getattr(self.context, "qq", None)
                if qq and hasattr(qq, "send_text"):
                    scene = getattr(context, "scene", None) or getattr(context, "conversation_type", "group")
                    await qq.send_text(context.conversation_id, scene, f"抖音媒体发送失败：{result}")
        except Exception as e:
            logger.exception("抖音异步下载与发送异常: %s", e)
            qq = getattr(self.context, "qq", None)
            if qq and hasattr(qq, "send_text"):
                scene = getattr(context, "scene", None) or getattr(context, "conversation_type", "group")
                await qq.send_text(context.conversation_id, scene, f"抖音媒体处理失败：{e}")
        finally:
            self._in_flight_tasks.discard(key)

    async def _download_and_send_images(self, context: Any, source_url: str) -> str:
        base = str(self._cfg("douyin_api_base_url") or "").rstrip("/")
        if not base:
            return "尚未配置抖音解析服务地址。"
        try:
            status, data = await self._fetch_aweme_data(source_url)
            if status >= 400 or not data:
                return self._format_aweme_error(status, data)

            img_urls: list[str] = []
            if isinstance(data.get("image_urls"), list):
                for u in data["image_urls"]:
                    if isinstance(u, str) and u.strip():
                        img_urls.append(_https_url(u.strip()))
            elif isinstance(data.get("images"), list):
                for item in data["images"]:
                    if isinstance(item, dict):
                        urls = item.get("url_list") or item.get("download_url_list") or []
                        if urls and isinstance(urls, list):
                            img_urls.append(_https_url(urls[0]))
                    elif isinstance(item, str) and item.strip():
                        img_urls.append(_https_url(item.strip()))

            if not img_urls:
                return "未获取到图集图片地址，该作品可能为视频而非图集。"

            max_count = max(1, int(self._cfg("max_image_count") or 9))
            to_send = img_urls[:max_count]
            total_found = len(img_urls)

            success_count = 0
            tmp_dir = self.downloads_dir / f"dy_img_{uuid.uuid4().hex[:8]}"
            tmp_dir.mkdir(parents=True, exist_ok=True)
            try:
                for idx, img_url in enumerate(to_send, start=1):
                    ext = ".jpg"
                    if ".png" in img_url.lower():
                        ext = ".png"
                    elif ".webp" in img_url.lower():
                        ext = ".webp"
                    local_file = tmp_dir / f"image_{idx}{ext}"
                    target, err = await self._download_http_file(img_url, local_file, self._service_headers(), max_bytes=10 * 1024 * 1024)
                    if not target or not target.is_file():
                        logger.warning("下载图集图片 %d 失败: %s", idx, err)
                        continue
                    ok, send_err = await self._send_file_to_qq(context, target, file_type=1)
                    if ok:
                        success_count += 1
                    else:
                        logger.warning("发送图集图片 %d 失败: %s", idx, send_err)
                    await asyncio.sleep(0.3)
            finally:
                shutil.rmtree(tmp_dir, ignore_errors=True)

            if success_count == 0:
                return "图集图片发送失败，请稍后重试。"
            if success_count < total_found:
                return f"图集共 {total_found} 张，已发送前 {success_count} 张（单次上限 {max_count} 张）。"
            return ""
        except Exception as e:
            logger.exception("处理抖音图集失败: %s", e)
            return f"处理图集失败: {e}"

    @staticmethod
    def _format_aweme_error(status: int, data: dict[str, Any] | None = None) -> str:
        data = data or {}
        detail = str(
            data.get("detail")
            or data.get("message")
            or data.get("error")
            or data.get("text")
            or ""
        ).strip()
        detail_lower = detail.lower()

        if status == 422:
            if "cookie" in detail_lower or "uifid" in detail_lower or "argus" in detail_lower or "auth" in detail_lower or "风控" in detail_lower:
                return "抖音作品解析失败：服务端抖音 Cookie 已失效或触发安全风控，请在管理台更新有效 Cookie 后重试。"
            if "unable to parse" in detail_lower or "check the url" in detail_lower or "404" in detail_lower:
                return "抖音作品解析失败：该作品可能已被删除、设置为私密，或当前链接无法公开访问 (HTTP 422)。"
            if detail:
                return f"抖音作品解析失败：作品不可访问或参数有误（{detail[:100]}，HTTP 422）。"
            return "抖音作品解析失败：该作品可能已被删除、设置为私密或链接无效 (HTTP 422)。"

        if status == 404:
            return "抖音作品解析失败：未找到指定作品，链接可能已失效或被删除 (HTTP 404)。"

        if status == 429:
            return "抖音解析请求过于频繁，已被服务限流，请稍后再试 (HTTP 429)。"

        if status in {401, 403}:
            return f"抖音解析服务鉴权失败或拒绝访问 (HTTP {status})，请检查 API Token 配置。"

        if status >= 500:
            if detail:
                return f"抖音解析上游服务响应异常：{detail[:100]} (HTTP {status})。"
            return f"抖音解析上游服务暂时不可用 (HTTP {status})，请稍后重试。"

        if detail:
            return f"抖音解析失败：{detail[:120]} (HTTP {status})"
        return f"抖音解析失败：HTTP {status}"

    async def _fetch_aweme_data(self, source_url: str) -> tuple[int, dict[str, Any]]:
        """获取并缓存抖音作品核心详情数据（300秒内存缓存，翻页秒级响应）。"""
        now = time.monotonic()
        if source_url in self._info_cache:
            ts, cached = self._info_cache[source_url]
            if now - ts < 300:
                return 200, cached

        status, payload = await self._request_status("/api/video/info", params={"url": source_url})
        if status >= 400:
            return status, payload if isinstance(payload, dict) else {}
        raw_data = payload.get("data") if isinstance(payload.get("data"), dict) else payload
        if "aweme_detail" in raw_data and isinstance(raw_data["aweme_detail"], dict):
            data = raw_data["aweme_detail"]
        elif "item_list" in raw_data and isinstance(raw_data["item_list"], list) and raw_data["item_list"]:
            first_item = raw_data["item_list"][0]
            data = first_item if isinstance(first_item, dict) else raw_data
        else:
            data = raw_data

        if isinstance(data, dict):
            self._info_cache[source_url] = (now, data)
        return status, data

    async def _download_and_send_zip(self, context: Any, source_url: str) -> str:
        """下载图集全部原图并打包为 ZIP 发送。"""
        base = str(self._cfg("douyin_api_base_url") or "").rstrip("/")
        if not base:
            return "尚未配置抖音解析服务地址。"
        try:
            status, data = await self._fetch_aweme_data(source_url)
            if status >= 400 or not data:
                return self._format_aweme_error(status, data)

            img_urls = self._extract_image_urls(data)
            if not img_urls:
                return "未获取到图集图片地址，该作品可能为视频而非图集。"

            total_found = len(img_urls)
            title = str(data.get("title") or data.get("desc") or "douyin_atlas").strip()
            safe_title = re.sub(r'[\/:*?"<>|]', '_', title)[:30].strip() or "douyin_atlas"

            import zipfile
            tmp_dir = self.downloads_dir / f"dy_zip_{uuid.uuid4().hex[:8]}"
            tmp_dir.mkdir(parents=True, exist_ok=True)
            zip_file_path = tmp_dir / f"{safe_title}_图集_{total_found}张.zip"

            downloaded_files: list[Path] = []
            try:
                for idx, img_url in enumerate(img_urls, start=1):
                    ext = ".jpg"
                    if ".png" in img_url.lower():
                        ext = ".png"
                    elif ".webp" in img_url.lower():
                        ext = ".webp"
                    local_img = tmp_dir / f"image_{idx:02d}{ext}"
                    target, err = await self._download_http_file(img_url, local_img, self._service_headers(), max_bytes=15 * 1024 * 1024)
                    if target and target.is_file():
                        downloaded_files.append(target)
                    else:
                        logger.warning("打包下载图集图片 %d 失败: %s", idx, err)

                if not downloaded_files:
                    return "图集原图下载失败，未能打包压缩包。"

                with zipfile.ZipFile(str(zip_file_path), "w", compression=zipfile.ZIP_DEFLATED) as zf:
                    for f in downloaded_files:
                        zf.write(str(f), arcname=f.name)

                ok, send_err = await self._send_file_to_qq(context, zip_file_path, file_type=4)
                if not ok:
                    return f"发送图集压缩包失败：{send_err}"
                return ""
            finally:
                shutil.rmtree(tmp_dir, ignore_errors=True)
        except Exception as e:
            logger.exception("打包发送抖音图集失败: %s", e)
            return f"打包图集失败: {e}"

    async def _async_download_and_send_zip(self, context: Any, source_url: str) -> None:
        key = self._task_key(context.conversation_id, source_url, audio_only="zip")
        if key in self._in_flight_tasks:
            return
        if time.monotonic() - self._recently_sent.get(key, 0) < 30:
            return
        self._in_flight_tasks.add(key)
        try:
            result = await self._download_and_send_zip(context, source_url)
            if not result:
                self._recently_sent[key] = time.monotonic()
            else:
                qq = getattr(self.context, "qq", None)
                if qq and hasattr(qq, "send_text"):
                    scene = getattr(context, "scene", None) or getattr(context, "conversation_type", "group")
                    await qq.send_text(context.conversation_id, scene, f"抖音图集打包提示：{result}")
        except Exception as e:
            logger.exception("抖音图集打包发送异常: %s", e)
            qq = getattr(self.context, "qq", None)
            if qq and hasattr(qq, "send_text"):
                scene = getattr(context, "scene", None) or getattr(context, "conversation_type", "group")
                await qq.send_text(context.conversation_id, scene, f"抖音图集打包失败：{e}")
        finally:
            self._in_flight_tasks.discard(key)

    async def _async_download_and_send_images(self, context: Any, source_url: str) -> None:
        key = self._task_key(context.conversation_id, source_url, audio_only="images")
        if key in self._in_flight_tasks:
            return
        if time.monotonic() - self._recently_sent.get(key, 0) < 30:
            return
        self._in_flight_tasks.add(key)
        try:
            result = await self._download_and_send_images(context, source_url)
            if not result:
                self._recently_sent[key] = time.monotonic()
            else:
                qq = getattr(self.context, "qq", None)
                if qq and hasattr(qq, "send_text"):
                    scene = getattr(context, "scene", None) or getattr(context, "conversation_type", "group")
                    await qq.send_text(context.conversation_id, scene, f"抖音图集提示：{result}")
        except Exception as e:
            logger.exception("抖音图集发送异常: %s", e)
            qq = getattr(self.context, "qq", None)
            if qq and hasattr(qq, "send_text"):
                scene = getattr(context, "scene", None) or getattr(context, "conversation_type", "group")
                await qq.send_text(context.conversation_id, scene, f"抖音图集处理失败：{e}")
        finally:
            self._in_flight_tasks.discard(key)

    # ================= 指令入口 =================
    async def command(self, context: Any, args: list[str]) -> Any:
        command_parts = str(getattr(context, "text", "") or "").lstrip().split(maxsplit=1)
        invoked = command_parts[0].lstrip("/").lower() if command_parts else ""
        if invoked.startswith("dy_") and invoked != "dy":
            args = [invoked[3:], *args]

        if not args and invoked == "dy":
            return self._menu_card()
        if args and args[0].lower() in {"help", "menu", "帮助", "菜单"}:
            return self._menu_card()
        if args and args[0].lower() in {"parse", "解析"}:
            return self._submenu_card("parse")
        if args and args[0].lower() in {"config", "配置"}:
            return self._submenu_card("config")

        action = args[0].lower() if args else ""
        if action in {"login", "dy_login"}:
            return "抖音登录支持通过导入 Cookie 完成。清除 Cookie：`/dy login clear confirm`"

        if action in {"page", "p", "翻页", "分页", "跳页"}:
            clean_args = [a for a in args[1:] if a.strip()]
            page_num = 1
            source = ""
            for a in clean_args:
                if a.isdigit():
                    page_num = int(a)
                elif self.URL_RE.search(a):
                    source = self.URL_RE.search(a).group(0)
            if not source:
                match = self.URL_RE.search(str(getattr(context, "text", "") or ""))
                if match:
                    source = match.group(0)
            conv_id = str(getattr(context, "conversation_id", "") or "")
            if not source and conv_id:
                source = self._last_album_url.get(conv_id, "")
            if not source:
                return "用法：/dy page <抖音链接> <页码>（也可直接点击图集卡片中间的【跳页】按钮）"
            status, data = await self._fetch_aweme_data(source)
            if status >= 400 or not data:
                return self._format_aweme_error(status, data)
            if conv_id and source:
                self._last_album_url[conv_id] = source
            img_urls = self._extract_image_urls(data)
            if img_urls and 1 <= page_num <= len(img_urls):
                await self._resolve_image_dimension(img_urls[page_num - 1])
            card = self._build_image_set_page_card(data, source, current_page=page_num)
            qq = getattr(self.context, "qq", None)
            if qq and hasattr(qq, "send_card"):
                scene = getattr(context, "scene", None) or getattr(context, "conversation_type", "group")
                await qq.send_card(context.conversation_id, scene, card)
                return ""
            return card

        if action in {"zip", "pack", "打包", "压缩包"}:
            raw_source = " ".join(args[1:]).strip() or str(getattr(context, "text", "") or "").split(maxsplit=2)[-1]
            match = self.URL_RE.search(raw_source)
            if not match:
                return "用法：/dy zip <抖音链接>"
            source = match.group(0)
            asyncio.create_task(self._async_download_and_send_zip(context, source))
            return "📦 已开始下载图集全套原图并打包 ZIP，正在处理中，请稍候..."

        if action in {"images", "image", "imgs", "img", "图集", "图片"}:
            raw_source = " ".join(args[1:]).strip() or str(getattr(context, "text", "") or "").split(maxsplit=2)[-1]
            match = self.URL_RE.search(raw_source)
            if not match:
                return "用法：/dy images <抖音链接>"
            source = match.group(0)
            asyncio.create_task(self._async_download_and_send_images(context, source))
            return "🖼️ 已开始获取抖音图集，正在处理并发送图片中，请稍候..."

        if action in {"dl", "download", "下载"}:
            raw_source = " ".join(args[1:]).strip() or str(getattr(context, "text", "") or "").split(maxsplit=2)[-1]
            match = self.URL_RE.search(raw_source)
            if not match:
                return "用法：/dy dl <抖音链接>"
            source = match.group(0)
            asyncio.create_task(self._async_download_and_send(context, source, audio_only=False))
            return "🎬 已开始抓取抖音视频，正在下载中，请稍候..."

        is_audio_file = action in {"audio_file", "audiofile", "file_audio", "fileaudio", "音频文件"}
        if action in {"audio", "dy_audio", "音频"} or is_audio_file:
            all_text_lower = " ".join(args).lower()
            if "file" in all_text_lower or "文件" in all_text_lower:
                is_audio_file = True
            clean_args = [a for a in args[1:] if a.lower() not in {"file", "audio_file", "audiofile", "file_audio", "fileaudio", "文件", "音频文件"}]
            raw_source = " ".join(clean_args).strip() or str(getattr(context, "text", "") or "").split(maxsplit=2)[-1]
            raw_source = re.sub(r"\s+(file|文件)$", "", raw_source, flags=re.I).strip()
            match = self.URL_RE.search(raw_source)
            if not match:
                return "用法：/dy audio <抖音链接>（发送语音）或 /dy audio_file <抖音链接>（发送音频文件）"
            source = match.group(0)
            target_label = "音频文件" if is_audio_file else "语音"
            asyncio.create_task(self._async_download_and_send(context, source, audio_only=True, as_file=is_audio_file))
            return f"🎵 已开始提取抖音{target_label}，正在下载中，请稍候..."

        if action in {"task", "dy_task", "file", "dy_file"}:
            is_task = action in {"task", "dy_task"}
            try:
                sub = str(args[1] if len(args) > 1 else "list").lower()
                target = str(args[2] if len(args) > 2 else "")
                if sub in {"del", "delete", "remove", "删除"}:
                    if not target:
                        return "请提供要删除的任务 ID 或文件名。"
                    if is_task:
                        status, _ = await self._request_status(f"/api/tasks/{quote(target, safe='')}", method="DELETE")
                        if status in {404, 405}:
                            status, _ = await self._request_status(f"/api/tasks/remove/{quote(target, safe='')}", method="POST", json={})
                    else:
                        status, _ = await self._request_status(f"/api/files/{quote(target, safe='')}", method="DELETE")
                    return "删除成功。" if status < 400 or status == 404 else f"删除失败：HTTP {status}"

                data = await self._request("/api/tasks" if is_task else "/api/files")
                key = "tasks" if is_task else "files"
                items = data.get(key, []) if isinstance(data.get(key), list) else []
                if not items:
                    return "暂无记录。"
                page = max(1, int(sub)) if sub.isdigit() else 1
                size = 8
                total_pages = max(1, (len(items) + size - 1) // size)
                page = min(page, total_pages)
                current = items[(page - 1) * size : page * size]
                command_prefix = "/dy task" if is_task else "/dy file"
                if is_task:
                    lines = ["| # | 任务 ID | 状态 | 消息 |", "|---:|---|---|---|"]
                    for index, item in enumerate(current, (page - 1) * size + 1):
                        lines.append(f"| {index} | `{item.get('task_id') or item.get('id') or '-'}` | {item.get('status') or 'unknown'} | {item.get('message') or '-'} |")
                    title = f"抖音下载任务（第 {page}/{total_pages} 页）"
                else:
                    lines = ["| # | 文件名 |", "|---:|---|"]
                    for index, item in enumerate(current, (page - 1) * size + 1):
                        lines.append(f"| {index} | `{item.get('filename') or item.get('name') or '-'}` |")
                    title = f"抖音下载文件（第 {page}/{total_pages} 页）"

                button_rows = [
                    [
                        make_button("上一页", f"{command_prefix} {page - 1}", type=1) if page > 1 else make_button("首页", f"{command_prefix} 1", type=1),
                        make_button("跳页", f"{command_prefix} ", type=2),
                        make_button("下一页", f"{command_prefix} {page + 1}", type=1) if page < total_pages else make_button("尾页", f"{command_prefix} {total_pages}", type=1),
                    ],
                    [
                        make_button("刷新", f"{command_prefix} {page}", type=1),
                        make_button("删除任务" if is_task else "删除文件", f"{command_prefix} del ", type=2),
                        make_button("返回菜单", "/dy", type=1),
                    ],
                ]
                return make_card(title, "\n".join(lines), button_rows)
            except Exception as error:
                return f"抖音服务请求失败：{str(error)[:160]}"

        if action in {"net", "dy_net"}:
            try:
                root_status, _ = await self._request_status("/")
                login_status, login = await self._request_status("/api/login/status")
                return f"抖音解析服务：{'正常' if root_status < 400 else f'异常（HTTP {root_status}）'}；令牌：{'已配置' if self._cfg('douyin_api_token') else '未设置'}；Cookie：{'已登录' if login_status < 400 and isinstance(login, dict) and login.get('logged_in') else '未登录'}。"
            except Exception as error:
                return f"抖音服务检查失败：{str(error)[:160]}"

        text = " ".join(args).strip() or str(getattr(context, "text", "") or "").strip()
        match = self.URL_RE.search(text)
        if not match:
            return "用法：/dy <抖音链接>"
        url = match.group(0)
        try:
            status, data = await self._fetch_aweme_data(url)
            if status >= 400 or not data:
                return self._format_aweme_error(status, data)
            conv_id = str(getattr(context, "conversation_id", "") or "")
            img_urls = self._extract_image_urls(data)
            if img_urls:
                await self._resolve_image_dimension(img_urls[0])
            else:
                cover = _https_url(data.get("cover") or data.get("cover_url") or data.get("dynamic_cover") or ((data.get("video") or {}).get("cover") if isinstance(data.get("video"), dict) else None))
                if cover:
                    await self._resolve_image_dimension(cover)
            card = self._build_info_card(data, url, conv_id)
            qq = getattr(self.context, "qq", None)
            if qq and hasattr(qq, "send_card"):
                scene = getattr(context, "scene", None) or getattr(context, "conversation_type", "group")
                await qq.send_card(context.conversation_id, scene, card)
                return ""
            return card
        except Exception as e:
            return f"抖音解析异常：{str(e)[:200]}"

    async def on_event(self, context: Any) -> Any:
        if not self._cfg("enable_auto_detect"):
            return None
        text = str(getattr(context, "text", "") or "").strip()
        if text.startswith("/"):
            return None
        match = self.URL_RE.search(text)
        if not match:
            return None
        return await self.command(context, [match.group(0)])

    # ================= 管理台数据通信 =================
    async def _write_page_snapshot(self) -> None:
        """导出声明式原生 UI 控制台所需的快照数据。"""
        out_dir = self.data_dir
        out_dir.mkdir(parents=True, exist_ok=True)
        snapshot_file = out_dir / "page_overview.json"
        nested = self.data_dir / "plugin-data"
        if nested.is_dir():
            shutil.rmtree(nested, ignore_errors=True)

        service_status = "unconfigured"
        service_latency_ms = 0.0
        cookie_status = "missing"
        cookie_message = "未登录抖音 Cookie"

        base = str(self._cfg("douyin_api_base_url") or "").rstrip("/")
        tasks = []
        files = []
        if base:
            t0 = time.monotonic()
            try:
                code, root_payload = await self._request_status("/")
                service_latency_ms = round((time.monotonic() - t0) * 1000, 1)
                if code < 400:
                    service_status = "healthy"
                else:
                    service_status = "error"
            except Exception:
                service_status = "unreachable"

            try:
                st_code, login_payload = await self._request_status("/api/login/status")
                if st_code < 400 and isinstance(login_payload, dict) and login_payload.get("logged_in"):
                    cookie_status = "healthy"
                    cookie_message = "抖音 Cookie 已正常登录"
                elif self._cfg("douyin_cookie"):
                    cookie_status = "unauthorized"
                    cookie_message = "已配置 Cookie 但未登录或已失效"
            except Exception:
                cookie_status = "error"

            try:
                t_data = await self._request("/api/tasks")
                tasks = t_data.get("tasks", []) if isinstance(t_data, dict) else []
            except Exception:
                pass
            try:
                f_data = await self._request("/api/files")
                files = f_data.get("files", []) if isinstance(f_data, dict) else []
            except Exception:
                pass

        snapshot = {
            "updated_at": datetime.datetime.now(datetime.UTC).isoformat(),
            "config": dict(self.config),
            "schema": CONFIG_SCHEMA,
            "labels": CONFIG_LABELS,
            "stats": {
                "缓存媒体数": len(self._media_cache),
                "服务端任务数": len(tasks),
                "服务端文件数": len(files),
                "Cookie 说明": cookie_message or "未配置",
            },
            "service": {
                "服务状态": service_status,
                "接口延迟": f"{service_latency_ms} ms" if service_latency_ms else "未知",
                "Cookie 状态": "已就绪" if cookie_status == "ok" else ("未配置" if cookie_status == "missing" else "异常"),
            },
            "tasks": tasks,
            "files": files,
        }
        try:
            snapshot_file.write_text(json.dumps(snapshot, ensure_ascii=False, indent=2), encoding="utf-8")
        except Exception as e:
            logger.warning("写入 plugin.dy page_overview.json 失败: %s", e)

    async def action_page_data(self, payload: dict[str, Any] | None = None) -> dict[str, Any]:
        base = str(self._cfg("douyin_api_base_url") or "").rstrip("/")
        if not base:
            return {"service_configured": False, "tasks": [], "files": []}

        headers = self._service_headers()
        tasks: list[dict[str, Any]] = []
        files: list[dict[str, Any]] = []
        timeout = float(self._cfg("api_timeout_sec") or 20)
        async with httpx.AsyncClient(timeout=timeout) as client:
            try:
                t_res = await client.get(f"{base}/api/tasks/json", headers=headers)
                if t_res.status_code == 200:
                    raw_tasks = t_res.json().get("tasks", {})
                    if isinstance(raw_tasks, dict):
                        tasks = [{"id": k, **(v if isinstance(v, dict) else {"status": v})} for k, v in raw_tasks.items()]
                    elif isinstance(raw_tasks, list):
                        tasks = [{"id": str(t.get("id", "") if isinstance(t, dict) else t), **(t if isinstance(t, dict) else {"status": t})} for t in raw_tasks]
            except Exception:
                try:
                    t_res = await client.get(f"{base}/api/tasks", headers=headers)
                    if t_res.status_code == 200:
                        raw = t_res.json()
                        raw_tasks = raw.get("tasks", raw)
                        if isinstance(raw_tasks, list):
                            tasks = [{"id": str(t.get("id", "") if isinstance(t, dict) else t), **(t if isinstance(t, dict) else {"status": t})} for t in raw_tasks]
                except Exception:
                    pass

            try:
                f_res = await client.get(f"{base}/api/files", headers=headers)
                if f_res.status_code == 200:
                    raw_files = f_res.json().get("files", [])
                    if isinstance(raw_files, list):
                        files = [{"name": str(f.get("name", "") if isinstance(f, dict) else f), **(f if isinstance(f, dict) else {})} for f in raw_files]
            except Exception:
                pass

        return {"tasks": tasks, "files": files}

    async def on_page_action(self, action: str, payload: dict[str, Any]) -> dict[str, Any]:
        """处理管理台保存配置、删除文件/任务等操作。"""
        if action in {"save_config", "config"}:
            cfg_updates = payload.get("config") or payload
            if isinstance(cfg_updates, dict):
                for k, v in cfg_updates.items():
                    if k in DEFAULT_CONFIG:
                        self.config[k] = v
                self._save_config()

                # 如果更新了 douyin_cookie，自动同步至解析服务
                if "douyin_cookie" in cfg_updates:
                    cookie_val = str(cfg_updates.get("douyin_cookie") or "").strip()
                    if cookie_val:
                        try:
                            st, resp = await self._request_status(
                                "/api/login/cookie",
                                method="POST",
                                json={"cookie": cookie_val},
                            )
                            logger.info("Auto-synced douyin_cookie to parse service: status=%s resp=%s", st, resp)
                        except Exception as sync_err:
                            logger.warning("Failed to auto-sync douyin_cookie to service: %s", sync_err)
                    else:
                        try:
                            await self._request_status("/api/login/cookie", method="DELETE")
                        except Exception:
                            pass

                await self._write_page_snapshot()
                return {"saved": True, "config": self.config}
            return {"saved": False, "error": "无效的配置参数"}

        if action in {"page_data", "data"}:
            return await self.action_page_data(payload)

        if action in {"page_delete", "delete"}:
            kind = str(payload.get("kind") or "file").strip()
            raw_targets = payload.get("identifiers") or [payload.get("identifier") or payload.get("id") or payload.get("filename")]
            targets: list[str] = []
            for t in raw_targets:
                if isinstance(t, list):
                    targets.extend(str(item) for item in t if item)
                elif t:
                    targets.append(str(t))
            targets = [t.strip() for t in targets if t.strip()]
            if not targets:
                return {"success": False, "error": "缺少删除标识"}

            deleted_ids = []
            if kind == "task":
                for tid in targets:
                    res = await self.on_page_action("cancel_task", {"task_id": tid})
                    if isinstance(res, dict) and res.get("success"):
                        deleted_ids.append(tid)
            else:
                for fname in targets:
                    res = await self.on_page_action("delete_file", {"filename": fname})
                    if isinstance(res, dict) and res.get("success"):
                        deleted_ids.append(fname)
            await self._write_page_snapshot()
            return {"success": True, "deleted": True, "ids": deleted_ids}

        if action in {"delete_file", "del_file"}:
            filename = payload.get("filename") or payload.get("name") or payload.get("id")
            if not filename:
                return {"success": False, "error": "缺少文件名"}
            import urllib.parse
            fname = Path(str(filename)).name.strip()
            fname = urllib.parse.unquote(fname)
            if not fname:
                return {"success": False, "error": "文件名无效"}
            safe_name = quote(fname, safe="")
            code, _ = await self._request_status(f"/api/files/{safe_name}", method="DELETE")
            await self._write_page_snapshot()
            return {"success": code < 400 or code == 404}

        if action in {"cancel_task", "del_task"}:
            task_id = payload.get("task_id") or payload.get("id")
            if not task_id:
                return {"success": False, "error": "缺少任务编号"}
            code, _ = await self._request_status(f"/api/tasks/{quote(str(task_id), safe='')}", method="DELETE")
            if code in {404, 405}:
                code, _ = await self._request_status(f"/api/tasks/remove/{quote(str(task_id), safe='')}", method="POST", json={})
            await self._write_page_snapshot()
            return {"success": code < 400 or code == 404}

        return {"error": f"未知操作: {action}"}


async def setup(context: Any) -> DyPlugin:
    plugin = DyPlugin(context)
    if hasattr(context, "register_command"):
        context.register_command("dy", plugin.command)
    if hasattr(context, "register_event_handler"):
        context.register_event_handler("*", plugin.on_event)
    if hasattr(context, "register_page_action"):
        context.register_page_action("home", plugin.on_page_action)
        context.register_page_action("save_config", plugin.on_page_action)
    if hasattr(context, "register_action"):
        context.register_action("save_config", plugin.on_page_action)
        context.register_action("page_data", plugin.on_page_action)
        context.register_action("page_delete", plugin.on_page_action)
        context.register_action("delete_file", plugin.on_page_action)
        context.register_action("cancel_task", plugin.on_page_action)
    await plugin._write_page_snapshot()
    logger.info("plugin.dy %s 已成功初始化加载", PLUGIN_VERSION)
    return plugin
