// Simple bridge to communicate with dashboard / plugin sandbox
function callAction(action, payload = {}) {
  return new Promise((resolve) => {
    const reqId = "req_" + Math.random().toString(36).slice(2);
    const handler = (e) => {
      if (e.data && e.data.reqId === reqId) {
        window.removeEventListener("message", handler);
        resolve(e.data.response);
      }
    };
    window.addEventListener("message", handler);
    window.parent.postMessage({ type: "plugin_action", action, payload, reqId }, "*");
  });
}

document.querySelectorAll(".tab").forEach((tab) => {
  tab.addEventListener("click", () => {
    document.querySelectorAll(".tab").forEach((t) => t.classList.remove("active"));
    document.querySelectorAll(".tab-panel").forEach((p) => p.classList.remove("active"));
    tab.classList.add("active");
    const target = tab.getAttribute("data-tab");
    document.getElementById("tab-" + target).classList.add("active");
  });
});

async function loadOverview() {
  const res = await callAction("overview");
  if (res && res.config) {
    const c = res.config;
    ["api_base_url", "api_key", "default_model", "aspect_ratio", "duration_sec", "provider_protocol", "custom_endpoint", "google_api_key", "video_credit_cost", "credit_cost_rules", "cooldown_sec"].forEach((k) => {
      const el = document.getElementById(k);
      if (el && c[k] !== undefined) {
        el.value = c[k];
      }
    });
  }
}

document.getElementById("btn-save").addEventListener("click", async () => {
  const status = document.getElementById("save-status");
  status.textContent = "正在保存...";
  const payload = {};
  ["api_base_url", "api_key", "default_model", "aspect_ratio", "duration_sec", "provider_protocol", "custom_endpoint", "google_api_key", "video_credit_cost", "credit_cost_rules", "cooldown_sec"].forEach((k) => {
    const el = document.getElementById(k);
    if (el) {
      payload[k] = el.type === "number" ? parseFloat(el.value) : el.value;
    }
  });
  const res = await callAction("save_config", payload);
  if (res && res.ok) {
    status.textContent = "✅ 保存成功！";
    setTimeout(() => { status.textContent = ""; }, 3000);
  } else {
    status.textContent = "❌ 保存失败";
  }
});

loadOverview();
