"""Video Generation Service Plugin (plugin.video.service).

Provides text-to-video, image-to-video, aspect-ratio/duration tuning,
credit billing, and asynchronous task polling for QQ Bot.
Supports Agnes, OpenAI-compatible, Google Veo, and Custom endpoints.
"""

from __future__ import annotations

import asyncio
import json
import logging
import math
import re
import ssl
import time
import uuid
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any

import aiohttp
import certifi

from runtime.models import Button, Card

try:
    from .credit_service import set_credit_service
except Exception:
    try:
        from credit_service import set_credit_service
    except Exception:
        def set_credit_service(s: Any) -> None:
            pass

logger = logging.getLogger("plugin.video.service")

PLUGIN_VERSION = "0.4.1"

GUIDE_TEXT = """🎬 **视听服务 - 视频生成指南**

1. **文生视频**：发送 `/vd 提示词` 或 `/vd 10s 提示词`
   - 例：`/vd 10s 一只在雪地中奔跑的柴犬，4k电影质感`
   - 支持在提示词前指定时长：`5s`、`10s`、`10秒` 或 `-d 10`
2. **图生视频**：发送 `/vde 提示词` 或 `/vde 10s 提示词`
   - 自动拾取您在当前会话中发送的上一张图片作为视频首帧！
3. **模型选择**：发送 `/vd models` 查看模型列表并一键切换。
4. **积分充值**：发送 `/vd pay` 调起在线支付充值。
5. **订单与下载**：发送 `/vd status` 查看最近生成记录，`/vd download <订单号>` 随时重新获取！
6. **参数快捷卡片**：直接发送 `/vd` 查看综合控制台。
"""


def _format_cst_time(ts: float | None = None) -> str:
    """Format timestamp in UTC+8 (China Standard Time) YYYY-MM-DD HH:MM:SS."""
    tz_cst = timezone(timedelta(hours=8))
    dt = datetime.fromtimestamp(ts, tz=tz_cst) if ts is not None else datetime.now(tz=tz_cst)
    return dt.strftime("%Y-%m-%d %H:%M:%S")


def _btn(
    label: str,
    text: str,
    *,
    fill: bool = False,
    enter: bool = True,
    style: str = "normal",
    permission: int = 2,
    action_type: int | None = None,
) -> Button:
    clean_label = label.strip()[:10]
    if action_type is None:
        action_type = 2 if fill else 1
    return Button(
        label=clean_label,
        command=text,
        style="normal" if style not in {"normal", "primary", "danger", "success"} else style,  # type: ignore[arg-type]
        action_type=action_type,
        enter=enter if not fill else False,
        permission=permission,
        unsupport_tips="客户端版本过低，请升级后使用",
    )



def _extract_duration_param(default_dur: int, prompt: str) -> tuple[int, str]:
    text = prompt.strip()
    if not text:
        return default_dur, ""

    # Flag style: -d 10 / --dur 10 / -d=10 / --duration 10
    m = re.match(r'^(?:-d|--dur|--duration)[=\s]+(\d+)(?:s|sec|秒)?\s*(.*)$', text, re.IGNORECASE)
    if m:
        try:
            sec = int(m.group(1))
            if 1 <= sec <= 120:
                return sec, m.group(2).strip()
        except ValueError:
            pass

    # Leading seconds style: 10s / 10秒 / 5s / 15s
    m = re.match(r'^(\d+)\s*(?:s|sec|秒)\s+(.*)$', text, re.IGNORECASE)
    if m:
        try:
            sec = int(m.group(1))
            if 1 <= sec <= 120:
                return sec, m.group(2).strip()
        except ValueError:
            pass

    # Leading standalone number if plausible duration: e.g. "5 prompt", "10 prompt"
    m = re.match(r'^(\d+)\s+(.*)$', text)
    if m:
        try:
            sec = int(m.group(1))
            if sec in {3, 4, 5, 6, 8, 10, 15, 20}:
                return sec, m.group(2).strip()
        except ValueError:
            pass

    return default_dur, text


def _normalize_scene(context: Any) -> str:
    raw = getattr(context, "scene", None) or getattr(context, "conversation_type", None) or "group"
    s = str(raw).lower().strip()
    if s in {"c2c", "private", "friend", "user", "dm", "c2c_message_create"}:
        return "c2c"
    if s in {"channel", "guild", "guild_direct"}:
        return "channel"
    return "group"


def _format_error_msg(err_str: str) -> str:
    s = str(err_str or "")
    if "connection reset by peer" in s.lower() or "connection closed" in s.lower():
        return "上游连接意外重置（上游并发过载或代理中断），请稍后重试。"
    if "image queue is full" in s.lower() or "task queue is full" in s.lower() or "queue full" in s.lower():
        return "上游生成队列暂时已满，请等待 1~2 分钟后重试。"
    if "eof" in s.lower():
        return "上游视频服务连接意外中断 (EOF)，请稍后重试。"
    if "timeout" in s.lower() or "timed out" in s.lower():
        return "视频生成超时（耗时较长），请稍后重试或尝试生成 5 秒短视频。"
    if "insufficient" in s.lower() or "quota" in s.lower() or "balance" in s.lower():
        return "服务商账户额度不足，请联系管理员核查。"
    return s[:200]


class VideoServicePlugin:
    """Video service plugin providing text/image to video generation."""

    def __init__(self, context: Any) -> None:
        self.context = context
        self.data_dir = Path(getattr(context, "data_dir", None) or "./data/plugin-data/plugin.video.service")
        self.data_dir.mkdir(parents=True, exist_ok=True)
        self.config_dir = Path(getattr(context, "config_dir", None) or "./data/plugin-config/plugin.video.service")
        self.config_dir.mkdir(parents=True, exist_ok=True)
        self.config: dict[str, Any] = {}
        self.user_prefs: dict[str, dict[str, Any]] = {}
        self.recent_images: dict[str, list[tuple[float, str]]] = {}
        self.user_credits: dict[str, float] = {}
        self.daily_usage: dict[str, int] = {}
        self.user_cooldowns: dict[str, float] = {}
        self.tasks: dict[str, dict[str, Any]] = {}
        self.cached_models: list[str] = []
        self.pending_pay_orders: dict[str, dict[str, Any]] = {}
        self.processed_orders: list[str] = []
        self._temp_dir = self.data_dir / "temp"
        self._temp_dir.mkdir(parents=True, exist_ok=True)
        self._load_config()
        self._load_data()
        set_credit_service(self)

        try:
            pay_api = getattr(self.context, "builtin", lambda name: None)("runtime.pay")
            if pay_api and hasattr(pay_api, "subscribe"):
                pay_api.subscribe("plugin.video.service", self.on_payment_success)
        except Exception:
            pass

    # ---------- Persistence ----------

    def _load_config(self) -> None:
        cfg_file = self.config_dir / "config.json"
        if cfg_file.is_file():
            try:
                self.config = json.loads(cfg_file.read_text(encoding="utf-8"))
            except Exception:
                pass
        if not self.config:
            self.config = {
                "api_base_url": "",
                "api_key": "",
                "default_model": "agnes-video-2.5-flash",
                "provider_protocol": "agnes",
                "aspect_ratio": "16:9",
                "duration_sec": 5,
                "fps": 30,
                "video_credit_cost_per_sec": 1.0,
                "video_credit_cost": 5.0,
                "credit_cost_rules": "agnes-video-2.5-flash:1.0;agnes-video-v2.0:0.5;agnes-video-2.5:2.0",
                "credit_price_yuan": 0.1,
                "default_balance": 0.0,
                "enable_group": True,
                "cooldown_sec": 20,
                "max_prompt_chars": 2000,
                "request_timeout_sec": 300,
                "poll_interval_sec": 3,
                "debug_log": False,
                "page_admin_usernames": ["yeyu"],
            }
        else:
            if "credit_price_yuan" not in self.config:
                self.config["credit_price_yuan"] = 0.1
            if "default_balance" not in self.config:
                self.config["default_balance"] = 0.0

    def _save_config(self) -> None:
        cfg_file = self.config_dir / "config.json"
        try:
            cfg_file.write_text(json.dumps(self.config, ensure_ascii=False, indent=2), encoding="utf-8")
        except Exception:
            pass

    def _load_data(self) -> None:
        data_file = self.data_dir / "data.json"
        if data_file.is_file():
            try:
                data = json.loads(data_file.read_text(encoding="utf-8"))
                if isinstance(data, dict):
                    self.user_prefs = data.get("user_prefs", {})
                    self.user_credits = data.get("user_credits", {})
                    self.daily_usage = data.get("daily_usage", {})
                    self.tasks = data.get("tasks", {})
                    self.cached_models = data.get("cached_models", [])
                    self.pending_pay_orders = data.get("pending_pay_orders", {})
                    self.processed_orders = data.get("processed_orders", [])
            except Exception:
                pass

    def _save_data(self) -> None:
        data_file = self.data_dir / "data.json"
        if len(self.tasks) > 200:
            keys = sorted(self.tasks.keys(), key=lambda k: self.tasks[k].get("created_at", ""))
            for k in keys[:-200]:
                self.tasks.pop(k, None)
        try:
            data_file.write_text(json.dumps({
                "user_prefs": self.user_prefs,
                "user_credits": self.user_credits,
                "daily_usage": self.daily_usage,
                "tasks": self.tasks,
                "cached_models": self.cached_models,
                "pending_pay_orders": self.pending_pay_orders,
                "processed_orders": self.processed_orders,
            }, ensure_ascii=False, indent=2), encoding="utf-8")
        except Exception:
            pass

    def _ensure_user(self, user_key: str) -> None:
        if not user_key or user_key == "unknown":
            return
        dirty = False
        if user_key not in self.user_credits:
            def_bal = float(self.config.get("default_balance", 0.0))
            self.user_credits[user_key] = def_bal
            dirty = True
        if user_key not in self.user_prefs:
            self.user_prefs[user_key] = {}
            dirty = True
        if dirty:
            self._save_data()

    def _get_available_models(self) -> list[str]:
        # If models have been fetched from upstream API, strictly use only those genuine models
        if self.cached_models:
            return [m for m in self.cached_models if m]
        # Otherwise only return configured default model if present
        default_m = str(self.config.get("default_model") or "").strip()
        if default_m:
            return [default_m]
        return []

    # ---------- User Preference Helpers ----------

    def _get_user_key(self, context: Any) -> str:
        sender_id = str(getattr(context, "sender_id", "") or getattr(context, "user_id", "") or "unknown")
        return sender_id

    def _get_pref(self, user_key: str, key: str, default: Any) -> Any:
        return self.user_prefs.get(user_key, {}).get(key, self.config.get(key, default))

    def _set_pref(self, user_key: str, key: str, value: Any) -> None:
        self._ensure_user(user_key)
        if user_key not in self.user_prefs:
            self.user_prefs[user_key] = {}
        self.user_prefs[user_key][key] = value
        self._save_data()

    # ---------- Credit & Points ----------

    def _get_cost_for_model(self, model_name: str) -> float:
        rules_str = str(self.config.get("credit_cost_rules") or "").strip()
        for item in rules_str.split(";"):
            item = item.strip()
            if ":" in item:
                m, cost = item.split(":", 1)
                if m.strip().lower() == model_name.strip().lower():
                    try:
                        return float(cost.strip())
                    except ValueError:
                        pass
        val = self.config.get("video_credit_cost_per_sec")
        if val is not None:
            try:
                return float(val)
            except ValueError:
                pass
        old = self.config.get("video_credit_cost")
        if old is not None:
            try:
                return float(old) / 5.0
            except ValueError:
                pass
        return 1.0

    async def _deduct_credits(self, user_key: str, cost: float, reason: str = "生成视频") -> bool:
        if cost <= 0:
            return True
        pay_api = getattr(self.context, "builtin", lambda name: None)("runtime.pay")
        if pay_api and hasattr(pay_api, "deduct_points"):
            try:
                res = await pay_api.deduct_points(user_key, cost, reason=reason)
                return bool(res)
            except Exception as e:
                logger.warning("runtime.pay deduct failed: %s", e)
        current = float(self.user_credits.get(user_key, self.config.get("default_balance", 0.0)))
        if current < cost:
            return False
        self.user_credits[user_key] = current - cost
        self._save_data()
        return True

    async def _refund_credits(self, user_key: str, cost: float, reason: str = "视频生成失败退还") -> None:
        if cost <= 0:
            return
        pay_api = getattr(self.context, "builtin", lambda name: None)("runtime.pay")
        if pay_api and hasattr(pay_api, "add_points"):
            try:
                await pay_api.add_points(user_key, cost, reason=reason)
                return
            except Exception as e:
                logger.warning("runtime.pay refund failed: %s", e)
        current = float(self.user_credits.get(user_key, 0.0))
        self.user_credits[user_key] = current + cost
        self._save_data()

    async def _add_credits(self, user_key: str, amount: float, reason: str = "充值增加") -> None:
        if amount <= 0:
            return
        pay_api = getattr(self.context, "builtin", lambda name: None)("runtime.pay")
        if pay_api and hasattr(pay_api, "add_points"):
            try:
                await pay_api.add_points(user_key, amount, reason=reason)
                return
            except Exception as e:
                logger.warning("runtime.pay add_points failed: %s", e)
        current = float(self.user_credits.get(user_key, self.config.get("default_balance", 0.0)))
        self.user_credits[user_key] = round(current + amount, 2)
        self._save_data()

    async def _get_balance(self, user_key: str) -> float:
        pay_api = getattr(self.context, "builtin", lambda name: None)("runtime.pay")
        if pay_api and hasattr(pay_api, "get_points"):
            try:
                pts = await pay_api.get_points(user_key)
                if pts is not None:
                    return float(pts)
            except Exception:
                pass
        return float(self.user_credits.get(user_key, self.config.get("default_balance", 0.0)))

    async def on_payment_success(self, intent: dict[str, Any]) -> None:
        if intent.get("local_status") != "paid":
            return
        user_id = str(intent.get("owner_key") or intent.get("user_id") or "")
        if not user_id:
            return
        points_minor = int(intent.get("points_minor") or 0)
        points = int(points_minor // 100) if points_minor else int(intent.get("points") or intent.get("point_count") or 0)
        if points <= 0:
            return

        order_id = str(intent.get("id") or intent.get("order_id") or "")
        if order_id:
            if order_id in self.processed_orders:
                return
            self.processed_orders.append(order_id)
            if len(self.processed_orders) > 2000:
                self.processed_orders = self.processed_orders[-1000:]
            if order_id in self.pending_pay_orders:
                self.pending_pay_orders.pop(order_id, None)

        cur = float(self.user_credits.get(user_id, self.config.get("default_balance", 0.0)))
        new_bal = round(cur + points, 2)
        self.user_credits[user_id] = new_bal
        self._save_data()
        logger.info("Payment success for %s: +%d points, current balance %s", user_id, points, new_bal)

    # ---------- Image Tracking for Image-to-Video (/vde) ----------

    async def on_event(self, context: Any) -> None:
        try:
            if getattr(context, "message_type", None) == "interaction":
                return
            sender_id = str(getattr(context, "sender_id", "") or getattr(context, "user_id", "") or "")
            conv_id = str(getattr(context, "conversation_id", "") or getattr(context, "group_id", "") or sender_id)
            if not conv_id:
                return

            # Check message attachments for images
            attachments = getattr(context, "attachments", None) or ()
            found_url = None
            if attachments and isinstance(attachments, (list, tuple)):
                for att in attachments:
                    if isinstance(att, dict):
                        ct = str(att.get("content_type") or "")
                        url = str(att.get("url") or "")
                        if "image" in ct or url.endswith((".png", ".jpg", ".jpeg", ".webp")):
                            found_url = url
                            break

            raw = getattr(context, "raw_payload", None)
            if not found_url and isinstance(raw, dict):
                atts = raw.get("attachments") or []
                if isinstance(atts, list):
                    for a in atts:
                        if isinstance(a, dict) and a.get("url"):
                            found_url = str(a["url"])
                            break

            if found_url:
                if conv_id not in self.recent_images:
                    self.recent_images[conv_id] = []
                self.recent_images[conv_id].append((time.time(), found_url))
                if len(self.recent_images[conv_id]) > 10:
                    self.recent_images[conv_id] = self.recent_images[conv_id][-10:]
        except Exception as e:
            logger.debug("on_event image capture error: %s", e)

    def _get_recent_image(self, conv_id: str) -> str | None:
        lst = self.recent_images.get(conv_id, [])
        now = time.time()
        valid = [u for t, u in lst if now - t < 1800]
        return valid[-1] if valid else None

    # ---------- Commands Dispatcher ----------

    async def handle_vd(self, context: Any, args: list[str]) -> str | Card:
        if not args:
            return await self._main_card(context)
        sub = args[0].lower()
        if sub in {"help", "帮助", "教程"}:
            return Card("使用教程", GUIDE_TEXT, rows=[
                [_btn("文生视频", "/vd ", fill=True), _btn("图生视频", "/vde ", fill=True)],
                [_btn("比例设置", "/vd ratio"), _btn("时长设置", "/vd dur")],
                [_btn("视频模型", "/vd models"), _btn("积分充值", "/vd pay")],
                [_btn("订单记录", "/vd status"), _btn("返回主菜单", "/vd")],
            ])
        if sub in {"pay", "充值", "buy"}:
            return await self._handle_pay(context, args[1:])
        if sub in {"rate", "cost", "单价", "计费", "价格", "pricing"}:
            return self._handle_rate(context, args[1:])
        if sub in {"ratio", "比例", "尺寸"}:
            return await self._handle_ratio(context, args[1:])
        if sub in {"dur", "duration", "时长", "秒数"}:
            return await self._handle_duration(context, args[1:])
        if sub in {"models", "模型", "模型列表"}:
            return self._handle_models(context, args[1:])
        if sub in {"model", "切模型", "切换模型"}:
            return self._handle_model(context, args[1:])
        if sub in {"status", "状态", "余额", "记录", "订单", "tasks", "task"}:
            return await self._handle_status(context, args[1:])
        if sub in {"download", "下载", "获取", "get"}:
            return await self._handle_download(context, args[1:])


        # Otherwise, treated as a prompt for text-to-video with optional duration
        user_key = self._get_user_key(context)
        default_dur = int(self._get_pref(user_key, "duration_sec", 5))
        prompt_raw = " ".join(args).strip()
        dur, prompt = _extract_duration_param(default_dur, prompt_raw)
        return await self._trigger_video_generation(context, prompt, is_edit=False, duration=dur)

    async def handle_vde(self, context: Any, args: list[str]) -> str | Card:
        user_key = self._get_user_key(context)
        default_dur = int(self._get_pref(user_key, "duration_sec", 5))
        prompt_raw = " ".join(args).strip() if args else "动态流动，逼真光影"
        dur, prompt = _extract_duration_param(default_dur, prompt_raw)
        if not prompt:
            prompt = "动态流动，逼真光影"
        return await self._trigger_video_generation(context, prompt, is_edit=True, duration=dur)

    # ---------- Card Views (Strictly <= 5 Rows & <= 10 Chars Labels) ----------

    async def _main_card(self, context: Any) -> Card:
        user_key = self._get_user_key(context)
        self._ensure_user(user_key)
        cur_bal = await self._get_balance(user_key)
        cur_ratio = self._get_pref(user_key, "aspect_ratio", "16:9")
        cur_dur = self._get_pref(user_key, "duration_sec", 5)
        cur_model = self._get_pref(user_key, "default_model", self.config.get("default_model", "agnes-video-2.5-flash"))
        cost_per_sec = self._get_cost_for_model(cur_model)

        md = (
            f"🎬 **视频生成控制台**\n"
            f"━━━━━━━━━━━━━━━━━━\n"
            f"• 账户余额：`{cur_bal:.1f}` 积分\n"
            f"• 当前模型：`{cur_model}`\n"
            f"• 画幅比例：`{cur_ratio}` | 默认时长：`{cur_dur}秒`\n"
            f"• 计费标准：`{cost_per_sec:.1f}` 积分/秒\n\n"
            f"💡 发送 `/vd 提示词` 直接生成，或点击下方按钮快捷调参！"
        )

        rows = [
            # Row 1: Aspect ratio selection
            [_btn(f"{'✅ ' if cur_ratio == '16:9' else ''}横屏16:9", "/vd ratio 16:9"),
             _btn(f"{'✅ ' if cur_ratio == '9:16' else ''}竖屏9:16", "/vd ratio 9:16")],
            # Row 2: Duration selection
            [_btn(f"{'✅ ' if cur_dur == 5 else ''}5秒短片", "/vd dur 5"),
             _btn(f"{'✅ ' if cur_dur == 10 else ''}10秒超长", "/vd dur 10")],
            # Row 3: Model & Image-to-Video
            [_btn("🎬 选择模型", "/vd models"),
             _btn("🖼️ 图生视频", "/vde ", fill=True)],
            # Row 4: Pay & Status
            [_btn("💳 充值积分", "/vd pay"),
             _btn("📜 订单记录", "/vd status")],
            # Row 5: Full-width Call to Action
            [_btn("✨ 立即生成视频", "/vd ", fill=True)],
        ]
        return Card("视频生成控制台", md, rows[:5])

    async def _handle_ratio(self, context: Any, args: list[str]) -> Card:
        user_key = self._get_user_key(context)
        if args:
            target = args[0].strip().lower()
            if target in {"16:9", "9:16", "1:1", "4:3"}:
                self._set_pref(user_key, "aspect_ratio", target)
                return await self._main_card(context)
        cur = self._get_pref(user_key, "aspect_ratio", "16:9")
        md = f"📐 **长宽比切换**\n当前选择：`{cur}`\n请选择生成的视频画面比例："
        rows = [
            [_btn(f"{'✅ ' if cur == '16:9' else ''}16:9 横屏", "/vd ratio 16:9"),
             _btn(f"{'✅ ' if cur == '9:16' else ''}9:16 竖屏", "/vd ratio 9:16")],
            [_btn(f"{'✅ ' if cur == '1:1' else ''}1:1 方形", "/vd ratio 1:1"),
             _btn(f"{'✅ ' if cur == '4:3' else ''}4:3 经典", "/vd ratio 4:3")],
            [_btn("🔙 返回主菜单", "/vd")],
        ]
        return Card("长宽比切换", md, rows[:5])

    async def _handle_duration(self, context: Any, args: list[str]) -> Card:
        user_key = self._get_user_key(context)
        if args:
            try:
                sec = int(args[0])
                if sec in {5, 10}:
                    self._set_pref(user_key, "duration_sec", sec)
                    return await self._main_card(context)
            except ValueError:
                pass
        cur = self._get_pref(user_key, "duration_sec", 5)
        md = f"⏱️ **默认视频时长设置**\n当前时长：`{cur} 秒`\n时长越长生成细节越丰富，生成耗时相应增加："
        rows = [
            [_btn(f"{'✅ ' if cur == 5 else ''}5秒短片", "/vd dur 5"),
             _btn(f"{'✅ ' if cur == 10 else ''}10秒超长", "/vd dur 10")],
            [_btn("🔙 返回主菜单", "/vd")],
        ]
        return Card("视频时长设置", md, rows[:5])

    def _handle_models(self, context: Any, args: list[str]) -> Card:
        user_key = self._get_user_key(context)
        cur = self._get_pref(user_key, "default_model", self.config.get("default_model", "agnes-video-2.5-flash"))
        models = self._get_available_models()

        page = 1
        if args:
            try:
                page = max(1, int(args[0]))
            except ValueError:
                page = 1

        per_page = 4
        total_pages = max(1, math.ceil(len(models) / per_page))
        page = min(page, total_pages)
        start = (page - 1) * per_page
        current = models[start:start + per_page]

        lines = [
            f"### 🎬 可用视频模型（第 {page}/{total_pages} 页，共 {len(models)} 个）\n",
            "| # | 模型名称 | 每秒扣费 | 状态 |",
            "|---|---|---|:---:|",
        ]
        for i, m in enumerate(current):
            idx = start + i + 1
            cost = self._get_cost_for_model(m)
            is_active = "✅ 已选" if m.lower() == cur.lower() else "-"
            lines.append(f"| {idx} | `{m}` | {cost:.1f} 积分/秒 | {is_active} |")
        lines.append(f"\n当前默认模型：`{cur}`")
        lines.append("点击下方按钮切换，或发送 `/vd model <名称或序号>`。")

        rows = []
        row1 = []
        for i, m in enumerate(current[:2]):
            idx = start + i + 1
            lbl = f"✓ 模型{idx}" if m.lower() == cur.lower() else f"模型{idx}"
            row1.append(_btn(lbl, f"/vd model {m}"))
        if row1:
            rows.append(row1)

        row2 = []
        for i, m in enumerate(current[2:4]):
            idx = start + i + 3
            lbl = f"✓ 模型{idx}" if m.lower() == cur.lower() else f"模型{idx}"
            row2.append(_btn(lbl, f"/vd model {m}"))
        if row2:
            rows.append(row2)

        nav_row = []
        if page > 1:
            nav_row.append(_btn("◀ 上一页", f"/vd models {page - 1}"))
        nav_row.append(_btn("跳页", "/vd models ", fill=True))
        if page < total_pages:
            nav_row.append(_btn("下一页 ▶", f"/vd models {page + 1}"))
        if nav_row:
            rows.append(nav_row)

        rows.append([
            _btn("切换模型", "/vd model ", fill=True),
            _btn("返回主菜单", "/vd"),
        ])
        return Card("可用视频模型", "\n".join(lines), rows=rows[:5])

    def _handle_model(self, context: Any, args: list[str]) -> Card:
        user_key = self._get_user_key(context)
        models = self._get_available_models()
        if args:
            raw = args[0].strip()
            chosen = None
            if raw.isdigit():
                idx = int(raw)
                if 1 <= idx <= len(models):
                    chosen = models[idx - 1]
            else:
                for m in models:
                    if m.lower() == raw.lower():
                        chosen = m
                        break
                if not chosen:
                    chosen = raw
            if chosen:
                self._set_pref(user_key, "default_model", chosen)
                cost = self._get_cost_for_model(chosen)
                return Card("模型切换成功", f"🎉 已将默认视频模型切换为：`{chosen}`\n计费标准：`{cost:.1f}` 积分/秒。\n发送 `/vd <提示词>` 立即开始创作！", rows=[
                    [_btn("✨ 文生视频", "/vd ", fill=True), _btn("🖼️ 图生视频", "/vde ", fill=True)],
                    [_btn("查看模型列表", "/vd models"), _btn("返回主菜单", "/vd")],
                ][:5])
        return self._handle_models(context, [])

    async def _handle_status(self, context: Any, args: list[str] | None = None) -> Card:
        user_key = self._get_user_key(context)
        self._ensure_user(user_key)
        args = args or []
        if args:
            task_id = args[0].strip()
            task = self.tasks.get(task_id)
            if not task:
                for tid, t in self.tasks.items():
                    if tid.endswith(task_id) or task_id in tid:
                        task = t
                        task_id = tid
                        break
            if not task:
                return Card("订单查询", f"❌ 未找到订单号 `{task_id}` 的记录。请核对订单号后重试。", rows=[
                    [_btn("查询全部订单", "/vd status"), _btn("返回主菜单", "/vd")]
                ][:5])

            st = task.get("status", "processing")
            st_str = "⏳ 正在排队生成中..." if st == "processing" else ("✅ 已生成完成！" if st == "completed" else f"❌ 生成失败: {task.get('error', '未知错误')}")
            md = (
                f"📋 **订单详情：`{task_id}`**\n"
                f"━━━━━━━━━━━━━━━━━━\n"
                f"• 状态：{st_str}\n"
                f"• 模式：{task.get('mode', '文生视频')} | 模型：`{task.get('model', '-')}`\n"
                f"• 时长：`{task.get('duration', 5)}秒` | 扣费：`{task.get('cost', 0)}` 积分\n"
                f"• 创建时间：`{task.get('created_at', '-')}`\n"
                f"• 提示词：{task.get('prompt', '-')[:100]}\n"
            )
            if task.get("video_url"):
                md += f"\n📥 [点击在线下载视频]({task.get('video_url')})"
            rows = []
            if task.get("video_url"):
                rows.append([_btn("📥 下载视频", f"/vd download {task_id}")])
            rows.append([_btn("刷新本单", f"/vd status {task_id}"), _btn("全部订单", "/vd status")])
            rows.append([_btn("返回主菜单", "/vd")])
            return Card("订单详情", md, rows=rows[:5])

        # User status and recent 5 tasks
        credits = await self._get_balance(user_key)
        cur_model = self._get_pref(user_key, "default_model", self.config.get("default_model", "agnes-video-2.5-flash"))
        cur_ratio = self._get_pref(user_key, "aspect_ratio", "16:9")
        cur_dur = self._get_pref(user_key, "duration_sec", 5)
        cost_per_sec = self._get_cost_for_model(cur_model)

        u_tasks = [t for t in self.tasks.values() if t.get("user_key") == user_key]
        recent_tasks = sorted(u_tasks, key=lambda t: t.get("created_at", ""), reverse=True)[:5]

        lines = [
            "👤 **用户资产与生成记录**\n",
            f"• 积分余额：`{credits:.1f}` 积分 | 单价：`{cost_per_sec:.1f}` 积分/秒",
            f"• 默认模型：`{cur_model}` | 画幅：`{cur_ratio}` ({cur_dur}s)\n",
        ]
        if recent_tasks:
            lines.append("### 📜 最近 5 笔订单记录")
            lines.append("| 订单号 | 状态 | 时长 | 提示词预览 |")
            lines.append("|---|:---:|---|---|")
            for t in recent_tasks:
                tid = t.get("task_id", "")
                st = "✅" if t.get("status") == "completed" else ("⏳" if t.get("status") == "processing" else "❌")
                dur = f"{t.get('duration', 5)}s"
                p_prev = t.get("prompt", "")[:10] + "..." if len(t.get("prompt", "")) > 10 else t.get("prompt", "")
                lines.append(f"| `{tid[-8:]}` | {st} | {dur} | {p_prev} |")
            lines.append("\n发送 `/vd status <订单号>` 查详情，或 `/vd download <订单号>` 获取作品。")
        else:
            lines.append("暂无生成记录，发送 `/vd 提示词` 开启第一次创作吧！")

        rows = [
            [_btn("✨ 文生视频", "/vd ", fill=True), _btn("🖼️ 图生视频", "/vde ", fill=True)],
            [_btn("💳 充值积分", "/vd pay"), _btn("🎬 切换模型", "/vd models")],
            [_btn("查单帮助", "/vd status ", fill=True), _btn("返回主菜单", "/vd")],
        ]
        return Card("用户状态与记录", "\n".join(lines), rows=rows[:5])

    async def _handle_download(self, context: Any, args: list[str]) -> Card | str:
        if not args:
            return "用法：`/vd download <订单号>` 或 `/vd 下载 <订单号>`"
        task_id = args[0].strip()
        task = self.tasks.get(task_id)
        if not task:
            for tid, t in self.tasks.items():
                if tid.endswith(task_id) or task_id in tid:
                    task = t
                    task_id = tid
                    break
        if not task:
            return f"❌ 未找到订单号 `{task_id}` 的记录。"
        if task.get("status") != "completed" or not task.get("video_url"):
            return f"⚠️ 订单 `{task_id}` 尚未生成完成或生成失败（状态：{task.get('status')}）。"

        url = task["video_url"]
        md = f"📥 **视频下载成功**\n\n订单号：`{task_id}`\n时长：`{task.get('duration')}秒`\n提示词：{task.get('prompt')[:100]}\n\n🔗 [点击直接下载视频 MP4]({url})"
        rows = [
            [_btn("再来一段", f"/vd {task.get('prompt')[:30]}", fill=True), _btn("全部订单", "/vd status")],
            [_btn("返回主菜单", "/vd")],
        ]
        asyncio.create_task(self._try_send_cached_video(context, url))
        return Card("视频获取成功", md, rows=rows[:5])

    async def _try_send_cached_video(self, context: Any, video_url: str) -> None:
        video_path = None
        try:
            video_path = await self._download_video_stream(video_url)
            if video_path and video_path.is_file() and video_path.stat().st_size > 0:
                await self._send_qq_video(context, video_path)
        except Exception as e:
            logger.debug("Failed to re-send cached video via QQ: %s", e)
        finally:
            if video_path and video_path.is_file():
                try:
                    video_path.unlink()
                except Exception:
                    pass

    async def _handle_pay(self, context: Any, args: list[str]) -> str | Card:
        user_id = self._get_user_key(context)
        self._ensure_user(user_id)
        rate_val = float(self.config.get("credit_price_yuan", 0.1))
        if not args:
            cur_bal = await self._get_balance(user_id)
            return Card(
                "充值积分",
                f"💳 **视频积分充值中心**\n"
                f"━━━━━━━━━━━━━━━━━━\n"
                f"• 当前账户积分：`{cur_bal:.1f}` 积分\n"
                f"• 充值比例：`1 积分 = ￥{rate_val:.2f} 元` (1元 = {int(1/rate_val) if rate_val > 0 else 10}积分)\n"
                f"• 到账时效：付款后系统自动秒级入账\n"
                f"• 支持渠道：微信支付 / 支付宝扫码\n\n"
                f"💡 点击下方常用面额快速创建订单，或发送 `/vd pay <积分数>` 自定义充值：",
                rows=[
                    [
                        _btn(f"充 10 积分 (¥{10 * rate_val:.1f})", "/vd pay 10", action_type=1, style="primary"),
                        _btn(f"充 50 积分 (¥{50 * rate_val:.1f})", "/vd pay 50", action_type=1),
                    ],
                    [
                        _btn(f"充 100 积分 (¥{100 * rate_val:.1f})", "/vd pay 100", action_type=1),
                        _btn("✏️ 自定义充值", "/vd pay ", fill=True),
                    ],
                    [
                        _btn("💰 查余额", "/vd status", action_type=1),
                        _btn("🔙 视频主菜单", "/vd", action_type=1),
                    ],
                ][:5]
            )

        sub = args[0].lower()
        if sub in {"link", "qr", "qrcode", "二维码"}:
            order_id = args[1].strip() if len(args) > 1 else ""
            if not order_id:
                for oid, info in reversed(list(self.pending_pay_orders.items())):
                    if info.get("user_id") == user_id:
                        order_id = oid
                        break
            if not order_id:
                pay_api = getattr(self.context, "builtin", lambda name: None)("runtime.pay")
                if pay_api and hasattr(pay_api, "get_latest_intent"):
                    try:
                        latest = await pay_api.get_latest_intent(user_id)
                        if latest and latest.get("local_status") in {"pending", "creating"}:
                            order_id = str(latest.get("id") or latest.get("trade_no") or "")
                    except Exception:
                        pass
            if not order_id:
                return Card("支付二维码", "未找到待支付的订单。您可以发送 `/vd pay 10` 创建新的充值订单。")

            pay_url = ""
            if order_id in self.pending_pay_orders:
                pay_url = self.pending_pay_orders[order_id].get("pay_url", "")
            if not pay_url:
                pay_api = getattr(self.context, "builtin", lambda name: None)("runtime.pay")
                if pay_api and hasattr(pay_api, "query_payment"):
                    try:
                        qres = await pay_api.query_payment(order_id)
                        pay_url = qres.get("pay_info") or qres.get("pay_url") or qres.get("qrcode") or ""
                    except Exception:
                        pass
            if not pay_url:
                return Card("支付二维码", f"订单 `{order_id}` 未找到有效的支付链接，或订单已过期。")

            row1 = []
            if pay_url and pay_url.startswith(("http://", "https://")):
                row1.append(_btn("💳 立即跳转付款", pay_url, action_type=0, style="primary"))
            row1.append(_btn("🔍 查询订单", f"/vd pay check {order_id}", action_type=1))
            return Card(
                "支付链接",
                f"📱 **支付链接已获取**\n"
                f"━━━━━━━━━━━━━━━━━━\n"
                f"• 订单号：`{order_id}`\n\n"
                f"👉 [点击打开支付页面付款]({pay_url})\n\n"
                f"✨ 付款完成后系统将自动秒级入账，亦可点击下方【🔍 查询订单】主动查验。",
                rows=[
                    row1,
                    [_btn("💰 查余额", "/vd status", action_type=1), _btn("🔙 视频主菜单", "/vd", action_type=1)],
                ][:5]
            )

        if sub in {"check", "order", "status", "query", "查询"}:
            order_id = args[1].strip() if len(args) > 1 else ""
            if not order_id:
                for oid, info in reversed(list(self.pending_pay_orders.items())):
                    if info.get("user_id") == user_id:
                        order_id = oid
                        break
            if not order_id:
                return Card("查询订单", "未指定订单号，且未找到最近的未完成订单。您可以发送 `/vd pay 10` 创建新的充值订单。")

            pay_api = getattr(self.context, "builtin", lambda name: None)("runtime.pay")
            if not pay_api or not hasattr(pay_api, "query_payment"):
                return Card("查询订单", "支付查询服务未就绪。")

            try:
                res = await asyncio.wait_for(pay_api.query_payment(order_id), timeout=5.0)
                status = str(res.get("local_status") or "")
                if status == "paid":
                    await self.on_payment_success(res)
                    self.pending_pay_orders.pop(order_id, None)
                    self._save_data()
                    bal = await self._get_balance(user_id)
                    return Card(
                        "订单已支付",
                        f"✅ **充值支付成功**\n\n"
                        f"订单号 `{order_id}` 已成功到账！\n"
                        f"• 当前总积分余额：**{bal:.1f}** 积分\n\n"
                        f"🎬 祝您创作愉快，发送 `/vd <提示词>` 立即开始生成视频！",
                        rows=[
                            [_btn("✨ 文生视频", "/vd ", fill=True), _btn("🖼️ 图生视频", "/vde ", fill=True)],
                            [_btn("💰 查余额", "/vd status"), _btn("🔙 返回主菜单", "/vd")],
                        ][:5]
                    )
                status_text = "待支付" if status in {"pending", "creating"} else status
                row1 = []
                pay_url = (self.pending_pay_orders.get(order_id) or {}).get("pay_url", "")
                if not pay_url:
                    pay_url = res.get("pay_info") or res.get("pay_url") or res.get("qrcode") or ""
                if pay_url and pay_url.startswith(("http://", "https://")):
                    row1.append(_btn("💳 立即跳转付款", pay_url, action_type=0, style="primary"))
                row1.append(_btn("🔍 刷新订单", f"/vd pay check {order_id}", action_type=1))
                return Card(
                    "订单待支付",
                    f"⏳ **订单待支付中**\n\n"
                    f"• 订单编号：`{order_id}`\n"
                    f"• 当前状态：**{status_text}**\n\n"
                    f"若您已付款，请稍候 2~3 秒后点击【🔍 刷新订单】自动对账；若未完成付款，请点击【💳 立即跳转付款】。",
                    rows=[
                        row1,
                        [_btn("💰 查余额", "/vd status", action_type=1), _btn("🔙 视频主菜单", "/vd", action_type=1)],
                    ][:5]
                )
            except Exception as e:
                return Card("查询订单", f"查询订单 `{order_id}` 失败：{e}")

        try:
            points = int(args[0])
            if points <= 0 or points > 100000:
                return "充值积分数量需在 1 ~ 100,000 之间。"
        except ValueError:
            return "充值指令格式：`/vd pay <积分数>`，例如 `/vd pay 10`"

        yuan_amount = round(points * rate_val, 2)
        if yuan_amount < 0.01:
            yuan_amount = 0.01

        pay_api = getattr(self.context, "builtin", lambda name: None)("runtime.pay")
        if not pay_api or not hasattr(pay_api, "create_payment"):
            return "⚠️ 支付模块不可用或未启用，请联系管理员配置。"

        try:
            ext_id = f"video_{user_id}_{int(time.time())}_{uuid.uuid4().hex[:8]}"
            order_info = await asyncio.wait_for(
                pay_api.create_payment(
                    source_plugin="plugin.video.service",
                    external_id=ext_id,
                    owner_key=user_id,
                    subject=f"视频服务积分充值 - {points} 积分",
                    amount=str(yuan_amount),
                    points=str(points),
                    point_type="video",
                    user_id=user_id,
                    amount_yuan=yuan_amount,
                    point_count=points,
                    description=f"视频服务积分充值 - {points} 积分",
                ),
                timeout=8.0,
            )
            qrcode_url = order_info.get("qrcode") or ""
            order_id = str(order_info.get("order_id") or order_info.get("trade_no") or order_info.get("id") or "")
            real_amount = order_info.get("amount") or str(yuan_amount)
            pay_url = order_info.get("pay_url") or order_info.get("url") or order_info.get("pay_info") or qrcode_url

            if order_id and order_id != "-":
                self.pending_pay_orders[order_id] = {
                    "user_id": user_id,
                    "points": points,
                    "time": time.time(),
                    "pay_url": pay_url,
                }
                self._save_data()

            markdown = (
                f"💳 **视频积分充值订单**\n"
                f"━━━━━━━━━━━━━━━━━━\n"
                f"• 充值数量：`{points}` 积分\n"
                f"• 应付金额：`￥{real_amount}` 元\n"
                f"• 订单号：`{order_id}`\n"
                f"• 订单状态：⏳ **待支付**\n\n"
                f"👉 请点击下方【💳 立即跳转付款】进入收银台完成支付；\n"
                f"✨ 付款完成后系统将秒级自动充值到账！"
            )
            row1 = []
            if pay_url and pay_url.startswith(("http://", "https://")):
                row1.append(_btn("💳 立即跳转付款", pay_url, action_type=0, style="primary"))
            row1.append(_btn("🔍 查询订单", f"/vd pay check {order_id}", action_type=1))
            return Card("积分充值", markdown, rows=[
                row1,
                [_btn("💰 查余额", "/vd status", action_type=1), _btn("🔙 返回主菜单", "/vd", action_type=1)],
            ][:5])
        except Exception as exc:
            return Card("积分充值", f"创建充值订单失败：{exc}")

    def _handle_rate(self, context: Any, args: list[str]) -> Card:
        rate_val = float(self.config.get("credit_price_yuan", 0.1))
        default_m = self.config.get("default_model", "agnes-video-2.5-flash")
        models = self._get_available_models()
        if not models:
            models = [default_m]

        lines = [
            "🎬 **视频服务模型单价与计费规则**",
            "━━━━━━━━━━━━━━━━━━",
            f"• 积分充值比例：`1 积分 = ￥{rate_val:.2f} 元`",
            "• 计费模式：按视频生成时长（秒数）动态计费\n",
            "📊 **当前可用模型单价**：",
        ]
        for m in models:
            cost = self._get_cost_for_model(m)
            lines.append(f"• `{m}`：`{cost:.1f}` 积分/秒 (5s约 `{cost*5:.1f}` 分 / 10s约 `{cost*10:.1f}` 分)")

        lines.append("\n💡 发送 `/vd pay <积分数>` 即可在线充值积分！")
        return Card(
            "计费与单价规则",
            "\n".join(lines),
            rows=[
                [_btn("💳 立即充值", "/vd pay", action_type=1, style="primary"), _btn("🎬 切换模型", "/vd models", action_type=1)],
                [_btn("🔙 返回主菜单", "/vd", action_type=1)],
            ][:5]
        )

    # ---------- Video Generation & Task Polling ----------

    async def _trigger_video_generation(
        self, context: Any, prompt: str, is_edit: bool, duration: int = 5
    ) -> str | Card:
        if not prompt:
            return "❌ 提示词不能为空，请输入如：`/vd 10s 电影镜头，未来赛博朋克城市雨夜`"
        if len(prompt) > int(self.config.get("max_prompt_chars", 2000)):
            return f"❌ 提示词过长（上限 {self.config.get('max_prompt_chars')} 字）"

        user_key = self._get_user_key(context)
        self._ensure_user(user_key)
        conv_id = str(getattr(context, "conversation_id", "") or getattr(context, "group_id", "") or user_key)

        # Cooldown check
        now = time.time()
        cd = int(self.config.get("cooldown_sec", 20))
        last_time = self.user_cooldowns.get(user_key, 0)
        if now - last_time < cd:
            return f"⏳ 操作太频繁，请等待 {int(cd - (now - last_time))} 秒后再试。"

        # Image for image-to-video
        ref_image = None
        if is_edit:
            ref_image = self._get_recent_image(conv_id)
            if not ref_image:
                return "⚠️ 未在当前会话检测到最近发送的图片。请先发一张图片，再发送 `/vde 提示词` 进行图生视频！"

        # Model & cost per second
        model = self._get_pref(user_key, "default_model", self.config.get("default_model", "agnes-video-2.5-flash"))
        cost_per_sec = self._get_cost_for_model(model)
        total_cost = round(duration * cost_per_sec, 2)

        # Deduct credits
        ok = await self._deduct_credits(user_key, total_cost, reason=f"生成视频({model},{duration}s)")
        if not ok:
            cur_bal = await self._get_balance(user_key)
            yuan_rate = float(self.config.get("credit_price_yuan", 0.1))
            needed_pts = max(0.0, total_cost - cur_bal)
            needed_yuan = round(needed_pts * yuan_rate, 2)
            md = (
                f"⚠️ **积分余额不足**\n"
                f"━━━━━━━━━━━━━━━━━━\n"
                f"• 当前余额：`{cur_bal:.1f}` 积分\n"
                f"• 本次所需：`{total_cost:.1f}` 积分（缺口 `{needed_pts:.1f}` 积分，约 `{needed_yuan:.2f}` 元）\n\n"
                f"💡 请点击下方常用面额快速充值，或发送 `/vd pay <积分数>` 自定义充值！"
            )
            rows = [
                [_btn(f"充 10 积分 (¥{10 * yuan_rate:.1f})", "/vd pay 10", action_type=1, style="primary"),
                 _btn(f"充 50 积分 (¥{50 * yuan_rate:.1f})", "/vd pay 50", action_type=1)],
                [_btn(f"充 100 积分 (¥{100 * yuan_rate:.1f})", "/vd pay 100", action_type=1),
                 _btn("✏️ 自定义充值", "/vd pay ", fill=True)],
                [_btn("🔙 返回主菜单", "/vd", action_type=1)],
            ]
            return Card("积分不足提示", md, rows[:5])

        self.user_cooldowns[user_key] = now

        task_id = f"v_{int(time.time())}_{uuid.uuid4().hex[:6]}"
        self.tasks[task_id] = {
            "task_id": task_id,
            "user_key": user_key,
            "prompt": prompt,
            "mode": "图生视频" if is_edit else "文生视频",
            "model": model,
            "duration": duration,
            "cost": total_cost,
            "status": "processing",
            "video_url": "",
            "error": "",
            "created_at": _format_cst_time(),
            "completed_at": "",
        }
        self._save_data()

        # Launch async task
        asyncio.create_task(
            self._run_async_video_pipeline(context, prompt, ref_image, model, total_cost, duration=duration, task_id=task_id)
        )

        mode_name = "图生视频" if is_edit else "文生视频"
        buttons = [
            [_btn("📊 查询进度", f"/vd status {task_id}"), _btn("📥 下载视频", f"/vd download {task_id}")],
            [_btn("📋 订单记录", "/vd 记录"), _btn("🎬 切换模型", "/vd models")],
        ]
        return Card(
            f"{mode_name}任务已提交",
            f"🎬 **已收到{mode_name}请求**（订单号 `{task_id}`）！\n"
            f"━━━━━━━━━━━━━━━━━━\n"
            f"• 模型：`{model}` | 时长：`{duration}秒`\n"
            f"• 预扣：`{total_cost}` 积分（{cost_per_sec:.1f} 积分/秒）\n\n"
            f"视频正在后台排队渲染中，预计需 30~180 秒。\n"
            f"💡 发送 `/vd status {task_id}` 随时查单；完成后将自动回传，亦可发送 `/vd download {task_id}` 随时重新下载！",
            rows=buttons[:5],
        )

    async def _run_async_video_pipeline(
        self, context: Any, prompt: str, ref_image: str | None, model: str, cost: float, duration: int = 5, task_id: str = ""
    ) -> None:
        user_key = self._get_user_key(context)
        video_path: Path | None = None
        try:
            video_url = await self._request_video_url(user_key, prompt, ref_image, model, duration=duration)
            if not video_url:
                raise RuntimeError("未能从上游获取到有效的视频下载地址")

            if task_id and task_id in self.tasks:
                self.tasks[task_id]["video_url"] = video_url
                self.tasks[task_id]["status"] = "completed"
                self.tasks[task_id]["completed_at"] = _format_cst_time()
                self._save_data()

            # Download video to local temp file
            video_path = await self._download_video_stream(video_url)
            if not video_path.is_file() or video_path.stat().st_size <= 0:
                raise RuntimeError("下载的视频文件为空或损坏")

            # Check soft limit 35MB
            size_mb = video_path.stat().st_size / (1024 * 1024)
            if size_mb > 35:
                raise RuntimeError(f"生成的视频体积过大 ({size_mb:.1f}MB)，超过平台限制")

            # Upload and send via QQ official rich media
            send_ok, err = await self._send_qq_video(context, video_path)
            if not send_ok:
                raise RuntimeError(f"QQ 视频媒体发送失败: {err}")

        except Exception as err:
            logger.error("Video generation pipeline failed: %s", err, exc_info=True)
            if task_id and task_id in self.tasks:
                self.tasks[task_id]["status"] = "failed"
                self.tasks[task_id]["error"] = str(err)[:200]
                self.tasks[task_id]["completed_at"] = _format_cst_time()
                self._save_data()
            # Refund credits
            await self._refund_credits(user_key, cost, reason="视频生成失败全额退还")
            clean_err = _format_error_msg(str(err))
            await self._notify_error(context, f"🎬 视频生成提醒：订单 `{task_id}` 生成失败：{clean_err}\n已全额退还扣除的 {cost} 积分。")
        finally:
            if video_path and video_path.is_file():
                try:
                    video_path.unlink()
                except Exception:
                    pass

    async def _request_video_url(
        self, user_key: str, prompt: str, ref_image: str | None, model: str, duration: int = 5
    ) -> str:
        protocol = str(self.config.get("provider_protocol", "agnes")).lower()
        api_base = str(self.config.get("api_base_url") or "").rstrip("/")
        clean_base = api_base[:-3].rstrip("/") if api_base.endswith("/v1") else api_base
        api_key = str(self.config.get("api_key") or "").strip()
        aspect_ratio = self._get_pref(user_key, "aspect_ratio", "16:9")
        if duration <= 0:
            duration = int(self._get_pref(user_key, "duration_sec", 5))

        headers = {
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
        }

        # Build payload & endpoint by protocol
        if protocol == "agnes":
            endpoint = f"{clean_base}/v1/videos"
            if "v2" in model.lower():
                payload: dict[str, Any] = {
                    "model": model,
                    "prompt": prompt,
                    "mode": "ti2vid",
                    "num_frames": 241 if duration >= 8 else 121,
                }
                if ref_image:
                    payload["image"] = ref_image
            else:
                payload = {
                    "model": model,
                    "prompt": prompt,
                    "mode": "keyframe" if ref_image else "text",
                    "seconds": str(duration),
                    "size": "720P",
                    "aspect_ratio": aspect_ratio,
                }
                if ref_image:
                    payload["first_frame"] = ref_image
        elif protocol == "custom":
            custom_ep = str(self.config.get("custom_endpoint") or "/v1/videos/generations")
            endpoint = f"{clean_base}{custom_ep}"
            payload = {
                "model": model,
                "prompt": prompt,
                "aspect_ratio": aspect_ratio,
                "duration": duration,
            }
            if ref_image:
                payload["image_url"] = ref_image
                payload["image"] = ref_image
        else:
            endpoint = f"{clean_base}/v1/videos/generations"
            payload = {
                "model": model,
                "prompt": prompt,
                "aspect_ratio": aspect_ratio,
                "duration": duration,
            }
            if ref_image:
                payload["image_url"] = ref_image
                payload["image"] = ref_image

        ssl_ctx = ssl.create_default_context(cafile=certifi.where())
        connector = aiohttp.TCPConnector(ssl=ssl_ctx)
        timeout = aiohttp.ClientTimeout(total=int(self.config.get("request_timeout_sec", 300)))

        async with aiohttp.ClientSession(connector=connector, timeout=timeout) as session:
            async with session.post(endpoint, json=payload, headers=headers) as resp:
                text = await resp.text()
                if resp.status not in {200, 201, 202}:
                    err_hint = text[:200]
                    try:
                        err_json = json.loads(text)
                        if isinstance(err_json, dict):
                            err_hint = err_json.get("message") or (err_json.get("error") if isinstance(err_json.get("error"), str) else (err_json.get("error") or {}).get("message")) or err_hint
                    except Exception:
                        pass
                    if resp.status == 429 or "rate_limit" in text.lower():
                        raise RuntimeError("上游接口已达限额或并发上限，请稍后重试（已全额退还积分）")
                    if resp.status == 503 and ("queue is full" in str(err_hint).lower() or "video_queue_full" in text.lower()):
                        raise RuntimeError("上游视频队列已满，请稍后重试（已全额退还积分）")
                    raise RuntimeError(f"上游接口状态码异常 ({resp.status}): {err_hint}")
                data = json.loads(text)

            if "error" in data and isinstance(data["error"], dict):
                err_msg = data["error"].get("message") or str(data["error"])
                raise RuntimeError(f"上游接口返回错误: {err_msg}")
            if data.get("code") and data.get("code") not in {0, "success", 200}:
                err_msg = data.get("message") or str(data.get("code"))
                raise RuntimeError(f"上游任务提交失败: {err_msg}")

            # Check if direct url returned
            if "data" in data and isinstance(data["data"], list) and data["data"]:
                first = data["data"][0]
                if isinstance(first, dict) and first.get("url"):
                    return str(first["url"])
            if "video_url" in data:
                return str(data["video_url"])

            # Check if task id returned for polling
            task_id = data.get("video_id") or data.get("task_id") or data.get("id")
            if not task_id and isinstance(data.get("data"), dict):
                task_id = data["data"].get("video_id") or data["data"].get("task_id") or data["data"].get("id")
            if not task_id:
                raise RuntimeError(f"响应缺少 video_url 或 task_id: {text[:200]}")

            # Polling task status
            return await self._poll_task_completion(session, clean_base, str(task_id), headers, model=model, protocol=protocol)

    async def _poll_task_completion(
        self,
        session: aiohttp.ClientSession,
        clean_base: str,
        task_id: str,
        headers: dict[str, str],
        model: str = "",
        protocol: str = "agnes",
    ) -> str:
        poll_interval = int(self.config.get("poll_interval_sec", 3))
        max_time = int(self.config.get("request_timeout_sec", 300))
        start_time = time.monotonic()

        poll_urls: list[str] = []
        if protocol == "agnes":
            poll_urls.append(f"{clean_base}/agnesapi?video_id={task_id}&model_name={model}")
            poll_urls.append(f"{clean_base}/v1/videos/{task_id}")
        else:
            poll_urls.append(f"{clean_base}/v1/videos/{task_id}")
            poll_urls.append(f"{clean_base}/v1/tasks/{task_id}")
            poll_urls.append(f"{clean_base}/v1/videos/generations/{task_id}")

        while time.monotonic() - start_time < max_time:
            await asyncio.sleep(poll_interval)
            for url in poll_urls:
                try:
                    async with session.get(url, headers=headers) as resp:
                        if resp.status != 200:
                            continue
                        data = await resp.json()
                        status = str(data.get("status") or data.get("state") or "").lower()
                        if status in {"success", "succeeded", "completed"} or (data.get("code") in {0, 200} and data.get("video_url")):
                            out = data.get("output") or data.get("result") or data.get("data")
                            if isinstance(out, dict):
                                u = out.get("video_url") or out.get("url")
                                if u:
                                    return str(u)
                            if isinstance(out, list) and out and isinstance(out[0], dict):
                                u = out[0].get("url") or out[0].get("video_url")
                                if u:
                                    return str(u)
                            if data.get("video_url"):
                                return str(data["video_url"])
                        elif status in {"failed", "error", "cancelled"}:
                            msg = data.get("error") or data.get("message") or "上游任务执行失败"
                            raise RuntimeError(f"视频任务生成失败: {msg}")
                except Exception as e:
                    if "视频任务生成失败" in str(e):
                        raise
                    logger.debug("Task poll retry: %s", e)

        raise TimeoutError("视频渲染超时，请稍后重试")

    async def _download_video_stream(self, url: str) -> Path:
        target_path = self._temp_dir / f"vid_{uuid.uuid4().hex}.mp4"
        ssl_ctx = ssl.create_default_context(cafile=certifi.where())
        connector = aiohttp.TCPConnector(ssl=ssl_ctx)
        timeout = aiohttp.ClientTimeout(total=120)

        async with aiohttp.ClientSession(connector=connector, timeout=timeout) as session:
            async with session.get(url) as resp:
                if resp.status != 200:
                    raise RuntimeError(f"下载视频失败 ({resp.status})")
                with target_path.open("wb") as f:
                    while True:
                        chunk = await resp.content.read(64 * 1024)
                        if not chunk:
                            break
                        f.write(chunk)
        return target_path

    async def _send_qq_video(self, context: Any, path: Path) -> tuple[bool, str]:
        source = Path(path)
        if not source.is_file():
            return False, f"本地视频文件不存在: {source}"
        scene = _normalize_scene(context)
        media = getattr(self.context, "media", None)
        qq = getattr(self.context, "qq", None)
        conv_id = (
            getattr(context, "conversation_id", "")
            or getattr(context, "group_id", "")
            or getattr(context, "sender_id", "")
        )
        if media is None or qq is None or not conv_id:
            return False, "QQ 媒体服务未就绪"

        try:
            msg_id = getattr(context, "message_id", None)
            if scene in {"c2c", "group"}:
                # Note: file_type = 2 for video!
                request = await media.prepare(scene, conv_id, 2, source)
                uploaded = await qq.upload_media_file(request, source)
                file_info = uploaded.get("file_info") if isinstance(uploaded, dict) else None
                if not file_info:
                    return False, f"上传接口未返回 file_info: {uploaded}"
                try:
                    if msg_id:
                        await qq.send_media(conv_id, scene, str(file_info), msg_id=msg_id)
                    else:
                        await qq.send_media(conv_id, scene, str(file_info))
                except Exception as e:
                    if msg_id:
                        logger.warning("Passive send_media failed (%s), fallback to active", e)
                        await qq.send_media(conv_id, scene, str(file_info))
                    else:
                        raise
                return True, ""
            return False, f"视频富媒体暂不支持当前场景: {scene}"
        except Exception as e:
            return False, str(e)

    async def _notify_error(self, context: Any, text: str) -> None:
        qq = getattr(self.context, "qq", None)
        conv_id = getattr(context, "conversation_id", "") or getattr(context, "group_id", "") or getattr(context, "sender_id", "")
        scene = _normalize_scene(context)
        msg_id = getattr(context, "message_id", None)
        if qq and conv_id:
            try:
                if scene == "c2c":
                    await qq.send_c2c_message(conv_id, text, msg_id=msg_id)
                elif scene == "group":
                    await qq.send_group_message(conv_id, text, msg_id=msg_id)
            except Exception as e:
                logger.warning("Notify error message failed: %s", e)

    # ---------- Scheduled Tasks ----------

    def cleanup(self) -> None:
        now = time.time()
        for f in self._temp_dir.glob("*.mp4"):
            try:
                if now - f.stat().st_mtime > 3600:
                    f.unlink()
            except Exception:
                pass

    async def _async_poll_pending_payments(self) -> None:
        if not self.pending_pay_orders:
            return
        pay_api = getattr(self.context, "builtin", lambda name: None)("runtime.pay")
        if not pay_api or not hasattr(pay_api, "query_payment"):
            return
        now = time.time()
        expired_ids = []
        active_items = []
        for order_id, info in list(self.pending_pay_orders.items()):
            order_time = info.get("time", 0)
            if now - order_time > 1800:
                expired_ids.append(order_id)
            else:
                active_items.append((order_id, info))

        for eid in expired_ids:
            self.pending_pay_orders.pop(eid, None)
        if expired_ids:
            self._save_data()

        active_items.sort(key=lambda x: x[1].get("time", 0), reverse=True)
        finished_ids = []
        for order_id, _info in active_items[:2]:
            try:
                res = await asyncio.wait_for(pay_api.query_payment(order_id), timeout=2.0)
                status = str(res.get("local_status") or "")
                if status == "paid":
                    await self.on_payment_success(res)
                    finished_ids.append(order_id)
                elif status in {"closed", "refunded", "create_failed", "polling_stopped"}:
                    finished_ids.append(order_id)
            except Exception:
                pass

        if finished_ids:
            for fid in finished_ids:
                self.pending_pay_orders.pop(fid, None)
            self._save_data()

    def poll_pending_payments(self) -> None:
        try:
            loop = asyncio.get_event_loop()
            if loop.is_running():
                asyncio.create_task(self._async_poll_pending_payments())
            else:
                loop.run_until_complete(self._async_poll_pending_payments())
        except Exception as e:
            logger.debug("poll_pending_payments error: %s", e)

    # ---------- WebUI Page Actions ----------

    async def action_save_config(self, payload: dict[str, Any]) -> dict[str, Any]:
        for k, v in payload.items():
            if k in self.config:
                self.config[k] = v
        self._save_config()
        return {"ok": True, "config": self.config}

    async def action_overview(self, payload: dict[str, Any] | None = None) -> dict[str, Any]:
        return {
            "ok": True,
            "version": PLUGIN_VERSION,
            "config": self.config,
            "total_users": len(self.user_credits),
        }

    async def action_probe(self, payload: dict[str, Any] | None = None) -> dict[str, Any]:
        payload = payload or {}
        api_base = str(payload.get("api_base_url") or self._get_cfg("api_base_url", "")).rstrip("/")
        api_key = str(payload.get("api_key") or self._get_cfg("api_key", "")).strip()
        if not api_base:
            return {"ok": False, "message": "未配置 API 服务地址"}
        headers = {"Authorization": f"Bearer {api_key}"} if api_key else {}
        t0 = time.time()
        try:
            ssl_ctx = ssl.create_default_context(cafile=certifi.where())
            timeout = aiohttp.ClientTimeout(total=10.0)
            async with aiohttp.ClientSession(timeout=timeout) as session:
                async with session.get(f"{api_base}/v1/models", headers=headers, ssl=ssl_ctx) as resp:
                    latency = round((time.time() - t0) * 1000, 1)
                    return {
                        "ok": True,
                        "status_code": resp.status,
                        "latency_ms": latency,
                        "message": f"连接成功 (HTTP {resp.status}，耗时 {latency}ms)",
                    }
        except Exception as e:
            return {"ok": False, "message": f"连接失败: {e}"}

    async def page_fetch_models(self, api_base: str = "", api_key: str = "") -> dict[str, Any]:
        base = (api_base or str(self.config.get("api_base_url") or "")).strip().rstrip("/")
        key = (api_key or str(self.config.get("api_key") or "")).strip()
        if not base:
            raise ValueError("请先填写 API 地址（api_base_url）")
        headers = {}
        if key:
            headers["Authorization"] = f"Bearer {key}"
        models: list[str] = []
        timeout = aiohttp.ClientTimeout(total=15)
        async with aiohttp.ClientSession(timeout=timeout) as session:
            resp_data = None
            err_msg = ""
            for path in ("/v1/models", "/models"):
                try:
                    ssl_ctx = ssl.create_default_context(cafile=certifi.where())
                    async with session.get(f"{base}{path}", headers=headers, ssl=ssl_ctx) as resp:
                        if resp.status == 200:
                            resp_data = await resp.json()
                            break
                        else:
                            err_msg = f"HTTP {resp.status}"
                except Exception as e:
                    err_msg = str(e)
            if not resp_data:
                raise ValueError(f"获取模型列表失败: {err_msg or '无法连接目标 API'}")
            data = resp_data.get("data", []) if isinstance(resp_data, dict) else (resp_data if isinstance(resp_data, list) else [])
            for item in data:
                mid = str(item.get("id") if isinstance(item, dict) else item).strip()
                if mid and mid not in models:
                    models.append(mid)

        video_keywords = (
            "video", "sora", "cogvideo", "kling", "hailuo", "runway", "luma",
            "minimax-video", "gen-2", "gen-3", "veo", "pika", "wanx",
            "hunyuan-video", "grok-imagine-video"
        )
        negative_keywords = (
            "image", "audio", "speech", "tts", "whisper", "embedding",
            "claude", "gemini", "gpt-", "deepseek", "chat"
        )
        video_models = []
        for m in models:
            m_lower = m.lower()
            if any(k in m_lower for k in video_keywords):
                if any(neg in m_lower for neg in negative_keywords):
                    if not any(pos in m_lower for pos in ("video", "i2v", "image-to-video")):
                        continue
                    if ("image-" in m_lower or "-image" in m_lower or "image." in m_lower) and not ("video" in m_lower or "i2v" in m_lower):
                        continue
                video_models.append(m)

        self.cached_models = video_models
        self._save_data()
        return {"ok": True, "models": video_models, "all_models": models, "total": len(video_models)}

    async def action_fetch_models(self, payload: Any = None) -> dict[str, Any]:
        payload = payload if isinstance(payload, dict) else {}
        base = str(payload.get("api_base_url") or "")
        key = str(payload.get("api_key") or "")
        try:
            return await self.page_fetch_models(base, key)
        except Exception as e:
            return {"ok": False, "error": str(e)}

    async def action_users(self, payload: Any = None) -> dict[str, Any]:
        users = []
        all_keys = set(self.user_credits.keys()) | set(self.user_prefs.keys())
        default_bal = float(self.config.get("default_balance", 0.0))
        for k in sorted(all_keys):
            creds = float(self.user_credits.get(k, default_bal))
            prefs = self.user_prefs.get(k, {})
            m = prefs.get("default_model", self.config.get("default_model", "agnes-video-2.5-flash"))
            ratio = prefs.get("aspect_ratio", "16:9")
            u_tasks = [t for t in self.tasks.values() if t.get("user_key") == k]
            last_active = u_tasks[-1].get("created_at", "-") if u_tasks else "-"
            users.append({
                "key": k,
                "credits": round(creds, 2),
                "model": m,
                "aspect_ratio": ratio,
                "tasks_count": len(u_tasks),
                "last_active": last_active,
            })
        return {"ok": True, "users": users}

    async def action_user_credit(self, payload: Any = None) -> dict[str, Any]:
        if not isinstance(payload, dict):
            return {"ok": False, "error": "无效参数"}
        user_key = str(payload.get("key") or "").strip()
        if not user_key:
            return {"ok": False, "error": "缺少用户标识"}
        try:
            credits = float(payload.get("credits", 0))
        except (ValueError, TypeError):
            return {"ok": False, "error": "积分数值无效"}
        mode = str(payload.get("mode") or "add").strip()
        default_bal = float(self.config.get("default_balance", 0.0))
        cur = float(self.user_credits.get(user_key, default_bal))
        if mode == "set":
            new_val = max(0.0, credits)
        else:
            new_val = max(0.0, cur + credits)
        self.user_credits[user_key] = round(new_val, 2)
        self._save_data()
        return {"ok": True, "key": user_key, "credits": self.user_credits[user_key]}

    async def action_user_model(self, payload: Any = None) -> dict[str, Any]:
        if not isinstance(payload, dict):
            return {"ok": False, "error": "无效参数"}
        user_key = str(payload.get("key") or "").strip()
        model = str(payload.get("model") or "").strip()
        if not user_key:
            return {"ok": False, "error": "缺少用户标识"}
        self._set_pref(user_key, "default_model", model)
        return {"ok": True, "key": user_key, "model": model}

    async def action_tasks(self, payload: Any = None) -> dict[str, Any]:
        recent = sorted(self.tasks.values(), key=lambda t: t.get("created_at", ""), reverse=True)[:50]
        return {"ok": True, "tasks": recent}

    async def on_page_action(self, *args: Any, **kwargs: Any) -> Any:
        if args and isinstance(args[0], str):
            action_name = args[0]
            payload = args[1] if len(args) > 1 else {}
        else:
            action_name = kwargs.get("action_name", "overview")
            payload = kwargs.get("payload", {})
        action = str(action_name or "").strip()
        payload = payload if isinstance(payload, dict) else {}
        if action in ("save_config", "config"):
            return await self.action_save_config(payload)
        if action in ("overview", "page_overview"):
            return await self.action_overview(payload)
        if action in ("probe", "ping", "test"):
            return await self.action_probe(payload)
        if action in ("fetch_models", "models"):
            return await self.action_fetch_models(payload)
        if action in ("users", "page_users"):
            return await self.action_users(payload)
        if action == "user_credit":
            return await self.action_user_credit(payload)
        if action == "user_model":
            return await self.action_user_model(payload)
        if action in ("tasks", "orders"):
            return await self.action_tasks(payload)
        return {"ok": True}


def setup(context: Any) -> VideoServicePlugin:
    plugin = VideoServicePlugin(context)
    context.register_command("vd", plugin.handle_vd, category="video", description="视频服务主入口")
    context.register_command("vds", plugin.handle_vd, category="video", description="视频服务主入口")
    context.register_command("vde", plugin.handle_vde, category="video", description="图生视频")
    context.register_command("vdse", plugin.handle_vde, category="video", description="图生视频")
    context.register_event_handler("*", plugin.on_event)
    context.register_task("cleanup", 3600, plugin.cleanup)
    context.register_task("check_payments", 15, plugin.poll_pending_payments)
    if hasattr(context, "register_action"):
        context.register_action("overview", plugin.action_overview)
        context.register_action("save_config", plugin.action_save_config)
        context.register_action("probe", plugin.action_probe)
        context.register_action("fetch_models", plugin.action_fetch_models)
        context.register_action("users", plugin.action_users)
        context.register_action("user_credit", plugin.action_user_credit)
        context.register_action("user_model", plugin.action_user_model)
        context.register_action("tasks", plugin.action_tasks)
    return plugin
