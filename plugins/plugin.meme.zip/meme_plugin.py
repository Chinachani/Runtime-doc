"""MemeCrafters 表情包外置插件。

从内置 runtime.meme.MemeService 移植：/meme 命令、无前缀自然语言触发、
模板搜索/别名/停用管理、头像与引用图兜底、媒体三步链路回传。
依赖 meme-generator（通过控制台"插件私有依赖"安装到本插件数据目录，
或镜像预装），渲染在沙箱 worker 内完成。

配置仅来自 config_dir/config.json（控制台通用保存 + save_config Action），
页面快照写入 data_dir/page_overview.json。
"""

from __future__ import annotations

import contextlib
import difflib
import html
import importlib.util
import json
import logging
import os
import re
import sys
import threading
import unicodedata
import uuid
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from tempfile import TemporaryDirectory
from typing import Any

import httpx

from runtime.models import Button, Card, MessageContext

logger = logging.getLogger("plugin.meme")

PLUGIN_VERSION = "0.1.5"
MENU_PAGE_SIZE = 8

# meme-generator 0.2.x moved the optional ``texts[0]`` value used by
# these templates into ``Image.name``. Preserve the older command
# contract (for example ``/meme 问问 张三``).
OPTIONAL_IMAGE_NAME_MEMES = frozenset(
    {
        "acg_entrance", "addiction", "alipay", "anya_suki", "ask",
        "beat_head", "caused_by_this", "coupon", "fill_head", "flash_blind",
        "fogging", "follow", "father_work", "genshin_start", "google_captcha",
        "incivilization", "interview", "jiji_king", "jiubingfufa", "keep_away",
        "learn", "little_angel", "look_flat", "look_this_icon", "make_friend",
        "note_for_leave", "oshi_no_ko", "pass_the_buck", "play_game", "read_book",
        "safe_sense", "sit_still", "speechless", "stew", "teach", "time_to_go",
        "together", "upside_down", "what_he_wants", "wechat_pay", "why_have_hands",
        "you_should_call",
    }
)

CONFIG_LABELS = {
    "enabled": "启用表情包",
    "allow_prefixless": "无前缀自然语言触发",
    "command_prefix": "命令前缀",
    "default_meme": "默认模板",
    "disabled_memes": "停用模板（JSON 数组）",
    "meme_aliases": "模板别名（JSON 数组）",
    "max_images": "最多图片数",
    "max_texts": "最多文字数",
    "timeout_seconds": "生成超时（秒）",
    "output_dir": "输出目录",
    "auto_preview": "自动预览（保留配置项；外置版控制台暂不提供缩略图）",
}

DEFAULT_CONFIG: dict[str, Any] = {
    "enabled": False,
    "allow_prefixless": False,
    "command_prefix": "meme",
    "default_meme": "",
    "disabled_memes": [],
    "meme_aliases": [],
    "max_images": 3,
    "max_texts": 6,
    "timeout_seconds": 30,
    "output_dir": "meme",
    "auto_preview": False,
}

CONFIG_SCHEMA: dict[str, dict[str, Any]] = {}
for _key, _default in DEFAULT_CONFIG.items():
    if isinstance(_default, bool):
        CONFIG_SCHEMA[_key] = {"type": "bool", "default": _default}
    elif isinstance(_default, float):
        CONFIG_SCHEMA[_key] = {"type": "float", "default": _default}
    elif isinstance(_default, int):
        CONFIG_SCHEMA[_key] = {"type": "int", "default": _default}
    elif isinstance(_default, list):
        CONFIG_SCHEMA[_key] = {"type": "list", "default": _default}
    else:
        CONFIG_SCHEMA[_key] = {"type": "str", "default": _default}

_resource_download_started = False
_resource_download_lock = threading.Lock()


def _available() -> bool:
    if importlib.util.find_spec("meme_generator") is None:
        return False
    try:
        import meme_generator
        if not callable(getattr(meme_generator, "get_meme_keys", None)):
            return False
    except (ImportError, OSError):
        return False
    return True


def _module():
    with _silence_native_stdout():
        import meme_generator

        return meme_generator


@contextlib.contextmanager
def _silence_native_stdout():
    """刷新 Python 输出缓冲。

    沙箱 worker 启动时已由 _worker_main 将 sys.stdout 导向 stderr，
    协议管道受 protocol_output 单独保护，无需也不得通过 os.dup2(2, 1) 侵入式修改全局文件描述符。
    """
    try:
        sys.stdout.flush()
        sys.stderr.flush()
    except Exception:
        pass
    try:
        yield
    finally:
        try:
            sys.stdout.flush()
            sys.stderr.flush()
        except Exception:
            pass


class MemePlugin:
    def __init__(self, context: Any) -> None:
        self.context = context
        self.plugin_id = getattr(context, "plugin_id", "plugin.meme")
        self.config_dir = Path(getattr(context, "config_dir", "") or "./config")
        self.data_dir = Path(getattr(context, "data_dir", "") or "./data")
        self.config_dir.mkdir(parents=True, exist_ok=True)
        self.data_dir.mkdir(parents=True, exist_ok=True)
        self.config_file = self.config_dir / "config.json"
        # meme-generator 的模板资源与配置目录跟随 XDG/HOME；指向插件数据目录保证
        # 资源随数据卷持久化，并避免只读容器下 Rust 核心的告警写满 RPC 通道
        # （必须在首次 import meme_generator 前设置）。
        os.environ.setdefault("XDG_DATA_HOME", str(self.data_dir))
        os.environ.setdefault("XDG_CONFIG_HOME", str(self.data_dir / "config"))
        os.environ.setdefault("HOME", str(self.data_dir))
        # meme-generator 的 Rust 核心把 env_logger 输出写到 stdout（含资源下载
        # 失败的 WARN），任何字节都会污染 worker 的 JSON-RPC 通道——静默之。
        os.environ.setdefault("RUST_LOG", "off")
        (self.data_dir / "config").mkdir(parents=True, exist_ok=True)
        self.config: dict[str, Any] = dict(DEFAULT_CONFIG)
        self._load_config()

    # ---------------- 配置 ----------------
    def _load_config(self) -> None:
        try:
            data = json.loads(self.config_file.read_text(encoding="utf-8"))
            if isinstance(data, dict):
                for key in DEFAULT_CONFIG:
                    if key in data:
                        self.config[key] = data[key]
        except FileNotFoundError:
            pass
        except Exception as error:
            logger.warning("读取 plugin.meme config.json 失败: %s", error)

    def _save_config(self) -> None:
        try:
            self.config_dir.mkdir(parents=True, exist_ok=True)
            self.config_file.write_text(
                json.dumps(self.config, ensure_ascii=False, indent=2), encoding="utf-8"
            )
        except Exception as error:
            logger.warning("写入 plugin.meme config.json 失败: %s", error)

    def _cfg(self, key: str) -> Any:
        return self.config.get(key, DEFAULT_CONFIG.get(key))

    def _apply_config(self, payload: dict[str, Any]) -> None:
        for key, value in (payload or {}).items():
            if key in DEFAULT_CONFIG:
                self.config[key] = value
        self._save_config()

    # ---------------- 页面快照 ----------------
    def _write_page_snapshot(self) -> None:
        try:
            self.data_dir.mkdir(parents=True, exist_ok=True)
            disabled = self._disabled_memes()
            alias_count = len(self._alias_map())
            total = len(self.meme_keys())
            available = _available()
            snapshot = {
                "available": available,
                "config": dict(self.config),
                "schema": CONFIG_SCHEMA,
                "labels": CONFIG_LABELS,
                "stats": {
                    "模板总数": total,
                    "启用模板": total - len(disabled),
                    "停用模板": len(disabled),
                    "别名条数": alias_count,
                },
                "service": {
                    "meme-generator": "已安装" if available else "未安装（安装依赖后重启插件）",
                    "插件版本": PLUGIN_VERSION,
                    "模板资源": "就绪" if available else "等待依赖安装",
                },
            }
            (self.data_dir / "page_overview.json").write_text(
                json.dumps(snapshot, ensure_ascii=False, indent=2), encoding="utf-8"
            )
        except Exception as error:
            logger.warning("写入 plugin.meme page_overview.json 失败: %s", error)

    async def on_page_action(self, action: str, payload: dict[str, Any] | None = None) -> Any:
        """页面 Action 入口：未预期异常附带 traceback 返回，便于控制台诊断。"""
        try:
            return await self._dispatch_page_action(action, payload)
        except Exception as error:
            import traceback
            logger.error("plugin.meme on_page_action %s 失败: %s", action, error, exc_info=True)
            return {"error": str(error), "traceback": traceback.format_exc()[-2000:]}

    async def _dispatch_page_action(self, action: str, payload: dict[str, Any] | None = None) -> Any:
        payload = payload or {}
        if action in {"save_config", "config"}:
            updates = payload.get("config") or payload
            if isinstance(updates, dict):
                for key, value in updates.items():
                    if key in DEFAULT_CONFIG:
                        self.config[key] = value
                self._save_config()
                self._write_page_snapshot()
                return {"saved": True, "config": self.config}
            return {"saved": False, "error": "无效的配置参数"}
        if action in {"page_data", "data"}:
            query = str((payload or {}).get("query") or "")
            available = _available()
            return {
                "available": available,
                "config": dict(self.config),
                "schema": CONFIG_SCHEMA,
                "labels": CONFIG_LABELS,
                "items": self.meme_catalog(query),
                "total": len(self.meme_keys()),
            }
        if action in {"set_template", "template"}:
            key = str(payload.get("key") or "").strip()
            enabled = bool(payload.get("enabled", True))
            if not key:
                return {"error": "模板 key 不能为空"}
            disabled = list(self.config.get("disabled_memes") or [])
            if enabled:
                disabled = [item for item in disabled if item != key]
            else:
                if key not in disabled:
                    disabled.append(key)
            self.config["disabled_memes"] = disabled
            self._save_config()
            self._write_page_snapshot()
            return {"success": True, "key": key, "enabled": enabled, "disabled_memes": disabled}
        if action in {"page_delete", "data_delete", "clear"}:
            return {"ok": True, "message": "表情包插件无待清理数据"}
        if action in {"preview", "get_preview"}:
            key = str(payload.get("key") or "").strip()
            preview = self.get_preview(key)
            if not preview:
                return {"ok": False, "error": "预览图不可用或模板不存在"}
            import base64
            raw, mime = preview
            return {"ok": True, "mime": mime, "data": base64.b64encode(raw).decode("ascii")}
        if action == "test_api":
            return {"success": _available(), "message": "meme-generator 可用" if _available() else "meme-generator 未安装"}
        return {"error": f"未知操作: {action}"}

    def get_preview(self, key: str) -> tuple[bytes, str] | None:
        """获取或生成表情包模板预览图，带本地磁盘持久缓存。"""
        if not _available():
            return None
        key = str(key or "").strip()
        if key not in set(self.meme_keys()):
            return None
        cache_dir = self.data_dir / "cache" / "meme_previews"
        cache_dir.mkdir(parents=True, exist_ok=True)
        for ext, mime in ((".gif", "image/gif"), (".png", "image/png"), (".jpg", "image/jpeg"), (".webp", "image/webp")):
            cached = cache_dir / f"{key}{ext}"
            if cached.is_file():
                try:
                    return cached.read_bytes(), mime
                except Exception:
                    pass
        try:
            meme = _module().get_meme(key)
            raw = meme.generate_preview()
            if isinstance(raw, (bytearray, memoryview)):
                raw = bytes(raw)
            elif not isinstance(raw, bytes):
                raw = bytes(raw)
            ext = self._detect_image_ext(raw)
            mime_map = {
                ".gif": "image/gif",
                ".png": "image/png",
                ".jpg": "image/jpeg",
                ".webp": "image/webp",
            }
            mime = mime_map.get(ext, "image/png")
            target = cache_dir / f"{key}{ext}"
            target.write_bytes(raw)
            return raw, mime
        except Exception as error:
            logger.warning("生成表情包预览失败 %s: %s", key, error)
            return None

    # ---------------- 模板元数据 ----------------
    def _start_resource_download(self) -> None:
        global _resource_download_started
        if _resource_download_started or not _available():
            return
        with _resource_download_lock:
            if _resource_download_started:
                return
            try:
                with _silence_native_stdout():
                    resources = getattr(_module(), "resources", None)
                    starter = getattr(resources, "check_resources_in_background", None)
                    if callable(starter):
                        starter()
                _resource_download_started = True
            except Exception:
                _resource_download_started = True

    def meme_keys(self) -> list[str]:
        if not _available():
            return []
        try:
            return sorted(str(key) for key in _module().get_meme_keys())
        except Exception:
            return []

    def _disabled_memes(self) -> set[str]:
        value = self._cfg("disabled_memes")
        return (
            {str(item).strip() for item in value if str(item).strip()}
            if isinstance(value, list)
            else set()
        )

    def _alias_map(self) -> dict[str, str]:
        value = self._cfg("meme_aliases")
        result: dict[str, str] = {}
        if not isinstance(value, list):
            return result
        for item in value:
            if not isinstance(item, dict):
                continue
            alias = str(item.get("alias") or "").strip()
            key = str(item.get("key") or "").strip()
            if alias and key:
                result[alias.casefold()] = key
        return result

    def enabled_meme_keys(self) -> list[str]:
        disabled = self._disabled_memes()
        return [key for key in self.meme_keys() if key not in disabled]

    def resolve_meme_key(self, value: str) -> str:
        token = str(value or "").strip()
        aliases = self._alias_map()
        folded = aliases.get(token.casefold())
        if folded:
            return folded
        known = {key.casefold(): key for key in self.meme_keys()}
        if token.casefold() in known:
            return known[token.casefold()]
        normalized = self._normalize_template_name(token)
        if normalized:
            for key in self.meme_keys():
                try:
                    info = _module().get_meme(key).info
                except Exception:
                    continue
                values = [
                    *self._metadata_values(getattr(info, "keywords", None)),
                    *self._metadata_values(getattr(info, "tags", None)),
                    *self._metadata_values(getattr(info, "shortcuts", None)),
                    *self._metadata_values(getattr(info, "name", None)),
                    *self._metadata_values(getattr(info, "title", None)),
                ]
                if any(self._normalize_template_name(item) == normalized for item in values):
                    return key
        return token

    @staticmethod
    def _metadata_values(value: object) -> list[object]:
        if value is None:
            return []
        if isinstance(value, (list, tuple, set, frozenset)):
            return list(value)
        return [value]

    @classmethod
    def _effective_text_bounds(cls, key: str, params: object) -> tuple[int, int]:
        minimum = int(getattr(params, "min_texts", 0))
        maximum = int(getattr(params, "max_texts", 0))
        if maximum == 0 and key in OPTIONAL_IMAGE_NAME_MEMES:
            return minimum, 1
        return minimum, maximum

    # ---------------- 参数清洗（与内置版一致） ----------------
    @staticmethod
    def _output_bytes(output: Any) -> bytes:
        if isinstance(output, bytes):
            return output
        if isinstance(output, (bytearray, memoryview)):
            return bytes(output)
        if isinstance(output, (list, tuple)):
            for item in output:
                raw = MemePlugin._output_bytes(item)
                if raw:
                    return raw
            return b""
        for attribute in ("data", "content", "bytes"):
            try:
                value = getattr(output, attribute, None)
            except Exception:
                value = None
            if isinstance(value, (bytes, bytearray, memoryview)):
                return bytes(value)
        reader = getattr(output, "read", None)
        if callable(reader):
            try:
                value = reader()
            except Exception:
                value = None
            if isinstance(value, (bytes, bytearray, memoryview)):
                return bytes(value)
        return b""

    @staticmethod
    def _normalize_template_name(value: object) -> str:
        text = html.unescape(str(value or "")).strip().casefold()
        return re.sub(r"[\s\u3000\-_·。！？!?、，,：:（）()【】\[\]{}]+", "", text)

    @staticmethod
    def _has_visible_text(value: object) -> bool:
        for char in str(value or ""):
            category = unicodedata.category(char)
            if category[0] in {"L", "N"}:
                return True
            if category not in {"Cc", "Cf", "Co", "Cs", "Cn"} and not char.isspace():
                return True
        return False

    @classmethod
    def _is_attachment_marker(cls, value: object) -> bool:
        raw = html.unescape(str(value or "")).strip()
        if not raw:
            return True
        stripped = cls._strip_attachment_markers(raw)
        if not stripped:
            return True
        if re.fullmatch(
            r"(?:图片|图像|照片|相片|附件|image|img|photo|picture|attachment)"
            r"(?:\s*[:：#=_-]\s*[\w. -]+)?",
            stripped,
            flags=re.IGNORECASE,
        ):
            return True
        if re.fullmatch(
            r"(?:input|image|img|attachment)[-_]?\d*(?:\.(?:png|jpe?g|gif|webp))?",
            stripped,
            flags=re.IGNORECASE,
        ):
            return True
        if not cls._has_visible_text(stripped):
            return True
        return all(char in "🖼️📷📸🧩🧱\uFFFC" for char in stripped)

    @staticmethod
    def _strip_attachment_markers(value: object) -> str:
        text = html.unescape(str(value or ""))
        text = re.sub(r"\[CQ:(?:image|img),[^\]]*\]", " ", text, flags=re.IGNORECASE)
        text = re.sub(r"!\[[^\]]*\]\([^\)]*\)", " ", text, flags=re.IGNORECASE)
        text = re.sub(
            r"(?:\[[^\]\r\n]*(?:图片|image|img|图像|照片|photo)[^\]\r\n]*\]"
            r"|【[^】\r\n]*(?:图片|image|img|图像|照片|photo)[^】\r\n]*】"
            r"|\([^\)\r\n]*(?:图片|image|img|图像|照片|photo)[^\)\r\n]*\))",
            " ", text, flags=re.IGNORECASE,
        )
        text = re.sub(r"<[^>]*(?:image|img|图片|照片)[^>]*>", " ", text, flags=re.IGNORECASE)
        text = re.sub(
            r"(?<![\w\u4e00-\u9fff])(?:图片|图像|照片|相片|附件|image|img|photo|picture|attachment)"
            r"(?:\s*[:：#=_-]\s*[\w. -]+)?(?![\w\u4e00-\u9fff])",
            " ",
            text,
            flags=re.IGNORECASE,
        )
        text = re.sub(
            r"(?<![\w])(?:input|image|img|attachment)[-_]?\d*(?:\.(?:png|jpe?g|gif|webp))?(?![\w])",
            " ",
            text,
            flags=re.IGNORECASE,
        )
        text = "".join(
            char
            for char in text
            if unicodedata.category(char) not in {"Cc", "Cf", "Co", "Cs", "Cn"}
            or char in {"\n", "\r", "\t"}
        )
        return text.strip()

    def _split_inline_mention(self, value: str) -> tuple[str, str | None]:
        raw = self._strip_attachment_markers(value)
        candidates = set(self.meme_keys()) | set(self._alias_map())
        for candidate in sorted((str(item) for item in candidates if str(item)), key=len, reverse=True):
            if raw.casefold().startswith(candidate.casefold()):
                suffix = raw[len(candidate):]
                if suffix.startswith("@") or suffix.startswith("＠") or suffix.startswith("<@"):
                    return candidate, suffix
                if suffix and self._is_attachment_marker(suffix):
                    return candidate, None
                if suffix and not self._has_visible_text(suffix):
                    return candidate, None
        return raw, None

    # ---------------- 图片来源 ----------------
    @staticmethod
    def _identity_id(value: object) -> str:
        if not isinstance(value, dict):
            return ""
        return str(
            value.get("id")
            or value.get("user_id")
            or value.get("openid")
            or value.get("user_openid")
            or value.get("member_openid")
            or ""
        ).strip()

    @staticmethod
    def _qlogo_url(context: MessageContext, identity: str) -> str:
        identity = str(identity or "").strip()
        if not identity or not context.bot_id:
            return ""
        return f"https://q.qlogo.cn/qqapp/{context.bot_id}/{identity}/640"

    @staticmethod
    def _raw_reference_elements(context: MessageContext) -> list[dict[str, object]]:
        raw = context.raw_payload or {}
        elements = raw.get("msg_elements")
        if not isinstance(elements, (list, tuple)):
            return []
        found: list[dict[str, object]] = []
        quoted: list[dict[str, object]] = []

        def visit(values: object, in_quote: bool = False) -> None:
            if not isinstance(values, (list, tuple)):
                return
            for item in values:
                if not isinstance(item, dict):
                    continue
                found.append(item)
                is_quote = in_quote or str(item.get("message_type") or "") == "103"
                if is_quote:
                    quoted.append(item)
                visit(item.get("msg_elements"), is_quote)

        visit(elements)
        return quoted or found

    @staticmethod
    def _reference_candidates(
        context: MessageContext, elements: list[dict[str, object]]
    ) -> list[tuple[str, str]]:
        candidates: list[tuple[str, str]] = []
        for element in elements:
            ref_attachments = element.get("attachments")
            if isinstance(ref_attachments, (list, tuple)):
                for item in ref_attachments:
                    if not isinstance(item, dict):
                        continue
                    content_type = str(item.get("content_type") or item.get("mime_type") or "").lower()
                    url = str(item.get("url") or item.get("resource_url") or "").strip()
                    if url and (content_type.startswith("image/") or not content_type):
                        candidates.append((url, "reference_image"))
            if candidates:
                return candidates
            author = element.get("author")
            if isinstance(author, dict):
                avatar = str(author.get("avatar") or author.get("avatar_url") or "").strip()
                identity = MemePlugin._identity_id(author)
                if not avatar:
                    avatar = MemePlugin._qlogo_url(context, identity)
                if avatar:
                    return [(avatar, "reference")]
        return candidates

    @staticmethod
    def _display_name(value: object) -> str:
        if not isinstance(value, dict):
            return ""
        for key in ("username", "nickname", "nick", "name", "display_name"):
            name = str(value.get(key) or "").strip()
            if name:
                return name
        return ""

    @classmethod
    def _reference_display_name(cls, elements: list[dict[str, object]]) -> str:
        for element in elements:
            name = cls._display_name(element.get("author"))
            if name:
                return name
            nested = element.get("msg_elements")
            if isinstance(nested, (list, tuple)):
                name = cls._reference_display_name([item for item in nested if isinstance(item, dict)])
                if name:
                    return name
        return ""

    @staticmethod
    def _detect_image_ext(raw: bytes) -> str:
        if raw.startswith((b"GIF87a", b"GIF89a")):
            return ".gif"
        if raw.startswith(b"\x89PNG\r\n\x1a\n"):
            return ".png"
        if raw.startswith(b"\xff\xd8"):
            return ".jpg"
        if raw.startswith(b"RIFF") and len(raw) > 12 and raw[8:12] == b"WEBP":
            return ".webp"
        return ".png"

    @staticmethod
    def _normalize_input_image(raw: bytes, max_dim: int = 1024) -> bytes:
        if not raw or raw.startswith((b"GIF87a", b"GIF89a")):
            return raw
        try:
            import io

            from PIL import Image, ImageOps

            with Image.open(io.BytesIO(raw)) as img:
                transposed = ImageOps.exif_transpose(img)
                width, height = transposed.size
                if max(width, height) <= max_dim and transposed is img:
                    return raw
                if max(width, height) > max_dim:
                    scale = max_dim / max(width, height)
                    new_size = (max(1, int(width * scale)), max(1, int(height * scale)))
                    transposed = transposed.resize(new_size, Image.Resampling.LANCZOS)
                buf = io.BytesIO()
                if transposed.mode in ("RGBA", "LA", "P"):
                    transposed.save(buf, format="PNG")
                else:
                    transposed.convert("RGB").save(buf, format="JPEG", quality=92)
                return buf.getvalue()
        except Exception:
            return raw

    async def _download_image(self, url: str) -> tuple[bytes, str]:
        try:
            async with httpx.AsyncClient(timeout=20, follow_redirects=True) as client:
                response = await client.get(url, headers={"User-Agent": "Mozilla/5.0"})
                response.raise_for_status()
            if len(response.content) > 20 * 1024 * 1024:
                return b"", "图片超过 20MB"
            return response.content, ""
        except Exception as error:
            return b"", str(error)[:100]

    async def _input_images(
        self,
        context: MessageContext,
        temp_dir: Path,
        preferred_name: str | None = None,
    ) -> tuple[list[Any], str]:
        module = _module()
        candidates: list[tuple[str, str]] = []
        reference_elements = self._raw_reference_elements(context)
        reference_name = self._reference_display_name(reference_elements)
        mention_name = ""
        for item in context.attachments:
            if not isinstance(item, dict):
                continue
            content_type = str(item.get("content_type") or item.get("mime_type") or "").lower()
            url = str(item.get("url") or item.get("resource_url") or "").strip()
            if url and (content_type.startswith("image/") or not content_type):
                candidates.append((url, "attachment"))
        if not candidates:
            candidates.extend(self._reference_candidates(context, reference_elements))
        if not candidates:
            mention_items: list[dict[str, object]] = [
                item for item in context.mentions if isinstance(item, dict)
            ]
            raw_mentions = (context.raw_payload or {}).get("mentions") if context.raw_payload else None
            if not mention_items and isinstance(raw_mentions, (list, tuple)):
                mention_items = [item for item in raw_mentions if isinstance(item, dict)]
            for item in mention_items:
                if isinstance(item, dict):
                    mention_name = self._display_name(item)
                    avatar = str(item.get("avatar") or item.get("avatar_url") or "").strip()
                    if not avatar:
                        mentioned_id = self._identity_id(item)
                        if not avatar:
                            avatar = self._qlogo_url(context, mentioned_id)
                    if avatar:
                        candidates.append((avatar, "mention"))
                        break
        if not candidates and context.sender_avatar:
            candidates.append((str(context.sender_avatar), "sender"))
        if not candidates:
            avatar = self._qlogo_url(context, context.sender_id)
            if avatar:
                candidates.append((avatar, "sender"))
        images: list[Any] = []
        source = ""
        for index, (url, kind) in enumerate(candidates):
            raw, error = await self._download_image(url)
            if not raw:
                continue
            raw = self._normalize_input_image(raw)
            ext = self._detect_image_ext(raw)
            path = temp_dir / f"input-{index}{ext}"
            path.write_bytes(raw)
            try:
                name = (
                    str(preferred_name or "").strip()
                    or (mention_name if kind == "mention" else "")
                    or (reference_name if kind.startswith("reference") else "")
                    or str(context.sender_name or "").strip()
                    or str(context.sender_id or "").strip()
                    or "用户"
                )
                images.append(module.Image(name, raw))
                source = kind
            except Exception:
                continue
            if len(images) >= int(self._cfg("max_images") or 3):
                break
        return images, source

    @classmethod
    def _clean_text_args(cls, context: MessageContext, values: list[str]) -> list[str]:
        normalized = [
            cls._strip_attachment_markers(raw)
            for raw in values
            if not cls._is_attachment_marker(raw)
        ]
        mention_names: list[str] = []
        for item in context.mentions:
            if not isinstance(item, dict):
                continue
            for key in ("username", "nickname", "nick", "name"):
                name = str(item.get(key) or "").strip()
                if name:
                    mention_names.append(name)
        raw_mentions = (context.raw_payload or {}).get("mentions") if context.raw_payload else None
        if isinstance(raw_mentions, (list, tuple)):
            for item in raw_mentions:
                if isinstance(item, dict):
                    for key in ("username", "nickname", "nick", "name"):
                        name = str(item.get(key) or "").strip()
                        if name:
                            mention_names.append(name)
        text = " ".join(item for item in normalized if item)
        for name in sorted(set(mention_names), key=len, reverse=True):
            text = re.sub(
                rf"(?<!\S)[@＠]\s*{re.escape(name)}(?=\s|$|[？?！!。，,、；;：:）)])",
                " ",
                text,
                flags=re.IGNORECASE,
            )
        text = re.sub(r"<qqbot-at-user\b[^>]*/>|<@!?[^>]+>|\[CQ:at,qq=[^\]]+\]", " ", text, flags=re.IGNORECASE)
        if context.mentions:
            parts = text.split()
            for index, item in enumerate(parts):
                if item.startswith(("@", "＠")):
                    parts = parts[:index]
                    break
            text = " ".join(parts)
        cleaned: list[str] = []
        for item in text.split():
            if re.fullmatch(r"[@＠][\w\-\u4e00-\u9fff]+[？?！!。，,、；;：:）)]*", item):
                continue
            if item:
                cleaned.append(item)
        return cleaned

    @classmethod
    def _has_image_attachment(cls, context: MessageContext) -> bool:
        if any(
            isinstance(item, dict)
            and str(item.get("url") or item.get("resource_url") or "").strip()
            and (
                str(item.get("content_type") or item.get("mime_type") or "").lower().startswith("image/")
                or not str(item.get("content_type") or item.get("mime_type") or "").strip()
            )
            for item in context.attachments
        ):
            return True
        raw = context.raw_payload or {}

        def visit(value: object, depth: int = 0, attachment_context: bool = False) -> bool:
            if depth > 8:
                return False
            if isinstance(value, dict):
                url = str(value.get("url") or value.get("resource_url") or value.get("content") or "").strip()
                content_type = str(value.get("content_type") or value.get("mime_type") or "").lower()
                if url and (
                    content_type.startswith("image/")
                    or (attachment_context and not content_type)
                ):
                    return True
                return any(
                    visit(item, depth + 1, attachment_context or key in {"attachments", "image", "images"})
                    for key, item in value.items()
                )
            if isinstance(value, (list, tuple)):
                return any(visit(item, depth + 1, attachment_context) for item in value)
            return False

        return visit(raw)

    @classmethod
    def _command_args_without_attachments(
        cls, context: MessageContext, args: list[str]
    ) -> list[str]:
        raw = cls._strip_attachment_markers(context.text)
        match = re.match(r"^\s*/\S+(?:\s+(.*))?\s*$", raw, flags=re.DOTALL)
        if match:
            tail = str(match.group(1) or "").strip()
            return [item for item in tail.split() if not cls._is_attachment_marker(item)] if tail else []
        return [
            cleaned
            for item in args
            if str(item or "").strip()
            and not cls._is_attachment_marker(item)
            for cleaned in [cls._strip_attachment_markers(item)]
            if cleaned
        ]

    # ---------------- 卡片 ----------------
    def _menu_card(self, page: int = 1) -> Card:
        keys = self.enabled_meme_keys()
        total_pages = max(1, (len(keys) + MENU_PAGE_SIZE - 1) // MENU_PAGE_SIZE)
        page = max(1, min(int(page or 1), total_pages))
        rows = []
        paged_keys = keys[(page - 1) * MENU_PAGE_SIZE : page * MENU_PAGE_SIZE]
        for key in paged_keys:
            try:
                info = _module().get_meme(key).info
                chinese = "、".join(str(x) for x in (getattr(info, "keywords", None) or [])) or key
                params = info.params
                image_hint = f"{int(params.min_images)}-{int(params.max_images)}"
                text_min, text_max = self._effective_text_bounds(key, params)
                text_hint = f"{text_min}-{text_max}"
            except Exception:
                chinese, image_hint, text_hint = key, "?", "?"
            index = (page - 1) * MENU_PAGE_SIZE + len(rows) + 1
            rows.append(f"| {index} | {chinese[:18]} | `{key}` | {image_hint} | {text_hint} |")
        markdown = (
            f"## 表情包 / Meme · 第 {page}/{total_pages} 页\n\n"
            "| # | 中文名称 | English key | 图片 Images | 文字 Texts |\n|---:|---|---|---:|---:|\n"
            + "\n".join(rows)
            + "\n\n发送 `/meme <English key或中文名称> 文字...` 使用模板。图片数量为 0 时会直接使用文字。"
        )
        nav_row: list[Button] = []
        if page > 1:
            nav_row.append(Button("上一页", f"/meme list {page - 1}", action_type=1, expires_after_seconds=300))
        nav_row.append(Button("跳页", "/meme list ", action_type=2, enter=False, expires_after_seconds=300))
        if page < total_pages:
            nav_row.append(Button("下一页", f"/meme list {page + 1}", action_type=1, expires_after_seconds=300))
        action_row = [
            Button("🔍 搜索表情", "/meme search ", action_type=2, enter=False, expires_after_seconds=300),
            Button("🏠 首页", "/meme list 1", action_type=1, expires_after_seconds=300),
        ]
        button_rows = [nav_row, action_row] if nav_row else [action_row]
        return Card("表情包 / Meme", markdown, button_rows, message_type="markdown")

    def search_memes(self, query: str) -> list[dict[str, object]]:
        query_raw = str(query or "").strip()
        if not query_raw or not _available():
            return []
        query_fold = query_raw.casefold()
        query_norm = self._normalize_template_name(query_raw)

        disabled = self._disabled_memes()
        enabled_keys = [k for k in self.meme_keys() if k not in disabled]
        alias_map = self._alias_map()
        reverse_aliases: dict[str, list[str]] = {}
        for alias, key in alias_map.items():
            reverse_aliases.setdefault(key, []).append(alias)

        results: list[dict[str, object]] = []
        module = _module()
        for key in enabled_keys:
            try:
                info = module.get_meme(key).info
                params = info.params
                keywords = [str(x) for x in (getattr(info, "keywords", None) or [])]
                tags = [str(x) for x in (getattr(info, "tags", None) or [])]
                shortcuts = [str(x) for x in (getattr(info, "shortcuts", None) or [])]
                name = str(getattr(info, "name", "") or "")
                title = str(getattr(info, "title", "") or "")
                aliases = reverse_aliases.get(key, [])
                image_min = int(getattr(params, "min_images", 0))
                image_max = int(getattr(params, "max_images", 0))
                text_min, text_max = self._effective_text_bounds(key, params)
            except Exception:
                keywords, tags, shortcuts, name, title, aliases = [], [], [], "", "", []
                image_min, image_max, text_min, text_max = 0, 0, 0, 0

            candidates = [key, *keywords, *aliases, *tags, *shortcuts, name, title]
            candidates = [c for c in candidates if c]

            best_score = 0
            for cand in candidates:
                cand_fold = cand.casefold()
                cand_norm = self._normalize_template_name(cand)
                if query_fold == cand_fold or (query_norm and query_norm == cand_norm):
                    score = 100
                elif cand_fold.startswith(query_fold) or (query_norm and cand_norm.startswith(query_norm)):
                    score = 85
                elif query_fold in cand_fold or (query_norm and query_norm in cand_norm):
                    score = 70
                elif any(token in cand_fold for token in query_fold.split() if token):
                    score = 50
                else:
                    ratio = difflib.SequenceMatcher(None, query_fold, cand_fold).ratio()
                    score = int(ratio * 60) if ratio >= 0.6 else 0
                if score > best_score:
                    best_score = score

            if best_score > 0:
                chinese_display = "、".join(keywords[:3]) if keywords else (aliases[0] if aliases else key)
                results.append({
                    "key": key,
                    "score": best_score,
                    "chinese": chinese_display,
                    "keywords": keywords,
                    "tags": tags,
                    "aliases": aliases,
                    "image_hint": f"{image_min}-{image_max}",
                    "text_hint": f"{text_min}-{text_max}",
                })

        results.sort(key=lambda item: (-int(item["score"]), str(item["key"])))
        return results

    def _search_card(self, keyword: str, page: int = 1) -> Card:
        results = self.search_memes(keyword)
        if not results:
            nav = [
                Button("🔍 换词搜索", "/meme search ", action_type=2, enter=False, style="primary", expires_after_seconds=300),
                Button("📖 全部表情", "/meme list 1", action_type=1, expires_after_seconds=300),
            ]
            return Card(
                "表情包搜索 / Search",
                f"## 🔍 表情包搜索 · “{html.escape(keyword)}”\n\n未找到与 **{html.escape(keyword)}** 相关的表情包模板。\n\n"
                f"💡 **搜索提示**：\n- 可以尝试输入更简短的核心词（例如：“摸”、“猫”、“问”、“哭”）；\n- 或发送 `/meme list` 浏览全部可用表情列表。",
                [nav],
                message_type="markdown",
            )

        total_items = len(results)
        total_pages = max(1, (total_items + MENU_PAGE_SIZE - 1) // MENU_PAGE_SIZE)
        page = max(1, min(int(page or 1), total_pages))
        paged_items = results[(page - 1) * MENU_PAGE_SIZE : page * MENU_PAGE_SIZE]

        rows = []
        for idx, item in enumerate(paged_items):
            item_num = (page - 1) * MENU_PAGE_SIZE + idx + 1
            rows.append(
                f"| {item_num} | {str(item['chinese'])[:18]} | `{item['key']}` | {item['image_hint']} | {item['text_hint']} |"
            )

        markdown = (
            f"## 🔍 表情包搜索 · “{html.escape(keyword)}”\n\n"
            f"共找到 **{total_items}** 个相关模板（第 {page}/{total_pages} 页）：\n\n"
            "| # | 中文名称 | English key | 图片 Images | 文字 Texts |\n|---:|---|---|---:|---:|\n"
            + "\n".join(rows)
            + "\n\n💡 发送 `/meme <名称> 文字...` 生成表情包。点击下方按钮可直接回填指令。"
        )

        quick_buttons: list[Button] = []
        for item in paged_items[:3]:
            keywords_list = item.get("keywords")
            disp = (keywords_list[0] if isinstance(keywords_list, list) and keywords_list else str(item["key"]))[:6]
            quick_buttons.append(
                Button(f"✨ 使用{disp}", f"/meme {item['key']} ", action_type=2, enter=False, expires_after_seconds=300)
            )

        nav_row: list[Button] = []
        if page > 1:
            nav_row.append(
                Button("上一页", f"/meme search {keyword} {page - 1}", action_type=1, expires_after_seconds=300)
            )
        nav_row.append(
            Button("跳页", f"/meme search {keyword} ", action_type=2, enter=False, expires_after_seconds=300)
        )
        if page < total_pages:
            nav_row.append(
                Button("下一页", f"/meme search {keyword} {page + 1}", action_type=1, expires_after_seconds=300)
            )

        action_row = [
            Button("🔍 搜索", "/meme search ", action_type=2, enter=False, expires_after_seconds=300),
            Button("📖 全部表情", "/meme list 1", action_type=1, expires_after_seconds=300),
        ]

        button_rows = []
        if quick_buttons:
            button_rows.append(quick_buttons[:2])
            if len(quick_buttons) > 2:
                button_rows.append(quick_buttons[2:])
        if nav_row:
            button_rows.append(nav_row)
        if action_row:
            button_rows.append(action_row)

        return Card(
            f"表情包搜索 / {keyword}",
            markdown,
            button_rows,
            message_type="markdown",
        )

    def meme_catalog(self, query: str = "") -> list[dict[str, object]]:
        query_text = str(query or "").strip().casefold()
        disabled = self._disabled_memes()
        aliases = self._alias_map()
        reverse_aliases: dict[str, list[str]] = {}
        for alias, key in aliases.items():
            reverse_aliases.setdefault(key, []).append(alias)
        items: list[dict[str, object]] = []
        if not _available():
            return items
        module = _module()
        for key in self.meme_keys():
            try:
                info = module.get_meme(key).info
                params = info.params
                keywords = [str(item) for item in (getattr(info, "keywords", None) or [])]
                tags = [str(item) for item in (getattr(info, "tags", None) or [])]
                item = {
                    "key": key,
                    "enabled": key not in disabled,
                    "aliases": sorted(reverse_aliases.get(key, [])),
                    "keywords": keywords[:20],
                    "tags": tags[:20],
                    "min_images": int(getattr(params, "min_images", 0)),
                    "max_images": int(getattr(params, "max_images", 0)),
                    "min_texts": self._effective_text_bounds(key, params)[0],
                    "max_texts": self._effective_text_bounds(key, params)[1],
                    "text_is_image_name": (
                        int(getattr(params, "max_texts", 0)) == 0
                        and key in OPTIONAL_IMAGE_NAME_MEMES
                    ),
                    "preview_url": f"/api/meme/page/preview/{key}",
                }
            except Exception as error:
                item = {
                    "key": key,
                    "enabled": key not in disabled,
                    "aliases": sorted(reverse_aliases.get(key, [])),
                    "preview_url": f"/api/meme/page/preview/{key}",
                    "error": str(error)[:120],
                }
            haystack = " ".join(
                str(item.get(field) or "") for field in ("key", "keywords", "tags", "aliases")
            ).casefold()
            if not query_text or query_text in haystack:
                items.append(item)
        return items

    # ---------------- 渲染与发送 ----------------
    async def command(self, context: MessageContext, args: list[str]) -> str | Card | None:
        args = self._command_args_without_attachments(context, args)
        if args and args[0].lower() in {"help", "帮助"}:
            return (
                "表情包指令：\n"
                "• /meme <表情名称> [文字...]：生成指定表情包\n"
                "• /meme list [页码]：查看表情包列表\n"
                "• /meme search <关键词> [页码]：模糊搜索表情模板\n"
                "• /meme jump：快速跳页\n"
                "💡 未附图时会自动尝试使用发送者或引用消息的头像。"
            )
        if not self._cfg("enabled"):
            return "表情包插件尚未启用，请在管理台开启 enabled 配置。"
        if not _available():
            return "当前环境未安装 meme-generator 依赖；请在控制台为本插件安装依赖（meme-generator）后重启插件。"
        if args and args[0].lower() in {"jump", "跳页"}:
            total_pages = max(1, (len(self.enabled_meme_keys()) + MENU_PAGE_SIZE - 1) // MENU_PAGE_SIZE)
            buttons = [
                [
                    Button("🔢 输入页码", "/meme list ", action_type=2, enter=False, style="primary", expires_after_seconds=300),
                    Button("🔍 搜索表情", "/meme search ", action_type=2, enter=False, expires_after_seconds=300),
                    Button("🏠 返回首页", "/meme list 1", action_type=1, expires_after_seconds=300),
                ]
            ]
            return Card(
                "表情包跳页 / Jump",
                f"## 📑 表情包快速跳页\n\n当前共有 **{total_pages}** 页表情模板（每页 {MENU_PAGE_SIZE} 个）。\n\n"
                f"点击下方按钮即可在输入框回填指令并输入页码，或直接发送：\n\n"
                f"> `/meme list <页码>` （例如：`/meme list 5`）\n"
                f"> `/meme search <关键词>` （例如：`/meme search 摸`）",
                buttons,
                message_type="markdown",
            )
        if args and args[0].lower() in {"search", "find", "搜索", "查询", "搜", "查"}:
            if len(args) < 2 or not str(args[1]).strip():
                return Card(
                    "表情包搜索 / Search",
                    "## 🔍 表情包模糊搜索\n\n请输入要搜索的表情包关键词。\n\n"
                    "💡 **使用示例**：\n• `/meme search 摸`\n• `/meme search 鲁迅`\n• `/meme search 猫 2`（查看第 2 页）",
                    [
                        [
                            Button("🔍 搜索表情", "/meme search ", action_type=2, enter=False, style="primary", expires_after_seconds=300),
                            Button("📖 全部表情", "/meme list 1", action_type=1, expires_after_seconds=300),
                        ]
                    ],
                    message_type="markdown",
                )
            keyword = str(args[1]).strip()
            page = 1
            if len(args) > 2:
                try:
                    page = int(args[2])
                except (TypeError, ValueError):
                    page = 1
            return self._search_card(keyword, page)
        if not args or args[0].lower() in {"list", "列表", "menu", "菜单"}:
            page = 1
            if len(args) > 1:
                arg_val = str(args[1]).strip()
                if arg_val.isdigit():
                    return self._menu_card(int(arg_val))
                search_page = 1
                if len(args) > 2 and str(args[2]).strip().isdigit():
                    search_page = int(args[2])
                return self._search_card(arg_val, search_page)
            return self._menu_card(page)
        key_arg, inline_mention = self._split_inline_mention(args[0])
        key = self.resolve_meme_key(key_arg)
        if key not in set(self.enabled_meme_keys()):
            matches = self.search_memes(key_arg)
            if matches:
                return self._search_card(key_arg, 1)
            return "该表情模板未启用或不存在，你可以发送 /meme search <关键词> 进行搜索，或发送 /meme list 查看全部表情。"
        text_args = ([inline_mention] if inline_mention else []) + args[1:]
        texts = self._clean_text_args(context, text_args)
        try:
            meme = _module().get_meme(key)
            params = meme.info.params
            text_min, text_max = self._effective_text_bounds(key, params)
            image_name = None
            if (
                key in OPTIONAL_IMAGE_NAME_MEMES
                and int(getattr(params, "max_texts", 0)) == 0
                and len(texts) == 1
            ):
                image_name, texts = texts[0], []
            if (
                int(getattr(params, "max_texts", 0)) == 0
                and key not in OPTIONAL_IMAGE_NAME_MEMES
                and texts
                and self._has_image_attachment(context)
            ):
                texts = []
            with TemporaryDirectory(prefix="meme-input-", dir=str(self.data_dir)) as temp:
                images: list[Any] = []
                source = ""
                if int(params.max_images) > 0:
                    images, source = await self._input_images(context, Path(temp), image_name)
                required = int(params.min_images)
                if not required <= len(images) <= int(params.max_images):
                    raise ValueError(
                        f"表情 {key} 需要 {required}-{params.max_images} 张图片；未附图时会尝试使用头像（当前来源：{source or '无'}）"
                    )
                if not text_min <= len(texts) <= text_max:
                    raise ValueError(f"表情 {key} 需要 {text_min}-{text_max} 段文字")
                # 注意：沙箱 worker 内不要使用 asyncio.to_thread，它会在主进程的
                # 事件循环中调度；这里渲染已经在 worker 进程内，直接同步调用即可。
                with _silence_native_stdout():
                    output = meme.generate(images, texts, {})
            raw = self._output_bytes(output)
            if not raw:
                output_type = type(output).__name__
                if output_type == "ImageAssetMissing":
                    raise ValueError(f"模板 {key} 的图片素材尚未下载完成，请稍后重试；首次启用可能需要等待素材同步")
                # 诊断落盘：错误对象本身不携带信息（pyo3 无字段变体），把渲染
                # 上下文写入 data_dir 供通用 page-data 端点读取排查。
                try:
                    self.data_dir.mkdir(parents=True, exist_ok=True)
                    probe = {
                        "type": output_type,
                        "str": str(output)[:200],
                        "repr": repr(output)[:200],
                        "attrs": {
                            attr: str(getattr(output, attr, None))[:120]
                            for attr in ("args", "message", "kind", "code", "source")
                            if hasattr(output, attr)
                        },
                        "template": key,
                        "inputs": [
                            {"kind": source, "index": index}
                            for index, _ in enumerate(images)
                        ],
                    }
                    (self.data_dir / "debug_last_render.json").write_text(
                        json.dumps(probe, ensure_ascii=False, indent=2), encoding="utf-8"
                    )
                except Exception:
                    pass
                hints = {
                    "ImageEncodeError": "输出编码失败：通常是模板资源尚未就绪或输入图片异常，请重试一次或换一张图片",
                    "ImageDecodeError": "输入图片无法解码：QQ 可能下发了不支持的图片格式，请换一张图片重试",
                }
                hint = hints.get(output_type, "请检查模板资源或升级 Meme 依赖")
                raise ValueError(f"模板 {key} 返回了不可发送的结果（{output_type}）——{hint}")
        except Exception as error:
            return f"表情生成失败：{str(error)[:200]}"
        gateway = getattr(self.context, "qq", None)
        if not gateway:
            return "表情已生成，但 QQ 网关尚未连接。"
        output_dir = self.data_dir / re.sub(r"[^A-Za-z0-9_-]", "_", str(self._cfg("output_dir") or "meme"))
        output_dir.mkdir(parents=True, exist_ok=True)
        ext = self._detect_image_ext(raw)
        path = output_dir / f"{uuid.uuid4().hex}{ext}"
        path.write_bytes(raw)
        scene = context.scene or context.conversation_type
        if scene in {"channel", "guild_direct"}:
            send_channel = getattr(gateway, "send_channel_media", None)
            if callable(send_channel):
                try:
                    await send_channel(context.conversation_id, scene, file_image=raw)
                    return None
                except Exception as error:
                    path.unlink(missing_ok=True)
                    return f"表情发送失败：{str(error)[:200]}"
        try:
            media = getattr(self.context, "media", None)
            if media is None or not callable(getattr(media, "prepare", None)):
                return "表情已生成，但媒体服务尚未就绪。"
            request = await media.prepare(scene, context.conversation_id, 1, path)
            uploaded = await gateway.upload_media_file(request, path)
            file_info = str(uploaded.get("file_info") or "") if isinstance(uploaded, dict) else ""
            await gateway.send_media(context.conversation_id, scene, file_info)
            return None
        except Exception as error:
            path.unlink(missing_ok=True)
            return f"表情发送失败：{str(error)[:200]}"

    async def on_event(self, context: MessageContext) -> str | Card | None:
        if not self._cfg("enabled") or not self._cfg("allow_prefixless"):
            return None
        if not _available():
            return None
        text = str(context.text or "").strip()
        if not text or text.startswith("/"):
            return None

        disabled = self._disabled_memes()
        enabled_keys = set(k for k in self.meme_keys() if k not in disabled)
        if not enabled_keys:
            return None

        alias_map = self._alias_map()
        module = _module()

        triggers: list[tuple[str, str]] = []
        for key in enabled_keys:
            triggers.append((key, key))
            try:
                info = module.get_meme(key).info
                for kw in (getattr(info, "keywords", None) or []):
                    if kw and str(kw).strip():
                        triggers.append((str(kw).strip(), key))
                for sc in (getattr(info, "shortcuts", None) or []):
                    if sc and str(sc).strip():
                        triggers.append((str(sc).strip(), key))
                name = str(getattr(info, "name", "") or "").strip()
                if name:
                    triggers.append((name, key))
            except Exception:
                pass

        for alias, key in alias_map.items():
            if key in enabled_keys and alias:
                triggers.append((alias, key))

        triggers.sort(key=lambda t: len(t[0]), reverse=True)

        cleaned_text = self._strip_attachment_markers(text)
        cleaned_norm = self._normalize_template_name(cleaned_text)

        matched_key = None
        matched_args: list[str] = []

        for trigger, key in triggers:
            trigger_norm = self._normalize_template_name(trigger)
            if not trigger_norm:
                continue
            if cleaned_text.startswith(trigger) or (cleaned_norm and cleaned_norm.startswith(trigger_norm)):
                matched_key = key
                remainder = cleaned_text[len(trigger):].strip()
                matched_args = [key] + ([remainder] if remainder else [])
                break

        if not matched_key:
            for trigger, key in triggers:
                if len(trigger) < 2:
                    continue
                if trigger in cleaned_text:
                    pos = cleaned_text.find(trigger)
                    matched_key = key
                    remainder = cleaned_text[pos + len(trigger):].strip()
                    matched_args = [key] + ([remainder] if remainder else [])
                    break

        if not matched_key:
            return None

        try:
            return await self.command(context, matched_args)
        except Exception:
            return None


async def setup(context: Any) -> MemePlugin:
    plugin = MemePlugin(context)
    if hasattr(context, "register_command"):
        context.register_command("meme", plugin.command, category="media", description="MemeCrafters 表情包生成")
    if hasattr(context, "register_event_handler"):
        context.register_event_handler("*", plugin.on_event)
    if hasattr(context, "register_action"):
        context.register_action("save_config", plugin.on_page_action)
        context.register_action("page_data", plugin.on_page_action)
        context.register_action("set_template", plugin.on_page_action)
        context.register_action("template", plugin.on_page_action)
        context.register_action("preview", plugin.on_page_action)
        context.register_action("get_preview", plugin.on_page_action)
    plugin._start_resource_download()
    plugin._write_page_snapshot()
    logger.info("plugin.meme %s 已成功初始化加载", PLUGIN_VERSION)
    return plugin
