# plugin.meme 表情包

MemeCrafters/meme-generator 表情包外置插件（由内置 runtime.meme 移植）。

## 功能

- `/meme`：主指令。`/meme list [页码]` 模板列表（分页卡片）、`/meme search <关键词>` 模糊搜索、
  `/meme jump` 快速跳页、`/meme <名称> [文字...]` 生成表情包；
- 未附图时自动回退：附件图片 → 引用消息图片/头像 → @用户头像 → 发送者头像（qlogo）；
- 无前缀自然语言触发（`allow_prefixless` 配置，默认关闭）；
- 模板别名（`meme_aliases`）、模板停用（`disabled_memes`）配置化管理；
- 原生控制台：配置 + 模板统计 + 依赖状态看板（`type = "native"`）。

## 依赖安装

本插件依赖 `meme-generator`（Rust 渲染核心，自带 libfontconfig）。安装方式（二选一）：

1. **控制台插件私有依赖（推荐）**：管理台 → 系统与终端 → pip 安装，
   包名 `meme-generator`，目标插件填 `plugin.meme` —— 依赖落盘到本插件数据目录，
   沙箱 worker 自动加载；
2. 镜像预装：构建时 `INSTALL_MEME=true`。

中文字体渲染依赖镜像内的 `fontconfig` 与 `fonts-noto-cjk`（`INSTALL_MEME=true` 时自动安装）。

## 版本

- 0.1.0：自内置 runtime.meme 0.1.0 外置化移植。
