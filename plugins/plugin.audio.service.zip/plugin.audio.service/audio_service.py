"""Audio & TTS Generation Service Plugin (plugin.audio.service).

Provides text-to-speech, multi-voice selection, speech speed control,
credit billing, asynchronous audio delivery, task tracking, and active order inquiry for QQ Bot.
Supports OpenAI-compatible, Google Gemini Audio, Agnes, and Custom endpoints.
"""

from __future__ import annotations

import asyncio
import base64
import json
import logging
import math
import re
import ssl
import time
import uuid
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any

import aiohttp
import certifi

from runtime.models import Button, Card

try:
    from .credit_service import set_credit_service
except Exception:
    try:
        from credit_service import set_credit_service
    except Exception:
        def set_credit_service(s: Any) -> None:
            pass

logger = logging.getLogger("plugin.audio.service")

PLUGIN_VERSION = "0.4.1"


def _format_cst_time(ts: float | None = None) -> str:
    tz = timezone(timedelta(hours=8))
    dt = datetime.fromtimestamp(ts, tz=tz) if ts is not None else datetime.now(tz=tz)
    return dt.strftime("%Y-%m-%d %H:%M:%S")

GUIDE_TEXT = """🎙️ **视听服务 - 语音朗读指南**

1. **文本朗读**：发送 `/tts 要朗读的文本` 或 `/tts 10s 要朗读的文本`
   - 例：`/tts 10s 大家好，我是 567 机器人语音助手，很高兴认识大家！`
   - 支持显式指定秒数：`10s`、`10秒` 或 `-d 10`；未指定时自动根据字数推算时长！
2. **快捷控制台**：直接发送 `/tts`
   - 可一键切换音色（Alloy、Nova、Echo 等）、调节语速（0.8x~1.5x）和模型。
3. **音色选择与切换**：
   - 发送 `/tts voice` 查看当前音色列表与分页卡片
   - 发送 `/tts voice <标识或序号>` 快速设置默认音色
4. **模型选择与切换**：
   - 发送 `/tts models` 查看当前可用语音模型列表与分页卡片
   - 发送 `/tts model <名称或序号>` 快速切换默认模型
5. **订单查询与下载**：
   - 发送 `/tts status` 查看积分资产与最近 5 条朗读订单
   - 发送 `/tts status <订单号>` 查看单笔订单详细进展与状态
   - 发送 `/tts download <订单号>` 随时重听并下载生成的语音
6. **语速与格式**：
   - 发送 `/tts speed 1.2` 调整为 1.2 倍速
   - 发送 `/tts format mp3` 切换音频封装格式
"""

DEFAULT_VOICES = [
    {"id": "alloy", "name": "Alloy", "desc": "中性沉稳，适合新闻与日常讲解"},
    {"id": "nova", "name": "Nova", "desc": "清脆灵动，适合活泼欢快的对话"},
    {"id": "echo", "name": "Echo", "desc": "温和男声，适合播客与磁性旁白"},
    {"id": "fable", "name": "Fable", "desc": "英音叙述，适合故事绘本与典雅朗读"},
    {"id": "onyx", "name": "Onyx", "desc": "浑厚男声，充满威严与力量感"},
    {"id": "shimmer", "name": "Shimmer", "desc": "甜美明快，亲和力极强的高音女声"},
]

DEFAULT_AUDIO_MODELS = [
    "tts-1",
    "tts-1-hd",
    "gemini-2.0-flash",
    "eleven_monolingual_v1",
    "cosyvoice-v1",
]


def _btn(
    label: str,
    command: str,
    *,
    fill: bool = False,
    enter: bool = True,
    style: str = "normal",
    permission: int = 2,
    action_type: int | None = None,
) -> Button:
    clean_label = label.strip()[:10]
    if action_type is None:
        action_type = 2 if fill else 1
    return Button(
        label=clean_label,
        command=command,
        style="normal" if style not in {"normal", "primary", "danger", "success"} else style,  # type: ignore[arg-type]
        action_type=action_type,
        enter=enter if not fill else False,
        permission=permission,
        unsupport_tips="客户端版本过低，请升级后使用",
    )


def _extract_duration_param(speed: float, text: str) -> tuple[int, str]:
    raw = text.strip()
    if not raw:
        return 1, ""

    # Check for prefix duration: e.g. /tts 10s 文本 or /tts 10秒 文本 or /tts -d 10 文本
    m = re.match(r'^(?:-d|--dur|--duration)[=\s]+(\d+)(?:s|sec|秒)?\s*(.*)$', raw, re.IGNORECASE)
    if m:
        try:
            sec = int(m.group(1))
            if 1 <= sec <= 600:
                return sec, m.group(2).strip()
        except ValueError:
            pass

    m = re.match(r'^(\d+)\s*(?:s|sec|秒)\s+(.*)$', raw, re.IGNORECASE)
    if m:
        try:
            sec = int(m.group(1))
            if 1 <= sec <= 600:
                return sec, m.group(2).strip()
        except ValueError:
            pass

    # No explicit duration prefix: estimate based on text length and speed
    effective_speed = max(0.5, min(2.5, speed))
    char_count = len(raw)
    estimated_sec = max(1, math.ceil(char_count / (3.5 * effective_speed)))
    return estimated_sec, raw


def _normalize_scene(context: Any) -> str:
    raw = getattr(context, "scene", None) or getattr(context, "conversation_type", None) or "group"
    s = str(raw).lower().strip()
    if s in {"c2c", "private", "friend", "user", "dm", "c2c_message_create"}:
        return "c2c"
    if s in {"channel", "guild", "guild_direct"}:
        return "channel"
    return "group"


def _format_error_msg(err_str: str) -> str:
    s = str(err_str or "")
    if "connection reset by peer" in s.lower() or "connection closed" in s.lower():
        return "上游语音服务连接意外重置，请稍后重试。"
    if "eof" in s.lower():
        return "上游语音服务连接意外中断 (EOF)，请稍后重试。"
    if "timeout" in s.lower() or "timed out" in s.lower():
        return "语音合成超时，请缩短朗读文本后重试。"
    if "quota" in s.lower() or "balance" in s.lower():
        return "语音服务商账户额度不足，请联系管理员核查。"
    return s[:200]


class AudioServicePlugin:
    """Audio & TTS service plugin with dynamic models, customizable voices, and order tracking."""

    def __init__(self, context: Any) -> None:
        self.context = context
        self.data_dir = Path(getattr(context, "data_dir", None) or "./data/plugin-data/plugin.audio.service")
        self.data_dir.mkdir(parents=True, exist_ok=True)
        self.config_dir = Path(getattr(context, "config_dir", None) or "./data/plugin-config/plugin.audio.service")
        self.config_dir.mkdir(parents=True, exist_ok=True)
        self.config: dict[str, Any] = {}
        self.user_prefs: dict[str, dict[str, Any]] = {}
        self.user_credits: dict[str, float] = {}
        self.daily_usage: dict[str, int] = {}
        self.user_cooldowns: dict[str, float] = {}
        self.tasks: dict[str, dict[str, Any]] = {}
        self.cached_models: list[str] = []
        self.pending_pay_orders: dict[str, dict[str, Any]] = {}
        self.processed_orders: list[str] = []
        self._temp_dir = self.data_dir / "temp"
        self._temp_dir.mkdir(parents=True, exist_ok=True)
        self._load_config()
        self._load_data()
        set_credit_service(self)

        try:
            pay_api = getattr(self.context, "builtin", lambda name: None)("runtime.pay")
            if pay_api and hasattr(pay_api, "subscribe"):
                pay_api.subscribe("plugin.audio.service", self.on_payment_success)
        except Exception:
            pass

    # ---------- Persistence ----------

    def _load_config(self) -> None:
        cfg_file = self.config_dir / "config.json"
        if cfg_file.is_file():
            try:
                self.config = json.loads(cfg_file.read_text(encoding="utf-8"))
            except Exception:
                pass
        if not self.config:
            self.config = {
                "api_base_url": "",
                "api_key": "",
                "default_model": "tts-1",
                "provider_protocol": "openai",
                "default_voice": "alloy",
                "default_speed": 1.0,
                "default_audio_format": "mp3",
                "google_api_key": "",
                "google_api_base": "",
                "custom_endpoint": "/v1/audio/speech",
                "audio_credit_cost_per_sec": 0.2,
                "audio_credit_cost": 1.0,
                "credit_cost_rules": "tts-1:0.2;tts-1-hd:0.4",
                "credit_price_yuan": 0.1,
                "default_balance": 0.0,
                "enable_group": True,
                "cooldown_sec": 5,
                "max_prompt_chars": 1000,
                "request_timeout_sec": 60,
                "debug_log": False,
                "custom_voices": DEFAULT_VOICES,
                "page_admin_usernames": ["yeyu"],
            }
        else:
            if "credit_price_yuan" not in self.config:
                self.config["credit_price_yuan"] = 0.1
            if "default_balance" not in self.config:
                self.config["default_balance"] = 0.0

    def _save_config(self) -> None:
        cfg_file = self.config_dir / "config.json"
        try:
            cfg_file.write_text(json.dumps(self.config, ensure_ascii=False, indent=2), encoding="utf-8")
        except Exception:
            pass

    def _load_data(self) -> None:
        data_file = self.data_dir / "data.json"
        if data_file.is_file():
            try:
                data = json.loads(data_file.read_text(encoding="utf-8"))
                if isinstance(data, dict):
                    self.user_prefs = data.get("user_prefs", {})
                    self.user_credits = data.get("user_credits", {})
                    self.daily_usage = data.get("daily_usage", {})
                    self.tasks = data.get("tasks", {})
                    self.cached_models = data.get("cached_models", [])
                    self.pending_pay_orders = data.get("pending_pay_orders", {})
                    self.processed_orders = data.get("processed_orders", [])
            except Exception:
                pass

    def _save_data(self) -> None:
        data_file = self.data_dir / "data.json"
        if len(self.tasks) > 200:
            keys = sorted(self.tasks.keys(), key=lambda k: self.tasks[k].get("created_at", ""))
            for k in keys[:-200]:
                self.tasks.pop(k, None)
        try:
            data_file.write_text(json.dumps({
                "user_prefs": self.user_prefs,
                "user_credits": self.user_credits,
                "daily_usage": self.daily_usage,
                "tasks": self.tasks,
                "cached_models": self.cached_models,
                "pending_pay_orders": self.pending_pay_orders,
                "processed_orders": self.processed_orders,
            }, ensure_ascii=False, indent=2), encoding="utf-8")
        except Exception:
            pass

    def _ensure_user(self, user_key: str) -> None:
        if not user_key or user_key == "unknown":
            return
        dirty = False
        if user_key not in self.user_credits:
            self.user_credits[user_key] = float(self.config.get("default_balance", 0.0))
            dirty = True
        if user_key not in self.user_prefs:
            self.user_prefs[user_key] = {}
            dirty = True
        if dirty:
            self._save_data()

    # ---------- Available Voices & Models Helpers ----------

    def _get_available_voices(self) -> list[dict[str, str]]:
        custom = self.config.get("custom_voices")
        voices: list[dict[str, str]] = []
        if isinstance(custom, list):
            for item in custom:
                if isinstance(item, dict) and item.get("id"):
                    voices.append({
                        "id": str(item["id"]).strip(),
                        "name": str(item.get("name") or item["id"]).strip(),
                        "desc": str(item.get("desc") or "").strip(),
                    })
        elif isinstance(custom, str) and custom.strip():
            try:
                parsed = json.loads(custom)
                if isinstance(parsed, list):
                    for item in parsed:
                        if isinstance(item, dict) and item.get("id"):
                            voices.append({
                                "id": str(item["id"]).strip(),
                                "name": str(item.get("name") or item["id"]).strip(),
                                "desc": str(item.get("desc") or "").strip(),
                            })
            except Exception:
                pass
        if not voices:
            voices = list(DEFAULT_VOICES)
        return voices

    def _get_available_models(self) -> list[str]:
        # If models have been fetched from upstream API, strictly use only those genuine models
        if self.cached_models:
            return [m for m in self.cached_models if m]
        default_m = str(self.config.get("default_model") or "").strip()
        if default_m:
            return [default_m]
        return []

    # ---------- User Preference Helpers ----------

    def _get_user_key(self, context: Any) -> str:
        sender_id = str(getattr(context, "sender_id", "") or getattr(context, "user_id", "") or "unknown")
        return sender_id

    def _get_pref(self, user_key: str, key: str, default: Any) -> Any:
        return self.user_prefs.get(user_key, {}).get(key, self.config.get(key, default))

    def _set_pref(self, user_key: str, key: str, value: Any) -> None:
        self._ensure_user(user_key)
        if user_key not in self.user_prefs:
            self.user_prefs[user_key] = {}
        self.user_prefs[user_key][key] = value
        self._save_data()

    # ---------- Credit & Points ----------

    def _get_cost_for_model(self, model_name: str) -> float:
        rules_str = str(self.config.get("credit_cost_rules") or "").strip()
        for item in rules_str.split(";"):
            item = item.strip()
            if ":" in item:
                m, cost = item.split(":", 1)
                if m.strip().lower() == model_name.strip().lower():
                    try:
                        return float(cost.strip())
                    except ValueError:
                        pass
        val = self.config.get("audio_credit_cost_per_sec")
        if val is not None:
            try:
                return float(val)
            except ValueError:
                pass
        old = self.config.get("audio_credit_cost")
        if old is not None:
            try:
                return float(old) / 5.0
            except ValueError:
                pass
        return 0.2

    async def _deduct_credits(self, user_key: str, cost: float, reason: str = "朗读语音") -> bool:
        if cost <= 0:
            return True
        pay_api = getattr(self.context, "builtin", lambda name: None)("runtime.pay")
        if pay_api and hasattr(pay_api, "deduct_points"):
            try:
                res = await pay_api.deduct_points(user_key, cost, reason=reason)
                return bool(res)
            except Exception as e:
                logger.warning("runtime.pay deduct failed: %s", e)
        current = float(self.user_credits.get(user_key, self.config.get("default_balance", 0.0)))
        if current < cost:
            return False
        self.user_credits[user_key] = current - cost
        self._save_data()
        return True

    async def _refund_credits(self, user_key: str, cost: float, reason: str = "语音生成失败退还") -> None:
        if cost <= 0:
            return
        pay_api = getattr(self.context, "builtin", lambda name: None)("runtime.pay")
        if pay_api and hasattr(pay_api, "add_points"):
            try:
                await pay_api.add_points(user_key, cost, reason=reason)
                return
            except Exception as e:
                logger.warning("runtime.pay refund failed: %s", e)
        current = float(self.user_credits.get(user_key, 0.0))
        self.user_credits[user_key] = current + cost
        self._save_data()

    async def _add_credits(self, user_key: str, amount: float, reason: str = "充值增加") -> None:
        if amount <= 0:
            return
        pay_api = getattr(self.context, "builtin", lambda name: None)("runtime.pay")
        if pay_api and hasattr(pay_api, "add_points"):
            try:
                await pay_api.add_points(user_key, amount, reason=reason)
                return
            except Exception as e:
                logger.warning("runtime.pay add_points failed: %s", e)
        current = float(self.user_credits.get(user_key, self.config.get("default_balance", 0.0)))
        self.user_credits[user_key] = round(current + amount, 2)
        self._save_data()

    async def _get_balance(self, user_key: str) -> float:
        pay_api = getattr(self.context, "builtin", lambda name: None)("runtime.pay")
        if pay_api and hasattr(pay_api, "get_points"):
            try:
                pts = await pay_api.get_points(user_key)
                if pts is not None:
                    return float(pts)
            except Exception:
                pass
        return float(self.user_credits.get(user_key, self.config.get("default_balance", 0.0)))

    async def on_payment_success(self, intent: dict[str, Any]) -> None:
        if intent.get("local_status") != "paid":
            return
        user_id = str(intent.get("owner_key") or intent.get("user_id") or "")
        if not user_id:
            return
        points_minor = int(intent.get("points_minor") or 0)
        points = int(points_minor // 100) if points_minor else int(intent.get("points") or intent.get("point_count") or 0)
        if points <= 0:
            return

        order_id = str(intent.get("id") or intent.get("order_id") or "")
        if order_id:
            if order_id in self.processed_orders:
                return
            self.processed_orders.append(order_id)
            if len(self.processed_orders) > 2000:
                self.processed_orders = self.processed_orders[-1000:]
            if order_id in self.pending_pay_orders:
                self.pending_pay_orders.pop(order_id, None)

        cur = float(self.user_credits.get(user_id, self.config.get("default_balance", 0.0)))
        new_bal = round(cur + points, 2)
        self.user_credits[user_id] = new_bal
        self._save_data()
        logger.info("Audio Payment success for %s: +%d points, current balance %s", user_id, points, new_bal)

    # ---------- Command Dispatcher ----------

    async def handle_tts(self, context: Any, args: list[str]) -> str | Card:
        if not args:
            return await self._main_card(context)
        sub = args[0].lower()
        if sub in {"help", "帮助", "教程"}:
            return Card("使用教程", GUIDE_TEXT, rows=[
                [_btn("朗读文本", "/tts ", fill=True), _btn("切换音色", "/tts voice")],
                [_btn("语速调节", "/tts speed"), _btn("切换模型", "/tts models")],
                [_btn("积分充值", "/tts pay"), _btn("订单与余额", "/tts status")],
                [_btn("视频服务", "/vd"), _btn("返回主菜单", "/tts")],
            ][:5])
        if sub in {"pay", "充值", "buy"}:
            return await self._handle_pay(context, args[1:])
        if sub in {"rate", "cost", "单价", "计费", "价格", "pricing"}:
            return self._handle_rate(context, args[1:])
        if sub in {"voice", "voices", "音色", "声音"}:
            return self._handle_voice(context, args[1:])
        if sub in {"speed", "语速", "速度"}:
            return await self._handle_speed(context, args[1:])
        if sub in {"models", "模型", "模型列表"}:
            return self._handle_models(context, args[1:])
        if sub in {"model", "切模型", "切换模型"}:
            return self._handle_model(context, args[1:])
        if sub in {"format", "格式"}:
            return await self._handle_format(context, args[1:])
        if sub in {"status", "状态", "余额", "记录", "订单", "tasks", "task"}:
            return await self._handle_status(context, args[1:])
        if sub in {"download", "下载", "获取", "get"}:
            return await self._handle_download(context, args[1:])

        user_key = self._get_user_key(context)
        cur_speed = float(self._get_pref(user_key, "default_speed", 1.0))
        raw_text = " ".join(args).strip()
        dur, text = _extract_duration_param(cur_speed, raw_text)
        return await self._trigger_tts(context, text, duration=dur)

    # ---------- Card Views (Strictly <= 5 Rows & <= 10 Chars Labels) ----------

    async def _main_card(self, context: Any) -> Card:
        user_key = self._get_user_key(context)
        self._ensure_user(user_key)
        cur_bal = await self._get_balance(user_key)
        cur_voice = self._get_pref(user_key, "default_voice", self.config.get("default_voice", "alloy"))
        cur_speed = float(self._get_pref(user_key, "default_speed", 1.0))
        cur_model = self._get_pref(user_key, "default_model", self.config.get("default_model", "tts-1"))
        cur_fmt = self._get_pref(user_key, "default_audio_format", "mp3")
        cost_per_sec = self._get_cost_for_model(cur_model)

        voices = self._get_available_voices()
        v_name = cur_voice
        for v in voices:
            if v["id"].lower() == cur_voice.lower():
                v_name = v["name"]
                break

        md = (
            f"🎙️ **语音朗读控制台**\n"
            f"━━━━━━━━━━━━━━━━━━\n"
            f"• 账户余额：`{cur_bal:.1f}` 积分\n"
            f"• 当前模型：`{cur_model}`\n"
            f"• 当前音色：`{v_name}`\n"
            f"• 当前语速：`{cur_speed}x` | 格式：`{cur_fmt.upper()}`\n"
            f"• 计费标准：`{cost_per_sec:.2f}` 积分/秒 (按时长计费)\n\n"
            f"💡 支持携带秒数（如 `/tts 10s 文本`）或按字数推算！"
        )

        rows = [
            # Row 1: Voice & Speed
            [_btn("🎙️ 切换音色", "/tts voice"),
             _btn(f"⚡ 语速{cur_speed}x", "/tts speed")],
            # Row 2: Format & Model
            [_btn(f"🎼 格式{cur_fmt.upper()}", "/tts format"),
             _btn("🤖 切换模型", "/tts models")],
            # Row 3: Pay & Status
            [_btn("💳 充值积分", "/tts pay"),
             _btn("📜 订单与状态", "/tts status")],
            # Row 4: Switch to Video Service & Help
            [_btn("📖 使用教程", "/tts help"),
             _btn("🎬 视频服务", "/vd")],
            # Row 5: Call to action (<= 10 chars)
            [_btn("🔊 立即朗读", "/tts ", fill=True)],
        ]
        return Card("语音朗读控制台", md, rows=rows[:5])

    def _handle_voice(self, context: Any, args: list[str]) -> Card:
        user_key = self._get_user_key(context)
        voices = self._get_available_voices()
        cur = self._get_pref(user_key, "default_voice", self.config.get("default_voice", "alloy"))

        page = 1
        if args:
            raw = args[0].strip()
            if raw == "page" and len(args) > 1:
                try:
                    page = max(1, int(args[1]))
                except ValueError:
                    page = 1
            elif raw.isdigit():
                val = int(raw)
                # If matches voice index directly, switch!
                if 1 <= val <= len(voices):
                    chosen = voices[val - 1]["id"]
                    self._set_pref(user_key, "default_voice", chosen)
                    v_name = voices[val - 1]["name"]
                    return Card("音色切换成功", f"🎉 已将默认音色切换为：`{v_name}` (`{chosen}`)。\n发送 `/tts <文本>` 即可试听！", rows=[
                        [_btn("🔊 立即朗读", "/tts ", fill=True), _btn("音色列表", "/tts voice")],
                        [_btn("返回主菜单", "/tts")]
                    ][:5])
                else:
                    page = val
            else:
                # String matching voice id or name
                matched = None
                for v in voices:
                    if v["id"].lower() == raw.lower() or raw.lower() in v["name"].lower():
                        matched = v
                        break
                if matched:
                    self._set_pref(user_key, "default_voice", matched["id"])
                    return Card("音色切换成功", f"🎉 已将默认音色切换为：`{matched['name']}` (`{matched['id']}`)。\n发送 `/tts <文本>` 即可试听！", rows=[
                        [_btn("🔊 立即朗读", "/tts ", fill=True), _btn("音色列表", "/tts voice")],
                        [_btn("返回主菜单", "/tts")]
                    ][:5])

        per_page = 4
        total_pages = max(1, math.ceil(len(voices) / per_page))
        page = min(max(1, page), total_pages)
        start = (page - 1) * per_page
        current = voices[start:start + per_page]

        lines = [
            f"### 🎙️ 可选语音音色（第 {page}/{total_pages} 页，共 {len(voices)} 个）\n",
            "| # | 音色标识 | 名称与特色描述 | 状态 |",
            "|---|---|---|:---:|",
        ]
        for i, v in enumerate(current):
            idx = start + i + 1
            is_active = "✅ 已选" if v["id"].lower() == cur.lower() else "-"
            desc_clean = v.get("desc") or v.get("name") or "-"
            lines.append(f"| {idx} | `{v['id']}` | {v['name']} ({desc_clean[:10]}) | {is_active} |")
        lines.append(f"\n当前默认音色：`{cur}`")
        lines.append("点击下方按钮快捷切换，或发送 `/tts voice <标识或序号>`。")

        rows: list[list[Button]] = []
        row1 = []
        for i, v in enumerate(current[:2]):
            idx = start + i + 1
            lbl = f"✓ 音色{idx}" if v["id"].lower() == cur.lower() else f"音色{idx}"
            row1.append(_btn(lbl, f"/tts voice {v['id']}"))
        if row1:
            rows.append(row1)

        row2 = []
        for i, v in enumerate(current[2:4]):
            idx = start + i + 3
            lbl = f"✓ 音色{idx}" if v["id"].lower() == cur.lower() else f"音色{idx}"
            row2.append(_btn(lbl, f"/tts voice {v['id']}"))
        if row2:
            rows.append(row2)

        nav_row = []
        if page > 1:
            nav_row.append(_btn("◀ 上一页", f"/tts voice page {page - 1}"))
        nav_row.append(_btn("跳页", "/tts voice page ", fill=True))
        if page < total_pages:
            nav_row.append(_btn("下一页 ▶", f"/tts voice page {page + 1}"))
        if nav_row:
            rows.append(nav_row)

        rows.append([
            _btn("切换音色", "/tts voice ", fill=True),
            _btn("返回主菜单", "/tts"),
        ])
        return Card("可选语音音色", "\n".join(lines), rows=rows[:5])

    async def _handle_speed(self, context: Any, args: list[str]) -> Card:
        user_key = self._get_user_key(context)
        if args:
            try:
                sp = float(args[0])
                if 0.5 <= sp <= 2.0:
                    self._set_pref(user_key, "default_speed", sp)
                    return await self._main_card(context)
            except ValueError:
                pass
        cur = float(self._get_pref(user_key, "default_speed", 1.0))
        md = f"⚡ **朗读语速调节**\n当前语速：`{cur}x`\n点击下方按钮快速切换倍速："
        rows = [
            [_btn(f"{'✅ ' if cur == 0.8 else ''}0.8x 慢速", "/tts speed 0.8"),
             _btn(f"{'✅ ' if cur == 1.0 else ''}1.0x 正常", "/tts speed 1.0")],
            [_btn(f"{'✅ ' if cur == 1.25 else ''}1.25x 快速", "/tts speed 1.25"),
             _btn(f"{'✅ ' if cur == 1.5 else ''}1.5x 倍速", "/tts speed 1.5")],
            [_btn("🔙 返回主菜单", "/tts")],
        ]
        return Card("语速调节", md, rows=rows[:5])

    def _handle_models(self, context: Any, args: list[str]) -> Card:
        user_key = self._get_user_key(context)
        cur = self._get_pref(user_key, "default_model", self.config.get("default_model", "tts-1"))
        models = self._get_available_models()

        page = 1
        if args:
            try:
                page = max(1, int(args[0]))
            except ValueError:
                page = 1

        per_page = 4
        total_pages = max(1, math.ceil(len(models) / per_page))
        page = min(page, total_pages)
        start = (page - 1) * per_page
        current = models[start:start + per_page]

        lines = [
            f"### 🤖 可用语音模型（第 {page}/{total_pages} 页，共 {len(models)} 个）\n",
            "| # | 模型名称 | 每秒扣费 | 状态 |",
            "|---|---|---|:---:|",
        ]
        for i, m in enumerate(current):
            idx = start + i + 1
            cost = self._get_cost_for_model(m)
            is_active = "✅ 已选" if m.lower() == cur.lower() else "-"
            lines.append(f"| {idx} | `{m}` | {cost:.2f} 积分/秒 | {is_active} |")
        lines.append(f"\n当前默认模型：`{cur}`")
        lines.append("点击下方按钮切换，或发送 `/tts model <名称或序号>`。")

        rows: list[list[Button]] = []
        row1 = []
        for i, m in enumerate(current[:2]):
            idx = start + i + 1
            lbl = f"✓ 模型{idx}" if m.lower() == cur.lower() else f"模型{idx}"
            row1.append(_btn(lbl, f"/tts model {m}"))
        if row1:
            rows.append(row1)

        row2 = []
        for i, m in enumerate(current[2:4]):
            idx = start + i + 3
            lbl = f"✓ 模型{idx}" if m.lower() == cur.lower() else f"模型{idx}"
            row2.append(_btn(lbl, f"/tts model {m}"))
        if row2:
            rows.append(row2)

        nav_row = []
        if page > 1:
            nav_row.append(_btn("◀ 上一页", f"/tts models {page - 1}"))
        nav_row.append(_btn("跳页", "/tts models ", fill=True))
        if page < total_pages:
            nav_row.append(_btn("下一页 ▶", f"/tts models {page + 1}"))
        if nav_row:
            rows.append(nav_row)

        rows.append([
            _btn("切换模型", "/tts model ", fill=True),
            _btn("返回主菜单", "/tts"),
        ])
        return Card("可用语音模型", "\n".join(lines), rows=rows[:5])

    def _handle_model(self, context: Any, args: list[str]) -> Card:
        user_key = self._get_user_key(context)
        models = self._get_available_models()
        if args:
            raw = args[0].strip()
            chosen = None
            if raw.isdigit():
                idx = int(raw)
                if 1 <= idx <= len(models):
                    chosen = models[idx - 1]
            else:
                for m in models:
                    if m.lower() == raw.lower():
                        chosen = m
                        break
                if not chosen:
                    chosen = raw
            if chosen:
                self._set_pref(user_key, "default_model", chosen)
                cost = self._get_cost_for_model(chosen)
                return Card("模型切换成功", f"🎉 已将默认语音模型切换为：`{chosen}`\n计费标准：`{cost:.2f}` 积分/秒。\n发送 `/tts <文本>` 立即开始朗读！", rows=[
                    [_btn("🔊 立即朗读", "/tts ", fill=True), _btn("查看模型列表", "/tts models")],
                    [_btn("返回主菜单", "/tts")],
                ][:5])
        return self._handle_models(context, [])

    async def _handle_format(self, context: Any, args: list[str]) -> Card:
        user_key = self._get_user_key(context)
        if args:
            fmt = args[0].strip().lower()
            if fmt in {"mp3", "wav", "silk", "opus"}:
                self._set_pref(user_key, "default_audio_format", fmt)
                return await self._main_card(context)
        cur = self._get_pref(user_key, "default_audio_format", "mp3")
        md = f"🎼 **音频格式设置**\n当前格式：`{cur.upper()}`\nQQ 官方支持发送 MP3、WAV、SILK 等原生音频："
        rows = [
            [_btn(f"{'✅ ' if cur == 'mp3' else ''}MP3 推荐", "/tts format mp3"),
             _btn(f"{'✅ ' if cur == 'wav' else ''}WAV 无损", "/tts format wav")],
            [_btn(f"{'✅ ' if cur == 'silk' else ''}SILK 语音", "/tts format silk"),
             _btn("🔙 返回主菜单", "/tts")],
        ]
        return Card("音频格式设置", md, rows=rows[:5])

    async def _handle_status(self, context: Any, args: list[str] | None = None) -> Card:
        user_key = self._get_user_key(context)
        self._ensure_user(user_key)
        args = args or []
        if args:
            task_id = args[0].strip()
            task = self.tasks.get(task_id)
            if not task:
                for tid, t in self.tasks.items():
                    if tid.endswith(task_id) or task_id in tid:
                        task = t
                        task_id = tid
                        break
            if not task:
                return Card("订单查询", f"❌ 未找到订单号 `{task_id}` 的录音记录。请核对订单号后重试。", rows=[
                    [_btn("查询全部订单", "/tts status"), _btn("返回主菜单", "/tts")]
                ][:5])

            st = task.get("status", "processing")
            st_str = "⏳ 正在合成处理中..." if st == "processing" else ("✅ 已合成完成！" if st == "completed" else f"❌ 合成失败: {task.get('error', '未知错误')}")
            md = (
                f"📋 **订单详情：`{task_id}`**\n"
                f"━━━━━━━━━━━━━━━━━━\n"
                f"• 状态：{st_str}\n"
                f"• 模型：`{task.get('model', '-')}` | 音色：`{task.get('voice', '-')}`\n"
                f"• 语速：`{task.get('speed', 1.0)}x` | 扣费：`{task.get('cost', 0)}` 积分\n"
                f"• 耗时预估：`{task.get('duration', 1)}秒`\n"
                f"• 创建时间：`{task.get('created_at', '-')}`\n"
                f"• 朗读文本：{task.get('prompt', '-')[:120]}\n"
            )
            rows = []
            if task.get("status") == "completed" and task.get("audio_path"):
                rows.append([_btn("📥 重新收听", f"/tts download {task_id}")])
            rows.append([_btn("刷新本单", f"/tts status {task_id}"), _btn("全部订单", "/tts status")])
            rows.append([_btn("返回主菜单", "/tts")])
            return Card("订单详情", md, rows=rows[:5])

        # User status and recent 5 tasks
        credits = await self._get_balance(user_key)
        cur_model = self._get_pref(user_key, "default_model", self.config.get("default_model", "tts-1"))
        cur_voice = self._get_pref(user_key, "default_voice", "alloy")
        cur_speed = self._get_pref(user_key, "default_speed", 1.0)
        cost_per_sec = self._get_cost_for_model(cur_model)

        u_tasks = [t for t in self.tasks.values() if t.get("user_key") == user_key]
        recent_tasks = sorted(u_tasks, key=lambda t: t.get("created_at", ""), reverse=True)[:5]

        lines = [
            "👤 **用户语音资产与记录**\n",
            f"• 积分余额：`{credits:.1f}` 积分 | 单价：`{cost_per_sec:.2f}` 积分/秒",
            f"• 常用模型：`{cur_model}` | 音色：`{cur_voice}` ({cur_speed}x)\n",
        ]
        if recent_tasks:
            lines.append("### 📜 最近 5 笔朗读订单")
            lines.append("| 订单号 | 状态 | 耗时 | 朗读文本预览 |")
            lines.append("|---|:---:|---|---|")
            for t in recent_tasks:
                tid = t.get("task_id", "")
                st = "✅" if t.get("status") == "completed" else ("⏳" if t.get("status") == "processing" else "❌")
                dur = f"{t.get('duration', 1)}s"
                p_prev = t.get("prompt", "")[:10] + "..." if len(t.get("prompt", "")) > 10 else t.get("prompt", "")
                lines.append(f"| `{tid[-8:]}` | {st} | {dur} | {p_prev} |")
            lines.append("\n发送 `/tts status <订单号>` 查详情，或 `/tts download <订单号>` 重听音频。")
        else:
            lines.append("暂无朗读记录，发送 `/tts 要朗读的文字` 开启第一次朗读吧！")

        rows = [
            [_btn("🔊 朗读文本", "/tts ", fill=True), _btn("🎙️ 切换音色", "/tts voice")],
            [_btn("💳 充值积分", "/tts pay"), _btn("🤖 切换模型", "/tts models")],
            [_btn("查单帮助", "/tts status ", fill=True), _btn("返回主菜单", "/tts")],
        ]
        return Card("用户状态与记录", "\n".join(lines), rows=rows[:5])

    async def _handle_download(self, context: Any, args: list[str]) -> Card | str:
        if not args:
            return "用法：`/tts download <订单号>` 或 `/tts 下载 <订单号>`"
        task_id = args[0].strip()
        task = self.tasks.get(task_id)
        if not task:
            for tid, t in self.tasks.items():
                if tid.endswith(task_id) or task_id in tid:
                    task = t
                    task_id = tid
                    break
        if not task:
            return f"❌ 未找到订单号 `{task_id}` 的录音记录。"

        st = task.get("status")
        if st == "processing":
            return f"⏳ 订单 `{task_id}` 仍在此刻合成中，请稍后再试（可发送 `/tts status {task_id}` 刷新进度）。"
        if st != "completed":
            return f"❌ 订单 `{task_id}` 之前合成失败，无法下载: {task.get('error', '未知错误')}"

        path_str = task.get("audio_path")
        if not path_str or not Path(path_str).is_file():
            return f"⚠️ 订单 `{task_id}` 的本地音频缓存已过期。如需重听请重新发送 `/tts` 进行朗读。"

        send_ok, err = await self._send_qq_audio(context, Path(path_str))
        if not send_ok:
            return f"❌ 重新投递音频失败: {err}"
        return f"✅ 已成功为您重新投递订单 `{task_id}` 的语音音频！"

    async def _handle_pay(self, context: Any, args: list[str]) -> str | Card:
        user_id = self._get_user_key(context)
        self._ensure_user(user_id)
        rate_val = float(self.config.get("credit_price_yuan", 0.1))
        if not args:
            cur_bal = await self._get_balance(user_id)
            return Card(
                "充值积分",
                f"💳 **语音积分充值中心**\n"
                f"━━━━━━━━━━━━━━━━━━\n"
                f"• 当前账户积分：`{cur_bal:.1f}` 积分\n"
                f"• 充值比例：`1 积分 = ￥{rate_val:.2f} 元` (1元 = {int(1/rate_val) if rate_val > 0 else 10}积分)\n"
                f"• 到账时效：付款后系统自动秒级入账\n"
                f"• 支持渠道：微信支付 / 支付宝扫码\n\n"
                f"💡 点击下方常用面额快速创建订单，或发送 `/tts pay <积分数>` 自定义充值：",
                rows=[
                    [
                        _btn(f"充 10 积分 (¥{10 * rate_val:.1f})", "/tts pay 10", action_type=1, style="primary"),
                        _btn(f"充 50 积分 (¥{50 * rate_val:.1f})", "/tts pay 50", action_type=1),
                    ],
                    [
                        _btn(f"充 100 积分 (¥{100 * rate_val:.1f})", "/tts pay 100", action_type=1),
                        _btn("✏️ 自定义充值", "/tts pay ", fill=True),
                    ],
                    [
                        _btn("💰 查余额", "/tts status", action_type=1),
                        _btn("🔙 语音主菜单", "/tts", action_type=1),
                    ],
                ][:5]
            )

        sub = args[0].lower()
        if sub in {"link", "qr", "qrcode", "二维码"}:
            order_id = args[1].strip() if len(args) > 1 else ""
            if not order_id:
                for oid, info in reversed(list(self.pending_pay_orders.items())):
                    if info.get("user_id") == user_id:
                        order_id = oid
                        break
            if not order_id:
                pay_api = getattr(self.context, "builtin", lambda name: None)("runtime.pay")
                if pay_api and hasattr(pay_api, "get_latest_intent"):
                    try:
                        latest = await pay_api.get_latest_intent(user_id)
                        if latest and latest.get("local_status") in {"pending", "creating"}:
                            order_id = str(latest.get("id") or latest.get("trade_no") or "")
                    except Exception:
                        pass
            if not order_id:
                return Card("支付二维码", "未找到待支付的订单。您可以发送 `/tts pay 10` 创建新的充值订单。")

            pay_url = ""
            if order_id in self.pending_pay_orders:
                pay_url = self.pending_pay_orders[order_id].get("pay_url", "")
            if not pay_url:
                pay_api = getattr(self.context, "builtin", lambda name: None)("runtime.pay")
                if pay_api and hasattr(pay_api, "query_payment"):
                    try:
                        qres = await pay_api.query_payment(order_id)
                        pay_url = qres.get("pay_info") or qres.get("pay_url") or qres.get("qrcode") or ""
                    except Exception:
                        pass
            if not pay_url:
                return Card("支付二维码", f"订单 `{order_id}` 未找到有效的支付链接，或订单已过期。")

            row1 = []
            if pay_url and pay_url.startswith(("http://", "https://")):
                row1.append(_btn("💳 立即跳转付款", pay_url, action_type=0, style="primary"))
            row1.append(_btn("🔍 查询订单", f"/tts pay check {order_id}", action_type=1))
            return Card(
                "支付链接",
                f"📱 **支付链接已获取**\n"
                f"━━━━━━━━━━━━━━━━━━\n"
                f"• 订单号：`{order_id}`\n\n"
                f"👉 [点击打开支付页面付款]({pay_url})\n\n"
                f"✨ 付款完成后系统将自动秒级入账，亦可点击下方【🔍 查询订单】主动查验。",
                rows=[
                    row1,
                    [_btn("💰 查余额", "/tts status", action_type=1), _btn("🔙 语音主菜单", "/tts", action_type=1)],
                ][:5]
            )

        if sub in {"check", "order", "status", "query", "查询"}:
            order_id = args[1].strip() if len(args) > 1 else ""
            if not order_id:
                for oid, info in reversed(list(self.pending_pay_orders.items())):
                    if info.get("user_id") == user_id:
                        order_id = oid
                        break
            if not order_id:
                return Card("查询订单", "未指定订单号，且未找到最近的未完成订单。您可以发送 `/tts pay 10` 创建新的充值订单。")

            pay_api = getattr(self.context, "builtin", lambda name: None)("runtime.pay")
            if not pay_api or not hasattr(pay_api, "query_payment"):
                return Card("查询订单", "支付查询服务未就绪。")

            try:
                res = await asyncio.wait_for(pay_api.query_payment(order_id), timeout=5.0)
                status = str(res.get("local_status") or "")
                if status == "paid":
                    await self.on_payment_success(res)
                    self.pending_pay_orders.pop(order_id, None)
                    self._save_data()
                    bal = await self._get_balance(user_id)
                    return Card(
                        "订单已支付",
                        f"✅ **充值支付成功**\n\n"
                        f"订单号 `{order_id}` 已成功到账！\n"
                        f"• 当前总积分余额：**{bal:.1f}** 积分\n\n"
                        f"🎙️ 祝您体验愉快，发送 `/tts <文本>` 立即开始语音朗读！",
                        rows=[
                            [_btn("🔊 朗读文本", "/tts ", fill=True), _btn("🎙️ 切换音色", "/tts voice")],
                            [_btn("💰 查余额", "/tts status"), _btn("🔙 返回主菜单", "/tts")],
                        ][:5]
                    )
                status_text = "待支付" if status in {"pending", "creating"} else status
                row1 = []
                pay_url = (self.pending_pay_orders.get(order_id) or {}).get("pay_url", "")
                if not pay_url:
                    pay_url = res.get("pay_info") or res.get("pay_url") or res.get("qrcode") or ""
                if pay_url and pay_url.startswith(("http://", "https://")):
                    row1.append(_btn("💳 立即跳转付款", pay_url, action_type=0, style="primary"))
                row1.append(_btn("🔍 刷新订单", f"/tts pay check {order_id}", action_type=1))
                return Card(
                    "订单待支付",
                    f"⏳ **订单待支付中**\n\n"
                    f"• 订单编号：`{order_id}`\n"
                    f"• 当前状态：**{status_text}**\n\n"
                    f"若您已付款，请稍候 2~3 秒后点击【🔍 刷新订单】自动对账；若未完成付款，请点击【💳 立即跳转付款】。",
                    rows=[
                        row1,
                        [_btn("💰 查余额", "/tts status", action_type=1), _btn("🔙 语音主菜单", "/tts", action_type=1)],
                    ][:5]
                )
            except Exception as e:
                return Card("查询订单", f"查询订单 `{order_id}` 失败：{e}")

        try:
            points = int(args[0])
            if points <= 0 or points > 100000:
                return "充值积分数量需在 1 ~ 100,000 之间。"
        except ValueError:
            return "充值指令格式：`/tts pay <积分数>`，例如 `/tts pay 10`"

        yuan_amount = round(points * rate_val, 2)
        if yuan_amount < 0.01:
            yuan_amount = 0.01

        pay_api = getattr(self.context, "builtin", lambda name: None)("runtime.pay")
        if not pay_api or not hasattr(pay_api, "create_payment"):
            return "⚠️ 支付模块不可用或未启用，请联系管理员配置。"

        try:
            ext_id = f"audio_{user_id}_{int(time.time())}_{uuid.uuid4().hex[:8]}"
            order_info = await asyncio.wait_for(
                pay_api.create_payment(
                    source_plugin="plugin.audio.service",
                    external_id=ext_id,
                    owner_key=user_id,
                    subject=f"语音服务积分充值 - {points} 积分",
                    amount=str(yuan_amount),
                    points=str(points),
                    point_type="audio",
                    user_id=user_id,
                    amount_yuan=yuan_amount,
                    point_count=points,
                    description=f"语音服务积分充值 - {points} 积分",
                ),
                timeout=8.0,
            )
            qrcode_url = order_info.get("qrcode") or ""
            order_id = str(order_info.get("order_id") or order_info.get("trade_no") or order_info.get("id") or "")
            real_amount = order_info.get("amount") or str(yuan_amount)
            pay_url = order_info.get("pay_url") or order_info.get("url") or order_info.get("pay_info") or qrcode_url

            if order_id and order_id != "-":
                self.pending_pay_orders[order_id] = {
                    "user_id": user_id,
                    "points": points,
                    "time": time.time(),
                    "pay_url": pay_url,
                }
                self._save_data()

            markdown = (
                f"💳 **语音积分充值订单**\n"
                f"━━━━━━━━━━━━━━━━━━\n"
                f"• 充值数量：`{points}` 积分\n"
                f"• 应付金额：`￥{real_amount}` 元\n"
                f"• 订单号：`{order_id}`\n"
                f"• 订单状态：⏳ **待支付**\n\n"
                f"👉 请点击下方【💳 立即跳转付款】进入收银台完成支付；\n"
                f"✨ 付款完成后系统将秒级自动充值到账！"
            )
            row1 = []
            if pay_url and pay_url.startswith(("http://", "https://")):
                row1.append(_btn("💳 立即跳转付款", pay_url, action_type=0, style="primary"))
            row1.append(_btn("🔍 查询订单", f"/tts pay check {order_id}", action_type=1))
            return Card("积分充值", markdown, rows=[
                row1,
                [_btn("💰 查余额", "/tts status", action_type=1), _btn("🔙 返回主菜单", "/tts", action_type=1)],
            ][:5])
        except Exception as exc:
            return Card("积分充值", f"创建充值订单失败：{exc}")

    def _handle_rate(self, context: Any, args: list[str]) -> Card:
        rate_val = float(self.config.get("credit_price_yuan", 0.1))
        default_m = self.config.get("default_model", "tts-1")
        models = self._get_available_models()
        if not models:
            models = [default_m]

        lines = [
            "🎙️ **语音服务模型单价与计费规则**",
            "━━━━━━━━━━━━━━━━━━",
            f"• 积分充值比例：`1 积分 = ￥{rate_val:.2f} 元`",
            "• 计费模式：按语音预估时长（秒数）计费\n",
            "📊 **当前可用模型单价**：",
        ]
        for m in models:
            cost = self._get_cost_for_model(m)
            lines.append(f"• `{m}`：`{cost:.2f}` 积分/秒 (5s约 `{cost*5:.1f}` 分 / 10s约 `{cost*10:.1f}` 分)")

        lines.append("\n💡 发送 `/tts pay <积分数>` 即可在线充值积分！")
        return Card(
            "计费与单价规则",
            "\n".join(lines),
            rows=[
                [_btn("💳 立即充值", "/tts pay", action_type=1, style="primary"), _btn("🤖 切换模型", "/tts models", action_type=1)],
                [_btn("🔙 返回主菜单", "/tts", action_type=1)],
            ][:5]
        )

    # ---------- TTS Pipeline ----------

    async def _trigger_tts(self, context: Any, text: str, duration: int = 1) -> str | Card:
        if not text:
            return "❌ 朗读文本不能为空，请输入如：`/tts 10s 你好，我是机器人助手`"
        if len(text) > int(self.config.get("max_prompt_chars", 1000)):
            return f"❌ 朗读文本过长（上限 {self.config.get('max_prompt_chars')} 字）"

        user_key = self._get_user_key(context)
        self._ensure_user(user_key)

        # Cooldown check
        now = time.time()
        cd = int(self.config.get("cooldown_sec", 5))
        last_time = self.user_cooldowns.get(user_key, 0)
        if now - last_time < cd:
            return f"⏳ 操作太频繁，请等待 {int(cd - (now - last_time))} 秒后再试。"

        model = self._get_pref(user_key, "default_model", self.config.get("default_model", "tts-1"))
        voice = self._get_pref(user_key, "default_voice", self.config.get("default_voice", "alloy"))
        speed = float(self._get_pref(user_key, "default_speed", 1.0))
        cost_per_sec = self._get_cost_for_model(model)
        total_cost = round(duration * cost_per_sec, 2)

        ok = await self._deduct_credits(user_key, total_cost, reason=f"朗读语音({model},{duration}s)")
        if not ok:
            cur_bal = await self._get_balance(user_key)
            yuan_rate = float(self.config.get("credit_price_yuan", 0.1))
            needed_pts = max(0.0, total_cost - cur_bal)
            needed_yuan = round(needed_pts * yuan_rate, 2)
            md = (
                f"⚠️ **积分余额不足**\n"
                f"━━━━━━━━━━━━━━━━━━\n"
                f"• 当前余额：`{cur_bal:.1f}` 积分\n"
                f"• 本次所需：`{total_cost:.2f}` 积分（缺口 `{needed_pts:.2f}` 积分，约 `{needed_yuan:.2f}` 元）\n\n"
                f"💡 请点击下方常用面额快速充值，或发送 `/tts pay <积分数>` 自定义充值！"
            )
            rows = [
                [_btn(f"充 10 积分 (¥{10 * yuan_rate:.1f})", "/tts pay 10", action_type=1, style="primary"),
                 _btn(f"充 50 积分 (¥{50 * yuan_rate:.1f})", "/tts pay 50", action_type=1)],
                [_btn(f"充 100 积分 (¥{100 * yuan_rate:.1f})", "/tts pay 100", action_type=1),
                 _btn("✏️ 自定义充值", "/tts pay ", fill=True)],
                [_btn("🔙 返回主菜单", "/tts", action_type=1)],
            ]
            return Card("积分不足提示", md, rows[:5])

        self.user_cooldowns[user_key] = now

        task_id = f"a_{int(now)}_{uuid.uuid4().hex[:6]}"
        now_str = _format_cst_time()
        self.tasks[task_id] = {
            "task_id": task_id,
            "user_key": user_key,
            "prompt": text,
            "model": model,
            "voice": voice,
            "speed": speed,
            "duration": duration,
            "cost": total_cost,
            "status": "processing",
            "created_at": now_str,
            "error": None,
            "audio_path": None,
        }
        self._save_data()

        asyncio.create_task(self._run_async_tts_pipeline(context, task_id, text, model, voice, speed, total_cost))
        buttons = [
            [_btn("📊 查询进度", f"/tts status {task_id}"), _btn("📥 下载音频", f"/tts download {task_id}")],
            [_btn("📋 订单记录", "/tts 记录"), _btn("🎙️ 音色列表", "/tts voice")],
        ]
        return Card(
            "朗读任务已提交",
            f"🎙️ **任务已提交并开始合成**！\n"
            f"━━━━━━━━━━━━━━━━━━\n"
            f"• 订单编号：`{task_id}`\n"
            f"• 语音模型：`{model}` | 音色：`{voice}`\n"
            f"• 预估耗时：约 {duration} 秒 (消耗 {total_cost} 积分 [{cost_per_sec:.2f} 积分/秒])\n\n"
            f"合成完成后将自动投递。可随时发送 `/tts status {task_id}` 查询进度或 `/tts download {task_id}` 重听！",
            rows=buttons[:5],
        )

    async def _run_async_tts_pipeline(
        self, context: Any, task_id: str, text: str, model: str, voice: str, speed: float, cost: float
    ) -> None:
        user_key = self._get_user_key(context)
        audio_path: Path | None = None
        try:
            audio_bytes = await self._request_tts_audio(user_key, text, model, voice, speed)
            if not audio_bytes or len(audio_bytes) < 100:
                raise RuntimeError("未能从上游获取到有效的音频数据流")

            fmt = self._get_pref(user_key, "default_audio_format", "mp3")
            audio_path = self._temp_dir / f"{task_id}.{fmt}"
            audio_path.write_bytes(audio_bytes)

            self.tasks[task_id]["status"] = "completed"
            self.tasks[task_id]["audio_path"] = str(audio_path)
            self.tasks[task_id]["completed_at"] = _format_cst_time()
            self._save_data()

            send_ok, err = await self._send_qq_audio(context, audio_path)
            if not send_ok:
                raise RuntimeError(f"QQ 富媒体音频发送失败: {err}")

        except Exception as err:
            logger.error("TTS pipeline failed for %s: %s", task_id, err, exc_info=True)
            self.tasks[task_id]["status"] = "failed"
            self.tasks[task_id]["error"] = str(err)
            self._save_data()
            await self._refund_credits(user_key, cost, reason="语音合成失败退款")
            clean_err = _format_error_msg(str(err))
            await self._notify_error(context, f"🎙️ 订单 `{task_id}` 语音合成失败：{clean_err}\n已退还 {cost} 积分。")

    async def _request_tts_audio(self, user_key: str, text: str, model: str, voice: str, speed: float) -> bytes:
        protocol = str(self.config.get("provider_protocol", "openai")).lower()
        api_base = str(self.config.get("api_base_url") or "").rstrip("/")
        clean_base = api_base[:-3].rstrip("/") if api_base.endswith("/v1") else api_base
        api_key = str(self.config.get("api_key") or "").strip()
        fmt = self._get_pref(user_key, "default_audio_format", "mp3")

        ssl_ctx = ssl.create_default_context(cafile=certifi.where())
        connector = aiohttp.TCPConnector(ssl=ssl_ctx)
        timeout = aiohttp.ClientTimeout(total=int(self.config.get("request_timeout_sec", 60)))

        # 1. Google Gemini Native Audio Protocol
        if protocol == "google" or "gemini" in model.lower():
            g_key = str(self.config.get("google_api_key") or api_key).strip()
            g_base = str(self.config.get("google_api_base") or "https://generativelanguage.googleapis.com").rstrip("/")
            url = f"{g_base}/v1beta/models/{model}:generateContent?key={g_key}"
            payload = {
                "contents": [{"parts": [{"text": text}]}],
                "generationConfig": {
                    "responseModalities": ["AUDIO"],
                    "speechConfig": {
                        "voiceConfig": {
                            "prebuiltVoiceConfig": {"voiceName": voice}
                        }
                    }
                }
            }
            async with aiohttp.ClientSession(connector=connector, timeout=timeout) as session:
                async with session.post(url, json=payload) as resp:
                    if resp.status != 200:
                        t = await resp.text()
                        raise RuntimeError(f"Google Gemini 状态码异常 ({resp.status}): {t[:200]}")
                    res_json = await resp.json()
                    candidates = res_json.get("candidates", [])
                    if candidates:
                        parts = candidates[0].get("content", {}).get("parts", [])
                        for p in parts:
                            if "inlineData" in p and p["inlineData"].get("data"):
                                return base64.b64decode(p["inlineData"]["data"])
                    raise RuntimeError(f"未能解析 Google Gemini 返回的音频数据: {res_json}")

        # 2. OpenAI & Agnes & Custom Compatible Protocol (/v1/audio/speech)
        endpoint = f"{clean_base}/v1/audio/speech"
        if protocol == "custom":
            custom_ep = str(self.config.get("custom_endpoint") or "/v1/audio/speech")
            endpoint = f"{clean_base}{custom_ep}"

        headers = {
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
        }
        payload = {
            "model": model,
            "input": text,
            "voice": voice,
            "speed": speed,
            "response_format": fmt,
        }

        async with aiohttp.ClientSession(connector=connector, timeout=timeout) as session:
            async with session.post(endpoint, json=payload, headers=headers) as resp:
                if resp.status not in {200, 201}:
                    t = await resp.text()
                    raise RuntimeError(f"上游语音服务响应异常 ({resp.status}): {t[:200]}")
                return await resp.read()

    async def _send_qq_audio(self, context: Any, path: Path) -> tuple[bool, str]:
        source = Path(path)
        if not source.is_file():
            return False, f"本地音频文件不存在: {source}"
        scene = _normalize_scene(context)
        media = getattr(self.context, "media", None)
        qq = getattr(self.context, "qq", None)
        conv_id = (
            getattr(context, "conversation_id", "")
            or getattr(context, "group_id", "")
            or getattr(context, "sender_id", "")
        )
        if media is None or qq is None or not conv_id:
            return False, "QQ 媒体服务未就绪"

        try:
            msg_id = getattr(context, "message_id", None)
            if scene in {"c2c", "group"}:
                # Note: file_type = 3 for audio / voice!
                request = await media.prepare(scene, conv_id, 3, source)
                uploaded = await qq.upload_media_file(request, source)
                file_info = uploaded.get("file_info") if isinstance(uploaded, dict) else None
                if not file_info:
                    return False, f"上传音频接口未返回 file_info: {uploaded}"
                try:
                    if msg_id:
                        await qq.send_media(conv_id, scene, str(file_info), msg_id=msg_id)
                    else:
                        await qq.send_media(conv_id, scene, str(file_info))
                except Exception as e:
                    if msg_id:
                        logger.warning("Passive send_media audio failed (%s), fallback to active", e)
                        await qq.send_media(conv_id, scene, str(file_info))
                    else:
                        raise
                return True, ""
            return False, f"语音富媒体暂不支持当前场景: {scene}"
        except Exception as e:
            return False, str(e)

    async def _notify_error(self, context: Any, text: str) -> None:
        qq = getattr(self.context, "qq", None)
        conv_id = getattr(context, "conversation_id", "") or getattr(context, "group_id", "") or getattr(context, "sender_id", "")
        scene = _normalize_scene(context)
        msg_id = getattr(context, "message_id", None)
        if qq and conv_id:
            try:
                if scene == "c2c":
                    await qq.send_c2c_message(conv_id, text, msg_id=msg_id)
                elif scene == "group":
                    await qq.send_group_message(conv_id, text, msg_id=msg_id)
            except Exception as e:
                logger.warning("Notify error message failed: %s", e)

    # ---------- Scheduled Tasks ----------

    def cleanup(self) -> None:
        now = time.time()
        # Keep files for 24 hours so users can re-download anytime
        for f in self._temp_dir.glob("*"):
            try:
                if now - f.stat().st_mtime > 86400:
                    f.unlink()
            except Exception:
                pass

    async def _async_poll_pending_payments(self) -> None:
        if not self.pending_pay_orders:
            return
        pay_api = getattr(self.context, "builtin", lambda name: None)("runtime.pay")
        if not pay_api or not hasattr(pay_api, "query_payment"):
            return
        now = time.time()
        expired_ids = []
        active_items = []
        for order_id, info in list(self.pending_pay_orders.items()):
            order_time = info.get("time", 0)
            if now - order_time > 1800:
                expired_ids.append(order_id)
            else:
                active_items.append((order_id, info))

        for eid in expired_ids:
            self.pending_pay_orders.pop(eid, None)
        if expired_ids:
            self._save_data()

        active_items.sort(key=lambda x: x[1].get("time", 0), reverse=True)
        finished_ids = []
        for order_id, _info in active_items[:2]:
            try:
                res = await asyncio.wait_for(pay_api.query_payment(order_id), timeout=2.0)
                status = str(res.get("local_status") or "")
                if status == "paid":
                    await self.on_payment_success(res)
                    finished_ids.append(order_id)
                elif status in {"closed", "refunded", "create_failed", "polling_stopped"}:
                    finished_ids.append(order_id)
            except Exception:
                pass

        if finished_ids:
            for fid in finished_ids:
                self.pending_pay_orders.pop(fid, None)
            self._save_data()

    def poll_pending_payments(self) -> None:
        try:
            loop = asyncio.get_event_loop()
            if loop.is_running():
                asyncio.create_task(self._async_poll_pending_payments())
            else:
                loop.run_until_complete(self._async_poll_pending_payments())
        except Exception as e:
            logger.debug("poll_pending_payments error: %s", e)

    # ---------- Dynamic Models & WebUI Page Actions ----------

    async def page_fetch_models(self, api_base_url: str = "", api_key: str = "") -> dict[str, Any]:
        base = (api_base_url or self.config.get("api_base_url") or "").rstrip("/")
        key = (api_key or self.config.get("api_key") or "").strip()
        if not base:
            raise ValueError("请先填写有效的 API 接口地址 (例如 https://api.openai.com)")

        if not (base.startswith("http://") or base.startswith("https://")):
            raise ValueError("API 接口地址必须以 http:// 或 https:// 开头")

        models: list[str] = []
        ssl_ctx = ssl.create_default_context(cafile=certifi.where())
        timeout = aiohttp.ClientTimeout(total=15.0)

        endpoints_to_try = [f"{base}/v1/models"]
        if not base.endswith("/v1"):
            endpoints_to_try.append(f"{base}/models")

        headers_list = []
        if key:
            headers_list.append({"Authorization": f"Bearer {key}"})
        headers_list.append({})

        resp_data = None
        err_msg = ""
        async with aiohttp.ClientSession(timeout=timeout) as session:
            for ep in endpoints_to_try:
                for hdrs in headers_list:
                    try:
                        async with session.get(ep, headers=hdrs, ssl=ssl_ctx) as resp:
                            if resp.status == 200:
                                resp_data = await resp.json()
                                break
                            else:
                                err_msg = f"HTTP {resp.status}"
                    except Exception as e:
                        err_msg = str(e)
                if resp_data:
                    break

        if not resp_data:
            raise ValueError(f"获取模型列表失败: {err_msg or '无法连接目标 API'}")

        data = resp_data.get("data", []) if isinstance(resp_data, dict) else (resp_data if isinstance(resp_data, list) else [])
        for item in data:
            mid = str(item.get("id") if isinstance(item, dict) else item).strip()
            if mid and mid not in models:
                models.append(mid)

        audio_keywords = ("tts", "speech", "voice", "cosyvoice", "fish-speech", "eleven", "whisper")
        negative_keywords = ("image", "video", "sora", "cogvideo", "claude", "gemini", "gpt-", "deepseek", "embedding", "chat")
        audio_models = []
        for m in models:
            m_lower = m.lower()
            if any(k in m_lower for k in audio_keywords) or m_lower.endswith("-audio") or m_lower.startswith("audio-"):
                if any(neg in m_lower for neg in negative_keywords):
                    if not any(pos in m_lower for pos in ("tts", "speech", "voice", "audio-preview")):
                        continue
                audio_models.append(m)

        self.cached_models = audio_models
        self._save_data()
        return {"ok": True, "models": audio_models, "all_models": models, "total": len(audio_models)}

    async def action_fetch_models(self, payload: Any = None) -> dict[str, Any]:
        payload = payload if isinstance(payload, dict) else {}
        base = str(payload.get("api_base_url") or "")
        key = str(payload.get("api_key") or "")
        try:
            return await self.page_fetch_models(base, key)
        except Exception as e:
            return {"ok": False, "error": str(e)}

    async def action_save_config(self, payload: dict[str, Any]) -> dict[str, Any]:
        for k, v in payload.items():
            if k in self.config:
                self.config[k] = v
        self._save_config()
        return {"ok": True, "config": self.config}

    async def action_save_voices(self, payload: Any = None) -> dict[str, Any]:
        payload = payload if isinstance(payload, dict) else {}
        voices = payload.get("voices")
        if isinstance(voices, str):
            try:
                parsed = json.loads(voices)
                if not isinstance(parsed, list):
                    return {"ok": False, "error": "JSON 格式必须为对象数组，例如 [{\"id\":\"alloy\",\"name\":\"Alloy\"}]"}
                voices = parsed
            except Exception as e:
                return {"ok": False, "error": f"JSON 解析失败: {e}"}
        if not isinstance(voices, list):
            return {"ok": False, "error": "音色配置必须为列表"}

        validated = []
        for item in voices:
            if isinstance(item, dict) and item.get("id"):
                validated.append({
                    "id": str(item["id"]).strip(),
                    "name": str(item.get("name") or item["id"]).strip(),
                    "desc": str(item.get("desc") or "").strip(),
                })
        self.config["custom_voices"] = validated
        self._save_config()
        return {"ok": True, "voices": validated}

    async def action_users(self, payload: Any = None) -> dict[str, Any]:
        users = []
        all_keys = set(self.user_credits.keys()) | set(self.user_prefs.keys())
        default_bal = float(self.config.get("default_balance", 0.0))
        for k in sorted(all_keys):
            creds = float(self.user_credits.get(k, default_bal))
            prefs = self.user_prefs.get(k, {})
            m = prefs.get("default_model", self.config.get("default_model", "tts-1"))
            v = prefs.get("default_voice", self.config.get("default_voice", "alloy"))
            sp = prefs.get("default_speed", 1.0)
            u_tasks = [t for t in self.tasks.values() if t.get("user_key") == k]
            last_active = u_tasks[-1].get("created_at", "-") if u_tasks else "-"
            users.append({
                "key": k,
                "credits": round(creds, 2),
                "model": m,
                "voice": v,
                "speed": sp,
                "tasks_count": len(u_tasks),
                "last_active": last_active,
            })
        return {"ok": True, "users": users}

    async def action_user_credit(self, payload: Any = None) -> dict[str, Any]:
        if not isinstance(payload, dict):
            return {"ok": False, "error": "无效参数"}
        user_key = str(payload.get("key") or "").strip()
        if not user_key:
            return {"ok": False, "error": "缺少用户标识"}
        try:
            credits = float(payload.get("credits", 0))
        except (ValueError, TypeError):
            return {"ok": False, "error": "积分数值无效"}
        mode = str(payload.get("mode") or "add").strip()
        default_bal = float(self.config.get("default_balance", 0.0))
        cur = float(self.user_credits.get(user_key, default_bal))
        if mode == "set":
            new_val = max(0.0, credits)
        else:
            new_val = max(0.0, cur + credits)
        self.user_credits[user_key] = round(new_val, 2)
        self._save_data()
        return {"ok": True, "key": user_key, "credits": self.user_credits[user_key]}

    async def action_user_model(self, payload: Any = None) -> dict[str, Any]:
        if not isinstance(payload, dict):
            return {"ok": False, "error": "无效参数"}
        user_key = str(payload.get("key") or "").strip()
        model = str(payload.get("model") or "").strip()
        if not user_key:
            return {"ok": False, "error": "缺少用户标识"}
        self._set_pref(user_key, "default_model", model)
        return {"ok": True, "key": user_key, "model": model}

    async def action_user_voice(self, payload: Any = None) -> dict[str, Any]:
        if not isinstance(payload, dict):
            return {"ok": False, "error": "无效参数"}
        user_key = str(payload.get("key") or "").strip()
        voice = str(payload.get("voice") or "").strip()
        if not user_key:
            return {"ok": False, "error": "缺少用户标识"}
        self._set_pref(user_key, "default_voice", voice)
        return {"ok": True, "key": user_key, "voice": voice}

    async def action_tasks(self, payload: Any = None) -> dict[str, Any]:
        recent = sorted(self.tasks.values(), key=lambda t: t.get("created_at", ""), reverse=True)[:50]
        return {"ok": True, "tasks": recent}

    async def action_overview(self, payload: dict[str, Any] | None = None) -> dict[str, Any]:
        return {
            "ok": True,
            "version": PLUGIN_VERSION,
            "config": self.config,
            "total_users": len(set(self.user_credits.keys()) | set(self.user_prefs.keys())),
            "total_tasks": len(self.tasks),
            "cached_models": self.cached_models,
            "voices": self._get_available_voices(),
        }

    async def action_probe(self, payload: dict[str, Any] | None = None) -> dict[str, Any]:
        payload = payload or {}
        api_base = str(payload.get("api_base_url") or self.config.get("api_base_url", "")).rstrip("/")
        api_key = str(payload.get("api_key") or self.config.get("api_key", "")).strip()
        if not api_base:
            return {"ok": False, "message": "未配置 API 服务地址"}
        headers = {"Authorization": f"Bearer {api_key}"} if api_key else {}
        t0 = time.time()
        try:
            ssl_ctx = ssl.create_default_context(cafile=certifi.where())
            timeout = aiohttp.ClientTimeout(total=10.0)
            async with aiohttp.ClientSession(timeout=timeout) as session:
                async with session.get(f"{api_base}/v1/models", headers=headers, ssl=ssl_ctx) as resp:
                    latency = round((time.time() - t0) * 1000, 1)
                    return {
                        "ok": True,
                        "status_code": resp.status,
                        "latency_ms": latency,
                        "message": f"连接成功 (HTTP {resp.status}，耗时 {latency}ms)",
                    }
        except Exception as e:
            return {"ok": False, "message": f"连接失败: {e}"}

    async def on_page_action(self, *args: Any, **kwargs: Any) -> Any:
        if args and isinstance(args[0], str):
            action_name = args[0]
            payload = args[1] if len(args) > 1 else {}
        else:
            action_name = kwargs.get("action_name", "overview")
            payload = kwargs.get("payload", {})
        action = str(action_name or "").strip()
        payload = payload if isinstance(payload, dict) else {}
        if action in ("save_config", "config"):
            return await self.action_save_config(payload)
        if action in ("overview", "page_overview"):
            return await self.action_overview(payload)
        if action in ("probe", "ping", "test"):
            return await self.action_probe(payload)
        if action in ("fetch_models", "models"):
            return await self.action_fetch_models(payload)
        if action in ("users", "page_users"):
            return await self.action_users(payload)
        if action == "user_credit":
            return await self.action_user_credit(payload)
        if action == "user_model":
            return await self.action_user_model(payload)
        if action == "user_voice":
            return await self.action_user_voice(payload)
        if action in ("tasks", "orders"):
            return await self.action_tasks(payload)
        if action in ("save_voices", "voices"):
            return await self.action_save_voices(payload)
        return {"ok": True}


def setup(context: Any) -> AudioServicePlugin:
    plugin = AudioServicePlugin(context)
    context.register_command("tts", plugin.handle_tts, category="audio", description="文本朗读与语音合成")
    context.register_command("ad", plugin.handle_tts, category="audio", description="语音服务主入口")
    context.register_task("cleanup", 3600, plugin.cleanup)
    context.register_task("check_payments", 15, plugin.poll_pending_payments)
    if hasattr(context, "register_action"):
        context.register_action("overview", plugin.action_overview)
        context.register_action("save_config", plugin.action_save_config)
        context.register_action("probe", plugin.action_probe)
        context.register_action("fetch_models", plugin.action_fetch_models)
        context.register_action("users", plugin.action_users)
        context.register_action("user_credit", plugin.action_user_credit)
        context.register_action("user_model", plugin.action_user_model)
        context.register_action("user_voice", plugin.action_user_voice)
        context.register_action("tasks", plugin.action_tasks)
        context.register_action("save_voices", plugin.action_save_voices)
    return plugin
