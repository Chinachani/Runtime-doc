# 语音服务插件 (plugin.audio.service)

管理员提供统一文本转语音 (TTS) 与音频合成服务，内置深度兼容 OpenAI、Google Gemini 多模态音频、Agnes 及自定义协议，支持多音色、语速微调、格式切换与 QQ 官方富媒体音频投递。

## 指令列表

- `/tts <文本>`：朗读指定文本并发送语音
- `/tts`：唤出语音控制台卡片
- `/tts voice`：切换预设音色（Alloy / Nova / Echo / Fable / Onyx / Shimmer）
- `/tts speed <0.5~2.0>`：调节语速倍率（如 0.8 / 1.0 / 1.25 / 1.5）
- `/tts format`：切换音频格式（MP3 / WAV / SILK / OPUS）
- `/tts models`：切换语音模型
- `/tts status`：查看积分余额与当前音色设置
