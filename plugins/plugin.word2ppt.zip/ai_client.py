from __future__ import annotations

import asyncio
import json
import re
from typing import Any

import httpx


class AIClientError(RuntimeError):
    pass


def _server_error_message(response: httpx.Response, limit: int = 160) -> str:
    """提取中转/上游返回的错误 message，便于排查模型缺失、令牌无效等问题。"""
    try:
        data = response.json()
    except Exception:  # noqa: BLE001 — 非 JSON 响应体
        text = (response.text or "").strip()
        return text[:limit]
    if isinstance(data, dict):
        error = data.get("error")
        if isinstance(error, dict):
            text = str(error.get("message") or error.get("code") or "")
        else:
            text = str(error or data.get("message") or "")
        return text.strip()[:limit]
    return ""


async def _consume_stream(response: httpx.Response) -> str:
    """消费 SSE 响应流，拼接文本内容；若上游直接返回 JSON 则自动降级解析。"""
    content_type = response.headers.get("content-type", "").lower()
    if "application/json" in content_type:
        await response.aread()
        data = response.json()
        return str(data["choices"][0]["message"]["content"] or "")

    collected: list[str] = []
    async for raw_line in response.aiter_lines():
        line = raw_line.strip()
        if not line or not line.startswith("data:"):
            continue
        data_str = line[5:].strip()
        if data_str == "[DONE]":
            break
        try:
            chunk = json.loads(data_str)
        except json.JSONDecodeError:
            continue
        choices = chunk.get("choices") or []
        if not choices or not isinstance(choices, list):
            continue
        choice = choices[0]
        if not isinstance(choice, dict):
            continue
        delta = choice.get("delta")
        if isinstance(delta, dict) and delta.get("content"):
            collected.append(str(delta["content"]))
        elif isinstance(choice.get("message"), dict) and choice["message"].get("content"):
            collected.append(str(choice["message"]["content"]))
    return "".join(collected).strip()


def extract_json(text: str) -> dict[str, Any]:
    value = str(text or "").strip()
    value = re.sub(
        r"^```(?:json)?\s*|\s*```$", "", value, flags=re.IGNORECASE | re.DOTALL
    ).strip()
    try:
        result = json.loads(value)
    except json.JSONDecodeError:
        match = re.search(r"\{.*\}", value, re.DOTALL)
        if not match:
            raise AIClientError("AI 未返回有效 JSON")
        try:
            result = json.loads(match.group(0))
        except json.JSONDecodeError as exc:
            raise AIClientError("AI 返回的 JSON 无法解析") from exc
    if not isinstance(result, dict):
        raise AIClientError("AI 返回格式不是对象")
    return result


def extract_python(text: str) -> str:
    value = str(text or "").strip()
    matches = re.findall(
        r"```(?:python|py)?\s*(.*?)```", value, re.IGNORECASE | re.DOTALL
    )
    code = max(matches, key=len).strip() if matches else value
    if "from ppt_builder" not in code and "import ppt_builder" not in code:
        raise AIClientError("AI 未返回可执行的 PPT Python 脚本")
    return code


class AIClient:
    def __init__(
        self,
        base_url: str,
        api_key: str,
        analysis_model: str,
        code_model: str = "",
        timeout: float = 180,
        image_model: str = "gpt-image-1",
    ):
        self.base_url = str(base_url or "").rstrip("/")
        if self.base_url.endswith("/v1"):
            self.base_url = self.base_url[:-3].rstrip("/")
        self.api_key = str(api_key or "").strip()
        self.analysis_model = str(analysis_model or "gpt-4o-mini").strip()
        self.code_model = str(code_model or self.analysis_model).strip()
        self.image_model = str(image_model or "gpt-image-1").strip()
        self.timeout = timeout

    async def _chat(self, model: str, system: str, user: str) -> str:
        if not self.base_url or not self.api_key:
            raise AIClientError("管理员尚未配置 AI 接口地址或令牌")
        payload = {
            "model": model,
            "messages": [
                {"role": "system", "content": system},
                {"role": "user", "content": user},
            ],
            "temperature": 0.2,
            "stream": True,
        }
        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
        }
        max_attempts = 3
        last_error: Exception | None = None
        for attempt in range(max_attempts):
            try:
                async with httpx.AsyncClient(
                    base_url=f"{self.base_url}/v1", headers=headers, timeout=self.timeout
                ) as client:
                    async with client.stream("POST", "/chat/completions", json=payload) as response:
                        if response.status_code >= 400:
                            await response.aread()
                            detail = _server_error_message(response)
                            error_msg = (
                                f"AI 接口返回 HTTP {response.status_code}"
                                + (f"（{detail}）" if detail else "")
                            )
                            # 5xx 服务端故障或上游断连（如 Google EOF），在未达最大重试次数时自动重试
                            if response.status_code in (500, 502, 503, 504) and attempt < max_attempts - 1:
                                await asyncio.sleep(1.0 * (attempt + 1))
                                continue
                            raise AIClientError(error_msg)
                        content = await _consume_stream(response)
                        if not content:
                            if attempt < max_attempts - 1:
                                await asyncio.sleep(1.0)
                                continue
                            raise AIClientError("AI 返回内容为空")
                        return content
            except AIClientError:
                raise
            except (httpx.HTTPError, KeyError, IndexError, TypeError, ValueError) as exc:
                last_error = exc
                if attempt < max_attempts - 1:
                    await asyncio.sleep(1.0 * (attempt + 1))
                    continue
                raise AIClientError(f"AI 接口调用失败：{type(exc).__name__}") from exc
        if last_error:
            raise AIClientError(f"AI 接口调用失败：{type(last_error).__name__}") from last_error
        raise AIClientError("AI 接口调用失败：未知错误")

    async def outline(
        self, content: dict[str, Any], slide_count: int, theme: str
    ) -> dict[str, Any]:
        system = "你是专业 PPT 策划。只返回 JSON，不要 Markdown。必须包含 title、theme、slide_count、slides。每页 layout 只能是 title、bullets、two_column、process、table、summary、image_text；需要视觉解释的页面可使用 image_text。"
        prompt = json.dumps(
            {
                "task": "把 Word 内容规划成 PPT",
                "slide_count": slide_count,
                "theme": theme,
                "document": content,
            },
            ensure_ascii=False,
        )
        return extract_json(await self._chat(self.analysis_model, system, prompt))

    async def script(
        self, content: dict[str, Any], outline: dict[str, Any], theme: str, assets: list[dict[str, Any]] | None = None
    ) -> str:
        system = """你是 Python PPT 工程师。只输出 Python 代码或一个 python 代码块。必须从 ppt_builder import Deck，使用 Path.cwd() / 'output.pptx' 保存。只能调用 Deck 的 add_title、add_bullets、add_two_column、add_process、add_table、add_image_text、add_summary、save；禁止 os、subprocess、socket、网络、eval、exec、open、任意文件读写。内容必须来自用户文档、大纲和给出的素材路径；若某页有素材，优先使用 add_image_text，并传入素材的相对路径（例如 Path("assets/slide_2.png")）。方法签名必须遵守：add_title(title, subtitle="")、add_bullets(title, items, subtitle="")、add_two_column(title, left_title, left_items, right_title, right_items)、add_process(title, steps)、add_table(title, headers, rows)、add_image_text(title, image_path, items)、add_summary(title, items, subtitle="")、save(path)。"""
        prompt = json.dumps(
            {"theme": theme, "document": content, "outline": outline, "assets": assets or []},
            ensure_ascii=False,
        )
        return extract_python(await self._chat(self.code_model, system, prompt))


    async def page_script(
        self, content: dict[str, Any], outline: dict[str, Any], page: int, theme: str, assets: list[dict[str, Any]] | None = None
    ) -> str:
        slides = outline.get("slides") if isinstance(outline, dict) else []
        selected = slides[page - 1] if isinstance(slides, list) and 0 < page <= len(slides) else {}
        system = """你是 Python PPT 单页重做工程师。只输出 Python 代码或一个 python 代码块。代码必须从 ppt_builder import Deck，创建 Deck 后只生成 1 页，并使用 Path.cwd() / 'output.pptx' 保存。运行环境会自动加载原 PPT 并替换指定页；不要读取或写入其它文件。只能调用 Deck 的 add_title、add_bullets、add_two_column、add_process、add_table、add_image_text、add_summary、save；禁止 os、subprocess、socket、网络、eval、exec、open。页面内容必须来自指定页面大纲、Word 文档和给出的素材路径；若当前页有素材，优先使用 add_image_text，并传入相对路径（例如 Path("assets/slide_2.png")）。"""
        prompt = json.dumps(
            {
                "task": "只重新设计并生成第 N 页，保持全套 PPT 的主题和内容风格",
                "page": page,
                "theme": theme,
                "selected_slide": selected,
                "document": content,
                "outline": outline,
                "assets": assets or [],
            },
            ensure_ascii=False,
        )
        return extract_python(await self._chat(self.code_model, system, prompt))

    async def image_prompts(
        self, content: dict[str, Any], outline: dict[str, Any], theme: str, max_images: int = 3
    ) -> list[dict[str, Any]]:
        slides = outline.get("slides") if isinstance(outline, dict) else []
        system = """你是 PPT 视觉策划。只返回 JSON，不要 Markdown。返回格式必须是 {\"images\":[{\"page\":1,\"prompt\":\"...\"}]}。从 PPT 大纲中选择最适合配图的页面，最多返回指定数量；封面、纯表格、纯流程页可以不配图。每条 prompt 写成适合图像模型的中文视觉描述，要求专业、简洁、无水印、无大段文字；如果需要图中标签，必须明确写出，但优先让 PPT 用文字说明而不是让图片承载文字。"""
        prompt = json.dumps({"theme": theme, "max_images": max(0, int(max_images)), "slides": slides, "document": content}, ensure_ascii=False)
        result = extract_json(await self._chat(self.analysis_model, system, prompt))
        values = result.get("images")
        if not isinstance(values, list):
            raise AIClientError("AI 未返回有效配图计划")
        normalized = []
        for item in values[: max(0, int(max_images))]:
            if not isinstance(item, dict):
                continue
            try:
                page = int(item.get("page"))
            except (TypeError, ValueError):
                continue
            prompt_text = str(item.get("prompt") or "").strip()
            if 0 < page <= len(slides) and prompt_text:
                normalized.append({"page": page, "prompt": prompt_text[:1200]})
        return normalized

    async def generate_image(self, prompt: str, size: str = "1024x1024") -> bytes:
        if not self.base_url or not self.api_key:
            raise AIClientError("管理员尚未配置 AI 接口地址或令牌")
        payload = {"model": self.image_model, "prompt": str(prompt)[:4000], "size": str(size or "1024x1024"), "n": 1}
        headers = {"Authorization": f"Bearer {self.api_key}", "Content-Type": "application/json"}
        try:
            async with httpx.AsyncClient(base_url=f"{self.base_url}/v1", headers=headers, timeout=self.timeout) as client:
                response = await client.post("/images/generations", json=payload)
                if response.status_code >= 400:
                    detail = _server_error_message(response)
                    raise AIClientError(
                        f"图像接口返回 HTTP {response.status_code}（模型 {self.image_model}）" + (f"：{detail}" if detail else "")
                    )
                data = response.json()
                first = (data.get("data") or [])[0]
                encoded = first.get("b64_json") if isinstance(first, dict) else None
                if encoded:
                    import base64
                    return base64.b64decode(encoded)
                url = first.get("url") if isinstance(first, dict) else ""
                if url:
                    image = await client.get(url)
                    image.raise_for_status()
                    return image.content
                raise AIClientError("图像接口未返回图片")
        except AIClientError:
            raise
        except (httpx.HTTPError, KeyError, IndexError, TypeError, ValueError) as exc:
            raise AIClientError(f"图像接口调用失败：{type(exc).__name__}") from exc

    async def speaker_notes(
        self, content: dict[str, Any], outline: dict[str, Any], theme: str, pages: list[int] | None = None
    ) -> dict[str, Any]:
        slides = outline.get("slides") if isinstance(outline, dict) else []
        selected_pages = pages or list(range(1, len(slides) + 1))
        system = """你是专业演讲稿编辑。只返回 JSON，不要 Markdown。返回格式必须是 {\"notes\":[{\"page\":1,\"text\":\"...\"}]}。每页写一段适合演讲者在 PPT 备注区使用的中文讲稿，约 80-180 字：解释页面重点、数据/结论之间的关系，并给出自然的讲解衔接；不要捏造 Word 文档没有的事实，不要输出标题、列表符号或页码以外的字段。"""
        selected = []
        for page in selected_pages:
            if 0 < page <= len(slides):
                selected.append({"page": page, "slide": slides[page - 1]})
        prompt = json.dumps(
            {"task": "为指定 PPT 页面生成演讲备注", "theme": theme, "pages": selected, "document": content},
            ensure_ascii=False,
        )
        result = extract_json(await self._chat(self.analysis_model, system, prompt))
        raw_notes = result.get("notes")
        if not isinstance(raw_notes, list):
            raise AIClientError("AI 未返回有效演讲备注")
        normalized = []
        allowed = set(selected_pages)
        for item in raw_notes:
            if not isinstance(item, dict):
                continue
            try:
                page = int(item.get("page"))
            except (TypeError, ValueError):
                continue
            if page not in allowed:
                continue
            text = str(item.get("text") or "").strip()
            if text:
                normalized.append({"page": page, "text": text[:1200]})
        if not normalized:
            raise AIClientError("AI 返回的演讲备注为空")
        return {"notes": normalized}

    async def repair_page(
        self, content: dict[str, Any], outline: dict[str, Any], page: int, script: str, error: str, theme: str
    ) -> str:
        system = "你是 Python PPT 单页脚本修复工程师。只输出修复后的 Python 代码。只生成 1 页并保存到 Path.cwd() / 'output.pptx'，继续使用 ppt_builder；禁止危险导入、网络和任意文件操作。"
        prompt = json.dumps(
            {"page": page, "theme": theme, "document": content, "outline": outline, "script": script, "execution_error": error[-6000:]},
            ensure_ascii=False,
        )
        return extract_python(await self._chat(self.code_model, system, prompt))

    async def repair(
        self,
        content: dict[str, Any],
        outline: dict[str, Any],
        script: str,
        error: str,
        theme: str,
    ) -> str:
        system = "你是 Python PPT 修复工程师。只输出修复后的 Python 代码。保持原大纲内容，只修复执行错误；必须继续使用 ppt_builder，禁止危险导入、网络和任意文件操作。"
        prompt = json.dumps(
            {
                "theme": theme,
                "document": content,
                "outline": outline,
                "script": script,
                "execution_error": error[-6000:],
            },
            ensure_ascii=False,
        )
        return extract_python(await self._chat(self.code_model, system, prompt))
