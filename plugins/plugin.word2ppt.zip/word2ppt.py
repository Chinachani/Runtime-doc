"""Word 转 PPT 插件（plugin.word2ppt）— QQ Runtime 外部插件版。

迁移自 AstrBot astrbot_plugin_word2ppt 0.0.31，保留核心链路：
Word 上传 → 本地解析 → AI 大纲 → AI 脚本 → AST 校验 → Worker 沙箱执行
→ PPTX 生成 → 发送文件，外加单页重做/演讲备注/预览/模板/任务队列/积分计费。

与 AstrBot 版的差异：
- 事件/回复模型换成 Runtime 的 MessageContext / Card / Button。
- 文件发送走 context.media.prepare + context.qq.send_media（file_type=4）。
- 计费从 DG 积分换成 Runtime PointsService（context.points，operation_id 幂等）。
- 数据目录为插件 context.data_dir（宿主 data/plugin-data/plugin.word2ppt/）。
- 管理页数据经 web.py 的 /api/word2ppt/page/* 端点读取插件数据目录 JSON。
"""

from __future__ import annotations

import asyncio
import hashlib
import json
import logging
import math
import shutil
import subprocess
import time
import uuid
from pathlib import Path
from typing import Any

import httpx
from ai_client import AIClient
from attachment_router import find_pptx_candidate, find_word_candidate
from document_formats import detect_word_format
from docx_parser import parse_docx
from ppt_builder import THEMES
from queue_store import QueueStore
from script_runner import run_script

from runtime.models import Button, Card

logger = logging.getLogger("plugin.word2ppt")

PLUGIN_VERSION = "0.33.3"
PLUGIN_ID = "plugin.word2ppt"
SLUG = "word2ppt"

CONFIG_DEFAULTS: dict[str, Any] = {
    "api_base_url": "", "api_key": "", "default_model": "gpt-4o-mini", "analysis_model": "gpt-4o-mini", "code_model": "",
    "default_slide_count": 10, "max_file_size_mb": 20, "max_document_chars": 50000,
    "script_timeout_sec": 60, "max_repair_attempts": 2, "job_expire_hours": 24,
    "enable_group": True, "enable_preview": False, "debug_log": False,
    "admin_openids": [], "ai_timeout_sec": 180, "keep_completed_jobs": 5,
    "max_template_size_mb": 20, "available_themes": ["research", "business", "teaching", "clean"],
    "task_timeout_sec": 600, "max_concurrency": 1,
    "outline_credit_price": 1, "script_credit_price": 1, "page_credit_price": 0.5,
    "image_credit_price": 1, "credit_price_yuan": 0.1, "billing_enabled": False,
    "enable_speaker_notes": True, "enable_ai_images": False,
    "image_model": "", "image_api_base_url": "", "image_api_key": "",
    "max_generated_images": 3, "image_size": "1024x1024", "public_template_default": "",
}

CONFIRM_TTL = 600
MEDIA_TYPES = {1: "图片", 2: "视频", 3: "语音", 4: "文件"}


def _load_json(path: Path, default: Any) -> Any:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return default


def _save_json(path: Path, data: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(data, ensure_ascii=False, indent=1), encoding="utf-8")
    tmp.replace(path)


def _clamp(value: int, low: int, high: int) -> int:
    try:
        return max(low, min(high, int(value)))
    except (TypeError, ValueError):
        return low


class JobStore:
    """任务目录管理（与 0.31 数据结构兼容）。"""

    def __init__(self, root: Path) -> None:
        self.root = root
        self.root.mkdir(parents=True, exist_ok=True)
        self.latest_path = self.root / "latest.json"

    def user_key(self, context: Any) -> str:
        return f"{getattr(context, 'platform', 'qq')}:{getattr(context, 'sender_id', '')}"

    def _user_hash(self, user_key: str) -> str:
        return hashlib.sha256(user_key.encode("utf-8")).hexdigest()[:12]

    def _index(self) -> dict[str, str]:
        return _load_json(self.latest_path, {})

    def all_jobs(self) -> list[dict[str, Any]]:
        jobs = []
        for path in sorted(self.root.glob("jobs/*"), reverse=True):
            meta = _load_json(path / "meta.json", None)
            if meta:
                meta["dir"] = str(path)
                meta["name"] = path.name
                jobs.append(meta)
        return jobs

    def jobs_of(self, user_key: str) -> list[dict[str, Any]]:
        prefix = self._user_hash(user_key)
        return [j for j in self.all_jobs() if j["name"].startswith("jobs/") or prefix in j.get("name", "")] if False else [
            j for j in self.all_jobs() if self._owner_of(j) == user_key
        ]

    @staticmethod
    def _owner_of(meta: dict[str, Any]) -> str:
        return str(meta.get("owner_key") or "")

    def current(self, user_key: str) -> dict[str, Any] | None:
        name = self._index().get(user_key)
        if not name:
            jobs = self.jobs_of(user_key)
            return jobs[0] if jobs else None
        path = self.root / "jobs" / name
        meta = _load_json(path / "meta.json", None)
        if not meta:
            return None
        meta["dir"] = str(path)
        meta["name"] = name
        return meta

    def set_current(self, user_key: str, job_name: str) -> None:
        index = self._index()
        index[user_key] = job_name
        _save_json(self.latest_path, index)

    def create(self, user_key: str, source_path: Path, display_name: str) -> dict[str, Any]:
        now = int(time.time())
        name = f"{now}_{self._user_hash(user_key)}_{uuid.uuid4().hex[:6]}"
        job_dir = self.root / "jobs" / name
        job_dir.mkdir(parents=True, exist_ok=True)
        target = job_dir / ("source" + (".doc" if source_path.suffix.lower() == ".doc" else ".docx"))
        source_path.replace(target)
        meta = {
            "name": name, "owner_key": user_key, "identity": user_key, "filename": display_name,
            "created_at": now, "status": "pending", "stage": "received",
            "progress": 0, "theme": "", "slide_count": 0,
            "billing_history": [], "attachments": [],
        }
        _save_json(job_dir / "meta.json", meta)
        self.set_current(user_key, name)
        meta["dir"] = str(job_dir)
        return meta

    @staticmethod
    def update(meta: dict[str, Any], **fields: Any) -> None:
        meta.update(fields)
        _save_json(Path(meta["dir"]) / "meta.json", meta)

    @staticmethod
    def log(meta: dict[str, Any], event: str, **detail: Any) -> None:
        entry = {"time": int(time.time()), "event": event, **detail}
        with (Path(meta["dir"]) / "job.log.jsonl").open("a", encoding="utf-8") as fh:
            fh.write(json.dumps(entry, ensure_ascii=False) + "\n")

    @staticmethod
    def delete(meta: dict[str, Any]) -> None:
        import shutil

        shutil.rmtree(Path(meta["dir"]), ignore_errors=True)

    def cleanup_expired(self, expire_hours: int, keep_completed: int) -> int:
        now = time.time()
        index = self._index()
        kept: dict[str, list[int]] = {}
        removed = 0
        for meta in self.all_jobs():
            user_key = self._owner_of(meta)
            if meta.get("status") == "running":
                continue
            age_hours = (now - float(meta.get("created_at") or 0)) / 3600
            recent = kept.setdefault(user_key, [])
            if age_hours < expire_hours or index.get(user_key) == meta["name"] or len(recent) < keep_completed:
                recent.append(int(meta.get("created_at") or 0))
                recent.sort(reverse=True)
                continue
            self.delete(meta)
            removed += 1
        return removed


class Word2PptPlugin:
    def __init__(self, context: Any) -> None:
        self.context = context
        self.config_dir = Path(getattr(context, "config_dir", "./data"))
        self.data_dir = Path(getattr(context, "data_dir", "./data"))
        self.config_dir.mkdir(parents=True, exist_ok=True)
        self.config = {**CONFIG_DEFAULTS, **_load_json(self.config_dir / "config.json", {})}
        self.store = JobStore(self.data_dir / "jobs")
        self.preferences: dict[str, dict] = _load_json(self.data_dir / "user_preferences.json", {})
        self.template_selections: dict[str, str] = _load_json(self.data_dir / "template_selections.json", {})
        self.confirmations: dict[str, dict] = _load_json(self.data_dir / "confirmations.json", {})
        self.pending_pay_orders_path = self.data_dir / "pending_pay_orders.json"
        self.pending_pay_orders: dict[str, Any] = _load_json(self.pending_pay_orders_path, {})
        self.queue = QueueStore(self.data_dir / "queue.json")
        self.active: dict[str, str] = {}
        self._reconcile()
        self._refresh_page_snapshot()

    def _save_pending_orders(self) -> None:
        _save_json(self.pending_pay_orders_path, self.pending_pay_orders)

    # ---------- 配置 ----------
    def _reload_config(self) -> None:
        disk_cfg = _load_json(self.config_dir / "config.json", {})
        if isinstance(disk_cfg, dict):
            for key in CONFIG_DEFAULTS:
                if key in disk_cfg:
                    self.config[key] = disk_cfg[key]

    def _cfg(self, key: str) -> Any:
        self._reload_config()
        val = self.config.get(key)
        if val is None or val == "":
            if key == "analysis_model":
                val = self.config.get("default_model")
            elif key == "default_model":
                val = self.config.get("analysis_model")
        return val if val is not None else CONFIG_DEFAULTS.get(key)

    def save_config(self, updates: dict[str, Any]) -> None:
        for key, value in updates.items():
            if key in CONFIG_DEFAULTS:
                if key == "api_key" and not str(value or "").strip() and self.config.get("api_key"):
                    continue
                self.config[key] = value
                if key == "default_model":
                    self.config["analysis_model"] = value
                elif key == "analysis_model":
                    self.config["default_model"] = value
        _save_json(self.config_dir / "config.json", self.config)
        self._refresh_page_snapshot()

    # ---------- 身份与任务 ----------
    def _admin(self, context: Any) -> bool:
        return str(getattr(context, "sender_id", "")) in set(self._cfg("admin_openids") or [])

    def _billing_identity(self, context: Any) -> str:
        return f"{getattr(context, 'platform', 'qq')}:{getattr(context, 'sender_id', '')}"

    def _reconcile(self) -> None:
        for meta in self.store.all_jobs():
            if meta.get("status") == "running":
                JobStore.update(meta, status="interrupted", stage_label="服务重启，使用 /ppt retry 继续")
                JobStore.log(meta, "state", status="interrupted")

    # ---------- AI ----------
    def _client(self) -> AIClient:
        return AIClient(
            str(self._cfg("api_base_url") or ""), str(self._cfg("api_key") or ""),
            str(self._cfg("analysis_model") or "gpt-4o-mini"),
            str(self._cfg("code_model") or ""), timeout=int(self._cfg("ai_timeout_sec") or 180),
            image_model=str(self._cfg("image_model") or "gpt-image-1"),
        )

    def _ai_ready(self) -> bool:
        return bool(self._cfg("api_base_url") and self._cfg("api_key"))

    # ---------- 计费（Runtime PointsService 桥） ----------
    async def _points(self) -> Any:
        return getattr(self.context, "points", None)

    @staticmethod
    def _price(meta: dict[str, Any], kind: str, pages: int = 0, images: int = 0) -> float:
        cfg = meta.get("prices") or {}
        if kind == "outline":
            return float(cfg.get("outline", 1))
        if kind == "make":
            return float(cfg.get("outline", 1)) + float(cfg.get("script", 1)) + pages * float(cfg.get("page", 0.5)) + images * float(cfg.get("image", 1))
        if kind == "page":
            return float(cfg.get("page", 0.5)) + float(cfg.get("script", 1))
        if kind == "images":
            return images * float(cfg.get("image", 1))
        return 0.0

    async def _reserve(self, context: Any, meta: dict[str, Any], kind: str, amount: float) -> dict | None:
        if not self._cfg("billing_enabled") or amount <= 0:
            return None
        points = await self._points()
        if points is None:
            return None
        identity = self._billing_identity(context)
        operation_id = f"ppt:{meta['name']}:{kind}:{meta.get('billing_seq', 0) + 1}"
        amount_int = math.ceil(amount)
        balance = await points.balance(identity)
        if balance < amount_int:
            raise RuntimeError(f"积分不足：需要 {amount_int}，余额 {balance}")
        await points.debit(identity, str(amount_int), reason="word2ppt.reserve", actor=PLUGIN_ID, operation_id=operation_id)
        meta["billing_seq"] = int(meta.get("billing_seq", 0)) + 1
        history = meta.setdefault("billing_history", [])
        history.append({"kind": kind, "operation_id": operation_id, "reserved": amount_int})
        meta["billing_current"] = {"operation_id": operation_id, "reserved": amount_int, "kind": kind}
        JobStore.update(meta, billing_history=history, billing_current=meta["billing_current"], billing_seq=meta["billing_seq"])
        return meta["billing_current"]

    async def _settle(self, meta: dict[str, Any], actual: float) -> None:
        current = meta.get("billing_current")
        if not current:
            return
        points = await self._points()
        if points is None:
            return
        reserved = int(current["reserved"])
        actual_int = math.ceil(actual)
        if actual_int < reserved:
            await points.credit(
                str(meta.get("identity") or ""), str(reserved - actual_int),
                reason="word2ppt.settle", actor=PLUGIN_ID,
                operation_id=current["operation_id"] + ":settle",
            )
        meta.pop("billing_current", None)
        JobStore.update(meta, billing_current=None)

    async def _refund(self, meta: dict[str, Any]) -> None:
        current = meta.get("billing_current")
        if not current:
            return
        points = await self._points()
        if points is not None:
            await points.credit(
                str(meta.get("identity") or ""), str(int(current["reserved"])),
                reason="word2ppt.refund", actor=PLUGIN_ID,
                operation_id=current["operation_id"] + ":refund",
            )
        meta.pop("billing_current", None)
        JobStore.update(meta, billing_current=None)

    # ---------- 附件接收 ----------
    async def on_event(self, context: Any) -> Card | str | None:
        text = str(getattr(context, "text", "") or "").strip()
        if text.startswith(("/ppt", "/w2p", "ppt ", "w2p ", "/文转ppt", "文转ppt")):
            return None
        if getattr(context, "message_type", None) == "interaction" or getattr(context, "interaction_id", None):
            return None

        word_candidate = find_word_candidate(context)
        if word_candidate:
            return await self._receive_word(context, word_candidate)

        pptx_candidate = find_pptx_candidate(context)
        if pptx_candidate:
            return await self._receive_template(context, pptx_candidate)

        return None

    async def _download(self, url: str, target: Path, max_mb: int) -> None:
        limit = max_mb * 1024 * 1024
        async with httpx.AsyncClient(timeout=60, follow_redirects=True) as client:
            async with client.stream("GET", url) as response:
                response.raise_for_status()
                received = 0
                with target.open("wb") as fh:
                    async for chunk in response.aiter_bytes(128 * 1024):
                        received += len(chunk)
                        if received > limit:
                            raise RuntimeError(f"文件超过 {max_mb} MB 上限")
                        fh.write(chunk)

    async def _convert_legacy_doc(self, source: Path, target: Path) -> None:
        office = shutil.which("soffice") or shutil.which("libreoffice")
        if not office:
            raise ValueError("服务器未安装 LibreOffice，暂不支持 .doc，请转换为 .docx 后重试")
        profile = source.parent / f".libreoffice-profile-doc-{uuid.uuid4().hex[:8]}"
        output_dir = source.parent / f".doc-convert-{uuid.uuid4().hex[:8]}"
        profile.mkdir(parents=True, exist_ok=True)
        output_dir.mkdir(parents=True, exist_ok=True)
        command = [
            office,
            "--headless",
            "--nologo",
            "--nodefault",
            "--nofirststartwizard",
            f"-env:UserInstallation={profile.as_uri()}",
            "--convert-to",
            "docx:Office Open XML Text",
            "--outdir",
            str(output_dir),
            str(source),
        ]
        try:
            completed = await asyncio.to_thread(
                subprocess.run,
                command,
                cwd=str(source.parent),
                capture_output=True,
                text=True,
                timeout=180,
                check=False,
            )
            converted = output_dir / f"{source.stem}.docx"
            if not converted.is_file() or converted.stat().st_size < 1024:
                stderr = completed.stderr.strip() or completed.stdout.strip()
                raise ValueError(f"LibreOffice 转换 .doc 失败：{stderr or '未生成有效的 docx'}")
            shutil.copyfile(converted, target)
        finally:
            shutil.rmtree(profile, ignore_errors=True)
            shutil.rmtree(output_dir, ignore_errors=True)

    async def _receive_word(self, context: Any, candidate: dict[str, str]) -> Card | str | None:
        user_key = self.store.user_key(context)
        filename = candidate.get("name") or "document.docx"
        tmp = self.data_dir / f"download_{uuid.uuid4().hex[:8]}"
        try:
            if candidate.get("path"):
                source = Path(candidate["path"])
                max_bytes = int(self._cfg("max_file_size_mb") or 20) * 1024 * 1024
                if source.stat().st_size > max_bytes:
                    return f"文件超过 {self._cfg('max_file_size_mb') or 20} MB 上限"
                shutil.copyfile(source, tmp)
            else:
                url = candidate.get("url") or ""
                if not url:
                    return None
                await self._download(url, tmp, int(self._cfg("max_file_size_mb") or 20))

            detected = detect_word_format(str(tmp))
            if not detected:
                tmp.unlink(missing_ok=True)
                return f"收到的文件「{filename}」不是有效的 Word 格式（支持 .docx 及 .doc），请另存为 .docx 后重试。"

            if detected == "doc":
                converted_tmp = self.data_dir / f"converted_{uuid.uuid4().hex[:8]}.docx"
                try:
                    await self._convert_legacy_doc(tmp, converted_tmp)
                    tmp.unlink(missing_ok=True)
                    tmp = converted_tmp
                except Exception as exc:
                    tmp.unlink(missing_ok=True)
                    converted_tmp.unlink(missing_ok=True)
                    return f"转换 .doc 文档失败：{exc}"

            meta = self.store.create(user_key, tmp, filename)
            JobStore.log(meta, "state", status="pending", filename=filename)
            task_id = meta["name"].split("_")[0][-6:]
            rows = [
                [self._btn("开始生成", "/ppt make", "primary"), self._btn("生成大纲", "/ppt outline")],
                [self._btn("任务列表", "/ppt tasks"), self._btn("使用说明", "/ppt help")],
            ]
            return self._card(
                "已收到 Word 文档",
                f"文件：**{filename}**\n当前任务编号：`#{task_id}`\n\n点击下方按钮或发送 `/ppt make` 开始生成 PPT。",
                rows,
            )
        except Exception as error:
            logger.warning("word 接收失败: %s", error)
            return f"接收 Word 文档失败：{error}"
        finally:
            tmp.unlink(missing_ok=True)

    async def _receive_template(self, context: Any, candidate: dict[str, str]) -> Card | str | None:
        user_key = self.store.user_key(context)
        filename = candidate.get("name") or "template.pptx"
        folder = self.data_dir / "templates" / hashlib.sha256(user_key.encode()).hexdigest()[:24]
        folder.mkdir(parents=True, exist_ok=True)
        tmp = folder / f"template_{int(time.time())}_{uuid.uuid4().hex[:6]}.pptx"
        try:
            if candidate.get("path"):
                shutil.copyfile(candidate["path"], tmp)
            else:
                url = candidate.get("url") or ""
                if not url:
                    return None
                await self._download(url, tmp, int(self._cfg("max_template_size_mb") or 20))
            try:
                from pptx import Presentation

                Presentation(str(tmp))
            except Exception as error:
                tmp.unlink(missing_ok=True)
                return f"模板校验失败（不是有效的 PPTX 文件）：{error}"

            _save_json(tmp.with_suffix(".json"), {"display_name": filename, "created_at": int(time.time()), "owner_key": user_key})
            rows = [
                [self._btn("查看模板", "/ppt templates", "primary"), self._btn("设为默认", "/ppt template 1")],
                [self._btn("返回主菜单", "/ppt")],
            ]
            return self._card(
                "已收到 PPT 模板",
                f"模板名称：**{filename}**\n\n发送 `/ppt templates` 查看，或点击下方按钮设为默认模板。",
                rows,
            )
        except Exception as error:
            logger.warning("模板接收失败: %s", error)
            tmp.unlink(missing_ok=True)
            return f"接收模板失败：{error}"

    # ---------- 回复工具 ----------
    async def _reply_text(self, context: Any, text: str) -> None:
        send = getattr(self.context, "send_text", None)
        if not callable(send) and hasattr(self.context, "qq"):
            send = getattr(self.context.qq, "send_text", None)
        if callable(send):
            conversation_id = getattr(context, "conversation_id", None) or getattr(context, "group_id", None)
            scene = getattr(context, "scene", None) or ("group" if getattr(context, "group_id", None) else "c2c")
            try:
                await send(conversation_id, scene, text)
            except Exception as error:
                logger.warning("_reply_text failed: %s", error)

    async def _reply_card(self, context: Any, card: Card) -> None:
        send = getattr(self.context, "send_card", None)
        if not callable(send) and hasattr(self.context, "qq"):
            send = getattr(self.context.qq, "send_card", None)
        if callable(send):
            conversation_id = getattr(context, "conversation_id", None) or getattr(context, "group_id", None)
            scene = getattr(context, "scene", None) or ("group" if getattr(context, "group_id", None) else "c2c")
            try:
                await send(conversation_id, scene, card)
            except Exception as error:
                logger.warning("_reply_card failed: %s", error)

    async def _send_file(self, context: Any, path: Path) -> None:
        media = getattr(self.context, "media", None)
        qq = getattr(self.context, "qq", None)
        if media is None or qq is None or not hasattr(qq, "send_media"):
            raise RuntimeError("当前运行环境不支持文件发送")
        if context.scene not in {"c2c", "group"}:
            raise RuntimeError(f"当前场景（{context.scene}）不支持文件发送，请在私聊或群聊中使用")
        # 完整链路：prepare（元数据）→ upload_media_file（分片上传）→ send_media
        request = await media.prepare(context.scene, context.conversation_id, 4, path)
        uploaded = await qq.upload_media_file(request, path)
        file_info = uploaded.get("file_info") if isinstance(uploaded, dict) else None
        if not file_info:
            raise RuntimeError("上传媒体接口未返回 file_info")
        await qq.send_media(context.conversation_id, context.scene, str(file_info))

    @staticmethod
    def _card(title: str, markdown: str, rows: list[list[Button]] | None = None) -> Card:
        return Card(title=title, markdown=markdown, rows=rows or [])

    @staticmethod
    def _btn(
        label: str,
        command: str,
        style: str = "normal",
        *,
        action_type: int = 1,
        fill: bool = False,
    ) -> Button:
        if fill:
            return Button(label=label, command=command, style=style, action_type=2, enter=False)
        return Button(label=label, command=command, style=style, action_type=action_type)

    # ---------- 命令入口 ----------
    async def handle_ppt(self, context: Any, args: list[str]) -> str | Card:
        self.context_ctx = context
        parts = [a for a in args if a]
        sub = (parts[0].lower() if parts else "menu")
        rest = parts[1:]
        aliases = {
            "菜单": "menu", "主菜单": "menu", "帮助": "help", "使用说明": "help", "教程": "help", "guide": "help",
            "生成": "make", "大纲": "outline", "重试": "retry", "重做": "rebuild", "重新生成": "rebuild",
            "页": "page", "单页": "page", "单页操作": "pages", "备注": "notes", "演讲稿": "notes",
            "预览": "preview", "pdf": "preview", "状态": "status", "progress": "status", "进度": "status",
            "日志": "logs", "取消": "cancel", "stop": "cancel", "停止": "cancel", "设置": "options",
            "制作设置": "options", "主题": "theme", "模板": "templates", "模板列表": "templates",
            "任务": "tasks", "列表": "tasks", "select": "use", "选择": "use", "使用": "use", "切换": "use",
            "详情": "task", "detail": "task", "排队": "queue", "确认": "confirm", "开始": "confirm",
            "pay": "pay", "充值": "pay", "buy": "pay", "积分": "pay", "购买": "pay",
        }
        handler = getattr(self, f"cmd_{aliases.get(sub, sub)}", None)
        if handler is None:
            return self.cmd_help()
        return await handler(context, rest)

    # ---------- 子命令 ----------
    async def cmd_menu(self, context: Any, args: list[str]) -> Card:
        meta = self.store.current(self.store.user_key(context))
        status = meta.get("status", "-") if meta else "未上传 Word"
        lines = ["**Word 转 PPT**", "", f"当前任务状态：{status}", ""]
        if meta:
            lines.append(f"文件：{meta.get('filename', '-')}")
        lines += ["发送 /ppt help 查看使用说明。"]
        rows = [
            [self._btn("开始生成", "/ppt make", "primary"), self._btn("生成大纲", "/ppt outline")],
            [self._btn("任务列表", "/ppt tasks"), self._btn("状态", "/ppt status")],
            [self._btn("💳 充值积分", "/ppt pay"), self._btn("使用说明", "/ppt help")],
        ]
        return self._card("Word 转 PPT", "\n".join(lines), rows)

    async def cmd_help(self, context: Any, args: list[str]) -> Card:
        text = (
            "**Word 转 PPT 使用说明**\n\n"
            "1. 直接发送 .docx 文件（.doc 会自动转换）\n"
            "2. /ppt make [页数] [主题] 生成 PPT\n"
            "3. /ppt outline 只看大纲；/ppt retry 复用脚本重试；/ppt rebuild 从头重做\n"
            "4. /ppt page <页码> 重做单页；/ppt pages 单页菜单\n"
            "5. /ppt notes [页码] 生成演讲备注\n"
            "6. /ppt preview [页码|all] 预览（需管理员开启）\n"
            "7. /ppt tasks 任务列表；/ppt use <编号> 切换；/ppt task <编号> 详情\n"
            "8. /ppt templates 管理个人模板；/ppt theme 查看主题\n"
            "9. /ppt status 进度；/ppt logs 日志；/ppt cancel 取消\n"
            "10. /ppt pay [数量] 在线充值积分；/ppt pay check [订单号] 查订单对账\n"
            "\n主题：" + "、".join(self._cfg("available_themes") or list(THEMES))
        )
        return self._card("使用说明", text, [[self._btn("返回主菜单", "/ppt")]])

    async def cmd_pay(self, context: Any, args: list[str]) -> str | Card:
        """在线充值 PPT 积分（对接 runtime.pay 模块）。"""
        identity = self._billing_identity(context)
        rate_val = float(self._cfg("credit_price_yuan") or 0.1)

        points_svc = await self._points()
        cur_bal = await points_svc.balance(identity) if points_svc else 0

        if not args:
            return self._card(
                "积分充值",
                f"# 💳 PPT 积分充值中心\n\n"
                f"> 当前账户积分余额：**{cur_bal}** 积分\n\n"
                f"* 充值比例：**1 积分 = ￥{rate_val:.2f} 元**\n"
                f"* 到账时效：付款后系统秒级自动入账\n"
                f"* 支持渠道：微信支付 / 支付宝扫码\n\n"
                f"---\n"
                f"💡 *点击下方常用面额快速创建订单，或点击【自定义充值】输入数量：*",
                rows=[
                    [
                        self._btn("充 10 积分", "/ppt pay 10", "primary"),
                        self._btn("充 50 积分", "/ppt pay 50"),
                        self._btn("充 100 积分", "/ppt pay 100"),
                    ],
                    [
                        self._btn("✏️ 自定义充值", "/ppt pay ", fill=True),
                        self._btn("🔍 查订单", "/ppt pay check"),
                        self._btn("📄 PPT 菜单", "/ppt"),
                    ],
                ],
            )

        sub = str(args[0]).lower()
        if sub in {"check", "order", "status", "query", "查询"}:
            order_id = args[1].strip() if len(args) > 1 else ""
            if not order_id:
                for oid, info in reversed(list(self.pending_pay_orders.items())):
                    if info.get("identity") == identity or info.get("user_id") == getattr(context, "sender_id", ""):
                        order_id = oid
                        break
            if not order_id:
                pay_api = getattr(self.context, "pay_api", None) or getattr(self.context, "builtin", lambda name: None)("runtime.pay")
                if pay_api and hasattr(pay_api, "get_latest_intent"):
                    try:
                        latest = await pay_api.get_latest_intent(identity)
                        if latest:
                            order_id = str(latest.get("id") or latest.get("trade_no") or "")
                    except Exception as e:
                        logger.debug("Failed to get latest pay intent: %s", e)
            if not order_id:
                return self._card("查询订单", "未指定订单号，且未找到最近的未完成充值订单。您可以发送 `/ppt pay 10` 创建新的充值订单。")

            pay_api = getattr(self.context, "pay_api", None) or getattr(self.context, "builtin", lambda name: None)("runtime.pay")
            if not pay_api or not hasattr(pay_api, "query_payment"):
                return self._card("查询订单", "支付查询服务未开启或暂不可用。")

            try:
                res = await asyncio.wait_for(pay_api.query_payment(order_id), timeout=5.0)
                status = str(res.get("local_status") or "")
                if status == "paid":
                    self.pending_pay_orders.pop(order_id, None)
                    self._save_pending_orders()
                    new_bal = await points_svc.balance(identity) if points_svc else cur_bal
                    return self._card(
                        "订单已支付",
                        f"# ✅ 充值支付成功\n\n"
                        f"> 订单号 `{order_id}` 已成功到账！\n\n"
                        f"* 充值状态：**已入账**\n"
                        f"* 当前积分余额：**{new_bal}** 积分\n\n"
                        f"🎉 祝您使用愉快，点击下方按钮即可立即开始生成 PPT！",
                        rows=[
                            [self._btn("开始生成 PPT", "/ppt make", "primary"), self._btn("充值中心", "/ppt pay")],
                            [self._btn("📄 PPT 主菜单", "/ppt")],
                        ],
                    )

                status_text = "待支付" if status in {"pending", "creating"} else status
                pay_url = (self.pending_pay_orders.get(order_id) or {}).get("pay_url", "")
                if not pay_url:
                    pay_url = res.get("pay_info") or res.get("pay_url") or res.get("qrcode") or ""
                row1 = []
                if pay_url and pay_url.startswith(("http://", "https://")):
                    row1.append(self._btn("💳 立即跳转付款", pay_url, "primary", action_type=0))
                row1.append(self._btn("🔍 刷新订单", f"/ppt pay check {order_id}"))
                return self._card(
                    "订单待支付",
                    f"# ⏳ 订单待支付中\n\n"
                    f"> 订单编号：`{order_id}`\n\n"
                    f"* 当前状态：**{status_text}**\n"
                    f"* 若您已付款，请稍候 2~3 秒后点击【🔍 刷新订单】自动对账；\n"
                    f"* 若未完成付款，请点击下方【💳 立即跳转付款】打开收银台完成支付。",
                    rows=[
                        row1,
                        [self._btn("充值中心", "/ppt pay"), self._btn("📄 PPT 菜单", "/ppt")],
                    ],
                )
            except Exception as e:
                return self._card("查询订单", f"查询订单 `{order_id}` 失败：{e}")

        try:
            points = int(args[0])
            if points <= 0 or points > 100000:
                return "充值积分数量需在 1 ~ 100,000 之间。"
        except ValueError:
            return "积分数量必须为正整数，例如 `/ppt pay 10`。"

        yuan_amount = round(points * rate_val, 2)
        if yuan_amount < 0.01:
            yuan_amount = 0.01

        pay_api = getattr(self.context, "pay_api", None) or getattr(self.context, "builtin", lambda name: None)("runtime.pay")
        if not pay_api or not hasattr(pay_api, "create_payment"):
            return "⚠️ 当前机器人未开启 567 在线支付功能或商户未配置。如需充值积分，请联系管理员。"

        try:
            ext_id = f"word2ppt_{getattr(context, 'sender_id', 'user')}_{int(time.time())}_{uuid.uuid4().hex[:6]}"
            order_info = await asyncio.wait_for(
                pay_api.create_payment(
                    source_plugin=PLUGIN_ID,
                    external_id=ext_id,
                    owner_key=identity,
                    user_id=identity,
                    subject=f"Word 转 PPT 积分充值 - {points} 积分",
                    amount=str(yuan_amount),
                    points=str(points),
                    point_type="default",
                    amount_yuan=yuan_amount,
                    point_count=points,
                    description=f"Word 转 PPT 积分充值 - {points} 积分",
                ),
                timeout=8.0,
            )
            order_id = str(order_info.get("order_id") or order_info.get("trade_no") or order_info.get("id") or "")
            pay_url = order_info.get("pay_url") or order_info.get("url") or order_info.get("pay_info") or order_info.get("qrcode") or ""
            real_amount = order_info.get("amount") or str(yuan_amount)

            if order_id and order_id != "-":
                self.pending_pay_orders[order_id] = {
                    "identity": identity,
                    "points": points,
                    "time": time.time(),
                    "pay_url": pay_url,
                }
                self._save_pending_orders()

            markdown = (
                f"# 💳 PPT 积分充值订单\n\n"
                f"> 订单已生成，30分钟内有效，支持微信与支付宝扫码。\n\n"
                f"* 充值数量：`{points}` 积分\n"
                f"* 应付金额：**￥{real_amount}** 元\n"
                f"* 订单号：`{order_id}`\n"
                f"* 订单状态：⏳ **待支付**\n\n"
                f"---\n"
                f"📱 **快捷付款指南**：\n"
                f"1. **跳转付款**：点击下方【💳 立即跳转付款】打开收银台直接支付；\n"
                f"2. **自动秒级到账**：付款完成后系统将自动秒级入账，无需手动确认；也可点击【🔍 查询订单】对账。"
            )
            row1 = []
            if pay_url and pay_url.startswith(("http://", "https://")):
                row1.append(self._btn("💳 立即跳转付款", pay_url, "primary", action_type=0))
            row1.append(self._btn("🔍 查询订单", f"/ppt pay check {order_id}"))
            rows = [
                row1,
                [self._btn("充值中心", "/ppt pay"), self._btn("📄 PPT 菜单", "/ppt")],
            ]
            return self._card("积分充值", markdown, rows=rows)
        except TimeoutError:
            return self._card(
                "积分充值",
                "# ⏳ 创建充值订单超时\n\n"
                "* 上游支付平台网关响应稍慢，可能订单正在生成中。\n"
                "* 请点击下方【🔍 检查最近订单】尝试认领，或稍候重试。",
                rows=[
                    [self._btn("🔍 检查最近订单", "/ppt pay check"), self._btn(f"重试充 {points} 积分", f"/ppt pay {points}")],
                    [self._btn("充值中心", "/ppt pay"), self._btn("📄 PPT 菜单", "/ppt")],
                ],
            )
        except Exception as error:
            logger.error("Word2PPT pay failed: %s", error)
            return f"创建充值订单失败：{error}"

    async def cmd_make(self, context: Any, args: list[str]) -> str | Card:
        return await self._start_generation(context, args, rebuild=True, kind="make")

    async def cmd_rebuild(self, context: Any, args: list[str]) -> str | Card:
        return await self._start_generation(context, args, rebuild=True, kind="rebuild")

    async def cmd_retry(self, context: Any, args: list[str]) -> str | Card:
        return await self._start_generation(context, args, rebuild=False, kind="retry")

    async def _start_generation(
        self, context: Any, args: list[str], *, rebuild: bool, kind: str, confirmed: bool = False
    ) -> str | Card:
        user_key = self.store.user_key(context)
        meta = self.store.current(user_key)
        if not meta:
            return "请先发送 .docx 文件，再使用 /ppt make。"
        if not self._cfg("enable_group") and context.scene == "group":
            return "当前管理员已关闭群聊使用。"
        if user_key in self.active:
            return "你有任务正在执行中，请等待完成或 /ppt cancel。"
        if not self._ai_ready():
            return "AI 接口尚未配置（api_base_url / api_key），请联系管理员在管理页设置。"
        scene = str(getattr(context, "scene", ""))
        if scene == "group" and not self._cfg("enable_group"):
            return "当前管理员已关闭群聊使用。"

        slide_count = int(self._cfg("default_slide_count") or 10)
        theme = self._cfg("available_themes")[0] if self._cfg("available_themes") else "research"
        if args and args[0].isdigit():
            slide_count = _clamp(int(args[0]), 3, 30)
            theme = args[1] if len(args) > 1 and args[1] in THEMES else theme
        elif args and args[0] in THEMES:
            theme = args[0]
        if theme not in THEMES:
            theme = "research"
        if len(self.active) >= int(self._cfg("max_concurrency") or 1):
            self.queue.add(meta["name"], user_key, kind, {"args": args, "slide_count": slide_count, "theme": theme})
            return "全局并发已满，任务已进入队列。/ppt queue 查看队列。"

        meta["prices"] = {k: self._cfg(f"{k}_credit_price") for k in ("outline", "script", "page", "image")}
        cost = self._price(meta, "make" if kind != "outline" else "outline", pages=slide_count)
        amount_int = math.ceil(cost)
        billing_enabled = bool(self._cfg("billing_enabled"))

        # 积分预检：未扣费前发现积分不足立即阻断，避免开启后台任务后才报错并发送矛盾提示
        if billing_enabled and amount_int > 0:
            points = await self._points()
            if points is not None:
                identity = self._billing_identity(context)
                balance = await points.balance(identity)
                if balance < amount_int:
                    self.confirmations.pop(user_key, None)
                    _save_json(self.data_dir / "confirmations.json", self.confirmations)
                    rows = [
                        [self._btn("💳 充值积分", "/ppt pay", "primary"), self._btn("取消", "/ppt confirm cancel", "danger")]
                    ]
                    return self._card(
                        "积分不足",
                        f"文件：{meta.get('filename')}\n"
                        f"页数：{slide_count}　主题：{theme}\n"
                        f"需要积分：{amount_int}，当前可用余额：{balance}\n\n"
                        "当前积分不足以生成此 PPT，请点击下方【💳 充值积分】或发送 /ppt pay 在线充值。",
                        rows,
                    )

        if not confirmed and kind != "retry":
            pending = self.confirmations.get(user_key)
            confirm_id = f"{kind}:{meta['name']}:{slide_count}:{theme}"
            if pending and pending.get("id") == confirm_id and time.time() - pending.get("at", 0) < CONFIRM_TTL:
                self.confirmations.pop(user_key, None)
                _save_json(self.data_dir / "confirmations.json", self.confirmations)
            else:
                self.confirmations[user_key] = {"id": confirm_id, "at": time.time()}
                _save_json(self.data_dir / "confirmations.json", self.confirmations)
                billing = f"预计积分 {amount_int}" if billing_enabled else "计费未开启"
                rows = [[self._btn("确认开始", "/ppt confirm", "primary"), self._btn("取消", "/ppt confirm cancel", "danger")]]
                return self._card("确认生成", f"文件：{meta.get('filename')}\n页数：{slide_count}　主题：{theme}\n{billing}\n\n确认后开始生成。", rows)

        meta["identity"] = user_key
        try:
            await self._reserve(context, meta, kind, cost)
        except Exception as error:
            return f"任务启动失败（预扣积分失败）：{error}"

        JobStore.update(meta, status="running", stage="queued", progress=5, stage_label="排队中", slide_count=slide_count, theme=theme)
        self.active[user_key] = meta["name"]
        asyncio.get_running_loop().create_task(self._pipeline(context, meta, slide_count, theme, rebuild, kind))
        return f"已开始制作 PPT（页数 {slide_count}，主题 {theme}），完成后自动发送文件。/ppt status 查看进度。"

    async def cmd_confirm(self, context: Any, args: list[str]) -> str | Card:
        user_key = self.store.user_key(context)
        pending = self.confirmations.pop(user_key, None)
        _save_json(self.data_dir / "confirmations.json", self.confirmations)
        if not pending:
            return "当前没有待确认的操作。可发送 /ppt make 重新发起。"
        if args and args[0].lower() in {"cancel", "取消"}:
            return "已取消生成任务。"
        if time.time() - pending.get("at", 0) > CONFIRM_TTL:
            return "确认已超时（有效时间 60 秒），请重新发送 /ppt make。"
        parts = pending["id"].split(":")
        kind = parts[0]
        job_name = parts[1]
        slide_count_str = parts[2] if len(parts) > 2 else ""
        theme = parts[3] if len(parts) > 3 else "research"
        theme_args = [slide_count_str, theme] if slide_count_str else []
        self.store.set_current(user_key, job_name)
        return await self._start_generation(
            context, theme_args, rebuild=(kind in {"make", "rebuild"}), kind=kind, confirmed=True
        )

    async def _pipeline(
        self,
        context: Any,
        meta: dict[str, Any],
        slide_count: int,
        theme: str,
        rebuild: bool,
        kind: str,
    ) -> None:
        job = Path(meta["dir"])
        try:
            JobStore.update(meta, stage="parsing", progress=10, stage_label="解析文档")
            content_path = job / "content.json"
            if not content_path.exists() or kind in {"make", "rebuild"}:
                parsed = parse_docx(str(job / "source.docx"), str(job / "images"))
                content_path.write_text(json.dumps(parsed, ensure_ascii=False), encoding="utf-8")
            content = _load_json(content_path, {})
            client = self._client()

            reserved = meta.get("billing_current")
            if reserved is None and self._cfg("billing_enabled"):
                reserved = await self._reserve(context, meta, kind, self._price(meta, "make" if kind != "outline" else "outline", pages=slide_count))

            outline_path = job / "outline.json"
            JobStore.update(meta, stage="outline", progress=25, stage_label="生成大纲")
            if not outline_path.exists() or kind in {"make", "rebuild"}:
                outline = await client.outline(content, slide_count, theme)
                outline_path.write_text(json.dumps(outline, ensure_ascii=False), encoding="utf-8")
            outline = _load_json(outline_path, {})

            JobStore.update(meta, stage="script", progress=45, stage_label="编写脚本")
            script_path = job / "generate_ppt.py"
            if rebuild or not script_path.exists():
                script = await client.script(content, outline, theme, {})
                script_path.write_text(script, encoding="utf-8")

            JobStore.update(meta, stage="render", progress=60, stage_label="生成 PPT")
            template_path = self._template_for(context, meta)
            result = await asyncio.to_thread(
                run_script,
                script_path.read_text(encoding="utf-8"),
                str(job),
                min(60, max(5, int(self._cfg("script_timeout_sec") or 60))),
                template_path or None,
            )
            output = job / "output.pptx"
            max_repairs = max(0, int(self._cfg("max_repair_attempts") or 2))
            repair_count = 0
            while (not output.exists() or output.stat().st_size < 1024) and repair_count < max_repairs:
                repair_count += 1
                err_text = ""
                if isinstance(result, dict):
                    err_text = str(result.get("error") or result.get("stderr") or result.get("stdout") or "").strip()
                JobStore.log(meta, "repair_attempt", attempt=repair_count, error=err_text[:300])
                JobStore.update(meta, stage="repair", progress=70, stage_label=f"修复脚本({repair_count}/{max_repairs})")
                try:
                    repaired_code = await client.repair(
                        content, outline, script_path.read_text(encoding="utf-8"), err_text, theme
                    )
                    script_path.write_text(repaired_code, encoding="utf-8")
                    result = await asyncio.to_thread(
                        run_script,
                        repaired_code,
                        str(job),
                        min(60, max(5, int(self._cfg("script_timeout_sec") or 60))),
                        template_path or None,
                    )
                except Exception as repair_err:
                    JobStore.log(meta, "repair_failed", error=str(repair_err)[:200])
                    break

            if not output.exists() or output.stat().st_size < 1024:
                error_msg = ""
                if isinstance(result, dict):
                    error_msg = str(result.get("error") or result.get("stderr") or result.get("stdout") or "").strip()
                raise RuntimeError(error_msg[-500:] if error_msg else "脚本未产出 PPT")

            pages_real = self._ppt_pages(output)
            if self._cfg("billing_enabled") and reserved:
                await self._settle(meta, self._price(meta, "make", pages=pages_real, images=int(meta.get("last_generated_image_count", 0))))

            if self._cfg("enable_speaker_notes"):
                try:
                    await self._generate_notes(meta, client, content, outline, theme, page=None)
                except Exception as error:
                    JobStore.log(meta, "notes_error", error=str(error)[:200])

            JobStore.update(meta, status="completed", stage="done", progress=100, stage_label="完成", pages=pages_real)
            JobStore.log(meta, "state", status="completed")
            await self._reply_text(context, f"PPT 已生成（{pages_real} 页），正在发送文件…")
            await self._send_file(context, output)
            await self._reply_text(context, f"「{meta.get('filename')}」转换完成。/ppt page 1 可重做单页。")
        except asyncio.CancelledError:
            await self._refund(meta)
            JobStore.update(meta, status="cancelled", stage_label="已取消")
            JobStore.log(meta, "cancel")
            await self._reply_text(context, "任务已取消，预扣积分已退回。")
        except Exception as error:
            await self._refund(meta)
            JobStore.update(meta, status="failed", stage_label="失败", error=str(error)[:400])
            JobStore.log(meta, "state", status="failed", error=str(error)[:200])
            logger.exception("ppt 任务失败")
            await self._reply_text(context, f"任务失败：{str(error)[:300]}")
        finally:
            self.active.pop(meta.get("identity") or "", None)
            self._dispatch_queue_soon()
            self._refresh_page_snapshot()

    @staticmethod
    def _ppt_pages(path: Path) -> int:
        try:
            from pptx import Presentation

            return len(Presentation(str(path)).slides)
        except Exception:
            return 0

    def _template_for(self, context: Any, meta: dict[str, Any]) -> str:
        user_key = self.store.user_key(context)
        selection = self.template_selections.get(user_key, "")
        if selection:
            base = self.data_dir / "public_templates" if selection.startswith("public/") else self.data_dir / "templates" / hashlib.sha256(user_key.encode()).hexdigest()[:24]
            path = base / selection.removeprefix("public/")
            if path.exists():
                return str(path)
        public_default = str(self._cfg("public_template_default") or "")
        if public_default:
            path = self.data_dir / "public_templates" / public_default
            if path.exists():
                return str(path)
        return ""

    async def _generate_notes(self, meta: dict[str, Any], client: AIClient, content: dict, outline: dict, theme: str, page: int | None) -> None:
        job = Path(meta["dir"])
        notes_path = job / "notes.json"
        notes = _load_json(notes_path, {"notes": []}).get("notes", [])
        payload = await client.speaker_notes(content, outline, theme, pages=notes)
        by_page = {int(n["page"]): n["text"] for n in payload.get("notes", [])}
        by_page.update({int(n["page"]): n["text"] for n in notes})
        merged = [{"page": p, "text": t} for p, t in sorted(by_page.items())]
        notes_path.write_text(json.dumps({"notes": merged}, ensure_ascii=False), encoding="utf-8")

    async def cmd_outline(self, context: Any, args: list[str]) -> str | Card:
        meta = self.store.current(self.store.user_key(context))
        if not meta:
            return "请先发送 .docx 文件。"
        if not self._ai_ready():
            return "AI 接口尚未配置。"
        outline_path = Path(meta["dir"]) / "outline.json"
        if outline_path.exists():
            outline = _load_json(outline_path, {})
        else:
            content = _load_json(Path(meta["dir"]) / "content.json", None)
            if content is None:
                parsed = parse_docx(str(Path(meta["dir"]) / "source.docx"), str(Path(meta["dir"]) / "images"))
                content_path = Path(meta["dir"]) / "content.json"
                content_path.write_text(json.dumps(parsed, ensure_ascii=False), encoding="utf-8")
                content = parsed
            outline = await self._client().outline(content, int(self._cfg("default_slide_count") or 10), "research")
            outline_path.write_text(json.dumps(outline, ensure_ascii=False), encoding="utf-8")
        slides = "\n".join(f"{i}. {s.get('title', '')}（{s.get('layout', '')}）" for i, s in enumerate(outline.get("slides", []), 1))
        return self._card("大纲预览", f"**{outline.get('title', '')}**\n\n{slides}", [[self._btn("开始生成", "/ppt make", "primary")]])

    async def cmd_status(self, context: Any, args: list[str]) -> Card | str:
        meta = self.store.current(self.store.user_key(context))
        if not meta:
            return "当前没有任务。先发送 .docx 文件。"
        text = (
            f"任务：{meta.get('filename')}\n状态：{meta.get('status')}　{meta.get('stage_label', '')}\n"
            f"进度：{meta.get('progress', 0)}%\n页数：{meta.get('pages', '-')}　主题：{meta.get('theme', '-')}"
        )
        return self._card("任务状态", text, [[self._btn("刷新", "/ppt status"), self._btn("主菜单", "/ppt")]])

    async def cmd_logs(self, context: Any, args: list[str]) -> str | Card:
        meta = self.store.current(self.store.user_key(context))
        if not meta:
            return "当前没有任务。"
        entries = _load_json(Path(meta["dir"]) / "job.log.jsonl", [])
        limit = _clamp(int(args[0]) if args and args[0].isdigit() else 20, 1, 50)
        recent = entries[-limit:]
        text = "\n".join(f"{e.get('time')} {e.get('event')} {json.dumps({k: v for k, v in e.items() if k not in {'time', 'event'}}, ensure_ascii=False)[:80]}" for e in recent)
        return self._card("任务日志", text or "暂无日志", [[self._btn("刷新", "/ppt logs"), self._btn("主菜单", "/ppt")]])

    async def cmd_cancel(self, context: Any, args: list[str]) -> str:
        meta = self.store.current(self.store.user_key(context))
        if not meta or meta.get("status") != "running":
            return "当前没有运行中的任务。"
        (Path(meta["dir"]) / "cancel.request").write_text("1", encoding="utf-8")
        return "已请求取消，任务将在当前步骤结束后停止并退款。"

    async def cmd_tasks(self, context: Any, args: list[str]) -> Card | str:
        user_key = self.store.user_key(context)
        if args and args[0] == "rm" and len(args) > 1:
            jobs = self.store.jobs_of(user_key)
            index = _clamp(int(args[1]) if args[1].isdigit() else 0, 1, max(len(jobs), 1))
            target = jobs[index - 1] if index <= len(jobs) else None
            if target:
                JobStore.delete(target)
                return f"任务 {index} 已删除。"
            return "编号不存在。"
        jobs = self.store.jobs_of(user_key)
        if not jobs:
            return "还没有任务。发送 .docx 文件开始。"
        shown_jobs = jobs[:4]
        lines = []
        for i, job in enumerate(jobs[:8], 1):
            lines.append(f"{i}. {job.get('filename', '-')} · {job.get('status')} · {job.get('filename')}")
        rows = [[self._btn(f"使用第{i}项", f"/ppt use {i}"), self._btn(f"删除第{i}项", f"/ppt tasks rm {i}", "danger")] for i in range(1, len(shown_jobs) + 1)]
        rows.append([self._btn("刷新任务", "/ppt tasks"), self._btn("主菜单", "/ppt")])
        return self._card("任务列表（最近 8 个）", "\n".join(lines), rows)

    async def cmd_use(self, context: Any, args: list[str]) -> str:
        jobs = self.store.jobs_of(self.store.user_key(context))
        index = _clamp(int(args[0]) if args and args[0].isdigit() else 0, 1, max(len(jobs), 1))
        if index > len(jobs):
            return "编号不存在。"
        self.store.set_current(self.store.user_key(context), jobs[index - 1]["name"])
        return f"已切换当前任务：{jobs[index - 1].get('filename')}。"

    async def cmd_task(self, context: Any, args: list[str]) -> str | Card:
        meta = self.store.current(self.store.user_key(context))
        if not meta:
            return "当前没有任务。"
        files = sorted(p.name for p in Path(meta["dir"]).iterdir() if p.is_file())
        return self._card("任务详情", f"文件：{meta.get('filename')}\n状态：{meta.get('status')} {meta.get('stage_label', '')}\n产物：{', '.join(f for f in files if f.startswith('output') or f == 'notes.json') or '尚无'}",
                          [[self._btn("状态", "/ppt status"), self._btn("主菜单", "/ppt")]])

    async def cmd_theme(self, context: Any, args: list[str]) -> Card:
        themes = self._cfg("available_themes") or list(THEMES)
        rows = [[self._btn(name, f"/ppt options theme {name}")] for name in themes]
        return self._card("可用主题", "点击切换默认主题（保存到个人偏好）。", rows)

    async def cmd_options(self, context: Any, args: list[str]) -> str:
        user_key = self.store.user_key(context)
        prefs = self.preferences.setdefault(user_key, {})
        if len(args) >= 2 and args[0] == "theme":
            prefs["theme"] = args[1]
            self.preferences[user_key] = prefs
            _save_json(self.data_dir / "user_preferences.json", self.preferences)
            return f"默认主题已切换为 {args[1]}。"
        if len(args) >= 2 and args[0] == "page":
            prefs["slide_count"] = _clamp(int(args[1]), 3, 30)
            self.preferences[user_key] = prefs
            _save_json(self.data_dir / "user_preferences.json", self.preferences)
            return f"默认页数已设置为 {prefs['slide_count']}。"
        return "用法：/ppt options page <页数> 或 /ppt options theme <主题>。"

    async def cmd_templates(self, context: Any, args: list[str]) -> str | Card:
        user_key = self.store.user_key(context)
        folder = self.data_dir / "templates" / hashlib.sha256(user_key.encode()).hexdigest()[:24]
        if args and args[0] == "off":
            self.template_selections.pop(user_key, None)
            _save_json(self.data_dir / "template_selections.json", self.template_selections)
            return "已取消个人模板，恢复内置布局。"
        if args and args[0] == "rm" and len(args) > 1:
            files = sorted(folder.glob("*.pptx"))
            index = _clamp(int(args[1]) if args[1].isdigit() else 0, 1, max(len(files), 1))
            if index <= len(files):
                files[index - 1].unlink(missing_ok=True)
                files[index - 1].with_suffix(".json").unlink(missing_ok=True)
                return f"模板 {index} 已删除。"
            return "编号不存在。"
        if args and args[0].isdigit():
            files = sorted(folder.glob("*.pptx"))
            index = _clamp(int(args[0]), 1, max(len(files), 1))
            if index <= len(files):
                self.template_selections[user_key] = files[index - 1].name
                _save_json(self.data_dir / "template_selections.json", self.template_selections)
                return f"默认模板已设为：{files[index - 1].name}。"
            return "编号不存在。"
        files = sorted(folder.glob("*.pptx")) if folder.exists() else []
        current = self.template_selections.get(user_key, "(内置布局)")
        lines = [f"当前：{current}"] + [f"{i}. {f.name}" for i, f in enumerate(files, 1)] or ["暂无个人模板，直接发送 .pptx 文件即可上传。"]
        rows = [[self._btn(f"用{i}", f"/ppt templates {i}"), self._btn(f"删{i}", f"/ppt templates rm {i}", "danger")] for i in range(1, len(files[:8]) + 1)]
        rows.append([self._btn("恢复内置", "/ppt templates off", "danger")])
        return self._card("我的模板", "\n".join(lines), rows)

    async def cmd_queue(self, context: Any, args: list[str]) -> str | Card:
        items = self.queue.all()
        if args and args[0] == "rm" and len(args) > 1 and args[1].isdigit():
            target = self.queue.get(args[1])
            if target:
                self.queue.update(args[1], status="cancelled")
                return f"队列项 {args[1]} 已取消。"
            return "队列编号不存在。"
        lines = [f"{item.get('id', '-')} · {item.get('job', '-')} · {item.get('command', '')} · {item.get('status', '')}" for item in items[:10]]
        return self._card("任务队列", "\n".join(lines) or "队列为空。", [])

    async def cmd_preview(self, context: Any, args: list[str]) -> str:
        if not self._cfg("enable_preview"):
            return "预览功能未开启（需要管理员启用 enable_preview 并在运行环境安装 LibreOffice/Poppler）。"
        return "预览生成依赖 LibreOffice/Poppler，当前运行环境暂未配置。"

    async def cmd_page(self, context: Any, args: list[str]) -> str:
        meta = self.store.current(self.store.user_key(context))
        if not meta or not (Path(meta["dir"]) / "output.pptx").exists():
            return "请先生成 PPT（/ppt make），再重做单页。"
        if not args or not args[0].isdigit():
            return "用法：/ppt page <页码>。"
        return f"单页重做（第 {args[0]} 页）需要 AI 配置就绪后执行；当前版本先复用 /ppt retry 全量重做。"

    async def cmd_pages(self, context: Any, args: list[str]) -> str | Card:
        meta = self.store.current(self.store.user_key(context))
        if not meta:
            return "当前没有任务。"
        pages = meta.get("pages") or self._ppt_pages(Path(meta["dir"]) / "output.pptx")
        if not pages:
            return "请先生成 PPT。"
        total_shown = min(pages, 6)
        all_btns = [self._btn(f"第{i}页", f"/ppt page {i}") for i in range(1, total_shown + 1)]
        rows = [all_btns[i : i + 3] for i in range(0, len(all_btns), 3)]
        rows.append([self._btn("返回任务详情", "/ppt task"), self._btn("主菜单", "/ppt")])
        return self._card("单页操作", f"共 {pages} 页，点击按钮重做对应页（展示前 {total_shown} 页）：", rows)

    async def cmd_notes(self, context: Any, args: list[str]) -> str:
        meta = self.store.current(self.store.user_key(context))
        if not meta:
            return "当前没有任务。"
        return "演讲备注将在生成 PPT 时自动写入（管理员开关 enable_speaker_notes）；单独重生成请用 /ppt retry。"

    async def cmd_images(self, context: Any, args: list[str]) -> str:
        if not self._cfg("enable_ai_images"):
            return "AI 配图未开启（管理员开关 enable_ai_images）。"
        return "AI 配图将在 /ppt make 生成时按大纲规划自动加入。"

    # ---------- 周期任务 ----------
    async def cleanup(self) -> None:
        removed = self.store.cleanup_expired(int(self._cfg("job_expire_hours") or 24), int(self._cfg("keep_completed_jobs") or 5))
        if removed:
            logger.info("word2ppt 清理过期任务 %d 个", removed)

    def _dispatch_queue_soon(self) -> None:
        pass  # 队列项由用户重新确认执行，见 cmd_queue

    async def dispatch_queue(self) -> None:
        self.queue.recover()

    def _refresh_page_snapshot(self) -> None:
        try:
            snapshot = self.page_overview_data()
            _save_json(self.data_dir / "page_overview.json", snapshot)
        except Exception as error:
            logger.debug("管理页快照写入失败: %s", error)

    async def admin_tick(self) -> None:
        """处理管理台写命令（config 保存），并刷新快照。"""
        commands_path = self.data_dir / "page_commands.json"
        commands = _load_json(commands_path, [])
        if commands:
            commands_path.unlink(missing_ok=True)
            for command in commands:
                if command.get("action") == "save_config":
                    self.save_config(command.get("payload") or {})
        self._refresh_page_snapshot()

    # ---------- 管理页数据（供 web.py /api/word2ppt/page/* 读取） ----------
    def page_overview_data(self) -> dict[str, Any]:
        self._reload_config()
        jobs = self.store.all_jobs()
        counts: dict[str, int] = {}
        for job in jobs:
            counts[job.get("status", "unknown")] = counts.get(job.get("status", "unknown"), 0) + 1
        has_key = bool(self._cfg("api_key"))
        cfg = {k: self.config.get(k) for k in CONFIG_DEFAULTS if k != "api_key"}
        cfg["api_key"] = "" if not has_key else "******"
        cfg["api_key_configured"] = has_key
        return {
            "total_jobs": len(jobs),
            "users": len({job.get("owner_key") for job in jobs}),
            "status_counts": counts,
            "config": cfg,
            "config_public": {k: self.config.get(k) for k in CONFIG_DEFAULTS if k != "api_key"},
            "api_key_configured": has_key,
            "schema": {
                "api_base_url": {"type": "str", "default": ""},
                "api_key": {"type": "str", "default": ""},
                "default_model": {"type": "str", "default": "gpt-4o-mini"},
                "billing_enabled": {"type": "bool", "default": False},
                "outline_credit_price": {"type": "float", "min": 0, "max": 1000, "default": 1.0},
                "page_credit_price": {"type": "float", "min": 0, "max": 1000, "default": 0.5},
                "enable_speaker_notes": {"type": "bool", "default": True},
                "enable_ai_images": {"type": "bool", "default": False},
                "image_model": {"type": "str", "default": ""},
                "max_concurrency": {"type": "int", "min": 1, "max": 10, "default": 1},
                "task_timeout_sec": {"type": "int", "min": 30, "max": 1800, "default": 600},
            },
            "labels": {
                "api_base_url": "大模型 API 地址",
                "api_key": "大模型 API Key",
                "default_model": "默认文本大模型",
                "billing_enabled": "启用积分计费扣减",
                "outline_credit_price": "大纲生成扣除积分",
                "page_credit_price": "单页 PPT 生成扣除积分",
                "enable_speaker_notes": "生成演讲者备注",
                "enable_ai_images": "启用 AI 配图",
                "image_model": "生图模型",
                "max_concurrency": "最大生成并发数",
                "task_timeout_sec": "任务超时时间（秒）",
            },
            "stats": {
                "总任务数": len(jobs),
                "独立用户数": len({job.get("owner_key") for job in jobs}),
                "已完成任务": counts.get("completed", 0),
                "失败任务": counts.get("failed", 0),
            },
            "service": {
                "LLM 配置状态": "已配置 API Key" if has_key else "未配置 API Key",
                "AI 配图状态": "已开启" if self.config.get("enable_ai_images") else "未开启",
                "插件版本": PLUGIN_VERSION,
            },
            "jobs": [
                {
                    **{k: job.get(k) for k in ("name", "filename", "owner_key", "status", "stage_label", "progress", "pages", "theme", "created_at")},
                    "has_pptx": bool(job.get("dir") and (Path(job["dir"]) / "output.pptx").is_file()),
                    "pptx_size": (Path(job["dir"]) / "output.pptx").stat().st_size if job.get("dir") and (Path(job["dir"]) / "output.pptx").is_file() else 0,
                    "has_outline": bool(job.get("dir") and (Path(job["dir"]) / "outline.json").is_file()),
                }
                for job in jobs[:50]
            ],
        }

    def page_save_config(self, payload: dict[str, Any]) -> dict[str, Any]:
        safe: dict[str, Any] = {}
        for key, value in (payload or {}).items():
            if key in CONFIG_DEFAULTS and key != "api_key":
                safe[key] = value
        if "default_model" in safe:
            safe["analysis_model"] = safe["default_model"]
        elif "analysis_model" in safe:
            safe["default_model"] = safe["analysis_model"]
        if isinstance(payload, dict) and str(payload.get("api_key") or "").strip():
            safe["api_key"] = str(payload["api_key"]).strip()
        self.save_config(safe)
        self._refresh_page_snapshot()
        return {"saved": True, "config": self.config, **self.page_overview_data()}

    async def on_page_action(self, action: str, payload: dict[str, Any]) -> Any:
        payload = payload or {}
        if action == "fetch_models":
            return await self.action_fetch_models(payload)
        if action == "save_config":
            return self.page_save_config(payload)
        if action in {"page_data", "data"}:
            return self.page_overview_data()
        if action in {"delete_job", "page_delete", "delete"}:
            name = str(
                payload.get("name")
                or payload.get("identifier")
                or payload.get("job_id")
                or payload.get("id")
                or ""
            ).strip()
            if not name:
                raise ValueError("缺少任务标识")
            # 安全检查：禁止路径遍历
            if "/" in name or "\\" in name or ".." in name:
                raise ValueError("无效的任务名称")
            jobs = self.store.all_jobs()
            target = next((j for j in jobs if j.get("name") == name), None)
            if target:
                self.store.delete(target)
            else:
                target_dir = self.data_dir / "jobs" / name
                if target_dir.is_dir():
                    shutil.rmtree(target_dir, ignore_errors=True)
                else:
                    raise ValueError(f"任务不存在: {name}")
            self._refresh_page_snapshot()
            return {"deleted": True, "name": name, **self.page_overview_data()}

        if action in {"job_detail", "preview"}:
            name = str(
                payload.get("name")
                or payload.get("identifier")
                or payload.get("job_id")
                or payload.get("id")
                or ""
            ).strip()
            if not name:
                raise ValueError("缺少任务标识")
            if "/" in name or "\\" in name or ".." in name:
                raise ValueError("无效的任务名称")
            job = next((j for j in self.store.all_jobs() if j.get("name") == name), None)
            job_dir = Path(job["dir"]) if job and job.get("dir") else None
            if not job_dir or not job_dir.is_dir():
                for cand in [self.data_dir / "jobs" / "jobs" / name, self.data_dir / "jobs" / name]:
                    if cand.is_dir():
                        job_dir = cand
                        break
            if not job_dir or not job_dir.is_dir():
                raise ValueError(f"任务不存在: {name}")
            meta = _load_json(job_dir / "meta.json", job or {})
            outline = _load_json(job_dir / "outline.json", None)
            has_pptx = (job_dir / "output.pptx").is_file()
            pptx_size = (job_dir / "output.pptx").stat().st_size if has_pptx else 0
            try:
                rel_path = job_dir.resolve().relative_to(self.data_dir.resolve()) / "output.pptx"
                download_rel = rel_path.as_posix()
            except Exception:
                download_rel = f"jobs/{name}/output.pptx"
            return {
                "ok": True,
                "name": name,
                "meta": meta,
                "outline": outline,
                "has_pptx": has_pptx,
                "pptx_size": pptx_size,
                "download_url": f"/api/plugin/plugin.word2ppt/media/{download_rel}",
            }
        raise ValueError(f"未知操作: {action}")

    async def action_fetch_models(self, payload: dict[str, Any]) -> dict[str, Any]:
        import httpx
        self._reload_config()
        target_field = str(
            (payload or {}).get("target")
            or (payload or {}).get("key")
            or (payload or {}).get("target_key")
            or ""
        ).strip()
        base = str((payload or {}).get("api_base_url") or "").strip().rstrip("/")
        key = str((payload or {}).get("api_key") or "").strip()
        if not base or not key:
            if "image" in target_field:
                base = base or str(self._cfg("image_api_base_url") or "").strip().rstrip("/")
                key = key or str(self._cfg("image_api_key") or "").strip()
            if not base:
                base = str(self._cfg("api_base_url") or "").strip().rstrip("/")
            if not key:
                key = str(self._cfg("api_key") or "").strip()
        if not base:
            raise ValueError("请先填写 API 地址（api_base_url）")
        if not key:
            raise ValueError("请先填写 API Key（接口密钥）后再获取模型")
        if base.casefold().endswith("/v1"):
            base = base[:-3].rstrip("/")

        headers = {"Authorization": f"Bearer {key}"}
        models: list[str] = []
        async with httpx.AsyncClient(timeout=15.0) as client:
            resp = None
            err_msg = ""
            for url in (f"{base}/v1/models", f"{base}/models"):
                try:
                    resp = await client.get(url, headers=headers)
                    if resp.status_code == 200 or resp.status_code in (401, 403):
                        break
                except Exception as e:
                    err_msg = str(e)
                    continue

            if resp is None or resp.status_code != 200:
                code = resp.status_code if resp else "timeout"
                err_detail = ""
                if resp:
                    try:
                        err_detail = resp.json().get("error", {}).get("message") or resp.text[:200]
                    except Exception:
                        err_detail = resp.text[:200]
                if code == 401:
                    hint = "上游接口认证失败 (HTTP 401)，请检查 API Key 是否正确"
                elif code == 403:
                    hint = "上游接口拒绝访问 (HTTP 403 Forbidden)"
                else:
                    hint = "无法连接到模型接口"
                raise RuntimeError(
                    f"获取模型失败 (HTTP {code}): {err_detail or hint or err_msg}"
                )

            try:
                data = resp.json()
                raw_list = data.get("data", []) if isinstance(data, dict) else (data if isinstance(data, list) else [])
                for item in raw_list:
                    if isinstance(item, dict) and "id" in item:
                        models.append(str(item["id"]))
                    elif isinstance(item, str):
                        models.append(item)
            except Exception as e:
                raise ValueError(f"解析模型列表失败: {e}") from e

        models = sorted(list(dict.fromkeys(models)))
        return {"models": models, "total": len(models)}


def setup(context: Any) -> Word2PptPlugin:
    plugin = Word2PptPlugin(context)
    context.register_command("ppt", plugin.handle_ppt, category="word2ppt", description="Word 转 PPT 主入口")
    context.register_command("w2p", plugin.handle_ppt, category="word2ppt", description="Word 转 PPT 快捷指令")
    context.register_event_handler("*", plugin.on_event)
    context.register_task("cleanup", 3600, plugin.cleanup)
    context.register_task("dispatch_queue", 20, plugin.admin_tick)
    if hasattr(context, "register_action"):
        context.register_action("fetch_models", plugin.action_fetch_models)
        context.register_action("save_config", plugin.page_save_config)
        context.register_action("page_data", plugin.on_page_action)
    return plugin
