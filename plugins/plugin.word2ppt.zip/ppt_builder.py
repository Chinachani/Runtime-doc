from __future__ import annotations

import os
from collections.abc import Sequence
from pathlib import Path
from typing import Any

from pptx import Presentation
from pptx.dml.color import RGBColor
from pptx.enum.shapes import MSO_SHAPE
from pptx.enum.text import MSO_ANCHOR, PP_ALIGN
from pptx.util import Inches, Pt

THEMES = {
    "research": {
        "bg": "F7F9FC",
        "accent": "1F5EFF",
        "text": "172033",
        "muted": "5C677D",
    },
    "business": {
        "bg": "FFFFFF",
        "accent": "173F5F",
        "text": "15202B",
        "muted": "52606D",
    },
    "teaching": {
        "bg": "FFFDF7",
        "accent": "D97706",
        "text": "292524",
        "muted": "78716C",
    },
    "clean": {"bg": "FFFFFF", "accent": "111827", "text": "111827", "muted": "6B7280"},
}


def _rgb(value: str) -> RGBColor:
    return RGBColor.from_string(value)


class Deck:
    """供 AI 生成脚本调用的受控 PPT API。"""

    def __init__(self, theme: str = "research", template_path: str = ""):
        self.theme_name = theme if theme in THEMES else "research"
        self.theme = THEMES[self.theme_name]
        selected_template = str(template_path or os.environ.get("PPT_TEMPLATE_PATH", "")).strip()
        self.template_path = Path(selected_template) if selected_template else None
        existing_path = str(os.environ.get("PPT_EXISTING_PATH", "")).strip()
        replace_page = str(os.environ.get("PPT_REPLACE_PAGE", "")).strip()
        self._replace_page = int(replace_page) if replace_page.isdigit() else 0
        self._existing_slide_count = 0
        self._single_page_mode = False
        self._page_slide_used = False
        if existing_path and Path(existing_path).is_file() and self._replace_page > 0:
            self.prs = Presentation(existing_path)
            self._existing_slide_count = len(self.prs.slides)
            if self._replace_page > self._existing_slide_count:
                raise ValueError(f"替换页码超出范围：1-{self._existing_slide_count}")
            self._single_page_mode = True
        elif self.template_path and self.template_path.is_file():
            self.prs = Presentation(str(self.template_path))
            # 删除模板示例页，但保留模板的主题、母版、布局和页面比例。
            for slide in list(self.prs.slides):
                slide_id = slide.slide_id
                slide_part = self.prs.part
                slide_id_list = self.prs.slides._sldIdLst
                for item in list(slide_id_list):
                    if int(item.id) == slide_id:
                        slide_id_list.remove(item)
                        slide_part.drop_rel(item.rId)
                        break
        else:
            self.prs = Presentation()
            self.prs.slide_width = Inches(13.333)
            self.prs.slide_height = Inches(7.5)
        self._blank_layout = self._find_blank_layout()

    def _remove_slide(self, index: int):
        slides = list(self.prs.slides)
        if index < 0 or index >= len(slides):
            return
        slide = slides[index]
        slide_id_list = self.prs.slides._sldIdLst
        for item in list(slide_id_list):
            if int(item.id) == slide.slide_id:
                slide_id_list.remove(item)
                self.prs.part.drop_rel(item.rId)
                break

    def _find_blank_layout(self):
        for layout in self.prs.slide_layouts:
            name = str(getattr(layout, "name", "")).lower()
            if "blank" in name or "空白" in name:
                return layout
        return self.prs.slide_layouts[6 if len(self.prs.slide_layouts) > 6 else -1]

    def _slide(self):
        if self._single_page_mode:
            # 单页模式直接清空并复用目标页，避免 python-pptx 删除/新增 slide
            # 时产生重复 slide XML 或破坏图片、超链接关系。
            slide = self.prs.slides[self._replace_page - 1]
            if not self._page_slide_used:
                shape_tree = slide.shapes._spTree
                for child in list(shape_tree)[2:]:
                    shape_tree.remove(child)
                self._page_slide_used = True
            return slide
        slide = self.prs.slides.add_slide(self._blank_layout)
        if not self.template_path:
            fill = slide.background.fill
            fill.solid()
            fill.fore_color.rgb = _rgb(self.theme["bg"])
        return slide

    def _box(
        self,
        slide,
        left: float,
        top: float,
        width: float,
        height: float,
        text: str = "",
        size: int = 24,
        color: str | None = None,
        bold: bool = False,
        align=PP_ALIGN.LEFT,
    ):
        shape = slide.shapes.add_textbox(
            Inches(left), Inches(top), Inches(width), Inches(height)
        )
        frame = shape.text_frame
        frame.clear()
        frame.word_wrap = True
        frame.margin_left = Inches(0.08)
        frame.margin_right = Inches(0.08)
        frame.margin_top = Inches(0.04)
        frame.margin_bottom = Inches(0.04)
        frame.vertical_anchor = MSO_ANCHOR.MIDDLE
        paragraph = frame.paragraphs[0]
        paragraph.alignment = align
        run = paragraph.add_run()
        run.text = str(text)
        run.font.name = "Microsoft YaHei"
        run.font.size = Pt(size)
        run.font.bold = bold
        run.font.color.rgb = _rgb(color or self.theme["text"])
        return shape

    def _header(self, slide, title: str, subtitle: str = ""):
        self._box(slide, 0.65, 0.42, 12.0, 0.65, title, 28, bold=True)
        if subtitle:
            self._box(slide, 0.68, 1.05, 11.8, 0.35, subtitle, 12, self.theme["muted"])
        line = slide.shapes.add_shape(
            MSO_SHAPE.RECTANGLE, Inches(0.68), Inches(1.48), Inches(1.25), Inches(0.06)
        )
        line.fill.solid()
        line.fill.fore_color.rgb = _rgb(self.theme["accent"])
        line.line.fill.background()

    def add_title(self, title: str, subtitle: str = ""):
        slide = self._slide()
        self._box(
            slide, 0.85, 2.25, 11.7, 1.3, title, 34, bold=True, align=PP_ALIGN.CENTER
        )
        if subtitle:
            self._box(
                slide,
                1.0,
                3.65,
                11.3,
                0.6,
                subtitle,
                18,
                self.theme["muted"],
                align=PP_ALIGN.CENTER,
            )
        self._box(
            slide,
            1.0,
            6.55,
            11.3,
            0.3,
            "AI 辅助生成 · Word 转 PPT",
            10,
            self.theme["muted"],
            align=PP_ALIGN.CENTER,
        )

    def add_bullets(self, title: str, items: Sequence[str], subtitle: str = ""):
        slide = self._slide()
        self._header(slide, title, subtitle)
        box = slide.shapes.add_textbox(
            Inches(0.95), Inches(1.9), Inches(11.4), Inches(4.8)
        )
        frame = box.text_frame
        frame.clear()
        frame.word_wrap = True
        for index, item in enumerate(list(items)[:8]):
            paragraph = frame.paragraphs[0] if index == 0 else frame.add_paragraph()
            paragraph.text = f"• {item!s}"
            paragraph.level = 0
            paragraph.space_after = Pt(14)
            for run in paragraph.runs:
                run.font.name = "Microsoft YaHei"
                run.font.size = Pt(22)
                run.font.color.rgb = _rgb(self.theme["text"])

    def add_two_column(
        self,
        title: str,
        left_title: str,
        left_items: Sequence[str],
        right_title: str,
        right_items: Sequence[str],
    ):
        slide = self._slide()
        self._header(slide, title)
        for x, heading, items in (
            (0.8, left_title, left_items),
            (6.85, right_title, right_items),
        ):
            card = slide.shapes.add_shape(
                MSO_SHAPE.ROUNDED_RECTANGLE,
                Inches(x),
                Inches(1.9),
                Inches(5.65),
                Inches(4.7),
            )
            card.fill.solid()
            card.fill.fore_color.rgb = _rgb("FFFFFF")
            card.line.color.rgb = _rgb("E5E7EB")
            self._box(
                slide,
                x + 0.3,
                2.2,
                5.0,
                0.45,
                heading,
                19,
                self.theme["accent"],
                bold=True,
            )
            for i, item in enumerate(list(items)[:6]):
                self._box(slide, x + 0.35, 2.85 + i * 0.52, 5.0, 0.42, f"• {item}", 15)

    @staticmethod
    def _process_text(item: Any) -> str:
        """将 AI 常见的二元组/字典步骤转成可读文本，避免把 Python repr 写进 PPT。"""
        if isinstance(item, (list, tuple)) and len(item) >= 2:
            title = str(item[0] or "").strip()
            detail = str(item[1] or "").strip()
            return f"{title}：{detail}".strip("：")
        if isinstance(item, dict):
            title = str(item.get("title") or item.get("name") or item.get("step") or "").strip()
            detail = str(
                item.get("description")
                or item.get("detail")
                or item.get("content")
                or ""
            ).strip()
            return f"{title}：{detail}".strip("：")
        return str(item or "").strip()

    def add_process(self, title: str, steps: Sequence[str]):
        slide = self._slide()
        self._header(slide, title)
        values = [self._process_text(item) for item in list(steps)[:6]]
        width = 11.6 / max(1, len(values))
        for i, item in enumerate(values):
            x = 0.85 + i * width
            shape = slide.shapes.add_shape(
                MSO_SHAPE.ROUNDED_RECTANGLE,
                Inches(x),
                Inches(3.0),
                Inches(width - 0.18),
                Inches(1.25),
            )
            shape.fill.solid()
            shape.fill.fore_color.rgb = _rgb(
                self.theme["accent"] if i == 0 else "E8EEFF"
            )
            shape.line.color.rgb = _rgb(self.theme["accent"])
            self._box(
                slide,
                x + 0.06,
                3.25,
                width - 0.3,
                0.72,
                item,
                14,
                "FFFFFF" if i == 0 else self.theme["text"],
                bold=True,
                align=PP_ALIGN.CENTER,
            )
            if i < len(values) - 1:
                self._box(
                    slide,
                    x + width - 0.15,
                    3.35,
                    0.25,
                    0.35,
                    "→",
                    20,
                    self.theme["accent"],
                    bold=True,
                    align=PP_ALIGN.CENTER,
                )

    def add_table(
        self, title: str, headers: Sequence[str], rows: Sequence[Sequence[str]]
    ):
        slide = self._slide()
        self._header(slide, title)
        safe_headers = list(headers)[:8] or ["内容"]
        data = [safe_headers] + [list(row) for row in list(rows)[:8]]
        table = slide.shapes.add_table(
            len(data),
            len(safe_headers),
            Inches(0.75),
            Inches(1.95),
            Inches(11.85),
            Inches(4.7),
        ).table
        for col in range(len(safe_headers)):
            table.columns[col].width = Inches(11.85 / len(safe_headers))
        for r, row in enumerate(data):
            for c in range(len(safe_headers)):
                cell = table.cell(r, c)
                cell.text = str(row[c] if c < len(row) else "")
                cell.fill.solid()
                cell.fill.fore_color.rgb = _rgb(
                    self.theme["accent"] if r == 0 else "FFFFFF"
                )
                for paragraph in cell.text_frame.paragraphs:
                    paragraph.alignment = PP_ALIGN.CENTER
                    for run in paragraph.runs:
                        run.font.name = "Microsoft YaHei"
                        run.font.size = Pt(13)
                        run.font.color.rgb = _rgb(
                            "FFFFFF" if r == 0 else self.theme["text"]
                        )
                        run.font.bold = r == 0

    def add_image_text(
        self, title: str, image_path: str, items: Sequence[str] = (), caption: str = ""
    ):
        """将 Word 原图与要点并排放置；图片必须来自当前任务目录。"""
        slide = self._slide()
        self._header(slide, title, caption)
        source = Path(image_path)
        if not source.is_file():
            self.add_bullets(title, items, "图片不可用，已降级为文字页")
            return
        slide.shapes.add_picture(
            str(source),
            Inches(0.75),
            Inches(1.9),
            width=Inches(5.8),
            height=Inches(4.7),
        )
        card = slide.shapes.add_shape(
            MSO_SHAPE.ROUNDED_RECTANGLE,
            Inches(6.85),
            Inches(1.9),
            Inches(5.65),
            Inches(4.7),
        )
        card.fill.solid()
        card.fill.fore_color.rgb = _rgb("FFFFFF")
        card.line.color.rgb = _rgb("E5E7EB")
        for i, item in enumerate(list(items)[:7]):
            self._box(slide, 7.15, 2.25 + i * 0.55, 5.05, 0.42, f"• {item}", 16)

    def add_summary(
        self, title: str, items: Sequence[str], subtitle: str = ""
    ):
        self.add_bullets(title, items, subtitle=subtitle)

    def save(self, path: str | Path):
        target = Path(path)
        target.parent.mkdir(parents=True, exist_ok=True)
        if self._single_page_mode and (
            len(self.prs.slides) != self._existing_slide_count or not self._page_slide_used
        ):
            # 单页脚本只能复用并更新目标页，不能新增或删除页面。
            raise ValueError("单页脚本必须且只能生成 1 页")
        self.prs.save(str(target))
