"""Word container detection used before invoking LibreOffice."""

from __future__ import annotations

import zipfile
from pathlib import Path

# OLE Compound File signature used by legacy binary .doc documents.
_OLE_MAGIC = b"\xd0\xcf\x11\xe0\xa1\xb1\x1a\xe1"


def detect_word_format(path: str | Path) -> str | None:
    """Return ``doc``/``docx`` from file content, or None for invalid data."""
    source = Path(path)
    try:
        if not source.is_file() or source.stat().st_size < 8:
            return None
        with source.open("rb") as handle:
            header = handle.read(8)
        if header == _OLE_MAGIC:
            return "doc"
        if header[:2] == b"PK" and zipfile.is_zipfile(source):
            return "docx"
    except (OSError, zipfile.BadZipFile):
        return None
    return None
