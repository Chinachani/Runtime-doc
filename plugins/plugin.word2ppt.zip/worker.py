from __future__ import annotations

import argparse
import json
import os
import signal
import subprocess
import sys
from pathlib import Path

_child: subprocess.Popen[str] | None = None


def _kill_child() -> None:
    if _child is None or _child.poll() is not None:
        return
    try:
        _child.terminate()
    except (OSError, ProcessLookupError):
        pass
    try:
        _child.kill()
    except (OSError, ProcessLookupError):
        pass


def _stop_on_signal(_signum: int, _frame) -> None:
    _kill_child()
    raise SystemExit(143)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--job", required=True)
    parser.add_argument("--timeout", type=int, default=60)
    parser.add_argument("--template", default="")
    parser.add_argument("--existing", default="")
    parser.add_argument("--replace-page", type=int, default=0)
    args = parser.parse_args()
    job = Path(args.job).resolve()
    script = job / "generate_ppt.py"
    output = job / "output.pptx"
    pid_file = job / "worker.pid"
    if not script.is_file():
        print(json.dumps({"ok": False, "error": "Worker 找不到生成脚本"}, ensure_ascii=False))
        return 2
    pid_file.write_text(str(os.getpid()), encoding="ascii")
    signal.signal(signal.SIGTERM, _stop_on_signal)
    signal.signal(signal.SIGINT, _stop_on_signal)
    env = {
        "PATH": os.environ.get("PATH", ""),
        "PYTHONPATH": os.pathsep.join([str(Path(__file__).resolve().parent), str(job)]),
        "PPT_JOB_DIR": str(job),
        "PYTHONNOUSERSITE": "1",
    }
    if args.template and Path(args.template).is_file():
        env["PPT_TEMPLATE_PATH"] = str(Path(args.template).resolve())
    if args.existing and args.replace_page > 0 and Path(args.existing).is_file():
        env["PPT_EXISTING_PATH"] = str(Path(args.existing).resolve())
        env["PPT_REPLACE_PAGE"] = str(args.replace_page)
    global _child
    try:
        _child = subprocess.Popen(
            [sys.executable, str(script)],
            cwd=str(job),
            env=env,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            start_new_session=False,
        )
        try:
            stdout, stderr = _child.communicate(timeout=min(60, max(5, int(args.timeout))))
        except subprocess.TimeoutExpired:
            _kill_child()
            stdout, stderr = _child.communicate()
            print(json.dumps({"ok": False, "error": "脚本执行超时", "stdout": stdout[-4000:], "stderr": stderr[-4000:]}, ensure_ascii=False))
            return 124
        if _child.returncode != 0:
            print(json.dumps({"ok": False, "error": (stderr or stdout or "脚本执行失败")[-6000:], "stdout": stdout[-4000:], "stderr": stderr[-4000:]}, ensure_ascii=False))
            return _child.returncode or 1
        if not output.is_file() or output.stat().st_size < 1024:
            print(json.dumps({"ok": False, "error": "脚本未生成有效 output.pptx", "stdout": stdout[-4000:], "stderr": stderr[-4000:]}, ensure_ascii=False))
            return 1
        print(json.dumps({"ok": True, "path": str(output), "stdout": stdout[-4000:], "stderr": stderr[-4000:]}, ensure_ascii=False))
        return 0
    finally:
        pid_file.unlink(missing_ok=True)
        _child = None


if __name__ == "__main__":
    raise SystemExit(main())
