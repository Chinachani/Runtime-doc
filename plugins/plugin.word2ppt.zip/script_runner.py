from __future__ import annotations

import ast
import json
import os
import subprocess
import sys
from pathlib import Path
from typing import Any


class ScriptSafetyError(ValueError):
    pass


ALLOWED_IMPORTS = {"ppt_builder", "pathlib", "json"}
FORBIDDEN_NAMES = {
    "eval",
    "exec",
    "compile",
    "__import__",
    "open",
    "input",
    "breakpoint",
}
FORBIDDEN_ATTRIBUTES = {
    "read_text",
    "write_text",
    "read_bytes",
    "write_bytes",
    "unlink",
    "rename",
    "replace",
    "rmdir",
    "mkdir",
    "chmod",
    "lchmod",
    "symlink_to",
    "hardlink_to",
    "resolve",
    "absolute",
    "glob",
    "rglob",
}
ALLOWED_DECK_METHODS = {
    "add_title",
    "add_bullets",
    "add_two_column",
    "add_process",
    "add_table",
    "add_image_text",
    "add_summary",
    "save",
}


class _SafetyVisitor(ast.NodeVisitor):
    def visit_Import(self, node):
        for alias in node.names:
            root = alias.name.split(".", 1)[0]
            if root not in ALLOWED_IMPORTS:
                raise ScriptSafetyError(f"禁止导入模块：{alias.name}")
        self.generic_visit(node)

    def visit_ImportFrom(self, node):
        if not node.module or node.module.split(".", 1)[0] not in ALLOWED_IMPORTS:
            raise ScriptSafetyError(f"禁止导入模块：{node.module}")
        self.generic_visit(node)

    def visit_Call(self, node):
        if isinstance(node.func, ast.Name) and node.func.id in FORBIDDEN_NAMES:
            raise ScriptSafetyError(f"禁止调用：{node.func.id}")
        if (
            isinstance(node.func, ast.Attribute)
            and node.func.attr in FORBIDDEN_ATTRIBUTES
        ):
            raise ScriptSafetyError(f"禁止调用文件操作：{node.func.attr}")
        self.generic_visit(node)

    def visit_Attribute(self, node):
        if str(node.attr).startswith("__") or node.attr in FORBIDDEN_ATTRIBUTES:
            raise ScriptSafetyError(f"禁止访问属性：{node.attr}")
        self.generic_visit(node)

    def visit_Name(self, node):
        if node.id in FORBIDDEN_NAMES:
            raise ScriptSafetyError(f"禁止使用名称：{node.id}")
        self.generic_visit(node)


def validate_script(code: str) -> None:
    try:
        tree = ast.parse(code, mode="exec")
    except SyntaxError as exc:
        raise ScriptSafetyError(f"脚本语法错误：{exc.msg}") from exc
    _SafetyVisitor().visit(tree)
    if "ppt_builder" not in code:
        raise ScriptSafetyError("脚本必须使用 ppt_builder")
    if not any(
        isinstance(node, ast.Call)
        and isinstance(node.func, ast.Attribute)
        and node.func.attr == "save"
        for node in ast.walk(tree)
    ):
        raise ScriptSafetyError("脚本必须调用 Deck.save 生成文件")


def run_script(
    code: str,
    job_dir: str | Path,
    timeout_sec: int = 60,
    template_path: str | Path | None = None,
    existing_pptx: str | Path | None = None,
    replace_page: int | None = None,
) -> dict[str, Any]:
    validate_script(code)
    job = Path(job_dir).resolve()
    job.mkdir(parents=True, exist_ok=True)
    script_path = job / "generate_ppt.py"
    output_path = job / "output.pptx"
    script_path.write_text(code, encoding="utf-8")
    output_path.unlink(missing_ok=True)
    plugin_dir = Path(__file__).resolve().parent
    worker = plugin_dir / "worker.py"
    command = [
        sys.executable, str(worker), "--job", str(job),
        "--timeout", str(min(60, max(5, int(timeout_sec)))),
    ]
    if template_path and Path(template_path).is_file():
        command.extend(["--template", str(Path(template_path).resolve())])
    if existing_pptx and replace_page and int(replace_page) > 0:
        command.extend(["--existing", str(Path(existing_pptx).resolve()), "--replace-page", str(int(replace_page))])
    env = {
        "PATH": os.environ.get("PATH", ""),
        "PYTHONPATH": os.pathsep.join([str(plugin_dir), str(job)]),
        "PYTHONNOUSERSITE": "1",
    }
    try:
        process = subprocess.Popen(
            command,
            cwd=str(job),
            env=env,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            start_new_session=False,
        )
        try:
            stdout, stderr = process.communicate(timeout=min(75, max(15, int(timeout_sec) + 10)))
        except subprocess.TimeoutExpired:
            try:
                process.terminate()
            except (OSError, ProcessLookupError):
                pass
            try:
                process.kill()
            except (OSError, ProcessLookupError):
                pass
            stdout, stderr = process.communicate()
            return {"ok": False, "error": "Worker 执行超时", "stdout": (stdout or "")[-4000:], "stderr": (stderr or "")[-4000:]}
    except OSError as exc:
        return {"ok": False, "error": f"Worker 启动失败：{type(exc).__name__} ({exc})"}
    raw = (stdout or "").strip().splitlines()
    payload: dict[str, Any] = {}
    if raw:
        try:
            value = json.loads(raw[-1])
            if isinstance(value, dict):
                payload = value
        except (TypeError, ValueError):
            pass
    if not payload:
        return {"ok": False, "error": (stderr or stdout or "Worker 未返回结果")[-6000:]}
    return payload

