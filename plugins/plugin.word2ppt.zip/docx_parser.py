from __future__ import annotations

import hashlib
import mimetypes
from pathlib import Path
from typing import Any

from docx import Document


def _clean(text: Any) -> str:
    return " ".join(str(text or "").replace("\u00a0", " ").split())


def _image_suffix(content_type: str) -> str:
    suffix = mimetypes.guess_extension(content_type or "") or ".bin"
    return ".jpg" if suffix == ".jpe" else suffix


def _has_numbering(paragraph: Any) -> bool:
    xml = str(getattr(getattr(paragraph, "_p", None), "xml", ""))
    return "<w:numPr" in xml or ":numPr" in xml


def parse_docx(path: str | Path, output_dir: str | Path) -> dict[str, Any]:
    """解析 docx 的可用结构；复杂视觉布局由后续 PDF/截图阶段处理。"""
    source = Path(path)
    target = Path(output_dir)
    target.mkdir(parents=True, exist_ok=True)
    images_dir = target / "images"
    images_dir.mkdir(parents=True, exist_ok=True)
    document = Document(str(source))

    headings: list[dict[str, Any]] = []
    paragraphs: list[dict[str, Any]] = []
    lists: list[dict[str, Any]] = []
    for index, paragraph in enumerate(document.paragraphs, 1):
        text = _clean(paragraph.text)
        if not text:
            continue
        style = _clean(getattr(paragraph.style, "name", ""))
        level = 0
        if style.lower().startswith("heading"):
            try:
                level = int(style.rsplit(" ", 1)[-1])
            except (TypeError, ValueError):
                level = 1
        item = {"index": index, "text": text, "style": style, "level": level}
        if level:
            headings.append(item)
        elif "list" in style.lower() or _has_numbering(paragraph):
            item["list_level"] = level
            lists.append(item)
        else:
            paragraphs.append(item)

    tables: list[dict[str, Any]] = []
    for table_index, table in enumerate(document.tables, 1):
        rows = [[_clean(cell.text) for cell in row.cells] for row in table.rows]
        rows = [row for row in rows if any(row)]
        if not rows:
            continue
        tables.append(
            {
                "index": table_index,
                "headers": rows[0],
                "rows": rows[1:],
                "all_rows": rows,
            }
        )

    images: list[dict[str, Any]] = []
    seen: set[str] = set()
    for rel in document.part.rels.values():
        # 超链接等 External relationship 没有 target_part；直接访问会抛出
        # ValueError（python-docx 的 Relationship.target_part 约束），不能
        # 让这类正常的 Word 外链阻断整份文档解析。
        if bool(getattr(rel, "is_external", False)):
            continue
        target_ref = str(getattr(rel, "target_ref", "")).lower()
        try:
            target_part = rel.target_part
        except (KeyError, AttributeError, ValueError):
            continue
        content_type = str(getattr(target_part, "content_type", "")).lower()
        if "image" not in target_ref and "image" not in content_type:
            continue
        blob = getattr(target_part, "blob", b"")
        if not blob:
            continue
        digest = hashlib.sha256(blob).hexdigest()[:16]
        if digest in seen:
            continue
        seen.add(digest)
        suffix = _image_suffix(content_type)
        image_path = images_dir / f"image_{len(images) + 1:03d}_{digest}{suffix}"
        image_path.write_bytes(blob)
        images.append(
            {
                "index": len(images) + 1,
                "path": str(image_path.relative_to(target)),
                "relative_path": str(image_path.relative_to(target)),
                "content_type": content_type,
                "sha256": hashlib.sha256(blob).hexdigest(),
            }
        )

    all_blocks = [item["text"] for item in headings + paragraphs + lists]
    raw_text = "\n".join(all_blocks)
    title = (
        headings[0]["text"]
        if headings
        else (paragraphs[0]["text"] if paragraphs else source.stem)
    )
    return {
        "filename": source.name,
        "title": title,
        "headings": headings,
        "paragraphs": paragraphs,
        "lists": lists,
        "tables": tables,
        "images": images,
        "raw_text": raw_text,
        "statistics": {
            "characters": len(raw_text),
            "paragraph_count": len(paragraphs),
            "heading_count": len(headings),
            "list_count": len(lists),
            "table_count": len(tables),
            "image_count": len(images),
        },
    }
