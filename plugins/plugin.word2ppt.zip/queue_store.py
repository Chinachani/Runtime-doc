from __future__ import annotations

import json
import threading
import time
import uuid
from pathlib import Path
from typing import Any


class QueueStore:
    """小型持久化队列；只保存任务元数据，不保存事件对象或敏感令牌。"""

    def __init__(self, path: Path):
        self.path = path
        self.lock = threading.RLock()
        self.entries: list[dict[str, Any]] = self._load()

    def _load(self) -> list[dict[str, Any]]:
        try:
            value = json.loads(self.path.read_text(encoding="utf-8"))
            return [item for item in value if isinstance(item, dict)] if isinstance(value, list) else []
        except (OSError, ValueError, TypeError):
            return []

    def save(self) -> None:
        with self.lock:
            self.path.parent.mkdir(parents=True, exist_ok=True)
            temporary = self.path.with_name(f".{self.path.name}.{uuid.uuid4().hex}.tmp")
            temporary.write_text(json.dumps(self.entries, ensure_ascii=False, indent=2), encoding="utf-8")
            temporary.replace(self.path)

    def recover(self) -> int:
        changed = 0
        with self.lock:
            for entry in self.entries:
                if entry.get("status") == "running":
                    entry.update({"status": "queued", "updated_at": time.time(), "recovered": True})
                    changed += 1
            if changed:
                self.save()
        return changed

    def add(self, job: str, owner_key: str, command: str, params: dict[str, Any] | None = None) -> dict[str, Any]:
        with self.lock:
            entry = {"id": f"q_{int(time.time())}_{uuid.uuid4().hex[:8]}", "job": job, "owner_key": owner_key, "command": command, "params": dict(params or {}), "status": "queued", "created_at": time.time(), "updated_at": time.time()}
            self.entries.append(entry)
            self.entries = self.entries[-500:]
            self.save()
            return dict(entry)

    def get(self, entry_id: str) -> dict[str, Any] | None:
        with self.lock:
            return next((dict(item) for item in self.entries if item.get("id") == entry_id), None)

    def update(self, entry_id: str, **fields: Any) -> dict[str, Any] | None:
        with self.lock:
            for item in self.entries:
                if item.get("id") == entry_id:
                    item.update(fields)
                    item["updated_at"] = time.time()
                    self.save()
                    return dict(item)
        return None

    def queued(self) -> list[dict[str, Any]]:
        with self.lock:
            return [dict(item) for item in self.entries if item.get("status") == "queued"]

    def all(self, limit: int = 100) -> list[dict[str, Any]]:
        with self.lock:
            return [dict(item) for item in self.entries[-max(1, min(500, limit)):]][::-1]
