"""Strict attachment routing for the Word-to-PPT plugin.

The platform may expose both a filename and a download URL.  Routing must use
an explicitly declared attachment name/path/URL suffix, never the message text
or a generic URL, so unrelated images and files are ignored silently.
"""

from __future__ import annotations

from collections.abc import Iterable
from pathlib import Path
from typing import Any
from urllib.parse import urlsplit

_NAME_KEYS = {"name", "file_name", "filename", "display_name"}
_PATH_KEYS = {"path", "file_path", "filepath", "local_path", "file", "file_"}
_URL_KEYS = {"url", "download_url", "downloadurl", "src", "file_url", "resource_url"}
_KEYS = _NAME_KEYS | _PATH_KEYS | _URL_KEYS


def attachment_suffix(value: str) -> str:
    """Return the final lowercase suffix from a filename, path, or URL."""
    clean = str(value or "").split("?", 1)[0].split("#", 1)[0].strip()
    if not clean:
        return ""
    if clean.startswith("//"):
        clean = "https:" + clean
    if clean.startswith(("http://", "https://")):
        clean = urlsplit(clean).path
    return Path(clean).suffix.casefold()


def _walk(value: Any, seen: set[int] | None = None, depth: int = 0) -> Iterable[tuple[str, Any]]:
    if depth > 6 or value is None:
        return
    seen = seen or set()
    if isinstance(value, (str, bytes, int, float, bool)):
        yield "", value
        return
    marker = id(value)
    if marker in seen:
        return
    seen.add(marker)
    if isinstance(value, dict):
        for key, child in value.items():
            yield str(key), child
            yield from _walk(child, seen, depth + 1)
        return
    if isinstance(value, (list, tuple, set)):
        for child in value:
            yield "", child
            yield from _walk(child, seen, depth + 1)
        return
    try:
        attrs = vars(value)
    except TypeError:
        attrs = {}
    for key, child in attrs.items():
        yield str(key), child
        yield from _walk(child, seen, depth + 1)


def _text(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, str):
        return value.strip()
    for method in ("get_plain_text", "to_plain_text"):
        fn = getattr(value, method, None)
        if callable(fn):
            try:
                result = fn()
                if isinstance(result, str):
                    return result.strip()
            except Exception:  # noqa: BLE001, S112 - platform components differ
                continue
    return str(value).strip()


def _event_roots(event: Any) -> list[Any]:
    roots = []
    for attr in ("attachments", "raw_payload", "message_chain", "message_obj"):
        val = getattr(event, attr, None)
        if val is not None:
            roots.append(val)
    if isinstance(event, dict):
        roots.append(event)
    elif not roots and event is not None:
        roots.append(event)
    return roots


def attachment_suffixes(event: Any) -> set[str]:
    """Collect only suffixes declared by attachment metadata fields."""
    suffixes: set[str] = set()
    for root in _event_roots(event):
        for key, value in _walk(root):
            if key.casefold() not in _KEYS:
                continue
            value_text = value.decode(errors="ignore") if isinstance(value, bytes) else _text(value)
            suffix = attachment_suffix(value_text)
            if suffix:
                suffixes.add(suffix)
    return suffixes


def event_has_attachment_suffix(event: Any, allowed: set[str]) -> bool:
    """Whether an event explicitly declares one of the exact allowed suffixes."""
    observed = attachment_suffixes(event)
    return bool(observed & {item.casefold() for item in allowed})


def looks_word(value: str) -> bool:
    return attachment_suffix(value) in {".doc", ".docx"}


def looks_pptx(value: str) -> bool:
    return attachment_suffix(value) == ".pptx"


def find_attachment_candidate(event: Any, allowed_suffixes: set[str]) -> dict[str, str] | None:
    """Extract a downloadable or local attachment candidate matching allowed suffixes."""
    allowed = {s.casefold() for s in allowed_suffixes}

    # 1. Fast path: check direct attachments tuple/list of dicts
    attachments = getattr(event, "attachments", None)
    if isinstance(attachments, (list, tuple)):
        for item in attachments:
            if not isinstance(item, dict):
                continue
            name = str(item.get("filename") or item.get("file_name") or item.get("name") or item.get("display_name") or "").strip()

            # Local path check
            for pk in ("path", "file_path", "filepath", "local_path"):
                p_val = str(item.get(pk) or "").strip()
                if p_val and attachment_suffix(p_val) in allowed:
                    p = Path(p_val).expanduser()
                    if p.is_file():
                        return {"path": str(p), "name": name or p.name}

            # Remote URL check
            u_val = str(item.get("url") or item.get("download_url") or item.get("resource_url") or item.get("src") or item.get("file_url") or "").strip()
            if u_val.startswith("//"):
                u_val = "https:" + u_val
            if u_val.startswith(("http://", "https://")):
                s_name = attachment_suffix(name)
                s_url = attachment_suffix(u_val)
                if s_name in allowed or s_url in allowed:
                    disp_name = name if s_name in allowed else (Path(urlsplit(u_val).path).name or "upload.file")
                    return {"url": u_val, "name": disp_name}

    # 2. Deep traversal across roots
    names: list[str] = []
    urls: list[str] = []
    loose_urls: list[str] = []
    paths: list[str] = []

    for root in _event_roots(event):
        for key, value in _walk(root):
            value_text = (
                value.decode(errors="ignore") if isinstance(value, bytes) else _text(value)
            )
            if not value_text:
                continue
            if value_text.startswith("//"):
                value_text = "https:" + value_text

            key_lower = key.lower()
            suf = attachment_suffix(value_text)

            if key_lower in _PATH_KEYS:
                if suf in allowed:
                    paths.append(value_text)
                elif value_text.startswith(("http://", "https://")):
                    if suf in allowed:
                        urls.append(value_text)
                    else:
                        loose_urls.append(value_text)
            elif key_lower in _URL_KEYS:
                if suf in allowed:
                    urls.append(value_text)
                elif value_text.startswith(("http://", "https://")):
                    loose_urls.append(value_text)
            elif key_lower in _NAME_KEYS and suf in allowed:
                names.append(value_text)

    # 3. Resolve candidates
    for candidate in paths:
        path = Path(candidate).expanduser()
        if path.is_file() and path.suffix.casefold() in allowed:
            return {"path": str(path), "name": path.name}

    if urls or (names and loose_urls):
        url = urls[0] if urls else loose_urls[0]
        chosen_name = names[0] if names else (Path(urlsplit(url).path).name or "upload.file")
        return {"url": url, "name": chosen_name}

    return None


def find_word_candidate(event: Any) -> dict[str, str] | None:
    return find_attachment_candidate(event, {".docx", ".doc"})


def find_pptx_candidate(event: Any) -> dict[str, str] | None:
    return find_attachment_candidate(event, {".pptx"})

