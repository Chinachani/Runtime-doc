"""B站音视频解析独立外部插件 (plugin.bili).

具备完整的 B 站视频、番剧解析、下载、音频提取、超长音频自动普通文件发送、
3x3 交互卡片菜单、任务/文件分页管理、扫码登录、接口连通性检查与管理台通信能力。
遵循标准普通外部插件规范，运行于沙箱隔离环境中，配置与缓存均存储于插件专属目录。
"""

from __future__ import annotations

import asyncio
import io
import json
import logging
import re
import shutil
import struct
import time
import uuid
from dataclasses import dataclass
from pathlib import Path
from typing import Any
from urllib.parse import quote

import httpx

logger = logging.getLogger("plugin.bili")
PLUGIN_VERSION = "1.7.3"


def parse_image_dimensions(b: bytes) -> tuple[int, int] | None:
    if len(b) < 16:
        return None
    # 1. PNG
    if b.startswith(b"\x89PNG\r\n\x1a\n") and len(b) >= 24:
        return struct.unpack(">II", b[16:24])
    # 2. GIF
    if b.startswith((b"GIF87a", b"GIF89a")) and len(b) >= 10:
        return struct.unpack("<HH", b[6:10])
    # 3. WEBP
    if len(b) >= 30 and b[:4] == b"RIFF" and b[8:12] == b"WEBP":
        chunk = b[12:16]
        if chunk == b"VP8X" and len(b) >= 30:
            w = 1 + struct.unpack("<I", b[24:27] + b"\x00")[0]
            h = 1 + struct.unpack("<I", b[27:30] + b"\x00")[0]
            return w, h
        elif chunk == b"VP8 " and len(b) >= 30:
            idx = b.find(b"\x9d\x01\x2a")
            if idx != -1 and idx + 7 <= len(b):
                w = struct.unpack("<H", b[idx+3:idx+5])[0] & 0x3fff
                h = struct.unpack("<H", b[idx+5:idx+7])[0] & 0x3fff
                return w, h
        elif chunk == b"VP8L" and len(b) >= 25:
            b0, b1, b2, b3 = b[21], b[22], b[23], b[24]
            w = 1 + (((b1 & 0x3f) << 8) | b0)
            h = 1 + (((b3 & 0x0f) << 10) | (b2 << 2) | ((b1 & 0xc0) >> 6))
            return w, h
    # 4. JPEG
    if b.startswith(b"\xff\xd8"):
        idx = 2
        while idx < len(b) - 8:
            if b[idx] != 0xff:
                idx += 1
                continue
            marker = b[idx+1]
            if marker in (0xc0, 0xc1, 0xc2, 0xc3, 0xc5, 0xc6, 0xc7, 0xc9, 0xca, 0xcb, 0xcd, 0xce, 0xcf):
                h, w = struct.unpack(">HH", b[idx+5:idx+9])
                return w, h
            length = struct.unpack(">H", b[idx+2:idx+4])[0]
            idx += 2 + length
    return None

def _sanitize_filename(name: str) -> str:
    """清理文件名中的非法字符以安全用于 QQ 媒体上传。"""
    clean = re.sub(r'[/\\:*?"<>|\r\n\t]+', '_', name).strip('. ')
    return clean[:120] if len(clean) > 120 else (clean or "bili_audio")

DEFAULT_CONFIG: dict[str, Any] = {
    "bilibili_cookie": "",
    "video_api_base_url": "",
    "video_api_login_token": "",
    "custom_api_fallback_official": True,
    "prefer_official_api": False,
    "video_download_timeout_sec": 0,
    "video_progress_stall_limit": 3,
    "video_poll_interval_sec": 1.0,
    "max_video_duration_sec": 0,
    "max_video_file_size_mb": 0,
    "video_quality_preset": 0,
    "auto_lower_quality_on_oversize": False,
    "enable_auto_detect": True,
    "enable_parse_miniapp": True,
    "api_timeout_sec": 10,
    "request_retries": 2,
    "retry_delay_sec": 1,
    "show_cover": True,
    "enable_video_output": False,
    "enable_audio_voice_output": False,
    "audio_voice_only_mode": False,
    "max_audio_duration_sec": 0,
    "audio_quality_preset": 0,
    "user_agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
    "debug_log": False,
    "enable_parse_hint": True,
}

URL_RE = re.compile(
    r"(?:https?://(?:[a-zA-Z0-9_-]+\.)?bilibili\.com/[^\s<>\"'\(\)]+|https?://b23\.tv/[^\s<>\"'\(\)]+|\b(?:BV[0-9A-Za-z]{10}|av\d+|ep\d+|ss\d+)\b)",
    re.I,
)


def _format_count(value: int | float | str | None) -> str:
    try:
        count = int(value or 0)
    except (TypeError, ValueError):
        return "0"
    if count >= 10000:
        return f"{count / 10000:.1f}万"
    return str(count)


def _format_duration(seconds: int | float | None) -> str:
    try:
        total = int(seconds or 0)
    except (TypeError, ValueError):
        return "00:00"
    minutes, sec = divmod(total, 60)
    hours, minutes = divmod(minutes, 60)
    if hours:
        return f"{hours:02d}:{minutes:02d}:{sec:02d}"
    return f"{minutes:02d}:{sec:02d}"


def _https_url(url: str | None) -> str:
    raw = str(url or "").strip()
    if raw.startswith("//"):
        return f"https:{raw}"
    if raw.startswith("http://"):
        return f"https://{raw[7:]}"
    return raw


def make_button(
    label: str,
    action: str,
    *,
    type: int = 1,
    permission: int = 0,
    style: str = "normal",
    permission_message: str = "",
) -> dict[str, Any]:
    btn: dict[str, Any] = {
        "label": label,
        "action": action,
        "command": action,
        "type": type,
        "action_type": type,
        "permission": permission,
        "style": style,
    }
    if permission_message:
        btn["permission_message"] = permission_message
    return btn


def make_card(title: str, content: str, rows: list[list[dict[str, Any]]] | None = None) -> dict[str, Any]:
    return {
        "title": title,
        "content": content,
        "markdown": content,
        "rows": rows or [],
    }


@dataclass
class VideoTarget:
    bvid: str = ""
    aid: str = ""
    ep_id: str = ""
    ss_id: str = ""
    title: str = ""
    source: str = ""

    @property
    def canonical_url(self) -> str:
        if self.bvid:
            return f"https://www.bilibili.com/video/{self.bvid}"
        if self.aid:
            return f"https://www.bilibili.com/video/av{self.aid}"
        if self.ep_id:
            return f"https://www.bilibili.com/bangumi/play/ep{self.ep_id}"
        if self.ss_id:
            return f"https://www.bilibili.com/bangumi/play/ss{self.ss_id}"
        return self.source


def find_target_in_text(text: str) -> VideoTarget | None:
    if not text:
        return None

    # 1. 优先检测 QQ 小程序卡片消息
    # 格式示例：
    # [卡片消息] 小程序
    # 摘要: [QQ小程序]...
    # source: 哔哩哔哩
    # title: 视频标题
    is_miniapp = ("[卡片消息]" in text or "小程序" in text or "[QQ小程序]" in text) and (
        "哔哩哔哩" in text or "bilibili" in text.lower()
    )
    if is_miniapp:
        m_title = re.search(r"(?:title|标题)[:：]\s*([^\r\n]+)", text, re.I)
        if m_title:
            cand_title = m_title.group(1).strip()
            cand_title = re.sub(r"^[\"\'\s]+|[\"\'\s]+$", "", cand_title)
            if cand_title:
                return VideoTarget(title=cand_title, source=text)

    # 2. 剥除非 B 站 URL，避免腾讯多媒体链接 (multimedia.nt.qq.com.cn) 附带的随机 hash 触发伪 BV/AV
    text_no_urls = re.sub(
        r"https?://(?!(?:[a-zA-Z0-9_-]+\.)?(?:bilibili\.com|b23\.tv))[^\s<>\"\'\(\)]+",
        "",
        text,
    )

    # 3. 显式短链与 B 站完整链接识别
    m_b23 = re.search(r"https?://b23\.tv/[a-zA-Z0-9]+", text, re.I)
    if m_b23:
        return VideoTarget(source=m_b23.group(0))
    m_url = re.search(r"https?://(?:[a-zA-Z0-9_-]+\.)?bilibili\.com/[^\s<>\"'\(\)]+", text, re.I)
    if m_url:
        return VideoTarget(source=m_url.group(0))

    # 4. 规范 BV 号识别：B站官方 BV 号必须以大写 BV1 开头，严格区分大小写并带单词边界
    m_bv = re.search(r"\b(BV1[0-9A-Za-z]{9})\b", text_no_urls)
    if m_bv:
        return VideoTarget(bvid=m_bv.group(1), source=text)

    # 5. AV 号、番剧剧集 ep / ss 识别（必须带单词边界，防止误伤普通数字或单词）
    m_av = re.search(r"\bav(\d+)\b", text_no_urls, re.I)
    if m_av:
        return VideoTarget(aid=m_av.group(1), source=text)
    m_ep = re.search(r"\bep(\d+)\b", text_no_urls, re.I)
    if m_ep:
        return VideoTarget(ep_id=m_ep.group(1), source=text)
    m_ss = re.search(r"\bss(\d+)\b", text_no_urls, re.I)
    if m_ss:
        return VideoTarget(ss_id=m_ss.group(1), source=text)

    return None


class BiliPlugin:
    def __init__(self, context: Any) -> None:
        self.context = context
        self.config_dir: Path = Path(context.config_dir) if getattr(context, "config_dir", None) else Path("./config")
        self.data_dir: Path = Path(context.data_dir) if getattr(context, "data_dir", None) else Path("./data")
        self.config_file = self.config_dir / "config.json"
        self.cache_dir = self.data_dir / "cache"
        self.config_dir.mkdir(parents=True, exist_ok=True)
        self.cache_dir.mkdir(parents=True, exist_ok=True)

        self.config: dict[str, Any] = dict(DEFAULT_CONFIG)
        self._load_config()

        self._in_flight_tasks: set[tuple[str, str, Any]] = set()
        self._recently_sent: dict[tuple[str, str, Any], float] = {}
        self._media_cache: dict[tuple[str, bool, int], tuple[float, Path]] = {}
        self._image_dim_cache: dict[str, tuple[int, int]] = {}

    async def _resolve_image_dimension(self, url: str) -> tuple[int, int] | None:
        if not url:
            return None
        if url in self._image_dim_cache:
            return self._image_dim_cache[url]
        try:
            async with httpx.AsyncClient(timeout=5.0, follow_redirects=True) as client:
                async with client.stream("GET", url, headers={"User-Agent": "Mozilla/5.0"}) as resp:
                    if resp.status_code in {200, 206}:
                        buf = bytearray()
                        async for chunk in resp.aiter_bytes(chunk_size=8192):
                            buf.extend(chunk)
                            dims = parse_image_dimensions(bytes(buf))
                            if dims:
                                self._image_dim_cache[url] = dims
                                return dims
                            if len(buf) >= 65536:
                                break
                        try:
                            from PIL import Image
                            im = Image.open(io.BytesIO(buf))
                            self._image_dim_cache[url] = im.size
                            return im.size
                        except Exception:
                            pass
        except Exception:
            pass
        return None

    def _compute_card_dimension(self, w: int, h: int, target_w: int = 720) -> str:
        if not w or not h or w <= 0 or h <= 0:
            return f"#{target_w}px #{target_w}px"
        target_h = max(200, min(1440, int(round(target_w * (h / w)))))
        return f"#{target_w}px #{target_h}px"

    def _resolve_card_dimension(self, url: str, info: dict[str, Any]) -> str:
        target_w = 720
        w = info.get("width")
        h = info.get("height")
        if w and h:
            try:
                return self._compute_card_dimension(int(w), int(h), target_w)
            except (ValueError, TypeError):
                pass
        if url and url in self._image_dim_cache:
            w, h = self._image_dim_cache[url]
            return self._compute_card_dimension(w, h, target_w)
        return f"#{target_w}px #405px"

    def _load_config(self) -> None:
        if self.config_file.is_file():
            try:
                mtime = self.config_file.stat().st_mtime
                if mtime != getattr(self, "_config_mtime", 0.0):
                    data = json.loads(self.config_file.read_text(encoding="utf-8"))
                    if isinstance(data, dict):
                        self.config.update(data)
                        self._config_mtime = mtime
            except Exception as e:
                logger.warning("加载 B站插件配置异常: %s", e)

    def _save_config(self) -> None:
        try:
            self.config_file.write_text(json.dumps(self.config, ensure_ascii=False, indent=2), encoding="utf-8")
        except Exception as e:
            logger.error("保存 B站插件配置异常: %s", e)

    def _cfg(self, key: str) -> Any:
        self._load_config()
        return self.config.get(key, DEFAULT_CONFIG.get(key))

    def _service_headers(self) -> dict[str, str]:
        token = str(self._cfg("video_api_login_token") or "").strip()
        return {"X-API-Token": token} if token else {}

    async def _sync_cookie_from_download_site(self) -> dict[str, Any]:
        """从下载站后端拉取最新 Cookie 并同步至插件配置 (Pull)。"""
        base = str(self._cfg("video_api_base_url") or "").rstrip("/")
        if not base:
            return {"success": False, "message": "尚未配置 video_api_base_url"}
        headers = self._service_headers()
        try:
            async with httpx.AsyncClient(timeout=float(self._cfg("api_timeout_sec") or 10)) as client:
                resp = await client.get(f"{base}/api/login/cookie", headers=headers)
                if resp.status_code >= 400:
                    return {"success": False, "message": f"下载站接口返回 HTTP {resp.status_code}"}
                data = resp.json()
                if not isinstance(data, dict):
                    return {"success": False, "message": "响应格式错误"}
                remote_cookie = str(data.get("cookie") or "").strip()
                if not remote_cookie and isinstance(data.get("cookies"), dict):
                    remote_cookie = "; ".join(f"{k}={v}" for k, v in data["cookies"].items())

                updated = False
                current_cookie = str(self._cfg("bilibili_cookie") or "").strip()
                if remote_cookie and remote_cookie != current_cookie:
                    self.config["bilibili_cookie"] = remote_cookie
                    self._save_config()
                    updated = True
                    logger.info("已从下载站同步最新 B站 Cookie")

                return {
                    "success": True,
                    "updated": updated,
                    "logged_in": bool(data.get("logged_in")),
                    "user_info": data.get("user_info"),
                    "cookie": remote_cookie or current_cookie,
                    "message": data.get("message") or "同步完成",
                }
        except Exception as e:
            logger.warning("从下载站同步 Cookie 失败: %s", e)
            return {"success": False, "message": str(e)}

    async def _sync_cookie_to_download_site(self, cookie: str) -> dict[str, Any]:
        """将机器人插件中的最新 Cookie 推送同步至下载站 cookies.txt (Push)。"""
        base = str(self._cfg("video_api_base_url") or "").rstrip("/")
        if not base or not cookie:
            return {"success": False, "message": "未配置服务地址或 Cookie 为空"}
        headers = self._service_headers()
        try:
            async with httpx.AsyncClient(timeout=float(self._cfg("api_timeout_sec") or 10)) as client:
                resp = await client.post(f"{base}/api/login/cookie", headers=headers, json={"cookie": cookie})
                if resp.status_code >= 400:
                    return {"success": False, "message": f"推送至下载站失败: HTTP {resp.status_code}"}
                data = resp.json()
                logger.info("已成功向下载站同步最新 B站 Cookie")
                return {"success": True, "message": "已同步至下载站", "data": data}
        except Exception as e:
            logger.warning("推送 Cookie 至下载站异常: %s", e)
            return {"success": False, "message": str(e)}

    async def _remove_task(self, base: str, task_id: str, headers: dict[str, str]) -> None:
        if not task_id:
            return
        try:
            async with httpx.AsyncClient(timeout=float(self._cfg("api_timeout_sec"))) as client:
                await client.post(f"{base}/api/tasks/remove/{quote(task_id, safe='')}", headers=headers, json={})
        except Exception as e:
            logger.debug("清理旧下载任务 %s 失败或已不存在: %s", task_id, e)

    def _clean_media_cache(self) -> None:
        now = time.monotonic()
        expired = [k for k, (exp, p) in self._media_cache.items() if now > exp or not p.is_file()]
        for k in expired:
            _, p = self._media_cache.pop(k, (0, Path("")))
            p.unlink(missing_ok=True)
        if len(self._media_cache) > 20:
            sorted_items = sorted(self._media_cache.items(), key=lambda item: item[1][0])
            for k, (_, p) in sorted_items[: len(self._media_cache) - 20]:
                self._media_cache.pop(k, None)
                p.unlink(missing_ok=True)

    def _task_key(self, conversation_id: str, source_url: str, audio_only: Any = False, as_file: bool = False) -> tuple[str, str, Any]:
        match = re.search(r"\b(BV1[0-9A-Za-z]{9})\b", str(source_url or ""))
        bvid = match.group(1) if match else str(source_url or "").strip().lower()
        kind = (bool(audio_only), True) if as_file else (audio_only if isinstance(audio_only, tuple) else bool(audio_only))
        return (str(conversation_id or ""), bvid, kind)

    async def _resolve_short_url(self, url: str) -> str:
        match = re.search(r"https?://[^\s<>\"'\(\)]+", url)
        target_url = match.group(0) if match else url.strip()
        headers = {"User-Agent": str(self._cfg("user_agent"))}
        try:
            async with httpx.AsyncClient(timeout=float(self._cfg("api_timeout_sec")), follow_redirects=False) as client:
                response = await client.get(target_url, headers=headers)
                if response.status_code in {301, 302, 303, 307, 308} and "location" in response.headers:
                    return response.headers["location"]
                if response.status_code == 200:
                    return str(response.url)
            async with httpx.AsyncClient(timeout=float(self._cfg("api_timeout_sec")), follow_redirects=True) as client:
                response = await client.get(target_url, headers=headers)
                return str(response.url)
        except Exception:
            return ""

    async def _search_video_by_title(self, keyword: str) -> str | None:
        if not keyword:
            return None
        cleaned = re.sub(r"\[QQ小程序\]", "", keyword).strip()
        headers = {
            "User-Agent": str(self._cfg("user_agent")),
            "Referer": "https://www.bilibili.com/",
        }
        cookies: dict[str, str] = {}
        cookie_cfg = str(self._cfg("bilibili_cookie") or "")
        if cookie_cfg:
            headers["Cookie"] = cookie_cfg
        try:
            async with httpx.AsyncClient(timeout=float(self._cfg("api_timeout_sec")), follow_redirects=True) as client:
                if "buvid3" not in cookie_cfg:
                    try:
                        spi_res = await client.get("https://api.bilibili.com/x/frontend/finger/spi", headers=headers)
                        if spi_res.status_code == 200:
                            b3 = spi_res.json().get("data", {}).get("b_3")
                            if b3:
                                cookies["buvid3"] = b3
                    except Exception:
                        pass
                resp = await client.get(
                    "https://api.bilibili.com/x/web-interface/search/type",
                    params={"search_type": "video", "keyword": cleaned},
                    headers=headers,
                    cookies=cookies,
                )
                if resp.status_code == 200:
                    data = resp.json()
                    results = data.get("data", {}).get("result", [])
                    if results and isinstance(results, list):
                        for item in results:
                            bvid = item.get("bvid")
                            if bvid:
                                return str(bvid)
        except Exception as e:
            logger.debug("B站小程序标题搜索匹配失败: %s", e)
        return None

    async def _resolve_target(self, target: VideoTarget) -> VideoTarget | None:
        if target.bvid or target.aid or target.ep_id or target.ss_id:
            return target
        if target.title:
            bvid = await self._search_video_by_title(target.title)
            if bvid:
                target.bvid = bvid
                return target
        if target.source and "b23.tv" in target.source:
            resolved = await self._resolve_short_url(target.source)
            if resolved:
                return find_target_in_text(resolved)
        return None

    async def _fetch_video_info(self, target: VideoTarget) -> dict[str, Any]:
        target = await self._resolve_target(target) or target
        if target.ep_id or target.ss_id:
            return await self._fetch_bangumi_info(target)
        params: dict[str, Any] = {}
        if target.bvid:
            params["bvid"] = target.bvid
        elif target.aid:
            params["aid"] = target.aid
        else:
            raise ValueError("无法提取有效 BV 或 AV 号。")

        url = "https://api.bilibili.com/x/web-interface/view"
        headers = {"User-Agent": str(self._cfg("user_agent"))}
        cookie = str(self._cfg("bilibili_cookie") or "")
        if cookie:
            headers["Cookie"] = cookie

        async with httpx.AsyncClient(timeout=float(self._cfg("api_timeout_sec")), follow_redirects=True) as client:
            resp = await client.get(url, params=params, headers=headers)
        if resp.status_code != 200:
            raise ValueError(f"B站官方接口请求失败：HTTP {resp.status_code}")
        try:
            data = resp.json()
        except Exception:
            data = {}
        if not isinstance(data, dict) or data.get("code") != 0:
            msg = data.get("message") if isinstance(data, dict) else "接口未返回有效数据"
            raise ValueError(f"B站返回错误：{msg}")
        d = data.get("data") or {}
        stat = d.get("stat") or {}
        owner = d.get("owner") or {}
        dim = d.get("dimension") if isinstance(d.get("dimension"), dict) else {}
        return {
            "title": d.get("title") or "无标题",
            "author": owner.get("name") or "未知",
            "cover": d.get("pic") or "",
            "width": dim.get("width"),
            "height": dim.get("height"),
            "desc": (d.get("desc") or "").strip(),
            "bvid": d.get("bvid") or target.bvid,
            "url": f"https://www.bilibili.com/video/{d.get('bvid') or target.bvid}",
            "view": stat.get("view", 0),
            "danmaku": stat.get("danmaku", 0),
            "like": stat.get("like", 0),
            "coin": stat.get("coin", 0),
            "favorite": stat.get("favorite", 0),
            "duration": d.get("duration", 0),
        }

    async def _fetch_bangumi_info(self, target: VideoTarget) -> dict[str, Any]:
        params: dict[str, Any] = {}
        if target.ep_id:
            params["ep_id"] = target.ep_id
        elif target.ss_id:
            params["season_id"] = target.ss_id
        else:
            raise ValueError("无法识别番剧 ID。")
        url = "https://api.bilibili.com/pgc/view/web/season"
        headers = {"User-Agent": str(self._cfg("user_agent"))}
        cookie = str(self._cfg("bilibili_cookie") or "")
        if cookie:
            headers["Cookie"] = cookie
        async with httpx.AsyncClient(timeout=float(self._cfg("api_timeout_sec")), follow_redirects=True) as client:
            resp = await client.get(url, params=params, headers=headers)
        if resp.status_code != 200:
            raise ValueError(f"番剧请求失败：HTTP {resp.status_code}")
        try:
            data = resp.json()
        except Exception:
            data = {}
        if not isinstance(data, dict) or data.get("code") != 0:
            raise ValueError(str(data.get("message") or "番剧不存在") if isinstance(data, dict) else "番剧返回格式异常")
        result = data.get("result", {}) or {}
        season_title = result.get("season_title") or result.get("title") or "B站番剧"
        cover = result.get("cover") or ""
        stat = result.get("stat", {}) or {}
        evaluate = (result.get("evaluate") or "").strip()
        ep_title = ""
        duration_sec = 0
        episodes = result.get("episodes", []) or []
        if target.ep_id and episodes:
            for ep in episodes:
                if str(ep.get("id")) == str(target.ep_id):
                    short_t = str(ep.get("title") or "").strip()
                    long_t = str(ep.get("long_title") or "").strip()
                    ep_title = f"第{short_t}话 {long_t}".strip() if short_t and long_t else (short_t or long_t)
                    duration_sec = int(ep.get("duration") or 0) // 1000
                    break
        full_title = f"{season_title} · {ep_title}" if ep_title else season_title
        play_url = f"https://www.bilibili.com/bangumi/play/ep{target.ep_id}" if target.ep_id else f"https://www.bilibili.com/bangumi/play/ss{target.ss_id}"
        return {
            "title": full_title,
            "author": "哔哩哔哩番剧",
            "cover": cover,
            "desc": evaluate,
            "bvid": f"ep{target.ep_id}" if target.ep_id else f"ss{target.ss_id}",
            "url": play_url,
            "view": stat.get("views", 0),
            "danmaku": stat.get("danmakus", 0),
            "like": stat.get("likes", 0),
            "coin": stat.get("coins", 0),
            "favorite": stat.get("favorites", 0),
            "duration": duration_sec,
        }

    # ================= 菜单卡片构造 =================
    def _menu_card(self) -> dict[str, Any]:
        """构建 3x3 标准九宫格菜单卡片，100% 对齐原版。"""
        rows = [
            [
                make_button("解析视频", "/bili ", type=2),
                make_button("下载视频", "/bili dl ", type=2),
                make_button("提取音频", "/bili audio ", type=2),
            ],
            [
                make_button("解析帮助", "/bili parse", type=1),
                make_button("任务列表", "/bili task", type=1),
                make_button("文件列表", "/bili file", type=1),
            ],
            [
                make_button("扫码登录", "/bili login", type=1, permission=1, permission_message="只有管理员可以操作 B 站登录。"),
                make_button("接口状态", "/bili net", type=1, permission=1, permission_message="只有管理员可以检查 B 站接口状态。"),
                make_button("配置说明", "/bili config", type=1, permission=1, permission_message="只有管理员可以查看 B 站配置说明。"),
            ],
        ]
        configured = "已配置解析服务" if self._cfg("video_api_base_url") else "未配置下载服务"
        markdown = (
            "## B站解析\n\n"
            "支持 B 站视频、番剧链接和 BV/AV 号解析。\n\n"
            f"当前状态：{configured}。\n\n"
            "直接发送 `/bili <链接或 BV 号>` 解析；下载、任务和文件管理需要配置外部解析服务。"
        )
        return make_card("B站解析", markdown, rows)

    def _submenu_card(self, module: str) -> dict[str, Any]:
        """构建二级子菜单引导卡片。"""
        module_lower = module.casefold()
        content = {
            "parse": "发送 `/bili <B站链接或 BV 号>` 解析视频信息。支持自动识别 QQ 分享卡片；下载使用 `/bili dl <链接>`。",
            "config": "配置项请在管理台的 B 站解析设置页修改：解析服务地址、服务令牌、Cookie、自动识别和媒体输出。",
            "net": "使用 `/bili net` 检查官方接口和外部解析服务状态。",
        }.get(module_lower, "发送 `/bili <链接或 BV 号>` 开始解析。")
        permission = 1 if module_lower in {"config", "net"} else 0
        rows = [
            [
                make_button("返回菜单", "/bili", type=1),
                make_button("任务列表", "/bili task", type=1),
                make_button("文件列表", "/bili file", type=1),
            ],
            [
                make_button("执行入口", f"/bili {module_lower}", type=1, permission=permission),
            ],
        ]
        return make_card(f"B站解析 · {module_lower}", content, rows)

    def _build_info_card(self, info: dict[str, Any], text: str = "") -> dict[str, Any]:
        """构建完整的视频/番剧富媒体卡片。"""
        title = str(info.get("title") or "B站视频")
        author = str(info.get("author") or "未知")
        video_url = str(info.get("url") or "").strip()
        duration_str = _format_duration(info.get("duration", 0))
        view_cnt = _format_count(info.get("view", 0))
        danmaku_cnt = _format_count(info.get("danmaku", 0))
        like_cnt = _format_count(info.get("like", 0))
        coin_cnt = _format_count(info.get("coin", 0))
        favorite_cnt = _format_count(info.get("favorite", 0))
        desc = str(info.get("desc") or "").strip()
        if len(desc) > 100:
            desc = desc[:98] + "…"

        markdown_lines = []
        cover = _https_url(info.get("cover") or info.get("pic"))
        if self._cfg("show_cover") and cover:
            dim_str = self._resolve_card_dimension(cover, info)
            markdown_lines.append(f"![封面 {dim_str}]({cover})\n")
        markdown_lines.append(f"### {title}")
        markdown_lines.append(f"👤 **UP主**：{author} · ⏱️ **时长**：{duration_str}")
        markdown_lines.append(f"📊 **数据**：▶️ {view_cnt} · 💬 {danmaku_cnt} 弹幕 · 👍 {like_cnt} · 🪙 {coin_cnt} · ⭐ {favorite_cnt}")
        if desc:
            markdown_lines.append(f"> {desc}")
        markdown = "\n\n".join(markdown_lines)

        source = video_url or text.strip()
        second_row: list[dict[str, Any]] = []
        if video_url:
            second_row.append(make_button("网页打开", video_url, type=0))
        second_row.append(make_button("解析菜单", "/bili", type=1, permission=0))

        rows: list[list[dict[str, Any]]] = [
            [
                make_button("下载视频", f"/bili dl {source}", type=1, permission=0),
                make_button("发送语音", f"/bili audio {source}", type=1, permission=0),
                make_button("音频文件", f"/bili audio_file {source}", type=1, permission=0),
            ],
            second_row,
        ]
        return make_card("B站解析", markdown, rows)

    # ================= QQ 媒体文件发送 =================
    async def _send_file_to_qq(self, context: Any, file_path: Path, file_type: int) -> tuple[bool, str]:
        qq = getattr(self.context, "qq", None)
        media = getattr(self.context, "media", None)
        if not qq:
            return False, "QQ 网关不可用"

        scene = getattr(context, "scene", None) or getattr(context, "conversation_type", "group")
        conversation_id = str(
            getattr(context, "conversation_id", "")
            or getattr(context, "group_openid", "")
            or getattr(context, "openid", "")
        )

        if scene in {"channel", "guild_direct"}:
            try:
                if hasattr(qq, "send_channel_media"):
                    await qq.send_channel_media(conversation_id, scene, file_image=file_path.read_bytes())
                    return True, ""
            except Exception as e:
                return False, f"频道媒体发送失败: {e}"

        if not media or not hasattr(media, "prepare"):
            return False, "Runtime 媒体服务不可用"

        effective_file_type = file_type
        if effective_file_type == 3 and file_path.suffix.lower() not in {".silk", ".mp3", ".wav", ".ogg"}:
            effective_file_type = 4

        async def _do_upload_and_send(target_type: int) -> tuple[bool, str]:
            req = await media.prepare(scene, conversation_id, target_type, file_path)
            up = await qq.upload_media_file(req, file_path)
            f_info = up.get("file_info") if isinstance(up, dict) else str(up)
            if not f_info:
                return False, "未获取到上传后的 file_info"
            m_id = getattr(context, "message_id", None)
            if not isinstance(m_id, str) or not m_id.strip() or (len(m_id) == 36 and m_id.count("-") == 4):
                m_id = None
            try:
                if m_id:
                    await qq.send_media(conversation_id, scene, str(f_info), msg_id=m_id)
                else:
                    await qq.send_media(conversation_id, scene, str(f_info))
            except Exception as s_err:
                if m_id:
                    logger.warning("带 msg_id 发送媒体失败 (%s)，回退主动发送...", s_err)
                    await qq.send_media(conversation_id, scene, str(f_info))
                else:
                    raise
            return True, ""

        if effective_file_type == 3:
            try:
                return await _do_upload_and_send(3)
            except Exception as audio_err:
                logger.warning("QQ 语音/音频发送失败 (%s)，可能因时长超过限制，自动降级为普通文件 (file_type=4)...", audio_err)
                return await _do_upload_and_send(4)

        return await _do_upload_and_send(effective_file_type)

    async def _service_text(self, path: str, params: dict[str, Any] | None = None) -> tuple[int, str, Any]:
        base = str(self._cfg("video_api_base_url") or "").rstrip("/")
        if not base:
            return 400, "", {}
        url = base + path if path.startswith("/") else f"{base}/{path}"
        headers = self._service_headers()
        try:
            async with httpx.AsyncClient(timeout=float(self._cfg("api_timeout_sec"))) as client:
                resp = await client.get(url, params=params, headers=headers)
                try:
                    payload = resp.json()
                except Exception:
                    payload = resp.text
                return resp.status_code, resp.text, payload
        except Exception as e:
            return 500, str(e), {}

    # ================= 音频转码 =================
    async def _convert_audio_to_mp3(self, source_path: Path) -> Path:
        """Convert audio file to mp3 for QQ voice compatibility."""
        if source_path.suffix.lower() == ".mp3":
            return source_path
        ffmpeg_bin = shutil.which("ffmpeg") or ("/app/data/bin/ffmpeg" if Path("/app/data/bin/ffmpeg").is_file() else None)
        if not ffmpeg_bin:
            return source_path
        mp3_path = source_path.with_suffix(".mp3")
        cmd = [
            str(ffmpeg_bin),
            "-y",
            "-i", str(source_path),
            "-vn",
            "-c:a", "libmp3lame",
            "-q:a", "2",
            str(mp3_path),
        ]
        try:
            proc = await asyncio.create_subprocess_exec(
                *cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )
            await proc.communicate()
            if proc.returncode == 0 and mp3_path.is_file() and mp3_path.stat().st_size > 0:
                source_path.unlink(missing_ok=True)
                return mp3_path
        except Exception as e:
            logger.warning("音频转码为 MP3 失败 (%s)，保持原文件", e)
        return source_path

    # ================= 下载与发送 =================
    async def _download_and_send(self, context: Any, source_url: str, audio_only: bool = False, as_file: bool = False) -> str:
        base = str(self._cfg("video_api_base_url") or "").rstrip("/")
        if not base:
            return "尚未配置 B站解析服务地址。"

        vt = find_target_in_text(source_url)
        if vt:
            vt = await self._resolve_target(vt) or vt
        canonical_url = vt.canonical_url if vt else source_url.strip()
        if not canonical_url.startswith("http"):
            canonical_url = f"https://www.bilibili.com/video/{canonical_url}"

        video_title = ""
        if vt:
            try:
                info = await self._fetch_video_info(vt)
                video_title = str(info.get("title") or "").strip()
            except Exception:
                pass

        quality = int(self._cfg("video_quality_preset") or 0)
        cache_key = (canonical_url, bool(audio_only), quality)
        cached_entry = self._media_cache.get(cache_key)
        if cached_entry:
            exp, cached_path = cached_entry
            if time.monotonic() < exp and cached_path.is_file() and cached_path.stat().st_size > 0:
                file_type = 4 if (audio_only and as_file) else (3 if audio_only else 2)
                ok, err = await self._send_file_to_qq(context, cached_path, file_type)
                if ok:
                    return ""
                logger.warning("缓存文件发送失败，将重新请求下载: %s", err)

        params = {
            "url": canonical_url,
            "merge": "false" if audio_only else "true",
            "video_quality": str(quality),
        }
        if audio_only:
            params["audio_only"] = "true"

        headers = self._service_headers()
        status, text, payload = await self._service_text("/api/video/download", params)
        task_id = ""
        if isinstance(payload, dict):
            task_id = str(payload.get("task_id") or payload.get("id") or "")
        if not task_id:
            m = re.search(r"(?:已存在任务ID|任务ID|task[_ -]?id)[:：\s]+([A-Za-z0-9_-]{8,})", text, re.I)
            task_id = m.group(1) if m else ""

        if status == 409:
            if not task_id:
                return "B站下载任务已存在，但服务端未返回任务编号。"
            # 查询已有任务，检查是否模式不匹配或已失败
            poll_status, poll_text, poll_payload = await self._service_text(f"/api/download/status/{quote(task_id, safe='')}")
            existing_audio_only = False
            existing_state = ""
            if isinstance(poll_payload, dict):
                t = poll_payload.get("task") if isinstance(poll_payload.get("task"), dict) else poll_payload
                existing_audio_only = bool(t.get("audio_only"))
                existing_state = str(t.get("status") or t.get("state") or "").lower()
            else:
                existing_audio_only = "仅音频: 是" in poll_text or "audio_only: true" in poll_text.lower()
                m_state = re.search(r"(?:任务状态|状态|status)[:：\s]+([a-zA-Z]+)", poll_text, re.I)
                if m_state:
                    existing_state = m_state.group(1).lower()

            is_failed = (
                any(term in (text + poll_text).lower() for term in ("failed", "失败", "error", "cancelled", "canceled", "取消"))
                or existing_state in {"failed", "error", "cancelled", "canceled"}
            )
            is_active = existing_state in {"pending", "downloading", "processing", "merging", "running"}
            same_mode = (bool(audio_only) == bool(existing_audio_only))

            if is_failed:
                # 已有任务已失败，清理旧任务后重新创建
                await self._remove_task(base, task_id, headers)
                status, text, payload = await self._service_text("/api/video/download", params)
                task_id = ""
                if isinstance(payload, dict):
                    task_id = str(payload.get("task_id") or payload.get("id") or "")
                if not task_id:
                    m = re.search(r"(?:已存在任务ID|任务ID|task[_ -]?id)[:：\s]+([A-Za-z0-9_-]{8,})", text, re.I)
                    task_id = m.group(1) if m else ""
            elif not same_mode:
                # 模式不同（例如已存在音频提取任务，当前请求视频下载；或反之）
                if is_active:
                    # 原任务仍在下载转码中，严禁强制清理（否则前序轮询协程会收到 404 导致生硬报错）
                    # 平滑等待原任务完成或失败（最多 45 秒）
                    wait_start = time.monotonic()
                    while time.monotonic() - wait_start < 45.0:
                        await asyncio.sleep(1.5)
                        p_status, p_text, p_payload = await self._service_text(f"/api/download/status/{quote(task_id, safe='')}")
                        p_state = ""
                        if isinstance(p_payload, dict):
                            pt = p_payload.get("task") if isinstance(p_payload.get("task"), dict) else p_payload
                            p_state = str(pt.get("status") or pt.get("state") or "").lower()
                        else:
                            m_pstate = re.search(r"(?:任务状态|状态|status)[:：\s]+([a-zA-Z]+)", p_text, re.I)
                            if m_pstate:
                                p_state = m_pstate.group(1).lower()
                        if p_state in {"completed", "success", "已完成", "完成", "failed", "error", "cancelled", "canceled"} or p_status in {404, 410}:
                            break
                    else:
                        prev_label = "音频提取" if existing_audio_only else "视频下载"
                        return f"该视频的{prev_label}任务仍在进行中，请等待其完成后再获取其他格式。"

                # 原任务已结束或等待完成，此时可以安全清理旧任务并重新发起新模式任务
                await self._remove_task(base, task_id, headers)
                status, text, payload = await self._service_text("/api/video/download", params)
                task_id = ""
                if isinstance(payload, dict):
                    task_id = str(payload.get("task_id") or payload.get("id") or "")
                if not task_id:
                    m = re.search(r"(?:已存在任务ID|任务ID|task[_ -]?id)[:：\s]+([A-Za-z0-9_-]{8,})", text, re.I)
                    task_id = m.group(1) if m else ""
            else:
                # 模式完全相同，且原任务正在进行或已完成，直接复用 task_id 进行等待或获取，不触发清理
                pass

        if (status >= 400 and status != 409) or not task_id:
            return f"B站解析服务请求失败 (HTTP {status}): {text[:120]}"

        poll_interval = max(0.5, float(self._cfg("video_poll_interval_sec") or 1.0))
        timeout_sec = float(self._cfg("video_download_timeout_sec") or 120.0)
        if timeout_sec <= 0:
            timeout_sec = 120.0

        start_time = time.monotonic()
        downloaded_filename = ""
        download_url = ""
        consecutive_404 = 0
        while time.monotonic() - start_time < timeout_sec:
            poll_status, poll_text, poll_payload = await self._service_text(f"/api/download/status/{quote(task_id, safe='')}")
            if poll_status in {404, 410}:
                consecutive_404 += 1
                if consecutive_404 >= 3:
                    return "B站下载任务不存在，可能已被服务端清理。"
                await asyncio.sleep(poll_interval)
                continue
            consecutive_404 = 0

            state = ""
            if isinstance(poll_payload, dict):
                task = poll_payload.get("task") if isinstance(poll_payload.get("task"), dict) else poll_payload
                state = str(task.get("status") or task.get("state") or "").lower()
                downloaded_filename = str(task.get("filename") or task.get("file_name") or task.get("name") or "")
                download_url = str(task.get("download_url") or task.get("file_url") or "")
            state_text = (state + " " + poll_text).lower()
            if any(token in state_text for token in ("failed", "error", "失败")):
                err_msg = ""
                if isinstance(poll_payload, dict):
                    t = poll_payload.get("task") if isinstance(poll_payload.get("task"), dict) else poll_payload
                    err_msg = str(t.get("error") or "")
                return f"B站媒体下载失败：{err_msg or '服务端下载任务异常'}"
            if any(token in state_text for token in ("completed", "success", "已完成", "完成")):
                match = re.search(r"(?:合并文件|视频文件|音频文件|filename)[:：\s]+([^\s]+)", poll_text, re.I)
                downloaded_filename = downloaded_filename or (match.group(1) if match else "")
                break
            await asyncio.sleep(poll_interval)
        else:
            return f"B站媒体下载超时（超过 {int(timeout_sec)} 秒），可能文件过大或服务繁忙。"

        if not downloaded_filename and not download_url:
            # 尝试根据 task_id 拼接兜底
            endpoint = "audio" if audio_only else "file"
            download_url = f"{base}/api/download/{endpoint}/{quote(task_id, safe='')}"

        ext = Path(downloaded_filename).suffix if downloaded_filename else (".m4a" if audio_only else ".mp4")
        safe_name = f"{uuid.uuid4().hex}{ext}"
        local_path = self.cache_dir / safe_name

        download_candidates = []
        if audio_only:
            download_candidates.append(f"{base}/api/download/audio/{quote(task_id, safe='')}")
        if download_url and download_url not in download_candidates:
            download_candidates.append(download_url)
        if downloaded_filename:
            fn = quote(Path(downloaded_filename).name, safe="")
            file_url = f"{base}/api/files/{fn}"
            if file_url not in download_candidates:
                download_candidates.append(file_url)
        if not download_candidates:
            endpoint = "audio" if audio_only else "file"
            download_candidates.append(f"{base}/api/download/{endpoint}/{quote(task_id, safe='')}")

        file_content = None
        last_error = ""
        async with httpx.AsyncClient(timeout=120.0) as client:
            for cand_url in download_candidates:
                try:
                    file_resp = await client.get(cand_url, headers=headers)
                    if file_resp.status_code == 200 and len(file_resp.content) > 0:
                        file_content = file_resp.content
                        break
                    last_error = f"HTTP {file_resp.status_code}"
                except Exception as dl_err:
                    last_error = str(dl_err)

        if not file_content:
            return f"下载成品媒体失败：{last_error or '未获取到有效媒体内容'}"

        local_path.write_bytes(file_content)

        if audio_only:
            local_path = await self._convert_audio_to_mp3(local_path)
            if video_title:
                safe_title = _sanitize_filename(video_title)
                if safe_title:
                    friendly_path = local_path.parent / f"{safe_title}.mp3"
                    try:
                        if friendly_path.exists():
                            friendly_path.unlink()
                        shutil.copy2(local_path, friendly_path)
                        local_path = friendly_path
                    except Exception as copy_err:
                        logger.warning("重命名音频文件为视频标题失败: %s", copy_err)

        self._media_cache[cache_key] = (time.monotonic() + 1800, local_path)
        self._clean_media_cache()

        file_type = 4 if (audio_only and as_file) else (3 if audio_only else 2)
        ok, err = await self._send_file_to_qq(context, local_path, file_type)
        if not ok:
            return f"B站媒体已下载，但 QQ 媒体发送失败：{err}"
        return ""

    async def _async_download_and_send(self, context: Any, source: str, audio_only: bool = False, as_file: bool = False) -> None:
        key = self._task_key(context.conversation_id, source, audio_only=audio_only, as_file=as_file)
        self._in_flight_tasks.add(key)
        try:
            res = await self._download_and_send(context, source, audio_only=audio_only, as_file=as_file)
            if res:
                qq = getattr(self.context, "qq", None)
                if qq:
                    await qq.send_text(context.conversation_id, getattr(context, "scene", "group"), res)
            else:
                self._recently_sent[key] = time.monotonic()
        except Exception as e:
            logger.exception("异步下载与发送异常: %s", e)
            qq = getattr(self.context, "qq", None)
            if qq:
                try:
                    await qq.send_text(context.conversation_id, getattr(context, "scene", "group"), f"B站媒体处理失败：{e}")
                except Exception:
                    pass
        finally:
            self._in_flight_tasks.discard(key)

    # ================= 扫码登录 =================
    async def _login(self, context: Any, args: list[str]) -> str:
        if not getattr(context, "is_admin", False):
            return "只有管理员可以操作 B站登录。"
        base = str(self._cfg("video_api_base_url") or "").rstrip("/")
        token = str(self._cfg("video_api_login_token") or "")
        if not base or not token:
            return "请先配置 video_api_base_url 和视频解析服务令牌。"
        action = str(args[1] if len(args) > 1 else "start").lower()
        if action in {"sync", "同步"}:
            res = await self._sync_cookie_from_download_site()
            if not res.get("success"):
                return f"❌ 从下载站同步 Cookie 失败：{res.get('message')}"
            u_info = res.get("user_info") or {}
            uname = u_info.get("username") or "未知"
            ulevel = f" (Lv{u_info.get('level')})" if u_info.get("level") else ""
            status_desc = "（已更新至本地）" if res.get("updated") else "（两边已一致）"
            login_desc = "已登录" if res.get("logged_in") else "未登录或已失效"
            return f"✅ 下载站 Cookie 同步完成 {status_desc}！\n👤 当前用户：{uname}{ulevel}\n📊 状态：{login_desc}"
        if action in {"status", "状态"}:
            key = str(args[2] if len(args) > 2 else "").strip()
            if not key:
                return "用法：/bili login status <qrcode_key>"
            status, _, payload = await self._service_text("/api/login/status", {"token": token, "qrcode_key": key})
            if status >= 400 or not isinstance(payload, dict):
                return f"B站登录状态查询失败：HTTP {status}"
            if payload.get("success") and str(payload.get("status") or "").lower() in {"success", "已登录"}:
                cookie = str(payload.get("cookie") or "").strip()
                if cookie:
                    self.config["bilibili_cookie"] = cookie
                    self._save_config()
                return "B站登录成功，Cookie 已保存。"
            return f"B站登录尚未完成：{payload.get('status') or payload.get('message') or '等待扫码'}"
        status, _, payload = await self._service_text("/api/login/qr", {"token": token})
        if status >= 400 or not isinstance(payload, dict) or not payload.get("success"):
            return f"B站登录二维码获取失败：HTTP {status}"
        key = str(payload.get("qrcode_key") or "")
        image_url = str(payload.get("image_url") or "")
        if image_url.startswith("/"):
            image_url = base + image_url
        if not key or not image_url:
            return "B站登录服务返回的二维码信息不完整。"
        target = self.cache_dir / f"login-qr-{key}.png"
        try:
            async with httpx.AsyncClient(timeout=float(self._cfg("api_timeout_sec"))) as client:
                resp = await client.get(image_url, headers=self._service_headers())
                if resp.status_code == 200 and len(resp.content) > 0:
                    target.write_bytes(resp.content)
            if target.is_file() and target.stat().st_size > 0:
                ok, err = await self._send_file_to_qq(context, target, file_type=1)
                if ok:
                    return f"B站登录二维码已发送，请扫码；查询：/bili login status {key}"
                logger.warning("发送 B站二维码图片失败: %s", err)
        finally:
            target.unlink(missing_ok=True)
        return f"B站登录二维码：{image_url}\n请扫码后查询：/bili login status {key}"

    # ================= 任务与文件管理 =================
    async def _handle_task_or_file(self, context: Any, action: str, args: list[str]) -> str | dict[str, Any]:
        base = str(self._cfg("video_api_base_url") or "").rstrip("/")
        if not base:
            return "尚未配置 B站视频解析服务。"
        is_task = action in {"task", "bili_task"}
        sub = str(args[1] or "").lower() if len(args) > 1 else ""
        target = str(args[2] or "") if len(args) > 2 else ""
        headers = self._service_headers()
        try:
            async with httpx.AsyncClient(timeout=float(self._cfg("api_timeout_sec"))) as client:
                if is_task and sub in {"cancel", "取消", "stop", "停止", "del", "delete", "删除"}:
                    if not target:
                        return "用法：/bili task cancel <任务ID/序号> 或 /bili task del <任务ID/序号>"
                    endpoint = "cancel" if sub in {"cancel", "取消", "stop", "停止"} else "remove"
                    resolved_id = target
                    if target.isdigit():
                        list_resp = await client.get(f"{base}/api/tasks/json", headers=headers)
                        if list_resp.status_code < 400:
                            try:
                                t_data = list_resp.json()
                            except Exception:
                                t_data = {}
                            t_map = t_data.get("tasks", {}) if isinstance(t_data, dict) else {}
                            t_list = list(t_map.keys()) if isinstance(t_map, dict) else []
                            idx = int(target) - 1
                            if 0 <= idx < len(t_list):
                                resolved_id = t_list[idx]
                    response = await client.post(f"{base}/api/tasks/{endpoint}/{quote(resolved_id, safe='')}", headers=headers, json={})
                    if response.status_code == 404:
                        return "B站任务未找到（可能已删除）。"
                    return "B站任务已取消。" if endpoint == "cancel" and response.status_code < 400 else ("B站任务已删除。" if response.status_code < 400 else f"B站任务操作失败：HTTP {response.status_code}")
                if not is_task and sub in {"del", "delete", "删除", "remove"}:
                    filename = target or (str(args[2]) if len(args) > 2 else "")
                    if not filename:
                        return "用法：/bili file del <文件名/序号>"
                    resolved_file = filename
                    if filename.isdigit():
                        list_resp = await client.get(f"{base}/api/files", headers=headers)
                        if list_resp.status_code < 400:
                            try:
                                f_data = list_resp.json()
                            except Exception:
                                f_data = {}
                            f_list = f_data.get("files", []) if isinstance(f_data, dict) else []
                            idx = int(filename) - 1
                            if 0 <= idx < len(f_list):
                                item = f_list[idx]
                                resolved_file = str(item.get("name") or item.get("filename") or resolved_file)
                    response = await client.delete(f"{base}/api/files/{quote(resolved_file, safe='')}", headers=headers)
                    if response.status_code == 404:
                        return "B站文件不存在（可能已删除）。"
                    return "B站文件已删除。" if response.status_code < 400 else f"B站文件删除失败：HTTP {response.status_code}"

                response = await client.get(base + ("/api/tasks/json" if is_task else "/api/files"), headers=headers)
                if response.status_code >= 400:
                    return f"解析服务 HTTP {response.status_code}"
                try:
                    data = response.json()
                except Exception:
                    data = {}

            values = data.get("tasks", {}) if is_task and isinstance(data, dict) else (data.get("files", []) if isinstance(data, dict) else [])
            items = ([{"id": str(k), **(v if isinstance(v, dict) else {"status": v})} for k, v in values.items()] if isinstance(values, dict) else [x for x in values if isinstance(x, dict)])
            if sub and sub.isdigit():
                page = max(1, int(sub))
            else:
                page = max(1, int(target)) if target.isdigit() else 1
            size = 8
            total_pages = max(1, (len(items) + size - 1) // size)
            page = min(page, total_pages)
            current = items[(page - 1) * size : page * size]
            if is_task:
                lines = ["| # | 任务 ID | 状态 | 文件 |", "|---:|---|---|---|"]
                for index, item in enumerate(current, (page - 1) * size + 1):
                    lines.append(f"| {index} | `{item.get('id', '-')}` | {item.get('status', 'unknown')} | {item.get('filename') or item.get('file_name') or '-'} |")
                title = f"B站下载任务（第 {page}/{total_pages} 页）"
                command_prefix = "/bili task"
            else:
                lines = ["| # | 文件名 | 大小 |", "|---:|---|---:|"]
                for index, item in enumerate(current, (page - 1) * size + 1):
                    name = item.get("filename") or item.get("name") or "-"
                    lines.append(f"| {index} | `{name}` | {item.get('size') or item.get('size_bytes') or '-'} |")
                title = f"B站下载文件（第 {page}/{total_pages} 页）"
                command_prefix = "/bili file"

            nav_row = []
            if page > 1:
                nav_row.append(make_button("上一页", f"{command_prefix} {page - 1}", type=1, permission=0))
            nav_row.append(make_button("跳页", f"{command_prefix} ", type=2, permission=0))
            if page < total_pages:
                nav_row.append(make_button("下一页", f"{command_prefix} {page + 1}", type=1, permission=0))

            action_row = [make_button("刷新", f"{command_prefix} {page}", type=1, permission=0)]
            if is_task:
                action_row.append(make_button("取消任务", f"{command_prefix} cancel ", type=2, permission=1))
                action_row.append(make_button("删除任务", f"{command_prefix} del ", type=2, permission=1))
            else:
                action_row.append(make_button("删除文件", f"{command_prefix} del ", type=2, permission=1))
            action_row.append(make_button("返回菜单", "/bili", type=1, permission=0))

            button_rows = []
            if nav_row:
                button_rows.append(nav_row)
            if len(action_row) > 3:
                button_rows.append(action_row[:2])
                button_rows.append(action_row[2:])
            elif action_row:
                button_rows.append(action_row)
            return make_card(title, "\n".join(lines) + "\n\n管理命令：任务可用 `/bili task cancel <ID>`、`/bili task del <ID>`；文件可用 `/bili file del <文件名>`。", button_rows)
        except (httpx.HTTPError, ValueError) as error:
            return f"解析服务请求失败：{str(error)[:160]}"

    # ================= 连通性检查与配置指令 =================
    async def _net_check(self) -> str:
        try:
            official_ok = False
            async with httpx.AsyncClient(timeout=float(self._cfg("api_timeout_sec"))) as client:
                r = await client.get("https://api.bilibili.com/x/web-interface/view?bvid=BV1Q541167Qg", headers={"User-Agent": str(self._cfg("user_agent"))})
                try:
                    official_ok = r.status_code == 200 and r.json().get("code") == 0
                except Exception:
                    official_ok = False
            custom = "未配置"
            cookie_desc = "未配置"
            base = str(self._cfg("video_api_base_url") or "").rstrip("/")
            if base:
                try:
                    async with httpx.AsyncClient(timeout=float(self._cfg("api_timeout_sec"))) as client:
                        r2 = await client.get(f"{base}/api", headers=self._service_headers())
                        custom = "正常" if r2.status_code < 400 else f"异常（HTTP {r2.status_code}）"
                except Exception as e:
                    custom = f"不可达 ({str(e)[:40]})"

                try:
                    sync_res = await self._sync_cookie_from_download_site()
                    if sync_res.get("logged_in") and sync_res.get("user_info"):
                        u = sync_res["user_info"]
                        cookie_desc = f"下载站已登录 ({u.get('username')}, Lv{u.get('level')})"
                    elif self._cfg("bilibili_cookie"):
                        cookie_desc = "已配置本地 Cookie"
                except Exception:
                    pass
            return f"B站官方接口：{'正常' if official_ok else '异常'}；自建解析服务：{custom}；Cookie 状态：{cookie_desc}。"
        except Exception as error:
            return f"B站接口检查失败：{str(error)[:160]}"

    async def _api_command(self, context: Any, args: list[str]) -> str:
        if len(args) >= 3 and args[1].lower() == "set":
            if not getattr(context, "is_admin", False):
                return "只有管理员可以修改 B站解析配置。"
            self.config["video_api_base_url"] = args[2]
            if len(args) >= 4:
                self.config["video_api_login_token"] = args[3]
            self._save_config()
            return "B站解析服务配置已保存。"
        base = self._cfg("video_api_base_url")
        cookie = self._cfg("bilibili_cookie")
        return f"B站解析 API：{'已配置 ' + str(base) if base else '未配置'}；Cookie：{'已设置' if cookie else '未设置'}。"

    # ================= 统一指令处理 =================
    async def on_command(self, context: Any, args: list[str]) -> Any:
        text = str(getattr(context, "text", "") or "").strip()
        parts = text.split()
        cmd_head = parts[0].lstrip("/").lower() if parts else "bili"
        sub_args = parts[1:] if len(parts) > 1 else []

        if cmd_head.startswith("bili_") and cmd_head not in {"bili"}:
            sub_args = [cmd_head[5:], *sub_args]

        action = sub_args[0].lower() if sub_args else ""

        if not action or action in {"help", "menu", "帮助", "菜单"}:
            card = self._menu_card()
            if hasattr(self.context, "qq") and hasattr(self.context.qq, "send_card"):
                await self.context.qq.send_card(context.conversation_id, getattr(context, "scene", "group"), card)
                return ""
            return card

        if action in {"parse", "解析"}:
            return self._submenu_card("parse")

        if action in {"config", "配置"}:
            return self._submenu_card("config")

        if action in {"net", "bili_net", "网络", "状态"}:
            return await self._net_check()

        if action in {"sync", "bili_sync", "同步"}:
            return await self._login(context, ["login", "sync"])

        if action in {"api", "bili_api"}:
            return await self._api_command(context, sub_args)

        if action in {"debug", "bili_debug", "callback", "bili_callback"}:
            return "该兼容命令已注册；详细配置请使用管理台设置页。"

        if action in {"login", "bili_login"}:
            return await self._login(context, sub_args)

        if action in {"task", "bili_task", "file", "bili_file"}:
            return await self._handle_task_or_file(context, action, sub_args)

        if action in {"dl", "download", "下载"}:
            source = " ".join(sub_args[1:]).strip() or text.split(maxsplit=2)[-1]
            if not source or not (URL_RE.search(source) or "b23.tv" in source.lower()):
                return "用法：/bili dl <B站链接>"
            key = self._task_key(context.conversation_id, source, False)
            if getattr(context, "interaction_id", None):
                if key in self._in_flight_tasks:
                    return "🎬 该视频正在下载处理中，马上发送，请稍候~"
                if time.monotonic() - self._recently_sent.get(key, 0) < 30:
                    return "🎬 该视频刚刚已发送到群里，无需重复下载~"
                asyncio.create_task(self._async_download_and_send(context, source, audio_only=False))
                return "🎬 已开始抓取B站视频，正在下载与处理中，请稍候..."
            if key in self._in_flight_tasks:
                return "🎬 该视频正在下载处理中，请稍候..."
            if time.monotonic() - self._recently_sent.get(key, 0) < 30:
                return "🎬 该视频刚刚已发送，无需重复下载。"
            self._in_flight_tasks.add(key)
            try:
                res = await self._download_and_send(context, source, audio_only=False)
                if not res:
                    self._recently_sent[key] = time.monotonic()
                return res or "B站视频已发送。"
            finally:
                self._in_flight_tasks.discard(key)

        is_audio_file = action in {"audio_file", "audiofile", "file_audio", "fileaudio", "音频文件"}
        if action in {"audio", "bili_audio", "音频"} or is_audio_file:
            all_text_lower = " ".join(sub_args).lower()
            if "file" in all_text_lower or "文件" in all_text_lower:
                is_audio_file = True
            clean_args = [a for a in sub_args[1:] if a.lower() not in {"file", "audio_file", "audiofile", "file_audio", "fileaudio", "文件", "音频文件"}]
            source = " ".join(clean_args).strip() or text.split(maxsplit=2)[-1]
            source = re.sub(r"\s+(file|文件)$", "", source, flags=re.I).strip()
            if not source or not (URL_RE.search(source) or "b23.tv" in source.lower()):
                return "用法：/bili audio <B站链接>（发送语音）或 /bili audio_file <B站链接>（发送音频文件）"
            key = self._task_key(context.conversation_id, source, audio_only=True, as_file=is_audio_file)
            target_label = "音频文件" if is_audio_file else "语音"
            if getattr(context, "interaction_id", None):
                if key in self._in_flight_tasks:
                    return f"🎵 该视频{target_label}正在抓取转码中，马上发送，请稍候~"
                if time.monotonic() - self._recently_sent.get(key, 0) < 30:
                    return f"🎵 该视频{target_label}刚刚已发送到群里，无需重复提取~"
                asyncio.create_task(self._async_download_and_send(context, source, audio_only=True, as_file=is_audio_file))
                return f"🎵 已开始抓取B站{target_label}，正在提取与转码中，请稍候..."
            if key in self._in_flight_tasks:
                return f"🎵 该视频{target_label}正在抓取转码中，请稍候..."
            if time.monotonic() - self._recently_sent.get(key, 0) < 30:
                return f"🎵 该视频{target_label}刚刚已发送，无需重复提取。"
            self._in_flight_tasks.add(key)
            try:
                res = await self._download_and_send(context, source, audio_only=True, as_file=is_audio_file)
                if not res:
                    self._recently_sent[key] = time.monotonic()
                return res or f"B站{target_label}提取并已发送。"
            finally:
                self._in_flight_tasks.discard(key)

        # 默认作为视频链接或 BV/AV 号进行解析
        target = find_target_in_text(text)
        if not target:
            target = find_target_in_text(" ".join(sub_args))
        if not target:
            return "用法：/bili <B站链接或 BV 号>"
        try:
            info = await self._fetch_video_info(target)
            cover = _https_url(info.get("cover") or info.get("pic"))
            if cover and (not info.get("width") or not info.get("height")):
                dim = await self._resolve_image_dimension(cover)
                if dim:
                    info["width"], info["height"] = dim
            card = self._build_info_card(info, text=target.canonical_url)
            if hasattr(self.context, "qq") and hasattr(self.context.qq, "send_card"):
                await self.context.qq.send_card(context.conversation_id, getattr(context, "scene", "group"), card)
                return ""
            return card
        except Exception as e:
            return f"B站解析失败：{str(e)[:200]}"

    async def on_event(self, context: Any) -> Any:
        if not self._cfg("enable_auto_detect"):
            return None
        msg_type = str(getattr(context, "message_type", "") or "")
        if msg_type == "102":
            return None
        text = str(getattr(context, "text", "") or "").strip()
        if text.startswith("/") or text.startswith(("[合并转发]", "[聊天记录]")):
            return None
        target = find_target_in_text(text)
        if not target:
            return None
        if target.title and not self._cfg("enable_parse_miniapp"):
            return None
        try:
            info = await self._fetch_video_info(target)
            cover = _https_url(info.get("cover") or info.get("pic"))
            if cover and (not info.get("width") or not info.get("height")):
                dim = await self._resolve_image_dimension(cover)
                if dim:
                    info["width"], info["height"] = dim
            card = self._build_info_card(info, text=target.canonical_url)
            if hasattr(self.context, "qq") and hasattr(self.context.qq, "send_card"):
                await self.context.qq.send_card(context.conversation_id, getattr(context, "scene", "group"), card)
            elif hasattr(self.context, "qq") and hasattr(self.context.qq, "send_text"):
                await self.context.qq.send_text(context.conversation_id, getattr(context, "scene", "group"), f"📺 {info['title']}\nUP主：{info['author']}\n{info['url']}")
        except Exception as e:
            logger.debug("B站被动链接识别忽略: %s", e)
        return None

    async def on_cleanup(self) -> None:
        self._clean_media_cache()
        self._write_page_snapshot()

    def _write_page_snapshot(self) -> None:
        """写入原生控制台快照（data_dir/page_overview.json）。

        敏感字段在快照中置空并以 ``_configured`` 标记代替，由控制台显示"已配置"。
        """
        try:
            self.data_dir.mkdir(parents=True, exist_ok=True)
            cookie = str(self._cfg("bilibili_cookie") or "").strip()
            token = str(self._cfg("video_api_login_token") or "").strip()
            cfg: dict[str, Any] = {}
            schema: dict[str, Any] = {}
            for key, default in DEFAULT_CONFIG.items():
                if key in ("bilibili_cookie", "video_api_login_token"):
                    cfg[key] = ""
                else:
                    cfg[key] = self._cfg(key)
                if isinstance(default, bool):
                    schema[key] = {"type": "bool", "default": default}
                elif isinstance(default, float):
                    schema[key] = {"type": "float", "default": default}
                elif isinstance(default, int):
                    schema[key] = {"type": "int", "default": default}
                else:
                    schema[key] = {"type": "str", "default": default}
            cfg["bilibili_cookie_configured"] = bool(cookie)
            cfg["video_api_login_token_configured"] = bool(token)
            base = str(self._cfg("video_api_base_url") or "").strip()
            snapshot = {
                "config": cfg,
                "schema": schema,
                "labels": {},
                "service": {
                    "B 站 Cookie": "已配置" if cookie else "未配置",
                    "解析服务": "已配置" if base else "未配置",
                },
            }
            (self.data_dir / "page_overview.json").write_text(
                json.dumps(snapshot, ensure_ascii=False, indent=2), encoding="utf-8"
            )
        except Exception as error:
            logger.warning("写入 plugin.bili page_overview.json 失败: %s", error)

    # ================= 管理台 Action 动作 =================
    async def action_get_config(self, payload: dict[str, Any] | None = None) -> dict[str, Any]:
        self._load_config()
        cfg = dict(self.config)
        if cfg.get("video_api_login_token"):
            cfg["video_api_login_token_configured"] = True
            cfg["video_api_login_token"] = "******"
        return {"config": cfg}

    async def action_save_config(self, payload: dict[str, Any] | None = None) -> dict[str, Any]:
        data = payload or {}
        new_cookie = None
        for k, v in data.items():
            if k in DEFAULT_CONFIG:
                if k == "video_api_login_token" and str(v).strip() == "******":
                    continue
                if k == "bilibili_cookie" and str(v).strip() != str(self.config.get("bilibili_cookie") or "").strip():
                    new_cookie = str(v).strip()
                self.config[k] = v
        self._save_config()
        self._write_page_snapshot()
        if new_cookie:
            asyncio.create_task(self._sync_cookie_to_download_site(new_cookie))
        return {"success": True, "config": self.config}

    async def action_page_data(self, payload: dict[str, Any] | None = None) -> dict[str, Any]:
        base = str(self._cfg("video_api_base_url") or "").rstrip("/")
        cookie = str(self._cfg("bilibili_cookie") or "").strip()
        cookie_status = "healthy" if "SESSDATA=" in cookie else ("incomplete" if cookie else "missing")
        user_info = None

        if not base:
            return {
                "service_configured": False,
                "cookie_status": cookie_status,
                "tasks": [],
                "files": [],
            }

        # 尝试拉取下载站最新 Cookie 并同步
        try:
            sync_res = await self._sync_cookie_from_download_site()
            if sync_res.get("logged_in") and sync_res.get("user_info"):
                user_info = sync_res["user_info"]
                cookie_status = "healthy"
                cookie = sync_res.get("cookie") or cookie
        except Exception:
            pass

        headers = self._service_headers()
        tasks = []
        files = []
        async with httpx.AsyncClient(timeout=float(self._cfg("api_timeout_sec"))) as client:
            try:
                t_res = await client.get(f"{base}/api/tasks/json", headers=headers)
                if t_res.status_code == 200:
                    raw_tasks = t_res.json().get("tasks", {})
                    if isinstance(raw_tasks, dict):
                        tasks = [{"id": k, **(v if isinstance(v, dict) else {"status": v})} for k, v in raw_tasks.items()]
                    elif isinstance(raw_tasks, list):
                        tasks = [{"id": str(t.get("id", "") if isinstance(t, dict) else t), **(t if isinstance(t, dict) else {"status": t})} for t in raw_tasks]
            except Exception:
                pass

            try:
                f_res = await client.get(f"{base}/api/files", headers=headers)
                if f_res.status_code == 200:
                    raw_files = f_res.json().get("files", [])
                    if isinstance(raw_files, list):
                        for f in raw_files:
                            name = str(f.get("name", "") if isinstance(f, dict) else f)
                            files.append({"id": name, "name": name, "filename": name, **(f if isinstance(f, dict) else {})})
            except Exception:
                pass

        return {
            "service_configured": True,
            "cookie_status": cookie_status,
            "user_info": user_info,
            "tasks": tasks,
            "files": files,
        }

    async def action_page_delete(self, payload: dict[str, Any] | None = None) -> dict[str, Any]:
        data = payload or {}
        kind = str(data.get("kind") or "file")
        targets = data.get("identifiers") or [data.get("identifier")]
        clean_targets = [str(t) for t in targets if t]

        base = str(self._cfg("video_api_base_url") or "").rstrip("/")
        if not base:
            raise ValueError("未配置视频解析服务")

        headers = self._service_headers()
        deleted = []
        async with httpx.AsyncClient(timeout=float(self._cfg("api_timeout_sec"))) as client:
            for item in clean_targets:
                safe_id = quote(Path(item).name if kind == "file" else item, safe="")
                url = f"{base}/api/tasks/remove/{safe_id}" if kind == "task" else f"{base}/api/files/{safe_id}"
                try:
                    res = await client.delete(url, headers=headers) if kind == "file" else await client.post(url, headers=headers)
                    if res.status_code < 400 or res.status_code == 404:
                        deleted.append(item)
                except Exception:
                    pass
        return {"deleted": True, "ids": deleted}


def setup(context: Any) -> BiliPlugin:
    plugin = BiliPlugin(context)
    context.register_command("bili", plugin.on_command, category="media", description="B站音视频解析与下载")
    context.register_event_handler("*", plugin.on_event)
    context.register_task("cleanup", 3600, plugin.on_cleanup)
    context.register_action("get_config", plugin.action_get_config)
    context.register_action("save_config", plugin.action_save_config)
    context.register_action("page_data", plugin.action_page_data)
    context.register_action("page_delete", plugin.action_page_delete)
    try:
        loop = asyncio.get_event_loop()
        if loop.is_running():
            loop.create_task(plugin._sync_cookie_from_download_site())
    except Exception:
        pass
    plugin._write_page_snapshot()
    return plugin
