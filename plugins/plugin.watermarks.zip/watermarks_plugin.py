"""外部独立插件 plugin.watermarks (水印清理)。

支持检测并移除图片、PDF、音视频及文本中的 EXIF、XMP、C2PA、隐写字符、
双向控制符及 AI 生成元数据标记，提供完整 QQ 交互卡片与原生管理台集成。
"""

from __future__ import annotations

import base64
import datetime
import io
import json
import logging
import os
import re
import shutil
import time
from pathlib import Path
from typing import Any

import httpx

from runtime.models import Button, Card

logger = logging.getLogger("plugin.watermarks")
PLUGIN_VERSION = "1.3.4"

DEFAULT_CONFIG: dict[str, Any] = {
    "enabled": True,
    "service_url": "http://watermarks-remover:8765",
    "service_token": "",
    "request_timeout_sec": 30,
    "max_file_size_mb": 20,
    "auto_detect": False,
    "require_confirm": True,
    "enable_qq_cards": True,
    "file_wait_seconds": 120,
    "keep_non_ai_metadata": True,
    "strip_all_metadata": False,
    "clean_text_homoglyphs": False,
}

CONFIG_SCHEMA: dict[str, Any] = {
    "enabled": {
        "type": "boolean",
        "label": "启用水印清理",
        "description": "全局控制是否开启水印检测与清理功能",
        "options": [
            {"label": "开启 / 启用", "value": True},
            {"label": "关闭 / 禁用", "value": False},
        ],
    },
    "service_url": {
        "type": "string",
        "label": "水印清理服务地址",
        "description": "独立 watermarks-remover 服务地址，例如 http://192.168.1.219:8765",
    },
    "service_token": {
        "type": "string",
        "label": "服务认证令牌",
        "description": "可选的服务鉴权 Token",
    },
    "request_timeout_sec": {
        "type": "number",
        "label": "请求超时（秒）",
        "description": "请求水印服务超时时间，建议 30 秒",
    },
    "max_file_size_mb": {
        "type": "number",
        "label": "最大文件大小（MB）",
        "description": "支持处理的最大文件限制",
    },
    "auto_detect": {
        "type": "boolean",
        "label": "被动检测记录",
        "description": "收图时自动分析元数据并登记（不主动刷屏提醒）",
        "options": [
            {"label": "开启被动检测", "value": True},
            {"label": "关闭被动检测", "value": False},
        ],
    },
    "require_confirm": {
        "type": "boolean",
        "label": "文件清理前二次确认",
        "description": "清理附件前提示用户点击确认按钮",
        "options": [
            {"label": "需要确认（提示确认按钮）", "value": True},
            {"label": "免确认直接清理回传", "value": False},
        ],
    },
    "enable_qq_cards": {
        "type": "boolean",
        "label": "启用 QQ Markdown 卡片",
        "description": "以官方富媒体卡片与交互按钮形式展示",
        "options": [
            {"label": "启用卡片与按钮菜单", "value": True},
            {"label": "仅使用纯文本交互", "value": False},
        ],
    },
    "file_wait_seconds": {
        "type": "number",
        "label": "文件等待窗口（秒）",
        "description": "发送检测/清理指令后等待用户发图的有效时间",
    },
    "keep_non_ai_metadata": {
        "type": "boolean",
        "label": "保留正常摄影 EXIF",
        "description": "仅清除 AI 与 C2PA 标记，保留普通相机的时间、光圈、ISO 等拍摄参数",
        "options": [
            {"label": "保留摄影 EXIF（推荐）", "value": True},
            {"label": "完全剥离所有 EXIF", "value": False},
        ],
    },
    "strip_all_metadata": {
        "type": "boolean",
        "label": "深度彻底抹杀元数据",
        "description": "无差别移除所有元数据轨道，达到最高级别的匿名脱敏",
        "options": [
            {"label": "常规安全脱敏", "value": False},
            {"label": "彻底抹杀所有元数据", "value": True},
        ],
    },
    "clean_text_homoglyphs": {
        "type": "boolean",
        "label": "文本激进同形字清洗",
        "description": "清洗文本时启用 Unicode 同形字与混淆字清洗",
        "options": [
            {"label": "开启同形字清洗", "value": True},
            {"label": "常规零宽字符清洗", "value": False},
        ],
    },
}

CONFIG_LABELS: dict[str, str] = {
    "enabled": "启用水印清理",
    "service_url": "独立服务地址",
    "service_token": "服务 Token",
    "request_timeout_sec": "请求超时（秒）",
    "max_file_size_mb": "最大文件大小（MB）",
    "auto_detect": "被动检测记录",
    "require_confirm": "文件清理前要求确认",
    "enable_qq_cards": "启用 QQ 卡片菜单",
    "file_wait_seconds": "文件等待窗口（秒）",
    "keep_non_ai_metadata": "保留摄影 EXIF",
    "strip_all_metadata": "彻底抹杀元数据",
    "clean_text_homoglyphs": "文本激进同形字清洗",
}


def _b64_text(text: str) -> str:
    return base64.b64encode(text.encode("utf-8")).decode("ascii")


def _wm_button(label: str, command: str, *, action_type: int | None = None, enter: bool = False, admin: bool = False) -> Button:
    resolved_action = action_type if action_type is not None else (2 if command.endswith(" ") else 1)
    return Button(
        label[:10],
        command,
        action_type=resolved_action,
        enter=enter,
        permission=1 if admin else 2,
        click_limit=30,
        expires_after_seconds=900,
        expired_message="此操作按钮已过期，请重新发送 /wm 打开菜单。",
        permission_message="此操作需要管理员权限。",
    )


def _wm_markdown(title: str, content: str, limit: int = 3300) -> str:
    text = str(content or "无数据").strip()
    if len(text) > limit:
        text = text[:limit].rsplit("\n", 1)[0].rstrip() + "\n\n> 内容较长，已截短。"
    return f"# {str(title)[:80]}\n\n{text}"[:4000]


_ACTION_LABELS = {
    "drop APP1": "移除 EXIF 段",
    "drop APP": "移除元数据段",
    "exiftool -all= pass": "exiftool 清空全部元数据",
    "preserved entropy-coded scan (SOS→EOF)": "保留图像本体",
    "strip xmp": "移除 XMP",
    "strip c2pa": "移除 C2PA",
}


def _humanize_action(action: str) -> str:
    return _ACTION_LABELS.get(action, action)


def _humanize_finding(finding: str) -> str:
    f_lower = str(finding or "").lower()
    if "c2pa-related manifest" in f_lower:
        return "C2PA 官方溯源清单 (Content Credentials Manifest)"
    if "jpeg app11 segment" in f_lower:
        return "JPEG APP11 扩展段 (JUMBF/C2PA 结构)"
    if "synthid pixel watermark detected" in f_lower:
        return "检测到 Google SynthID 像素级不可见隐写水印"
    if "synthid" in f_lower:
        return "包含 Google SynthID AI 水印标记"
    if "trainedalgorithmicmedia" in f_lower:
        return "IPTC 算法/AI 模型生成媒体声明 (trainedAlgorithmicMedia)"
    if "google generative ai" in f_lower:
        return "Google Generative AI 官方生成标记"
    if "digitalsourcetype" in f_lower:
        return "数字来源类型标记 (digitalSourceType)"
    return str(finding or "")


def _format_fraction(val: Any) -> str:
    try:
        f = float(val)
        if f <= 0:
            return str(val)
        if f < 1.0:
            denom = int(round(1.0 / f))
            return f"1/{denom}s"
        return f"{f:.1f}s" if f != int(f) else f"{int(f)}s"
    except Exception:
        return str(val)


def _dms_str(dms: Any, ref: str = "") -> str:
    try:
        if isinstance(dms, (list, tuple)) and len(dms) >= 3:
            deg = int(dms[0])
            m = int(dms[1])
            s = float(dms[2])
            dec = deg + m / 60.0 + s / 3600.0
            if ref in {"S", "W"}:
                dec = -dec
            return f"{deg}°{m}'{s:.1f}\"{ref} ({dec:.5f}°)"
        elif isinstance(dms, (int, float)):
            dec = float(dms)
            if ref in {"S", "W"}:
                dec = -dec
            return f"{dec:.5f}°{ref}"
    except Exception:
        pass
    return f"{dms} {ref}".strip()


def _extract_rich_metadata(raw: bytes, filename: str) -> dict[str, Any]:
    meta: dict[str, Any] = {}
    if not raw:
        return meta

    meta["filename"] = filename or "未知"
    meta["file_size"] = f"{len(raw) / 1024:.1f} KB" if len(raw) < 1024 * 1024 else f"{len(raw) / (1024 * 1024):.2f} MB"

    # 1. 尝试从 PIL Image 读取 EXIF 与图片属性
    try:
        from PIL import ExifTags, Image
        img = Image.open(io.BytesIO(raw))
        meta["dimensions"] = f"{img.width} x {img.height} 像素 ({img.width * img.height / 1_000_000:.1f} MP)"
        meta["format"] = (img.format or "未知").upper()
        if img.mode:
            meta["mode"] = img.mode

        exif_data = img.getexif()
        if exif_data:
            tag_map = {
                ExifTags.Base.DateTimeOriginal.value: "datetime_original",
                ExifTags.Base.DateTime.value: "datetime",
                ExifTags.Base.DateTimeDigitized.value: "datetime_digitized",
                ExifTags.Base.Make.value: "make",
                ExifTags.Base.Model.value: "model",
                ExifTags.Base.Software.value: "software",
                ExifTags.Base.Artist.value: "artist",
                ExifTags.Base.Copyright.value: "copyright",
                ExifTags.Base.ImageDescription.value: "description",
                ExifTags.Base.ExposureTime.value: "exposure_time",
                ExifTags.Base.FNumber.value: "f_number",
                ExifTags.Base.ISOSpeedRatings.value: "iso",
                ExifTags.Base.FocalLength.value: "focal_length",
                ExifTags.Base.FocalLengthIn35mmFilm.value: "focal_length_35mm",
                ExifTags.Base.ExposureBiasValue.value: "exposure_bias",
                ExifTags.Base.LensModel.value: "lens_model",
                ExifTags.Base.LensMake.value: "lens_make",
                ExifTags.Base.MeteringMode.value: "metering_mode",
                ExifTags.Base.Flash.value: "flash",
                ExifTags.Base.WhiteBalance.value: "white_balance",
            }

            for tag_id, key in tag_map.items():
                if tag_id in exif_data:
                    val = exif_data[tag_id]
                    if val is not None and str(val).strip() != "":
                        meta[key] = val

            try:
                sub_ifd = exif_data.get_ifd(ExifTags.IFD.Exif)
                if sub_ifd:
                    for tag_id, key in tag_map.items():
                        if key not in meta and tag_id in sub_ifd:
                            val = sub_ifd[tag_id]
                            if val is not None and str(val).strip() != "":
                                meta[key] = val
            except Exception:
                pass

            try:
                gps_ifd = exif_data.get_ifd(ExifTags.IFD.GPSInfo)
                if gps_ifd:
                    lat = gps_ifd.get(2)
                    lat_ref = str(gps_ifd.get(1) or "N").strip()
                    lon = gps_ifd.get(4)
                    lon_ref = str(gps_ifd.get(3) or "E").strip()
                    if lat and lon:
                        meta["gps_latitude"] = _dms_str(lat, lat_ref)
                        meta["gps_longitude"] = _dms_str(lon, lon_ref)
                    alt = gps_ifd.get(6)
                    if alt is not None:
                        try:
                            meta["gps_altitude"] = f"{float(alt):.1f} 米"
                        except Exception:
                            meta["gps_altitude"] = f"{alt} 米"
                    gps_date = gps_ifd.get(29)
                    gps_time = gps_ifd.get(7)
                    if gps_date:
                        time_part = f" {int(gps_time[0]):02d}:{int(gps_time[1]):02d}:{int(gps_time[2]):02d} UTC" if gps_time and len(gps_time) >= 3 else ""
                        meta["gps_datetime"] = f"{gps_date}{time_part}"
            except Exception:
                pass
    except Exception:
        pass

    # 2. 如果是 PDF 文件，解析标准 Info 字典
    suffix = os.path.splitext(str(filename or ""))[1].lower()
    if suffix == ".pdf" or raw[:1024].startswith(b"%PDF"):
        meta["format"] = "PDF 文档"
        for key, field in [
            ("Title", "pdf_title"),
            ("Author", "pdf_author"),
            ("Subject", "pdf_subject"),
            ("Creator", "pdf_creator"),
            ("Producer", "pdf_producer"),
            ("CreationDate", "pdf_creation_date"),
            ("ModDate", "pdf_mod_date"),
        ]:
            m = re.search(rb"/" + key.encode("ascii") + rb"\s*\(([^)]+)\)", raw[:65536] + raw[-65536:])
            if m:
                try:
                    meta[field] = m.group(1).decode("utf-8", errors="replace")
                except Exception:
                    pass

    return meta


def _format_rich_metadata_lines(meta: dict[str, Any]) -> list[str]:
    lines: list[str] = []
    if not meta:
        return lines

    # 拍摄时间
    dt = meta.get("datetime_original") or meta.get("datetime") or meta.get("datetime_digitized")
    if dt:
        lines.append(f"- 🕒 **拍摄时间**：`{str(dt).strip()}`")

    # 设备型号
    make = str(meta.get("make") or "").strip()
    model = str(meta.get("model") or "").strip()
    if model:
        device_str = f"{make} {model}".strip() if make and make.lower() not in model.lower() else model
        lines.append(f"- 📱 **拍摄设备**：`{device_str}`")
    elif make:
        lines.append(f"- 📱 **拍摄品牌**：`{make}`")

    # 镜头型号
    lens = str(meta.get("lens_model") or meta.get("lens_make") or "").strip()
    if lens:
        lines.append(f"- 🔭 **镜头型号**：`{lens}`")

    # 拍摄参数组合 (光圈 · 快门 · ISO · 焦距)
    param_parts: list[str] = []
    if meta.get("f_number"):
        try:
            param_parts.append(f"f/{float(meta['f_number']):.1f}")
        except Exception:
            param_parts.append(f"f/{meta['f_number']}")
    if meta.get("exposure_time"):
        param_parts.append(_format_fraction(meta["exposure_time"]))
    if meta.get("iso"):
        param_parts.append(f"ISO {meta['iso']}")
    if meta.get("focal_length"):
        try:
            fl_str = f"{float(meta['focal_length']):.1f}mm"
        except Exception:
            fl_str = f"{meta['focal_length']}mm"
        if meta.get("focal_length_35mm"):
            fl_str += f" (等效 35mm: {meta['focal_length_35mm']}mm)"
        param_parts.append(fl_str)
    if meta.get("exposure_bias"):
        try:
            bias = float(meta["exposure_bias"])
            param_parts.append(f"{bias:+.1f} EV")
        except Exception:
            param_parts.append(f"{meta['exposure_bias']} EV")
    if param_parts:
        lines.append(f"- ⚙️ **拍摄参数**：`{' · '.join(param_parts)}`")

    # 地理位置 GPS
    if meta.get("gps_latitude") and meta.get("gps_longitude"):
        gps_str = f"{meta['gps_latitude']}, {meta['gps_longitude']}"
        if meta.get("gps_altitude"):
            gps_str += f" · 海拔 {meta['gps_altitude']}"
        lines.append(f"- 📍 **地理位置 (GPS)**：`{gps_str}`")
    elif meta.get("gps_altitude"):
        lines.append(f"- 📍 **海拔高度**：`{meta['gps_altitude']}`")

    # 图像基础信息
    if meta.get("dimensions"):
        dim_str = meta["dimensions"]
        if meta.get("mode"):
            dim_str += f" · {meta['mode']}"
        lines.append(f"- 📐 **图像尺寸**：`{dim_str}`")

    # 固件/软件
    if meta.get("software"):
        lines.append(f"- 💻 **处理软件**：`{str(meta['software']).strip()}`")

    # 创作者与版权
    creator = meta.get("artist") or meta.get("pdf_author")
    if creator:
        lines.append(f"- 👤 **创作者/作者**：`{str(creator).strip()}`")
    if meta.get("copyright"):
        lines.append(f"- ⚖️ **版权信息**：`{str(meta['copyright']).strip()}`")
    if meta.get("description"):
        lines.append(f"- 📝 **图片描述**：`{str(meta['description']).strip()}`")

    # PDF 文档元数据
    if meta.get("pdf_title"):
        lines.append(f"- 📄 **文档标题**：`{str(meta['pdf_title']).strip()}`")
    if meta.get("pdf_creator") or meta.get("pdf_producer"):
        tool_str = " · ".join(filter(None, [str(meta.get("pdf_creator") or "").strip(), str(meta.get("pdf_producer") or "").strip()]))
        lines.append(f"- 🖨️ **生成工具**：`{tool_str}`")
    if meta.get("pdf_creation_date"):
        lines.append(f"- 📅 **创建日期**：`{str(meta['pdf_creation_date']).strip()}`")

    return lines


def _local_inspect_file(raw: bytes, filename: str) -> dict[str, Any]:
    suffix = os.path.splitext(str(filename or ""))[1].lower()
    report: dict[str, Any] = {"format": suffix.lstrip(".") or "bin", "has_c2pa": False, "has_ai_metadata": False, "findings": []}
    suspicious: dict[str, Any] = {"verdict": False, "description": "本地基础检测：未发现明显元数据标记。"}

    raw_head = raw[: 2 * 1024 * 1024]
    raw_lower = raw_head.lower()
    findings: list[str] = []

    if b"c2pa" in raw_lower or b"c2manifest" in raw_lower or b"jumb" in raw_lower or b"contentcredentials" in raw_lower:
        report["has_c2pa"] = True
        findings.append("C2PA 溯源签名标记 (JUMBF/Manifest)")
    if any(k in raw_lower for k in (
        b"stable diffusion", b"midjourney", b"dall-e", b"dalle", b"novelai", b"comfyui", b"steerable",
        b"synthid", b"trainedalgorithmicmedia", b"google generative ai", b"digitalsourcetype",
        b"aigc", b"parameters\xa1", b"parameters", b"negative prompt", b"steps: ", b"sampler: "
    )):
        report["has_ai_metadata"] = True
        findings.append("AI 生成工具元数据标识 (AIGC/SynthID/Prompt)")
    if b"exif" in raw_lower or b"\xff\xe1" in raw_head:
        findings.append("EXIF 元数据轨道")
    if b"xmp" in raw_lower or b"http://ns.adobe.com/xap/" in raw_lower:
        findings.append("XMP 扩展元数据")

    try:
        from PIL import Image
        img = Image.open(io.BytesIO(raw))
        report["dimensions"] = f"{img.width}x{img.height}"
        report["format"] = img.format or report["format"]
        raw_exif = img.getexif()
        if raw_exif:
            findings.append(f"EXIF 标签 ({len(raw_exif)} 项)")
    except Exception:
        pass

    rich_meta = _extract_rich_metadata(raw, filename)
    report["rich_metadata"] = rich_meta
    report["findings"] = findings
    if findings:
        suspicious["verdict"] = True
        suspicious["description"] = "发现以下元数据痕迹：" + "、".join(findings)
    return {"ok": True, "kind": "file", "filename": filename, "report": report, "suspicious": suspicious}


def _local_clean_image(raw: bytes, filename: str) -> tuple[bytes, list[str]]:
    try:
        from PIL import Image
        img = Image.open(io.BytesIO(raw))
        fmt = (img.format or "PNG").upper()
        out = io.BytesIO()
        if fmt in ("JPEG", "JPG"):
            if img.mode not in ("RGB", "L"):
                img = img.convert("RGB")
            img.save(out, format="JPEG", quality=95)
        elif fmt == "PNG":
            img.save(out, format="PNG", optimize=True)
        elif fmt == "WEBP":
            img.save(out, format="WEBP", quality=95)
        else:
            img.save(out, format=fmt)
        return out.getvalue(), [f"本地剥离 {fmt} EXIF/元数据"]
    except Exception:
        return raw, []


class WatermarksPlugin:
    PLUGIN_VERSION = PLUGIN_VERSION

    def __init__(self, context: Any) -> None:
        self.context = context
        self.config_dir = Path(getattr(context, "config_dir", "./config"))
        self.data_dir = Path(getattr(context, "data_dir", "./data"))
        self.config_dir.mkdir(parents=True, exist_ok=True)
        self.data_dir.mkdir(parents=True, exist_ok=True)
        self.temp_dir = self.data_dir / "temp"
        self.temp_dir.mkdir(parents=True, exist_ok=True)

        self.config = dict(DEFAULT_CONFIG)
        self._load_config()

        self._pending_files: dict[str, dict[str, str]] = {}
        self._pending_files_at: dict[str, float] = {}
        self._detection_log: list[dict[str, Any]] = []
        self._file_waiters: dict[str, Any] = {}
        self._last_cleaned = ""
        self._load_detection_records()

    def _load_config(self) -> None:
        cfg_file = self.config_dir / "config.json"
        if cfg_file.is_file():
            try:
                mtime = cfg_file.stat().st_mtime
                if mtime != getattr(self, "_config_mtime", 0.0):
                    data = json.loads(cfg_file.read_text(encoding="utf-8"))
                    if isinstance(data, dict):
                        self.config.update(data)
                        self._config_mtime = mtime
            except Exception as e:
                logger.warning("读取 plugin.watermarks 配置失败: %s", e)
        else:
            self._save_config()

    def _cfg(self, key: str) -> Any:
        self._load_config()
        val = self.config.get(key, DEFAULT_CONFIG.get(key))
        if isinstance(DEFAULT_CONFIG.get(key), bool):
            if isinstance(val, str):
                return val.lower() in {"true", "1", "on", "yes"}
            return bool(val)
        return val

    def _is_admin(self, context: Any) -> bool:
        return bool(getattr(context, "is_admin", False) or getattr(context, "role", "") in {"admin", "owner", "master"})

    def _save_config(self) -> None:
        cfg_file = self.config_dir / "config.json"
        try:
            cfg_file.parent.mkdir(parents=True, exist_ok=True)
            cfg_file.write_text(json.dumps(self.config, ensure_ascii=False, indent=2), encoding="utf-8")
        except Exception as e:
            logger.error("保存 plugin.watermarks 配置失败: %s", e)

    def _load_detection_records(self) -> None:
        rec_file = self.data_dir / "detection_records.json"
        if rec_file.is_file():
            try:
                data = json.loads(rec_file.read_text(encoding="utf-8"))
                if isinstance(data, list):
                    self._detection_log = data[-500:]
            except Exception as e:
                logger.warning("读取 detection_records 失败: %s", e)

    def _save_detection_records(self) -> None:
        rec_file = self.data_dir / "detection_records.json"
        try:
            rec_file.write_text(json.dumps(self._detection_log[-500:], ensure_ascii=False, indent=2), encoding="utf-8")
        except Exception as e:
            logger.debug("保存 detection_records 失败: %s", e)

    def _save_preview_file(self, raw: bytes, filename: str) -> str:
        """将图片安全缓存至本地 previews 目录，返回通过运行时代理访问的本地 URL。"""
        if not raw:
            return ""
        try:
            preview_dir = self.data_dir / "previews"
            preview_dir.mkdir(parents=True, exist_ok=True)
            import hashlib
            h = hashlib.sha256(raw[: 1024 * 1024] + str(len(raw)).encode()).hexdigest()[:16]
            ext = os.path.splitext(str(filename or ""))[1].lower()
            if not ext or ext not in {".jpg", ".jpeg", ".png", ".webp", ".gif", ".bmp", ".pdf"}:
                ext = ".jpg"
            target_name = f"{h}{ext}"
            target_path = preview_dir / target_name
            if not target_path.exists():
                target_path.write_bytes(raw)
            return f"/api/plugin/plugin.watermarks/media/previews/{target_name}"
        except Exception as e:
            logger.debug("保存本地水印预览文件失败: %s", e)
            return ""

    async def _write_page_snapshot(self) -> None:
        out_dir = self.data_dir
        out_dir.mkdir(parents=True, exist_ok=True)
        snapshot_file = out_dir / "page_overview.json"
        nested = self.data_dir / "plugin-data"
        if nested.is_dir():
            shutil.rmtree(nested, ignore_errors=True)

        service_status = "offline"
        try:
            await self._call("/capabilities", timeout=1.5)
            service_status = "online"
        except Exception:
            service_status = "offline"

        records = self.detection_records(50)
        snapshot = {
            "updated_at": datetime.datetime.now(datetime.UTC).isoformat(),
            "config": dict(self.config),
            "schema": CONFIG_SCHEMA,
            "labels": CONFIG_LABELS,
            "stats": {
                "累计检测记录": len(self._detection_log),
                "疑似AI标记数": sum(1 for r in self._detection_log if r.get("flags", {}).get("ai_metadata")),
                "C2PA溯源数": sum(1 for r in self._detection_log if r.get("flags", {}).get("c2pa")),
                "包含隐形特征数": sum(
                    1 for r in self._detection_log
                    if r.get("flags", {}).get("verdict") or r.get("flags", {}).get("ai_metadata") or r.get("flags", {}).get("c2pa")
                ),
            },
            "service": {
                "服务状态": "正常在线" if service_status == "online" else "离线 / 未就绪",
                "被动检测": "已开启" if self._cfg("auto_detect") else "已关闭",
                "服务地址": str(self._cfg("service_url") or "未配置"),
            },
            "records": records,
            "files": self._format_records_as_files(records),
        }
        try:
            raw_text = json.dumps(snapshot, ensure_ascii=False, indent=2)
            snapshot_file.write_text(raw_text, encoding="utf-8")
            if snapshot_file != self.data_dir / "page_overview.json":
                try:
                    (self.data_dir / "page_overview.json").write_text(raw_text, encoding="utf-8")
                except Exception:
                    pass
        except Exception as e:
            logger.warning("写入 page_overview.json 失败: %s", e)

    def _format_records_as_files(self, records: list[dict[str, Any]]) -> list[dict[str, Any]]:
        formatted = []
        for idx, r in enumerate(records):
            flags = r.get("flags") or {}
            has_c2pa = bool(flags.get("c2pa"))
            has_ai = bool(flags.get("ai_metadata"))
            has_watermark = bool(flags.get("verdict") or has_c2pa or has_ai)
            findings = r.get("findings") or []
            summary = r.get("summary") or ""
            marks = []
            if has_c2pa:
                marks.append("C2PA")
            if has_ai:
                marks.append("AI")
            if not marks and has_watermark:
                marks.append("元数据")
            mark_label = "+".join(marks) if marks else "无标记"
            verdict = "疑似AI" if has_ai else ("已溯源" if has_c2pa else ("含元数据" if has_watermark else "正常"))
            local_url = str(r.get("local_url") or "").strip()
            raw_url = str(r.get("url") or "").strip()
            preview_url = local_url or raw_url
            is_expired = bool(not local_url and "multimedia.nt.qq.com.cn" in raw_url)
            formatted.append({
                "id": f"rec_{idx}_{r.get('name', 'file')}",
                "filename": f"{r.get('name', 'file')} [{mark_label}/{verdict}]",
                "name": r.get("name", "file"),
                "url": preview_url,
                "local_url": local_url,
                "raw_url": raw_url,
                "is_expired": is_expired,
                "has_aigc": has_ai,
                "c2pa": has_c2pa,
                "has_watermark": has_watermark,
                "findings": findings,
                "summary": summary,
                "size": r.get("size", 0),
                "content_type": r.get("kind", "unknown"),
                "status": verdict,
                "flags": flags,
                "created_at": r.get("at", ""),
            })
        return formatted

    async def on_page_action(self, action: str, payload: dict[str, Any]) -> dict[str, Any]:
        if action in {"save_config", "config"}:
            updates = payload.get("config") or payload
            if isinstance(updates, dict):
                for k, v in updates.items():
                    if k in DEFAULT_CONFIG:
                        self.config[k] = v
                self._save_config()
                await self._write_page_snapshot()
                return {"saved": True, "config": self.config}
            return {"saved": False, "error": "无效的配置参数"}

        if action in {"page_data", "data"}:
            records = self.detection_records(100)
            # 只返回格式化后的files数据，避免重复records导致payload过大
            service_status = "offline"
            try:
                await self._call("/capabilities", timeout=1.5)
                service_status = "online"
            except Exception:
                pass
            return {
                "records": records,
                "files": self._format_records_as_files(records),
                "total": len(records),
                "stats": {
                    "累计检测记录": len(self._detection_log),
                    "疑似AI标记数": sum(1 for r in self._detection_log if r.get("flags", {}).get("ai_metadata")),
                    "C2PA溯源数": sum(1 for r in self._detection_log if r.get("flags", {}).get("c2pa")),
                    "包含隐形特征数": sum(
                        1 for r in self._detection_log
                        if r.get("flags", {}).get("verdict") or r.get("flags", {}).get("ai_metadata") or r.get("flags", {}).get("c2pa")
                    ),
                },
                "service": {
                    "服务状态": "正常在线" if service_status == "online" else "离线 / 未就绪",
                    "被动检测": "已开启" if self._cfg("auto_detect") else "已关闭",
                },
            }

        if action in {"page_delete", "data_delete"}:
            raw_ids = payload.get("identifiers") or []
            if not raw_ids and payload.get("identifier"):
                raw_ids = [payload.get("identifier")]
            if raw_ids:
                count = self.delete_detection_records(raw_ids)
            else:
                count = self.clear_detection_records()
            await self._write_page_snapshot()
            return {"ok": True, "deleted_count": count}

        if action in {"clear", "data_clear"}:
            count = self.clear_detection_records()
            await self._write_page_snapshot()
            return {"ok": True, "deleted_count": count}

        if action in {"inspect_upload", "upload_inspect", "test_inspect"}:
            import base64
            filename = str(payload.get("filename") or "uploaded_test.jpg").strip()
            raw: bytes = b""

            temp_rel = str(payload.get("temp_file") or "").strip()
            if temp_rel:
                try:
                    temp_path = (self.data_dir / temp_rel).resolve()
                    if (self.data_dir.resolve() in temp_path.parents or temp_path.parent == self.data_dir.resolve()) and temp_path.is_file():
                        raw = temp_path.read_bytes()
                        try:
                            temp_path.unlink()
                        except Exception:
                            pass
                except Exception as e:
                    logger.warning("读取临时上传文件失败: %s", e)

            if not raw:
                b64 = str(payload.get("data") or payload.get("content_base64") or "")
                if "," in b64:
                    b64 = b64.partition(",")[2]
                if b64:
                    try:
                        raw = base64.b64decode(b64)
                    except Exception as e:
                        return {"ok": False, "error": f"Base64 解码失败: {e}"}

            if not raw:
                return {"ok": False, "error": "图片数据为空"}
            if len(raw) > int(self._cfg("max_file_size_mb") or 20) * 1024 * 1024:
                return {"ok": False, "error": "文件超出大小限制"}

            findings: list[str] = []
            has_c2pa = False
            has_ai = False
            format_name = os.path.splitext(filename)[1].lstrip(".") or "unknown"
            summary = ""

            try:
                res = await self._call("/inspect", {"file": base64.b64encode(raw).decode("ascii"), "name": filename}, timeout=10.0)
                report = res.get("report") if isinstance(res.get("report"), dict) else {}
                format_name = str(report.get("format") or format_name)
                has_c2pa = bool(report.get("has_c2pa"))
                has_ai = bool(report.get("has_ai_metadata"))
                # 立即提取findings，避免保存大量原始数据
                raw_findings = report.get("findings") or report.get("hits") or []
                for item in raw_findings[:20]:  # 最多处理20个原始findings
                    label = _humanize_finding(str(item)[:500])  # 限制单个finding长度
                    if label and label not in findings and len(findings) < 10:  # 最多保存10个
                        findings.append(label)
                # 提取C2PA snippet，但限制长度
                tools = report.get("tools") if isinstance(report.get("tools"), dict) else {}
                c2pa_tool = tools.get("c2patool") if isinstance(tools.get("c2patool"), dict) else {}
                snippet = str(c2pa_tool.get("snippet") or "")[:2000]  # 限制snippet长度为2000字符
                # 清理大对象，释放内存
                del res, report, tools, c2pa_tool

                if "Created by Google Generative AI" in snippet and not any("Google Generative AI" in f for f in findings):
                    findings.append("生成来源：Created by Google Generative AI")
                    has_ai = True
                if "Applied imperceptible SynthID watermark" in snippet and not any("SynthID" in f for f in findings):
                    findings.append("防伪标识：Applied imperceptible SynthID watermark")
                    has_ai = True
                if "Google C2PA Core Generator Library" in snippet and not any("Google C2PA" in f for f in findings):
                    findings.append("凭据签发：Google C2PA Core Generator Library")
                    has_c2pa = True
                if ("DALL-E" in snippet or "OpenAI" in snippet) and not any("OpenAI" in f for f in findings):
                    findings.append("生成来源：OpenAI DALL-E")
                    has_ai = True
                if has_c2pa and not any("C2PA" in f for f in findings):
                    findings.append("C2PA 官方溯源签名认证凭据")
                if has_ai and not any("AI" in f or "SynthID" in f for f in findings):
                    findings.append("AI 生成模型特征元数据 (AIGC)")
                summary = "检测完成：" + "、".join(findings) if findings else "未发现明显隐形元数据或水印标记"
            except Exception:
                info = _local_inspect_file(raw, filename)
                report = info.get("report") or {}
                format_name = report.get("format", format_name)
                has_c2pa = bool(report.get("has_c2pa", False))
                has_ai = bool(report.get("has_ai_metadata", False))
                findings = list(report.get("findings") or [])
                summary = str(info.get("suspicious", {}).get("description") or "手动上传检测完成")

            local_url = self._save_preview_file(raw, filename)
            has_verdict = bool(has_c2pa or has_ai or findings)
            rec = {
                "name": filename,
                "url": local_url,
                "local_url": local_url,
                "raw_url": local_url,
                "is_expired": False,
                "size": len(raw),
                "kind": format_name,
                "at": datetime.datetime.now(datetime.UTC).isoformat(),
                "findings": findings,
                "summary": summary,
                "flags": {
                    "c2pa": has_c2pa,
                    "ai_metadata": has_ai,
                    "verdict": has_verdict,
                },
            }
            self._detection_log.append(rec)
            self._save_detection_records()
            await self._write_page_snapshot()
            # 返回极简响应，避免超出协议大小限制
            # 前端会在刷新后从page_data获取完整记录
            response = {
                "ok": True,
                "local_url": local_url,
                "record": {
                    "name": filename,
                    "local_url": local_url,
                    "url": local_url,
                    "summary": summary[:200] if summary else "",  # 限制摘要长度
                    "findings": findings[:5],  # 最多返回5个发现
                    "flags": {
                        "c2pa": has_c2pa,
                        "ai_metadata": has_ai,
                        "verdict": has_verdict,
                    },
                    "at": rec["at"],
                },
            }
            import json
            size = len(json.dumps(response, ensure_ascii=False))
            logger.info(f"inspect_upload response size: {size} bytes")
            return response

        return {"error": f"未知操作: {action}"}

    def _headers(self) -> dict[str, str]:
        token = str(self._cfg("service_token") or "").strip()
        return {"Authorization": f"Bearer {token}"} if token else {}

    async def _call(self, path: str, payload: dict[str, Any] | None = None, timeout: float | None = None) -> dict[str, Any]:
        base = str(self._cfg("service_url") or "").rstrip("/")
        if not base:
            raise ValueError("尚未配置水印清理服务地址")
        effective_timeout = timeout if timeout is not None else float(self._cfg("request_timeout_sec") or 30.0)
        t = httpx.Timeout(effective_timeout, connect=min(effective_timeout, 2.0))
        try:
            async with httpx.AsyncClient(timeout=t) as client:
                if payload is None:
                    response = await client.get(base + path, headers=self._headers())
                else:
                    response = await client.post(base + path, json=payload, headers=self._headers())
        except httpx.ConnectError as error:
            raise ValueError(f"无法连接至水印清理服务（{base}）") from error
        except httpx.TimeoutException as error:
            raise ValueError(f"水印服务请求超时（超过 {timeout} 秒）") from error
        except httpx.HTTPError as error:
            raise ValueError(f"水印服务网络异常：{str(error)[:120]}") from error
        try:
            data = response.json() if response.content else {}
        except ValueError as error:
            raise ValueError("水印服务返回了无效 JSON") from error
        if response.status_code >= 400:
            raise ValueError(str(data.get("error") or f"水印服务 HTTP {response.status_code}"))
        return data if isinstance(data, dict) else {"data": data}

    def _remember_pending(self, sender: str, url: str, name: str, conversation: str = "") -> None:
        now = time.monotonic()
        for key, at in list(self._pending_files_at.items()):
            if now - at > 900:
                self._pending_files.pop(key, None)
                self._pending_files_at.pop(key, None)
        self._pending_files[sender] = {"url": url, "name": name, "conversation": conversation}
        self._pending_files_at[sender] = now

    def _pending_lookup(self, context: Any, conversation: str) -> dict[str, str] | None:
        sender_id = getattr(context, "sender_id", "") or ""
        pending = self._pending_files.get(sender_id)
        if pending:
            return pending
        for item in self._pending_files.values():
            if item.get("conversation") == conversation:
                return item
        return None

    def _clear_pending(self, context: Any, conversation: str = "") -> None:
        sender = getattr(context, "sender_id", "") if hasattr(context, "sender_id") else str(context or "")
        conv = getattr(context, "conversation_id", "") if hasattr(context, "conversation_id") else conversation
        if sender:
            self._pending_files.pop(sender, None)
            self._pending_files_at.pop(sender, None)
        if conv:
            for key, item in list(self._pending_files.items()):
                if item.get("conversation") == conv:
                    self._pending_files.pop(key, None)
                    self._pending_files_at.pop(key, None)

    async def _clean_text(self, text: str) -> str:
        try:
            options = {
                "nfkc": True,
                "aggressive_homoglyphs": bool(self._cfg("clean_text_homoglyphs")),
                "normalize_spaces": True,
            }
            result = await self._call("/clean", {
                "file": _b64_text(text),
                "name": "input.txt",
                "options": options,
            }, timeout=3.0)
        except Exception:
            return self._strip_invisible_unicode(text)
        if isinstance(result.get("text"), str):
            return result["text"]
        cleaned = result.get("file")
        if isinstance(cleaned, str):
            try:
                return base64.b64decode(cleaned).decode("utf-8", errors="replace")
            except Exception:
                pass
        return self._strip_invisible_unicode(text)

    def _strip_invisible_unicode(self, text: str) -> str:
        return re.sub(r"[\u200B-\u200D\uFEFF\u202A-\u202E\u2060-\u206F]", "", text)

    async def _download_attachment(self, url: str) -> tuple[bytes, str]:
        max_bytes = int(self._cfg("max_file_size_mb") or 20) * 1024 * 1024
        try:
            headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"}
            async with httpx.AsyncClient(timeout=float(self._cfg("request_timeout_sec") or 30.0), follow_redirects=True, headers=headers) as client:
                resp = await client.get(url)
                if resp.status_code != 200:
                    logger.warning("下载附件失败: HTTP %s, url: %s", resp.status_code, url[:100])
                    return b"", f"HTTP {resp.status_code}"
                if len(resp.content) > max_bytes:
                    return b"", f"文件体积超过限制 ({len(resp.content) // 1024 // 1024}MB > {self._cfg('max_file_size_mb')}MB)"
                logger.info("下载附件成功: %d 字节, url: %s", len(resp.content), url[:100])
                return resp.content, ""
        except Exception as e:
            logger.error("下载附件异常: %s, url: %s", e, url[:100])
            return b"", str(e)

    def _attachment_candidates(self, context: Any) -> list[tuple[str, str]]:
        candidates: list[tuple[str, str]] = []

        def add(item: Any, default_name: str = "attachment") -> None:
            if not isinstance(item, dict):
                return
            url = str(item.get("url") or item.get("resource_url") or item.get("file_url") or item.get("download_url") or "").strip()
            image_info = item.get("image_info") if isinstance(item.get("image_info"), dict) else {}
            file_info = item.get("file_info") if isinstance(item.get("file_info"), dict) else {}
            url = url or str(image_info.get("url") or file_info.get("url") or "").strip()
            if not url:
                return
            if url.startswith("//"):
                url = f"https:{url}"
            if not url.startswith(("http://", "https://")):
                return
            name = (
                str(item.get("filename") or item.get("name") or "").strip()
                or str(image_info.get("filename") or file_info.get("filename") or "").strip()
                or default_name
            )
            candidates.append((url, name))

        attachments = getattr(context, "attachments", None) or ()
        if isinstance(attachments, (list, tuple)):
            for a in attachments:
                add(a, "file")

        raw = getattr(context, "raw_payload", None) or getattr(context, "raw_message", None) or {}
        if not isinstance(raw, dict):
            raw = {}

        def visit(values: Any) -> None:
            if not isinstance(values, (list, tuple)):
                return
            for item in values:
                if not isinstance(item, dict):
                    continue
                add(item)
                for key in (
                    "attachments", "image_info", "file_info", "msg_elements",
                    "ref_msg", "message_reference", "quote", "source", "source_msg",
                    "quote_element", "elements",
                ):
                    nested = item.get(key)
                    if isinstance(nested, (list, tuple)):
                        visit(nested)
                    elif isinstance(nested, dict):
                        add(nested)
                        visit([nested])

        for root_key in (
            "attachments", "msg_elements", "message_reference", "ref_msg", "quote", "source", "source_msg",
        ):
            root_val = raw.get(root_key)
            if isinstance(root_val, (list, tuple)):
                visit(root_val)
            elif isinstance(root_val, dict):
                add(root_val)
                visit([root_val])

        scene = raw.get("message_scene") if isinstance(raw.get("message_scene"), dict) else {}
        elements = scene.get("elements") or scene.get("msg_elements")
        if isinstance(elements, (list, tuple)):
            visit(elements)

        seen: set[str] = set()
        unique: list[tuple[str, str]] = []
        for url, name in candidates:
            if url not in seen:
                seen.add(url)
                unique.append((url, name))
        if unique:
            logger.info("WatermarksPlugin 提取到 %d 个附件候选: %s", len(unique), [(u[:60], n) for u, n in unique])
        return unique

    async def _send_cleaned_file(self, context: Any, data: bytes, original_name: str) -> tuple[bool, str]:
        media = getattr(self.context, "media", None)
        gateway = getattr(self.context, "qq", None)
        if media is None or gateway is None:
            return False, "当前运行时不支持媒体回传"

        suffix = Path(original_name or "attachment.bin").suffix.lower()
        file_type = 1 if suffix in {".jpg", ".jpeg", ".png", ".gif", ".webp", ".bmp"} else (2 if suffix in {".mp4", ".mov", ".m4v"} else (3 if suffix in {".mp3", ".wav", ".ogg"} else 4))

        clean_filename = f"clean_{Path(original_name).name}" if original_name else f"cleaned{suffix or '.bin'}"
        path = self.temp_dir / f"{time.time_ns()}_{clean_filename}"
        path.write_bytes(data)

        scene = getattr(context, "scene", "group")
        conv_id = getattr(context, "conversation_id", "")

        async def _upload_and_send(target_type: int) -> tuple[bool, str]:
            req = await media.prepare(scene, conv_id, target_type, path)
            up = await gateway.upload_media_file(req, path)
            f_info = up.get("file_info") if isinstance(up, dict) else None
            if not f_info:
                return False, "未获取到上传后的 file_info"
            await gateway.send_media(conv_id, scene, str(f_info), msg_id=getattr(context, "message_id", None))
            return True, ""

        try:
            if file_type in (1, 2, 3):
                try:
                    return await _upload_and_send(file_type)
                except Exception as e:
                    logger.warning("富媒体 (type=%s) 发送失败 (%s)，降级为普通文件发送...", file_type, e)
                    return await _upload_and_send(4)
            return await _upload_and_send(file_type)
        finally:
            path.unlink(missing_ok=True)

    async def _detect_message_file(self, context: Any, remembered: dict[str, str] | None = None) -> str | Card:
        candidates = self._attachment_candidates(context)
        conv = getattr(context, "conversation_id", "")
        pending = remembered or self._pending_lookup(context, conv)
        if not candidates and not pending:
            return "请把要检测的文件和指令一起发送（当前消息未检测到附件）。"
        if pending and not candidates:
            url, name = pending["url"], pending["name"]
        else:
            url, name = candidates[0]
            self._remember_pending(getattr(context, "sender_id", ""), url, name, conv)

        raw, error = await self._download_attachment(url)
        if not raw:
            return f"附件下载失败：{error}"

        findings: list[str] = []
        has_ai_flag = False
        has_c2pa_flag = False
        format_name = "unknown"

        try:
            res = await self._call("/inspect", {"file": base64.b64encode(raw).decode("ascii"), "name": name or "attachment.bin"})
            report = res.get("report") if isinstance(res.get("report"), dict) else {}
            format_name = str(report.get("format") or os.path.splitext(str(name or ""))[1].lstrip(".") or "unknown")
            has_c2pa_flag = bool(report.get("has_c2pa"))
            has_ai_flag = bool(report.get("has_ai_metadata"))

            raw_findings = report.get("findings") or report.get("hits") or []
            for item in raw_findings:
                label = _humanize_finding(str(item))
                if label and label not in findings:
                    findings.append(label)

            tools = report.get("tools") if isinstance(report.get("tools"), dict) else {}
            c2pa_tool = tools.get("c2patool") if isinstance(tools.get("c2patool"), dict) else {}
            snippet = str(c2pa_tool.get("snippet") or "")
            if "Created by Google Generative AI" in snippet and not any("Google Generative AI" in f for f in findings):
                findings.append("生成来源：Created by Google Generative AI")
                has_ai_flag = True
            if "Applied imperceptible SynthID watermark" in snippet and not any("SynthID" in f for f in findings):
                findings.append("防伪标识：Applied imperceptible SynthID watermark")
                has_ai_flag = True
            if "Google C2PA Core Generator Library" in snippet and not any("Google C2PA" in f for f in findings):
                findings.append("凭据签发：Google C2PA Core Generator Library")
                has_c2pa_flag = True
            if ("DALL-E" in snippet or "OpenAI" in snippet) and not any("OpenAI" in f for f in findings):
                findings.append("生成来源：OpenAI DALL-E")
                has_ai_flag = True

            if has_c2pa_flag and not any("C2PA" in f for f in findings):
                findings.append("C2PA 官方溯源签名认证凭据")
            if has_ai_flag and not any("AI" in f or "SynthID" in f for f in findings):
                findings.append("AI 生成模型特征元数据 (AIGC)")

        except Exception as e:
            logger.info("远端 inspect 调用失败或不可用 (%s)，回退至本地检测...", e)
            local = _local_inspect_file(raw, name or "attachment.bin")
            loc_report = local.get("report") or {}
            format_name = loc_report.get("format", "unknown")
            has_c2pa_flag = loc_report.get("has_c2pa", False)
            has_ai_flag = loc_report.get("has_ai_metadata", False)
            for item in loc_report.get("findings", []):
                label = _humanize_finding(str(item))
                if label and label not in findings:
                    findings.append(label)

        # 综合结论
        if has_ai_flag and has_c2pa_flag:
            verdict = "⚠️ 该文件确认包含 AI 生成元数据与 C2PA 官方溯源凭据（明确可溯源），建议使用 /wm clean 清理脱敏后再发送。"
        elif has_ai_flag:
            verdict = "⚠️ 检测到 AI 生成工具特征或数字水印标记（如 AIGC / SynthID），建议使用 /wm clean 清理脱敏。"
        elif has_c2pa_flag:
            verdict = "⚠️ 包含 C2PA 溯源签名认证凭据（Content Credentials），建议使用 /wm clean 剥离溯源轨道。"
        elif findings:
            verdict = "⚠️ 检测到潜在元数据轨道或隐藏标记，可按需使用 /wm clean 脱敏。"
        else:
            verdict = ""

        # 登记检测记录
        local_url = self._save_preview_file(raw, name)
        self._detection_log.append({
            "name": name,
            "url": str(url or ""),
            "local_url": local_url,
            "size": len(raw),
            "kind": format_name,
            "at": datetime.datetime.now(datetime.UTC).isoformat(),
            "findings": list(findings),
            "summary": str(verdict or ""),
            "flags": {
                "c2pa": has_c2pa_flag,
                "ai_metadata": has_ai_flag,
                "verdict": bool(findings),
            },
        })
        self._save_detection_records()

        rich_meta = _extract_rich_metadata(raw, name)
        rich_lines = _format_rich_metadata_lines(rich_meta)

        lines = [f"**文件名**：`{name}`", f"**文件大小**：{len(raw) // 1024} KB", ""]
        if rich_lines:
            lines.append("📷 **照片与文件元数据**：")
            lines.extend(rich_lines)
            lines.append("")

        if findings:
            lines.append("⚠️ **检测到以下标记**：")
            for f in findings[:8]:
                lines.append(f"- {f}")
        else:
            lines.append("✅ **水印与溯源分析**：未发现明显 C2PA 或 AI 生成元数据标记。")
        if verdict:
            lines.append(f"\n> 综合分析：{verdict}")

        text = "\n".join(lines)
        return self._result_card("元数据检测结果", text, pending_name=name) or text

    async def _clean_message_file(self, context: Any, confirm: bool, remembered: dict[str, str] | None = None) -> str | Card:
        candidates = self._attachment_candidates(context)
        conv = getattr(context, "conversation_id", "")
        pending = remembered or self._pending_lookup(context, conv)
        if not candidates and not pending:
            return "请把要清理的文件和指令一起发送（当前消息未检测到附件）。"
        if pending and not candidates:
            url, name = pending["url"], pending["name"]
        else:
            url, name = candidates[0]
            self._remember_pending(getattr(context, "sender_id", ""), url, name, conv)

        if self._cfg("require_confirm") and not confirm:
            rows = [
                [_wm_button("确认清理", "/wm file confirm"), _wm_button("取消", "/wm")],
            ]
            card = Card("确认清理", _wm_markdown("确认清理", f"将对附件 **{name}** 执行元数据水印清理。\n\n该操作只在服务端临时处理，不会持久化保存。"), rows)
            return card if self._cfg("enable_qq_cards") else f"将对附件 {name} 执行清理，请回复 /wm file confirm 确认。"

        raw, error = await self._download_attachment(url)
        if not raw:
            return f"附件下载失败：{error}"

        actions: list[str] = []
        cleaned_bytes: bytes | None = None
        try:
            options = {
                "keep_non_ai_metadata": bool(self._cfg("keep_non_ai_metadata")),
                "strip_all_metadata": bool(self._cfg("strip_all_metadata")),
                "remove_audio_watermark": True,
            }
            result = await self._call("/clean", {
                "file": base64.b64encode(raw).decode("ascii"),
                "name": name or "attachment.bin",
                "options": options,
            })
            cleaned = result.get("cleaned") or result.get("file") or result.get("data")
            if isinstance(cleaned, str):
                cleaned_bytes = base64.b64decode(cleaned)
            report = result.get("report") if isinstance(result.get("report"), dict) else {}
            actions = [str(item) for item in (report.get("actions") or []) if item]
        except Exception as call_err:
            logger.info("上游服务不可用 (%s)，回退至本地脱敏处理...", call_err)
            cleaned_bytes, actions = _local_clean_image(raw, name or "attachment.bin")

        if cleaned_bytes is None:
            return "清理完成，但服务未返回文件内容。"

        summary = "已处理：" + "；".join(_humanize_action(item) for item in actions[:4]) if actions else "已重写文件（剥离元数据轨道）"
        sent, send_err = await self._send_cleaned_file(context, cleaned_bytes, name)
        if not sent:
            return f"清理完成（{summary}），但{send_err}。"
        self._clear_pending(context)
        return f"✅ 清理完成（{summary}），已回传无水印文件。"

    def _menu_card(self) -> Card | str:
        if not self._cfg("enable_qq_cards"):
            return self._help_text()
        content = (
            "**水印清理与元数据检测**\n\n"
            "支持图片/PDF/音视频的 C2PA、EXIF、XMP 标记脱敏，以及文本不可见字符与双向控制符清洗。\n\n"
            "> 点击下方按钮快速操作，或在 120 秒内直接发送图片/附件自动去水印。"
        )
        rows = [
            [_wm_button("去水印清理", "/wm clean"), _wm_button("元数据检测", "/wm detect"), _wm_button("文本清洗", "/wm text ")],
            [_wm_button("服务状态", "/wm status"), _wm_button("检测记录", "/wm records"), _wm_button("帮助说明", "/wm help")],
        ]
        return Card("水印清理", _wm_markdown("水印清理服务", content), rows)

    def _result_card(self, title: str, result: str, pending_name: str | None = None) -> Card | None:
        if not self._cfg("enable_qq_cards"):
            return None
        rows = [
            [_wm_button("清理此文件", "/wm file confirm"), _wm_button("查看记录", "/wm records"), _wm_button("主菜单", "/wm")],
        ] if pending_name else [
            [_wm_button("主菜单", "/wm"), _wm_button("检测记录", "/wm records")],
        ]
        return Card(title, _wm_markdown(title, result), rows)

    def _help_text(self) -> str:
        return (
            "【水印清理助手指令说明】\n\n"
            "1. /wm 或 /去水印：打开功能主菜单与操作按钮（120秒内发图直接清理）\n"
            "2. 发送图片带 /wm detect：检测图片或附件的 C2PA、EXIF 与 AI 标记\n"
            "3. 发送图片带 /wm clean 或 /去水印：清理附件隐写与元数据水印并回传\n"
            "4. /wm text <内容>：清洗文本中潜藏的双向控制符与零宽字符\n"
            "5. /wm status：检测水印清理后台服务健康状态与能力\n"
            "6. /wm records：查询最近被动检测与分析记录\n"
            "7. /wm clear：清空检测历史记录（需管理员）"
        )

    def detection_records(self, limit: int = 30) -> list[dict[str, Any]]:
        return list(reversed(self._detection_log[-limit:]))

    def clear_detection_records(self) -> int:
        count = len(self._detection_log)
        self._detection_log.clear()
        self._save_detection_records()
        return count

    def delete_detection_records(self, identifiers: list[str] | set[str]) -> int:
        if not identifiers:
            return 0
        targets = {str(i).strip() for i in identifiers if str(i).strip()}
        before = len(self._detection_log)
        filtered = []
        for idx, r in enumerate(self._detection_log):
            name = str(r.get("name", "")).strip()
            raw_id = f"rec_{idx}_{name}"
            matched = name in targets or raw_id in targets or any(t in name or (t and name and name in t) for t in targets)
            if matched:
                local_url = str(r.get("local_url") or "")
                if local_url:
                    clean_name = Path(local_url).name
                    preview_file = self.data_dir / "previews" / clean_name
                    if preview_file.is_file():
                        try:
                            preview_file.unlink(missing_ok=True)
                        except Exception:
                            pass
                continue
            filtered.append(r)
        self._detection_log = filtered
        self._save_detection_records()
        return before - len(self._detection_log)

    async def command(self, context: Any, args: list[str]) -> str | Card:
        sub_args = [a.strip() for a in args if a.strip()]
        action = sub_args[0].lower() if sub_args else "menu"

        if action in {"on", "enable", "开启", "启动"}:
            if not self._is_admin(context):
                return "只有管理员可以开启水印清理功能。"
            self.config["enabled"] = True
            self._save_config()
            return "✅ 水印清理功能已开启！发送 `/wm` 即可查看功能菜单。"

        if action in {"off", "disable", "关闭", "停用"}:
            if not self._is_admin(context):
                return "只有管理员可以关闭水印清理功能。"
            self.config["enabled"] = False
            self._save_config()
            return "⏸️ 水印清理功能已关闭。管理员发送 `/wm on` 即可重新开启。"

        if not self._cfg("enabled"):
            rows = []
            if self._is_admin(context):
                rows.append([_wm_button("开启水印清理", "/wm on", action_type=1, admin=True)])
            if self._cfg("enable_qq_cards"):
                return Card("水印清理 · 已停用", "水印清理功能当前已关闭。\n管理员可发送 `/wm on` 或点击下方按钮快速开启。", rows=rows)
            return "水印清理功能当前已关闭。管理员可发送 /wm on 开启。"

        if action in {"menu", "wm", "watermark", "watermarks"}:
            # 仅显示菜单，不设置等待窗口（用户需要明确点击按钮才会处理）
            return self._menu_card()

        if action in {"help", "帮助", "--help", "-h"}:
            return self._help_text()

        if action in {"detect", "inspect", "检测"}:
            candidates = self._attachment_candidates(context)
            if not candidates:
                conv = getattr(context, "conversation_id", "")
                self._file_waiters[conv] = ("detect", time.monotonic())
                target_place = "私聊窗口" if getattr(context, "scene", "") == "c2c" else "群内"
                return f"已开启文件检测等待窗口（{self._cfg('file_wait_seconds')} 秒）。请直接在{target_place}发送要检测的图片或文件附件~"
            return await self._detect_message_file(context)

        if action in {"clean", "file", "去水印", "清理"}:
            confirm = len(sub_args) > 1 and sub_args[1].lower() in {"confirm", "yes", "true", "确认"}
            candidates = self._attachment_candidates(context)
            if not candidates and not self._pending_lookup(context, getattr(context, "conversation_id", "")):
                conv = getattr(context, "conversation_id", "")
                self._file_waiters[conv] = ("clean", time.monotonic())
                target_place = "私聊窗口" if getattr(context, "scene", "") == "c2c" else "群内"
                return f"已开启去水印等待窗口（{self._cfg('file_wait_seconds')} 秒）。请直接在{target_place}发送要清理的图片或文件附件~"
            return await self._clean_message_file(context, confirm=confirm)

        if action in {"text", "txt", "文本"}:
            content = " ".join(sub_args[1:]).strip()
            if not content:
                return "用法：/wm text <要检测或清洗的文字>"
            cleaned = await self._clean_text(content)
            diff_len = len(content) - len(cleaned)
            if diff_len > 0:
                return f"⚠️ 文本已清洗！检测并移除了 {diff_len} 个隐藏零宽/控制字符：\n\n`{cleaned}`"
            return f"✅ 文本检测正常，未发现隐藏控制符与隐写字符：\n\n`{cleaned}`"

        if action in {"status", "caps", "状态"}:
            try:
                res = await self._call("/capabilities")
                version = res.get("version", "?")
                tools = res.get("tools") or {}
                available = [k for k, v in tools.items() if v]
                return f"✅ 水印清理服务正常在线 (v{version})，支持工具: {', '.join(available) or '基础文本清理'}。"
            except Exception as e:
                return f"❌ 水印清理服务当前不可用: {e}"

        if action in {"records", "log", "记录"}:
            records = self.detection_records(10)
            if not records:
                return "暂无水印检测与分析记录。"
            lines = ["📋 **最近检测记录**："]
            for r in records:
                flags = r.get("flags") or {}
                mark = "疑似AI" if flags.get("ai_metadata") else ("C2PA" if flags.get("c2pa") else "正常")
                lines.append(f"- `{r.get('at', '')[:19]}` {r.get('name', 'file')} [{mark}]")
            return "\n".join(lines)

        if action in {"clear", "reset", "清空"}:
            if not getattr(context, "is_admin", False):
                return "只有管理员可以清空检测记录。"
            count = self.clear_detection_records()
            await self._write_page_snapshot()
            return f"已清空 {count} 条检测记录。"

        return self._help_text()

    async def on_event(self, context: Any) -> Any:
        if not self._cfg("enabled"):
            return None

        interaction_id = getattr(context, "interaction_id", None)
        msg_type = getattr(context, "message_type", None)
        if (isinstance(interaction_id, str) and interaction_id) or msg_type == "interaction":
            return None

        conv = getattr(context, "conversation_id", "")
        now = time.monotonic()
        waiter = self._file_waiters.get(conv)

        # 1. 检查是否处于指令等待窗口
        if waiter:
            act, start_at = waiter
            ttl = float(self._cfg("file_wait_seconds") or 120.0)
            if now - start_at <= ttl:
                candidates = self._attachment_candidates(context)
                if candidates:
                    self._file_waiters.pop(conv, None)
                    if act == "detect":
                        return await self._detect_message_file(context)
                    return await self._clean_message_file(context, confirm=not self._cfg("require_confirm"))
            else:
                self._file_waiters.pop(conv, None)

        # 2. 检查中文触发词别名（/去水印 或 去水印）
        text = str(getattr(context, "text", "") or "").strip()
        if text.startswith(("/去水印", "去水印", "/水印检测", "水印检测")):
            parts = text.lstrip("/").split()
            sub_args = parts[1:] if len(parts) > 1 else (["detect"] if "检测" in parts[0] else ["clean"])
            return await self.command(context, sub_args)

        # 3. 被动检测登记
        if self._cfg("auto_detect"):
            candidates = self._attachment_candidates(context)
            if candidates:
                url, name = candidates[0]
                raw, _ = await self._download_attachment(url)
                if raw:
                    findings: list[str] = []
                    has_c2pa = False
                    has_ai = False
                    format_name = os.path.splitext(name or "")[1].lstrip(".") or "unknown"
                    summary = ""
                    try:
                        res = await self._call("/inspect", {"file": base64.b64encode(raw).decode("ascii"), "name": name or "attachment.bin"}, timeout=4.0)
                        report = res.get("report") if isinstance(res.get("report"), dict) else {}
                        format_name = str(report.get("format") or format_name)
                        has_c2pa = bool(report.get("has_c2pa"))
                        has_ai = bool(report.get("has_ai_metadata"))
                        for item in (report.get("findings") or report.get("hits") or []):
                            label = _humanize_finding(str(item))
                            if label and label not in findings:
                                findings.append(label)
                        tools = report.get("tools") if isinstance(report.get("tools"), dict) else {}
                        c2pa_tool = tools.get("c2patool") if isinstance(tools.get("c2patool"), dict) else {}
                        snippet = str(c2pa_tool.get("snippet") or "")
                        if "Created by Google Generative AI" in snippet and not any("Google Generative AI" in f for f in findings):
                            findings.append("生成来源：Created by Google Generative AI")
                            has_ai = True
                        if "Applied imperceptible SynthID watermark" in snippet and not any("SynthID" in f for f in findings):
                            findings.append("防伪标识：Applied imperceptible SynthID watermark")
                            has_ai = True
                        if "Google C2PA Core Generator Library" in snippet and not any("Google C2PA" in f for f in findings):
                            findings.append("凭据签发：Google C2PA Core Generator Library")
                            has_c2pa = True
                        if ("DALL-E" in snippet or "OpenAI" in snippet) and not any("OpenAI" in f for f in findings):
                            findings.append("生成来源：OpenAI DALL-E")
                            has_ai = True
                        if has_c2pa and not any("C2PA" in f for f in findings):
                            findings.append("C2PA 官方溯源签名认证凭据")
                        if has_ai and not any("AI" in f or "SynthID" in f for f in findings):
                            findings.append("AI 生成模型特征元数据 (AIGC)")
                        summary = "检测完成：" + "、".join(findings) if findings else ""
                    except Exception:
                        info = _local_inspect_file(raw, name)
                        report = info.get("report") or {}
                        format_name = report.get("format", format_name)
                        findings = list(report.get("findings") or [])
                        has_c2pa = bool(report.get("has_c2pa", False))
                        has_ai = bool(report.get("has_ai_metadata", False))
                        summary = str(info.get("suspicious", {}).get("description") or "")

                    local_url = self._save_preview_file(raw, name)
                    has_verdict = bool(has_c2pa or has_ai or findings)
                    self._detection_log.append({
                        "name": name,
                        "url": str(url or ""),
                        "local_url": local_url,
                        "raw_url": str(url or ""),
                        "is_expired": False,
                        "size": len(raw),
                        "kind": format_name,
                        "at": datetime.datetime.now(datetime.UTC).isoformat(),
                        "findings": findings,
                        "summary": summary,
                        "flags": {
                            "c2pa": has_c2pa,
                            "ai_metadata": has_ai,
                            "verdict": has_verdict,
                        },
                    })
                    self._save_detection_records()
        return None

    async def cleanup_task(self) -> None:
        now = time.monotonic()
        for key, at in list(self._pending_files_at.items()):
            if now - at > 900:
                self._pending_files.pop(key, None)
                self._pending_files_at.pop(key, None)
        for conv, (_, start_at) in list(self._file_waiters.items()):
            if now - start_at > 300:
                self._file_waiters.pop(conv, None)
        await self._write_page_snapshot()


async def setup(context: Any) -> WatermarksPlugin:
    plugin = WatermarksPlugin(context)

    # 注册命令（严格与 plugin.toml 保持一致）
    for cmd in ("wm", "watermark", "watermarks"):
        if hasattr(context, "register_command"):
            try:
                context.register_command(cmd, plugin.command, category="utility", description="水印清理与检测")
            except Exception as e:
                logger.debug("注册命令 %s 异常: %s", cmd, e)

    # 注册通用事件监听
    if hasattr(context, "register_event_handler"):
        context.register_event_handler("*", plugin.on_event)

    # 注册周期性任务
    if hasattr(context, "register_task"):
        try:
            context.register_task("cleanup", 3600, plugin.cleanup_task)
        except Exception as e:
            logger.warning("注册 cleanup 定时任务失败: %s", e)

    # 注册原生页面与动作
    if hasattr(context, "register_page_action"):
        context.register_page_action("home", plugin.on_page_action)
        context.register_page_action("save_config", plugin.on_page_action)
    if hasattr(context, "register_action"):
        context.register_action("save_config", plugin.on_page_action)
        context.register_action("page_data", plugin.on_page_action)
        context.register_action("page_delete", plugin.on_page_action)
        context.register_action("inspect_upload", plugin.on_page_action)

    await plugin._write_page_snapshot()
    logger.info("plugin.watermarks %s 已成功初始化加载", PLUGIN_VERSION)
    return plugin
