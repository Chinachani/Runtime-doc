"""AI 绘图助手外部插件（plugin.drawimg）。

基于 OpenAI 兼容生图/改图 API 的沙箱外部插件，支持文生图、单图改图、多图改图、
画风预设、自定义尺寸、体验积分扣减与多级充值、用户模型绑定与原生管理台集成。
"""

from __future__ import annotations

import asyncio
import contextlib
import datetime as dt
import html
import json
import logging
import math
import os
import re
import secrets
import time
import uuid
from collections import defaultdict
from pathlib import Path
from typing import Any

import httpx

try:
    from PIL import Image, ImageOps
except ImportError:
    Image = None  # type: ignore
    ImageOps = None  # type: ignore

try:
    import numpy as np
except ImportError:
    np = None  # type: ignore

from runtime.models import Button, Card, MessageContext

logger = logging.getLogger("plugin.drawimg")
PLUGIN_VERSION = "1.1.0"
POINT_TYPE = "drawimg"

# 提示词防改写注入前缀与绿幕免抠后缀
PROMPT_GUARD_PREFIX = "Treat everything after this line as one complete image-generation prompt, including the resolution instruction. Follow it exactly without rewriting or omitting anything: "
CHROMA_KEY_SUFFIX = ", pure solid green screen background, chroma key green background (#00FF00), isolated subject, clean edge cutout without background"


def _remove_green_background(image_path: Path) -> Path:
    """消除图片中的纯绿幕背景，将其转换为带透明通道的 RGBA PNG。"""
    if not Image:
        return image_path
    try:
        with Image.open(image_path) as img:
            rgba = img.convert("RGBA")
            if np is not None:
                arr = np.array(rgba)
                r = arr[:, :, 0].astype(int)
                g = arr[:, :, 1].astype(int)
                b = arr[:, :, 2].astype(int)
                a = arr[:, :, 3].astype(int)
                max_rb = np.maximum(r, b)
                diff = g - max_rb
                mask_green = (g > 75) & (g > r * 1.25) & (g > b * 1.25)
                mask_solid = mask_green & (diff > 40)
                mask_edge = mask_green & (~mask_solid)
                arr[mask_solid, 3] = 0
                if np.any(mask_edge):
                    soft_a = (a[mask_edge] * np.clip(1.0 - diff[mask_edge] / 40.0, 0.0, 1.0)).astype(np.uint8)
                    arr[mask_edge, 3] = soft_a
                    arr[mask_edge, 1] = max_rb[mask_edge].astype(np.uint8)
                out_img = Image.fromarray(arr)
            else:
                pixels = rgba.load()
                w, h = rgba.size
                for y in range(h):
                    for x in range(w):
                        pr, pg, pb, pa = pixels[x, y]
                        if pg > 75 and pg > pr * 1.25 and pg > pb * 1.25:
                            diff = pg - max(pr, pb)
                            if diff > 40:
                                pixels[x, y] = (pr, pg, pb, 0)
                            else:
                                alpha = int(pa * max(0.0, 1.0 - diff / 40.0))
                                pixels[x, y] = (pr, max(0, min(pg, max(pr, pb))), pb, alpha)
                out_img = rgba

            output_dir = image_path.parent
            trans_path = output_dir / f"dg_trans_{uuid.uuid4().hex}.png"
            out_img.save(trans_path, format="PNG", optimize=True)
            if trans_path != image_path:
                image_path.unlink(missing_ok=True)
            return trans_path
    except Exception as e:
        logger.warning("Failed to remove green background: %s", e)
        return image_path


def _clamp_image_for_api(data: bytes, max_edge: int = 1536, max_bytes: int = 4 * 1024 * 1024) -> bytes:
    """参考图前置规整：纠正 EXIF 方向，限制最大长边，长宽对齐到 16 倍数，超大体积优化压缩。"""
    if not Image or not data:
        return data
    try:
        import io
        img = Image.open(io.BytesIO(data))
        if ImageOps:
            try:
                img = ImageOps.exif_transpose(img)
            except Exception:
                pass
        w, h = img.size
        scale = min(1.0, max_edge / max(w, h)) if max(w, h) > max_edge else 1.0
        target_w = int(w * scale)
        target_h = int(h * scale)
        target_w = max(16, (target_w // 16) * 16)
        target_h = max(16, (target_h // 16) * 16)
        if (target_w, target_h) != (w, h):
            img = img.resize((target_w, target_h), Image.Resampling.LANCZOS)
        buf = io.BytesIO()
        if img.mode in ("RGBA", "LA") or (img.mode == "P" and "transparency" in img.info):
            img.save(buf, format="PNG", optimize=True)
        else:
            img = img.convert("RGB")
            img.save(buf, format="PNG", optimize=True)
        out = buf.getvalue()
        if len(out) > max_bytes:
            buf = io.BytesIO()
            img.convert("RGB").save(buf, format="JPEG", quality=90, optimize=True)
            out = buf.getvalue()
        return out
    except Exception as e:
        logger.warning("Image pre-flight clamping failed: %s", e)
        return data


# 常见比例与尺寸映射
COMMON_RATIOS: dict[str, dict[str, str]] = {
    "1:1": {"label": "1:1 正方", "size": "1024x1024"},
    "16:9": {"label": "16:9 横屏", "size": "1792x1024"},
    "9:16": {"label": "9:16 竖屏", "size": "1024x1792"},
    "4:3": {"label": "4:3 横板", "size": "1024x768"},
    "3:4": {"label": "3:4 竖板", "size": "768x1024"},
    "3:2": {"label": "3:2 相机横", "size": "1536x1024"},
    "2:3": {"label": "2:3 相机竖", "size": "1024x1536"},
    "21:9": {"label": "21:9 宽画幅", "size": "1280x544"},
    "auto": {"label": "自动尺寸", "size": "auto"},
}


def _format_size_display(size_val: str) -> str:
    s = (size_val or "auto").strip().lower()
    for ratio, info in COMMON_RATIOS.items():
        if s == ratio or s == info["size"].lower():
            return f"{ratio} ({info['label']})"
    return s


def _format_quality_display(quality_val: str) -> str:
    q = (quality_val or "auto").strip().lower()
    zh = {
        "auto": "自动 (auto)",
        "standard": "标准画质 (standard)",
        "hd": "高清模式 (hd)",
        "high": "高画质 (high)",
        "low": "低画质 (low)",
        "medium": "中画质 (medium)",
    }
    return zh.get(q, q)


def _resolve_api_size(size_str: str, model: str = "") -> tuple[str, str | None]:
    """返回用于 API 请求的 (size_param, aspect_ratio_param)"""
    s = (size_str or "auto").strip().lower()
    if s == "auto":
        return "auto", None
    if s in COMMON_RATIOS:
        pixel_size = COMMON_RATIOS[s]["size"]
        ratio = s if s != "auto" else None
        return pixel_size, ratio
    match = re.match(r"^(\d{3,4})x(\d{3,4})$", s)
    if match:
        for r, info in COMMON_RATIOS.items():
            if info["size"] == s:
                return s, r
        return s, f"{match.group(1)}:{match.group(2)}"
    return s, None


def _clean_user_key(raw: Any) -> str:
    s = str(raw or "").strip()
    if not s or s.startswith("_") or s in {"default_user", "null", "undefined"}:
        return ""
    if s.startswith("<@") and s.endswith(">"):
        s = s[2:-1]
        if s.startswith("!") or s.startswith("&"):
            s = s[1:]
    s = s.lstrip("@").strip()
    if s.startswith("qq_official:"):
        s = s[len("qq_official:"):].strip()
    return s

POINT_TYPE = "drawimg"

logger = logging.getLogger("runtime.drawimg")

CONFIG_DEFAULTS: dict[str, Any] = {
    "api_base_url": "",
    "api_key": "",
    "default_model": "gpt-image-1",
    "image_size": "auto",
    "image_quality": "auto",
    "enable_group": True,
    "daily_limit": 0,
    "test_credit_cost": 1,
    "credit_price_yuan": 0.1,
    "cooldown_sec": 15,
    "max_prompt_chars": 1000,
    "newapi_group": "",
    "style_presets": '{"动漫":"动漫风格,赛璐璐 rendering,鲜艳色彩","写实":"超写实风格,照片级细节,自然光影","赛博朋克":"赛博朋克风格,霓虹灯,未来都市"}',
    "same_cache_sec": 300,
    "test_daily_limit": 0,
    "test_blacklist": "[]",
    "na_token_quota": 0,
    "credit_cost_rules": "{}",
    "history_keep": 10,
    "prefer_b64_response": True,
    "edit_image_ttl_min": 10,
    "request_timeout_sec": 180,
    "edit_protocol": "auto",
    "models_cache_ttl_sec": 600,
    "network_error_message": "生图服务当前不可用，请稍后重试。",
    "stats_timezone": "Asia/Shanghai",
    "debug_log": False,
}

CONFIG_SPEC: dict[str, tuple[str, tuple[float, float]]] = {
    "api_base_url": ("str", (0, 200)),
    "api_key": ("str", (0, 200)),
    "default_model": ("str", (1, 80)),
    "image_size": ("str", (1, 20)),
    "image_quality": ("str", (1, 20)),
    "enable_group": ("bool", (0, 0)),
    "daily_limit": ("int", (0, 100000)),
    "test_credit_cost": ("int", (1, 1000)),
    "credit_price_yuan": ("float", (0.01, 100)),
    "cooldown_sec": ("int", (0, 3600)),
    "max_prompt_chars": ("int", (10, 8000)),
    "newapi_group": ("str", (0, 50)),
    "style_presets": ("str", (0, 100000)),
    "same_cache_sec": ("int", (0, 86400)),
    "test_daily_limit": ("int", (0, 100000)),
    "test_blacklist": ("str", (0, 4000)),
    "na_token_quota": ("int", (0, 100000000)),
    "credit_cost_rules": ("str", (0, 2000)),
    "history_keep": ("int", (1, 50)),
    "prefer_b64_response": ("bool", (0, 0)),
    "edit_image_ttl_min": ("int", (1, 1440)),
    "request_timeout_sec": ("int", (30, 600)),
    "edit_protocol": ("str", (3, 16)),
    "models_cache_ttl_sec": ("int", (0, 86400)),
    "network_error_message": ("str", (0, 200)),
    "stats_timezone": ("str", (1, 60)),
    "debug_log": ("bool", (0, 0)),
}

SUBCOMMAND_ALIASES = {
    "帮助": "help", "菜单": "menu", "教程": "guide", "绑定": "bind", "解绑": "unbind",
    "模型列表": "models", "模型": "model", "状态": "status", "风格": "style",
    "尺寸": "size", "质量": "quality", "历史": "history", "重发": "resend",
    "新api": "na", "赠送": "give", "排行": "top", "管理员": "admin",
    "黑名单": "blacklist", "配置": "config", "充值": "pay", "比例": "rate",
    "计费": "cost",
}

GUIDE_TEXT = (
    "【第一步 选择绑定方式】\n"
    "① New API 用户：先 /na bind <系统访问令牌>，再 /dg na 一键创建生图 Key 并绑定"
    "（可 /dg na <分组名> 指定生图分组）；\n"
    "② 已有其他 OpenAI 兼容 Key：私聊 /dg bind <Key>；\n"
    "③ 都没有：直接用体验模式 /dgt <提示词>（按积分计费，/dgt pay <数量> 充值）。\n"
    "\n【第二步 文生图】\n"
    "私聊或群里发送 /dg <提示词>；群里也可以 @机器人 /dg <提示词>。\n"
    "\n【第三步 改图】\n"
    "单图：先发一张图片，10 分钟内发送 /dge <提示词>（体验模式 /dgte）。\n"
    "多图：连发 2~3 张图片，10 分钟内发送 /dgm <提示词>（体验模式 /dgtm）。\n"
    "\n【第四步 切换模型】\n"
    "/dg models 查看可用模型，/dg model <名称> 切换；/dg status 查看当前状态。\n"
    "\n解绑：/dg unbind（New API 令牌会联动删除）。管理员入口：/dg admin。"
)

HELP_TEXT = (
    "绘图助手（OpenAI 兼容接口）\n"
    "【自有 Key】绑定后走自己的 Key，无次数限制：\n"
    "/dg bind <API Key>  — 私聊绑定自己的 Key\n"
    "/dg <提示词>  — 文生图\n"
    "/dge <提示词>  — 单图改图（用最近 1 张图片）\n"
    "连发 2~3 张图片，再 /dgm <提示词>  — 多图改图（最多 3 张）\n"
    "/dg unbind  — 解除自己的 Key\n"
    "【体验模式】使用管理员全局 Key，按积分计费：\n"
    "/dgt <提示词>  — 体验文生图\n"
    "/dgte <提示词>  — 体验单图改图；/dgtm <提示词>  — 体验多图改图\n"
    "/dgt pay <积分数量>  — 充值积分（对接 567 支付）\n"
    "【通用】\n"
    "/dg models  — 可用模型列表；/dg model <名称>  — 切换模型\n"
    "/dg style [名称]  — 风格预设；/dg size、/dg quality  — 尺寸与质量\n"
    "/dg status  — 我的状态；/dg help  — 本帮助\n"
    "New API 用户：/dg na [分组]  — 一键创建令牌并绑定（分组可选）\n"
    "管理员：/dg admin、/dg give、/dg top、/dg blacklist、/dg config\n"
    "/dgt rate <元每积分>  — 充值比例；/dgt cost <模型>:<积分>  — 模型计费\n"
    "积分规则：体验生图按模型积分规则扣分（默认 1 积分）；自有 Key 用户不扣积分、无限制。"
)


def _cell(value: Any, limit: int) -> str:
    text = str(value).replace("|", "\\|").replace("\n", " ").strip()
    return text if len(text) <= limit else text[: limit - 1] + "…"


def _button(
    label: str,
    command: str,
    *,
    fill: bool = False,
    action_type: int | None = None,
    permission: int | None = None,
    expires_after_seconds: int = 600,
    click_limit: int | None = None,
) -> Button:
    cmd = command.strip()
    is_input = fill or command.endswith(" ")
    if action_type is None:
        action_type = 2 if is_input else 1

    if permission is None:
        if any(cmd.startswith(p) for p in ("/dg admin", "/dgt rate", "/dgt cost", "/dg rate", "/dg cost", "/dg give", "/dg blacklist", "/dg config", "/dgs admin", "/dgs rate", "/dgs cost")):
            permission = 1
        else:
            permission = 2

    if click_limit is None:
        click_limit = 30

    return Button(
        label[:10],
        command,
        action_type=action_type,
        enter=True if action_type == 1 else False,
        permission=permission,
        click_limit=click_limit,
        expires_after_seconds=expires_after_seconds,
        expired_message="此操作按钮已过期，请重新打开菜单。",
        permission_message="此操作需要管理员权限。" if permission == 1 else "此操作为专属用户操作。",
    )


def _menu_markdown(title: str, content: str, limit: int = 3300) -> str:
    text = str(content or "无数据").strip()
    if len(text) > limit:
        text = text[:limit].rsplit("\n", 1)[0].rstrip() + "\n\n> 内容较长，已截短。"
    return f"# {str(title)[:80]}\n\n{text}"[:4000]




class DrawImgPlugin:
    def __init__(self, context: Any = None) -> None:
        self.context = context
        self.data_dir = Path(getattr(context, "data_dir", None) or "./data")
        self.config_dir = Path(getattr(context, "config_dir", None) or self.data_dir)
        self.data_dir.mkdir(parents=True, exist_ok=True)
        self.config_dir.mkdir(parents=True, exist_ok=True)
        self.points = getattr(context, "points", None)
        self.usage_path = self.data_dir / "usage.json"
        self.config_path = self.config_dir / "config.json"
        self.snapshot_path = self.data_dir / "page_overview.json"
        self.models_cache: tuple[float, list[str]] | None = None
        self._b64_rejected = False
        self._recent_urls: dict[str, list[tuple[float, str]]] = {}
        self._same_cache: dict[tuple, tuple[float, str]] = {}
        self._transport: httpx.AsyncBaseTransport | None = None
        self._config_mtime: float = 0.0
        self.config: dict[str, Any] = {}
        self.usage: dict[str, Any] = self._load_usage()
        self._load_config()
        self._write_page_snapshot()

    @property
    def na(self) -> Any:
        return getattr(self.context, "na", None)

    @property
    def pay(self) -> Any:
        return getattr(self.context, "pay", None)

    @property
    def media(self) -> Any:
        return getattr(self.context, "media", None)

    @property
    def gateway(self) -> Any:
        return getattr(self.context, "qq", self.context)

    def bind_runtime(self, runtime: Any) -> None:
        self.context = runtime

    def _load_config(self) -> None:
        current_mtime = 0.0
        if self.config_path.exists():
            with contextlib.suppress(OSError):
                current_mtime = self.config_path.stat().st_mtime
        if current_mtime != self._config_mtime or not self.config:
            loaded = dict(CONFIG_DEFAULTS)
            if self.config_path.exists():
                try:
                    data = json.loads(self.config_path.read_text(encoding="utf-8"))
                    if isinstance(data, dict):
                        loaded.update(data)
                except Exception as err:
                    logger.warning("读取配置文件失败: %s", err)
            self.config = loaded
            self._config_mtime = current_mtime

    def _save_config_file(self) -> None:
        temp = self.config_path.with_suffix(".tmp")
        temp.write_text(json.dumps(self.config, ensure_ascii=False, indent=2), encoding="utf-8")
        temp.replace(self.config_path)
        with contextlib.suppress(OSError):
            self._config_mtime = self.config_path.stat().st_mtime

    def _write_page_snapshot(self) -> None:
        try:
            cfg = {k: self._cfg(k) for k in CONFIG_DEFAULTS}
            # api_key 掩码
            if cfg.get("api_key"):
                cfg["api_key"] = "●●●●●●●●"
            data = {
                "plugin_id": "plugin.drawimg",
                "name": "AI 绘图助手",
                "version": PLUGIN_VERSION,
                "config": cfg,
                "config_public": cfg,
                "stats": {
                    "users": len(self.usage),
                    "cached_models": len(self.models_cache[1]) if self.models_cache else 0,
                    "presets_count": len(self._style_presets()),
                },
                "management": {
                    "permission": "plugin.dg.manage",
                    "requests_per_minute": 20,
                    "button_ttl_seconds": 300,
                    "admin_source": "Runtime 角色与机器人主人",
                },
                "schema": {
                    key: {"type": kind, "min": low, "max": high, "default": CONFIG_DEFAULTS[key]}
                    for key, (kind, (low, high)) in CONFIG_SPEC.items()
                },
                "updated_at": dt.datetime.now().isoformat(),
            }
            temp = self.snapshot_path.with_suffix(".tmp")
            temp.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
            temp.replace(self.snapshot_path)
        except Exception as err:
            logger.warning("写入控制台快照失败: %s", err)

    async def reload_config(self) -> None:
        self._load_config()
        self._write_page_snapshot()

    def _cfg(self, key: str) -> Any:
        self._load_config()
        return self.config.get(key, CONFIG_DEFAULTS.get(key))

    async def set_config(self, key: str, value: Any) -> None:
        if key not in CONFIG_SPEC:
            raise ValueError(f"未知的配置项：{key}")
        self._load_config()
        kind, _ = CONFIG_SPEC[key]
        if kind == "bool" and isinstance(value, str):
            val = value.lower() in ("true", "1", "on", "开")
        elif kind == "int" and isinstance(value, str):
            val = int(value)
        elif kind == "float" and isinstance(value, str):
            val = float(value)
        else:
            val = value
        self.config[key] = val
        self._save_config_file()
        self._write_page_snapshot()

    async def close(self) -> None:
        self._save_usage()
        self._recent_urls.clear()
        self._same_cache.clear()

    def _load_usage(self) -> dict[str, Any]:
        try:
            data = json.loads(self.usage_path.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            return {}
        if not isinstance(data, dict):
            return {}
        return self._migrate_prefixed_keys(data)

    @staticmethod
    def _migrate_prefixed_keys(data: dict[str, Any]) -> dict[str, Any]:
        """Merge legacy ``qq_official:<user>`` keys into bare user keys.

        Older releases stored usage.json / blacklist entries with a platform
        prefix.  The prefix carried no information (Runtime only speaks to QQ
        official) and leaked into every admin surface, so keys are canonical
        to the bare user id now.  When both forms exist the non-prefixed entry
        wins for scalar values; dict entries (per-user settings) merge with
        the prefixed row filling in missing fields.
        """
        renamed: list[tuple[str, str]] = []
        for key, value in list(data.items()):
            if not isinstance(key, str) or not key.startswith("qq_official:"):
                continue
            bare = _clean_user_key(key)
            if not bare:
                continue
            existing = data.get(bare)
            if existing is None:
                data[bare] = value
            elif isinstance(existing, dict) and isinstance(value, dict):
                for field, item in value.items():
                    existing.setdefault(field, item)
            renamed.append(key)
        for key in renamed:
            del data[key]
        if renamed:
            logger.info("drawimg: merged %d legacy qq_official: usage keys", len(renamed))
        return data

    def _save_usage(self) -> None:
        self.data_dir.mkdir(parents=True, exist_ok=True)
        temporary = self.usage_path.with_suffix(".tmp")
        temporary.write_text(json.dumps(self.usage, ensure_ascii=False, indent=2), encoding="utf-8")
        os.chmod(temporary, 0o600)
        temporary.replace(self.usage_path)

    # ---------- context helpers ----------

    @staticmethod
    def _user_key(context: MessageContext) -> str:
        # 积分账本（point_accounts）以裸用户编号为 identity，usage.json 的
        # qq_official: 前缀键也已在加载时合并；这里必须对齐，否则 /dg status
        # 等机器人侧余额查询会落到带前缀的幽灵账户上。
        return _clean_user_key(f"{context.platform or 'unknown'}:{context.sender_id}")

    @staticmethod
    def _is_private(context: MessageContext) -> bool:
        return context.conversation_type == "private"

    @staticmethod
    def _scene(context: MessageContext) -> str:
        return context.scene or (
            "c2c" if context.conversation_type == "private" else context.conversation_type
        )

    def _entry(self, context: MessageContext) -> dict[str, Any]:
        entry = self.usage.setdefault(self._user_key(context), {"model": ""})
        if self._is_private(context) or context.scene in {"group"}:
            entry["notify"] = {"conversation_id": context.conversation_id, "scene": self._scene(context)}
        return entry

    def _attachment_urls(self, context: MessageContext) -> list[str]:
        found: list[str] = []
        for item in context.attachments:
            if not isinstance(item, dict):
                continue
            url = str(item.get("url") or "")
            if not url.startswith("http"):
                continue
            kind = str(item.get("content_type") or "")
            name = str(item.get("filename") or item.get("id") or "")
            if kind.startswith("image") or re.search(r"\.(?:jpe?g|png|webp|gif|bmp)$", name, re.IGNORECASE):
                if url not in found:
                    found.append(url)
        return found

    def on_event(self, context: MessageContext) -> None:
        """通配事件处理器：记录用户最近发送的图片 URL（仅内存，不回复）。"""
        urls = self._attachment_urls(context)
        if not urls:
            return
        key = self._user_key(context)
        recent = self._recent_urls.setdefault(key, [])
        for url in reversed(urls):
            recent.insert(0, (time.time(), url))
        del self._recent_urls[key][3:]

    def _recent_urls_within_ttl(self, context: MessageContext, limit: int = 3) -> list[str]:
        ttl_min = max(1, int(self._cfg("edit_image_ttl_min")))
        recent = self._recent_urls.get(self._user_key(context), [])
        fresh = [url for saved_at, url in recent if time.time() - saved_at <= ttl_min * 60]
        self._recent_urls[self._user_key(context)] = [(t, u) for t, u in recent if time.time() - t <= ttl_min * 60]
        return fresh[:limit]

    # ---------- config helpers ----------

    def _base_url(self) -> str:
        base = str(self._cfg("api_base_url") or "").strip().rstrip("/")
        # 请求路径统一由本插件追加 `/v1/...`。管理员可能会把示例里的
        # `https://host/v1` 直接粘进配置，因此去掉末尾版本段，避免变成
        # `/v1/v1/images/generations`；根域名和带 `/v1` 两种写法均可用。
        if base.casefold().endswith("/v1"):
            base = base[:-3].rstrip("/")
        return base

    def _api_key(self) -> str:
        return str(self._cfg("api_key") or "").strip()

    def _timeout(self) -> float:
        return max(30.0, min(600.0, float(self._cfg("request_timeout_sec"))))

    def _cooldown(self) -> int:
        return max(0, int(self._cfg("cooldown_sec")))

    def _test_credit_cost(self) -> int:
        return max(1, int(self._cfg("test_credit_cost")))

    def _history_dir(self) -> Path:
        path = self.data_dir / "history"
        path.mkdir(parents=True, exist_ok=True)
        return path

    def _credit_rules(self) -> dict[str, int]:
        rules: dict[str, int] = {}
        raw_value = self._cfg("credit_cost_rules")
        try:
            parsed = json.loads(str(raw_value or "{}"))
        except (TypeError, ValueError, json.JSONDecodeError):
            parsed = None
        if isinstance(parsed, dict):
            for name, value in parsed.items():
                try:
                    cost = int(value)
                except (TypeError, ValueError):
                    continue
                name = str(name).strip()
                if name and cost > 0:
                    rules[name.casefold()] = cost
            return rules
        # 兼容升级前的分号格式；下次通过管理台保存时会转换为 JSON。
        raw = str(raw_value or "")
        for chunk in re.split(r"[;,，；\n]+", raw):
            if ":" not in chunk and "：" not in chunk:
                continue
            parts = re.split(r"[:：]", chunk, maxsplit=1)
            if len(parts) != 2:
                continue
            name, value = parts
            name = name.strip()
            try:
                cost = int(value.strip())
            except (TypeError, ValueError):
                continue
            if name and cost > 0:
                rules[name.casefold()] = cost
        return rules

    def _test_credit_cost_for(self, context: MessageContext) -> int:
        rules = self._credit_rules()
        return rules.get(self._model_of(context).casefold(), self._test_credit_cost())

    def _credit_price(self) -> float:
        return max(0.01, float(self._cfg("credit_price_yuan")))

    def _group_enabled(self) -> bool:
        return bool(self._cfg("enable_group"))

    def _default_model(self) -> str:
        return str(self._cfg("default_model") or "gpt-image-1").strip()

    def _size(self) -> str:
        return str(self._cfg("image_size") or "auto").strip()

    def _quality(self) -> str:
        return str(self._cfg("image_quality") or "auto").strip()

    def _today(self) -> str:
        try:
            tz = ZoneInfo(str(self._cfg("stats_timezone") or "Asia/Shanghai"))
        except Exception:
            tz = dt.UTC
        return dt.datetime.now(tz).strftime("%Y-%m-%d")

    def _style_presets(self) -> dict[str, str]:
        presets: dict[str, str] = {}
        raw_value = self._cfg("style_presets")
        try:
            parsed = json.loads(str(raw_value or "{}"))
        except (TypeError, ValueError, json.JSONDecodeError):
            parsed = None
        if isinstance(parsed, dict):
            return {
                str(name).strip(): str(prompt).strip()
                for name, prompt in parsed.items()
                if str(name).strip() and str(prompt).strip()
            }
        # 兼容升级前的分号格式；下次通过管理台保存时会转换为 JSON。
        raw = str(raw_value or "")
        for chunk in re.split(r"[;；\n]+", raw):
            parts = re.split(r"[:：]", chunk, maxsplit=1)
            if len(parts) == 2 and parts[0].strip() and parts[1].strip():
                presets[parts[0].strip()] = parts[1].strip()
        return presets

    def _test_blacklist(self) -> list[str]:
        try:
            data = json.loads(str(self._cfg("test_blacklist") or "[]"))
            items = [str(item) for item in data] if isinstance(data, list) else []
        except ValueError:
            return []
        # 归一化：剥除旧 qq_official: 前缀并去重
        return list(dict.fromkeys(item for item in (_clean_user_key(i) for i in items) if item))

    async def _set_blacklist(self, items: list[str]) -> None:
        await self.set_config("test_blacklist", json.dumps(items, ensure_ascii=False))

    def _user_size(self, context: MessageContext) -> str:
        return str(self._entry(context).get("image_size") or "").strip() or self._size()

    def _user_quality(self, context: MessageContext) -> str:
        return str(self._entry(context).get("image_quality") or "").strip() or self._quality()

    def _user_transparent(self, context: MessageContext) -> bool:
        return bool(self._entry(context).get("transparent", False))

    def _user_prompt_guard(self, context: MessageContext) -> bool:
        return bool(self._entry(context).get("prompt_guard", True))

    def _na_token_quota(self) -> int:
        return max(0, int(self._cfg("na_token_quota")))

    def _bound_key(self, context: MessageContext) -> str:
        return str(self._entry(context).get("api_key") or "").strip()

    @staticmethod
    def _headers_for(key: str) -> dict[str, str]:
        return {"Authorization": f"Bearer {key}"}

    def _network_error(self) -> str:
        return str(self._cfg("network_error_message") or CONFIG_DEFAULTS["network_error_message"])

    # ---------- cooldown / credits ----------

    def _cooldown_left(self, context: MessageContext) -> int:
        last = self.usage.get("_cooldowns", {}).get(self._user_key(context), 0)
        return max(0, self._cooldown() - int(time.time() - last))

    def _mark_cooldown(self, context: MessageContext) -> None:
        self.usage.setdefault("_cooldowns", {})[self._user_key(context)] = time.time()
        cooldowns = self.usage["_cooldowns"]
        if len(cooldowns) > 500:
            threshold = time.time() - 86400
            for key in [k for k, v in cooldowns.items() if v < threshold][:100]:
                cooldowns.pop(key, None)

    async def _credit_error(self, context: MessageContext) -> str:
        need = self._test_credit_cost_for(context)
        balance = await self.points.balance(self._user_key(context), POINT_TYPE)
        if balance >= need:
            return ""
        return f"积分不足（余额 {balance:.0f}，本次需要 {need}）。使用 /dgt pay <数量> 充值积分。"

    async def _consume_test(self, context: MessageContext) -> None:
        entry = self._entry(context)
        cost = self._test_credit_cost_for(context)
        daily = entry.setdefault("test_daily", {})
        today = self._today()
        daily[today] = int(daily.get(today, 0)) + 1
        if len(daily) > 7:
            for stale in sorted(daily.keys())[:-7]:
                daily.pop(stale, None)
        operation = f"drawimg:{self._user_key(context)}:{int(time.time() * 1000)}:{uuid.uuid4().hex[:6]}"
        try:
            await self.points.debit(
                self._user_key(context), str(cost), "drawimg.generate",
                "runtime.drawimg", operation, POINT_TYPE,
            )
        except ValueError as error:
            if "Insufficient" not in str(error):
                raise
        self._save_usage()

    async def _refund_test(self, context: MessageContext) -> None:
        cost = self._test_credit_cost_for(context)
        operation = f"drawimg-refund:{self._user_key(context)}:{int(time.time() * 1000)}:{uuid.uuid4().hex[:6]}"
        try:
            await self.points.credit(
                self._user_key(context), str(cost), "drawimg.refund",
                "runtime.drawimg", operation, POINT_TYPE,
            )
        except ValueError:
            pass

    # ---------- cards ----------

    def _menu_card(self, context: MessageContext, page: str = "") -> Card:
        page = (page or "").strip().lower()
        aliases = {"生图": "draw", "体验": "test", "账户": "account"}
        page = aliases.get(page, page)
        back = [_button("返回主菜单", "/dg")]
        pages = {
            "draw": ("生图功能", "生成图片与切换模型", [
                [_button("文生图", "/dg ", fill=True), _button("单图改图", "/dge ", fill=True)],
                [_button("多图改图", "/dgm ", fill=True), _button("模型列表", "/dg models")],
                [_button("风格预设", "/dg style")],
                [_button("尺寸", "/dg size"), _button("质量", "/dg quality")],
                back,
            ]),
            "test": ("体验模式", "使用管理员全局服务，按积分计费", [
                [_button("体验文生图", "/dgt ", fill=True), _button("体验单图改图", "/dgte ", fill=True)],
                [_button("体验多图改图", "/dgtm ", fill=True), _button("充值积分", "/dgt pay ", fill=True)],
                [_button("我的状态", "/dg status")],
                back,
            ]),
            "account": ("账户绑定", "自有 Key 用户无限制；New API 用户可一键绑定", [
                [_button("NewAPI绑定", "/dg na ", fill=True), _button("绑定Key", "/dg bind ", fill=True)],
                [_button("解绑", "/dg unbind"), _button("我的状态", "/dg status")],
                back,
            ]),
        }
        if page in pages:
            title, text, rows = pages[page]
            return Card(title, _menu_markdown(title, text), rows)
        rows = [
            [_button("生图功能", "/dg menu draw"), _button("体验模式", "/dg menu test")],
            [_button("账户绑定", "/dg menu account"), _button("使用教程", "/dg guide")],
        ]
        if context.is_admin:
            rows.append([_button("管理员菜单", "/dg admin")])
        return Card("绘图助手", _menu_markdown(
            "绘图助手",
            "选择分类进入子菜单。New API 用户推荐 /dg na 一键绑定；"
            "自有 Key 无限制，体验模式按积分计费。\n\n"
            "按钮填入指令后补上内容发送即可；不会用就点“使用教程”。",
        ), rows)

    def _admin_card(self) -> Card:
        rows = [
            [_button("充值比例", "/dg rate"), _button("模型计费", "/dg cost ", fill=True)],
            [_button("赠送积分", "/dg give ", fill=True), _button("积分排行", "/dg top")],
            [_button("模型列表", "/dg models"), _button("返回主菜单", "/dg")],
        ]
        return Card("管理员菜单", _menu_markdown(
            "管理员菜单",
            "/dg rate <元每积分>  — 设置积分充值比例（0.01-100）\n"
            "/dg rate  — 查看当前比例\n"
            "/dg give <数量> [用户编号]  — 赠送积分（编号见对方 /dg status）\n"
            "/dg top  — 积分排行\n"
            "/dg blacklist add|remove <用户编号>  — 黑名单管理\n"
            "/dg config [键] [值]  — 查看或修改插件配置\n"
            "生图单价由 test_credit_cost 配置（/dg config）。",
        ), rows)

    # ---------- /dg entry ----------

    async def command(self, context: MessageContext, args: list[str]) -> str | Card | None:
        raw = (args[0] if args else "").strip()
        sub = SUBCOMMAND_ALIASES.get(raw.lower(), raw.lower())
        rest = args[1:]
        if not sub:
            return self._menu_card(context)
        if sub == "help":
            return HELP_TEXT
        if sub == "menu":
            return self._menu_card(context, rest[0] if rest else "")
        if sub == "guide":
            return Card("使用教程", _menu_markdown("使用教程", GUIDE_TEXT), [
                [_button("文生图", "/dg ", fill=True), _button("单图改图", "/dge ", fill=True)],
                [_button("多图改图", "/dgm ", fill=True), _button("选择模型", "/dg models")],
                [_button("风格预设", "/dg style"), _button("充值积分", "/dg pay ", fill=True)],
                [_button("返回主菜单", "/dg")],
            ])
        if sub == "bind":
            return await self._bind(context, " ".join(rest))
        if sub == "unbind":
            return await self._unbind(context)
        if sub == "models":
            return await self._models(context, self._page_arg(rest))
        if sub == "model":
            return self._set_model(context, " ".join(rest))
        if sub == "status":
            return await self._status(context)
        if sub == "style":
            return await self._style(context, " ".join(rest))
        if sub in {"size", "ratio", "尺寸", "比例"}:
            return self._handle_size(context, rest)
        if sub in {"quality", "画质", "质量"}:
            return self._handle_quality(context, rest)
        if sub in {"bg", "transparent", "抠图", "透明", "免抠"}:
            return self._handle_transparent(context, rest)
        if sub in {"pg", "guard", "prompt_guard", "防改写"}:
            return self._handle_prompt_guard(context, rest)
        if sub == "history":
            return self._history(context)
        if sub == "resend":
            return await self._resend(context, self._page_arg(rest))
        if sub == "na":
            return await self._na_bind(context, " ".join(rest))
        if sub == "give":
            return await self._give(context, rest)
        if sub == "top":
            return await self._top(context)
        if sub == "admin":
            if not context.is_admin:
                return "只有管理员可以打开管理员菜单。"
            return self._admin_card()
        if sub == "blacklist":
            return await self._blacklist(context, rest)
        if sub == "config":
            return await self._config_command(context, rest)
        if sub in {"pay", "rate", "cost"}:
            return await self._dgt_subcommand(context, [sub, *rest])
        # /dg <提示词> 文生图
        mode = "pro" if self._bound_key(context) else "test"
        if mode == "test" and not self._api_key():
            return (
                "插件尚未配置统一生图接口，个人用户可私聊发送 /dg bind <Key> 绑定个人 Key 后使用。"
            )
        precheck = await self._precheck(context, " ".join(args), mode=mode)
        if precheck:
            return precheck
        return await self._generate_flow(context, " ".join(args), mode=mode)

    # ---------- standalone commands ----------

    async def dge_command(self, context: MessageContext, args: list[str]) -> str | None:
        prompt = " ".join(args).strip()
        urls = self._recent_urls_within_ttl(context, limit=1)
        if not urls:
            ttl_min = max(1, int(self._cfg("edit_image_ttl_min")))
            return (
                f"没有找到你最近发送的图片。请先发送一张图片，然后在 {ttl_min} 分钟内执行 /dge <提示词>。\n"
                "多图改图：连发 2~3 张图后 /dgm <提示词>。"
            )
        mode = "pro" if self._bound_key(context) else "test"
        if mode == "test" and not self._api_key():
            return "改图需要绑定自己的 API Key：私聊发送 /dg bind <Key>，或联系管理员配置统一服务。"
        precheck = await self._precheck(context, prompt, mode=mode)
        if precheck:
            return precheck
        return await self._generate_flow(context, prompt, edit_urls=urls, mode=mode, announce="单图改图")

    async def dgm_command(self, context: MessageContext, args: list[str]) -> str | None:
        prompt = " ".join(args).strip()
        urls = self._recent_urls_within_ttl(context, limit=3)
        if len(urls) < 2:
            ttl_min = max(1, int(self._cfg("edit_image_ttl_min")))
            return (
                f"多图改图需要至少 2 张图片：请在 {ttl_min} 分钟内连发 2~3 张图片，"
                f"再执行 /dgm <提示词>（当前 {len(urls)} 张）。"
            )
        mode = "pro" if self._bound_key(context) else "test"
        if mode == "test" and not self._api_key():
            return "多图改图需要绑定自己的 API Key：私聊发送 /dg bind <Key>，或联系管理员配置统一服务。"
        precheck = await self._precheck(context, prompt, mode=mode)
        if precheck:
            return precheck
        return await self._generate_flow(context, prompt, edit_urls=urls, mode=mode, announce=f"多图改图（{len(urls)} 张参考图）")

    async def dgt_command(self, context: MessageContext, args: list[str]) -> str | Card | None:
        head = (args[0].lower() if args else "")
        if head in {"pay", "充值", "rate", "比例", "cost", "计费"}:
            return await self._dgt_subcommand(context, args)
        prompt = " ".join(args).strip()
        if prompt.lower() in {"help", "帮助"}:
            return HELP_TEXT
        if not prompt:
            return "体验文生图用法：/dgt <提示词>。每次消耗积分，用 /dgt pay <数量> 充值。"
        precheck = await self._precheck(context, prompt, mode="test")
        if precheck:
            return precheck
        return await self._generate_flow(context, prompt, mode="test", announce="体验生成")

    async def dgte_command(self, context: MessageContext, args: list[str]) -> str | None:
        prompt = " ".join(args).strip()
        urls = self._recent_urls_within_ttl(context, limit=1)
        if not urls:
            ttl_min = max(1, int(self._cfg("edit_image_ttl_min")))
            return (
                f"没有找到你最近发送的图片。请先发送一张图片，然后在 {ttl_min} 分钟内执行 /dgte <提示词>。\n"
                "多图体验改图：连发 2~3 张图后 /dgtm <提示词>。"
            )
        precheck = await self._precheck(context, prompt, mode="test")
        if precheck:
            return precheck
        return await self._generate_flow(context, prompt, edit_urls=urls, mode="test", announce="体验单图改图")

    async def dgtm_command(self, context: MessageContext, args: list[str]) -> str | None:
        prompt = " ".join(args).strip()
        urls = self._recent_urls_within_ttl(context, limit=3)
        if len(urls) < 2:
            ttl_min = max(1, int(self._cfg("edit_image_ttl_min")))
            return (
                f"多图体验改图需要至少 2 张图片：请在 {ttl_min} 分钟内连发 2~3 张图片，"
                f"再执行 /dgtm <提示词>（当前 {len(urls)} 张）。"
            )
        precheck = await self._precheck(context, prompt, mode="test")
        if precheck:
            return precheck
        return await self._generate_flow(context, prompt, edit_urls=urls, mode="test", announce=f"体验多图改图（{len(urls)} 张参考图）")

    async def _dgt_subcommand(self, context: MessageContext, args: list[str]) -> str:
        action = args[0].lower()
        rest = args[1:]
        if action in {"pay", "充值"}:
            return await self._dgt_pay(context, " ".join(rest))
        if action in {"rate", "比例"}:
            return await self._dgt_rate(context, " ".join(rest))
        if action in {"cost", "计费"}:
            return await self._dgt_cost(context, " ".join(rest))
        return "用法：/dgt pay <积分数量>、/dgt rate <元每积分>、/dgt cost <模型>:<积分>"

    # ---------- account commands ----------

    async def _bind(self, context: MessageContext, key: str) -> str:
        if not self._is_private(context):
            return "API Key 只能通过私聊绑定，请私聊机器人执行 /dg bind <Key>。"
        key = key.strip()
        if key.lower().startswith("bearer "):
            key = key[7:].strip()
        if not key or len(key) > 200 or any(ord(c) < 32 for c in key):
            return "没有读取到有效 Key。用法：/dg bind <API Key>"
        entry = self._entry(context)
        entry["api_key"] = key
        self._save_usage()
        return "绑定成功。你的生成请求将使用自己的 Key，无次数与积分限制；/dg unbind 可解除。"

    async def _unbind(self, context: MessageContext) -> str:
        if not self._is_private(context):
            return "解绑只能在私聊中执行。"
        entry = self._entry(context)
        if not entry.get("api_key"):
            return "当前没有绑定 API Key。"
        token_name = str(entry.get("na_token_name") or "")
        entry.pop("api_key", None)
        entry.pop("base_url", None)
        entry.pop("na_token_name", None)
        self._save_usage()
        reply = "已解除 API Key 绑定；之后可用体验模式 /dgt（按积分计费）。"
        if token_name and self.na is not None:
            deleted = await self.na.svc_delete_token(self._user_key(context), token_name)
            if deleted.get("ok"):
                reply += "\n联动删除 New API 令牌成功：" + token_name
            else:
                reply += f"\nNew API 令牌删除失败：{deleted.get('error')}；可稍后用 /na tokendelete 手动删除。"
        return reply

    def _set_model(self, context: MessageContext, name: str) -> str:
        name = name.strip()
        if not name:
            current = self._entry(context).get("model") or self._default_model()
            return f"当前模型：{current}\n用法：/dg model <名称>，可用名称见 /dg models。"
        self._entry(context)["model"] = name
        self._save_usage()
        return f"已切换模型：{name}"

    async def _status(self, context: MessageContext) -> str:
        entry = self._entry(context)
        balance = await self.points.balance(self._user_key(context), POINT_TYPE)
        bound = "自有 Key（无限制）" if entry.get("api_key") else "体验模式（按积分计费）"
        lines = [
            f"用户编号：{self._user_key(context)}",
            f"服务来源：{'New API 账户令牌（' + entry['na_token_name'] + '）' if entry.get('na_token_name') else ('自定义 Key' if entry.get('api_key') else '体验模式（管理员全局服务）')}",
            f"当前模式：{bound}",
            f"积分余额：{balance:.0f}",
            f"当前模型：{entry.get('model') or self._default_model()}",
            f"体验生图单价：{self._test_credit_cost()} 积分/次；充值：/dgt pay <数量>",
        ]
        return "\n".join(lines)

    async def _style(self, context: MessageContext, name: str) -> str | Card:
        presets = self._style_presets()
        name = name.strip()
        current = self._entry(context).get("style") or ""
        if name.casefold() in {"off", "取消", "关闭"}:
            self._entry(context).pop("style", None)
            self._save_usage()
            return "已取消风格预设。"
        if name and name.isdigit():
            names = list(presets.keys())
            idx = int(name) - 1
            if 0 <= idx < len(names):
                self._entry(context)["style"] = names[idx]
                self._save_usage()
                return f"风格已设为 {names[idx]}。"
        if name:
            matched = next((key for key in presets if key.casefold() == name.casefold()), None)
            if not matched:
                return "没有这个风格。可用：" + ("、".join(presets.keys()) or "（未配置）")
            self._entry(context)["style"] = matched
            self._save_usage()
            return f"风格已设为 {matched}。"
        if not presets:
            return "管理员尚未配置 style_presets 风格预设（/dg config style_presets ...）。"
        names = list(presets.keys())
        text = f"当前风格：{current or '未设置'}\n点击按钮切换（实时读取最新预设）：\n可用：" + "、".join(names)
        rows = [[_button(n, f"/dg style {n}") for n in names[i : i + 2]] for i in range(0, min(len(names), 4), 2)]
        rows.append([_button("取消风格", "/dg style off"), _button("返回主菜单", "/dg")])
        return Card("风格预设", _menu_markdown("风格预设", text), rows)

    def _size_and_quality_card(self, context: MessageContext, notice: str = "") -> Card:
        current_size = self._user_size(context).lower()
        current_quality = self._user_quality(context).lower()
        cur_trans = self._user_transparent(context)
        cur_guard = self._user_prompt_guard(context)

        selected_ratio = "auto"
        for ratio, info in COMMON_RATIOS.items():
            if current_size == ratio or current_size == info["size"].lower():
                selected_ratio = ratio
                break
        if selected_ratio == "auto" and current_size != "auto":
            selected_ratio = current_size

        display_size = _format_size_display(current_size)
        display_quality = _format_quality_display(current_quality)
        trans_display = "✅ 开启 (自动免抠)" if cur_trans else "❌ 关闭"
        guard_display = "✅ 开启 (锁定原意)" if cur_guard else "❌ 关闭"

        notice_text = f"✨ **{notice}**\n\n" if notice else ""
        content = (
            f"{notice_text}"
            f"⚙️ **当前生图参数与偏好预设：**\n"
            f"• **画面尺寸/比例**：`{display_size}`\n"
            f"• **画面生成画质**：`{display_quality}`\n"
            f"• **免抠透明底图**：`{trans_display}`\n"
            f"• **提示词防改写**：`{guard_display}`\n\n"
            f"💡 *点击按钮一键切换比例与画质（更多比例可发送 `/dg size 3:2`、`2:3` 或 `21:9`）：*"
        )

        def ratio_btn(key: str, text: str) -> Button:
            checked = (selected_ratio == key or current_size == key)
            label = f"✓{text}" if checked else text
            return Button(label, f"/dg size {key}", action_type=1, permission=2, expires_after_seconds=600)

        def quality_btn(key: str, text: str) -> Button:
            checked = (current_quality == key)
            label = f"✓{text}" if checked else text
            return Button(label, f"/dg quality {key}", action_type=1, permission=2, expires_after_seconds=600)

        def trans_btn() -> Button:
            label = "✓ 免抠透明底" if cur_trans else "免抠透明底"
            return Button(label, "/dg bg toggle", action_type=1, permission=2, expires_after_seconds=600)

        def guard_btn() -> Button:
            label = "✓ 提示词防改写" if cur_guard else "提示词防改写"
            return Button(label, "/dg guard toggle", action_type=1, permission=2, expires_after_seconds=600)

        rows = [
            [
                ratio_btn("1:1", "1:1 正方"),
                ratio_btn("16:9", "16:9 宽屏"),
                ratio_btn("9:16", "9:16 竖屏"),
            ],
            [
                ratio_btn("4:3", "4:3 横版"),
                ratio_btn("3:4", "3:4 竖版"),
                ratio_btn("auto", "自适应"),
            ],
            [
                quality_btn("auto", "自动画质"),
                quality_btn("standard", "标准质量"),
                quality_btn("hd", "高清 HD"),
            ],
            [
                trans_btn(),
                guard_btn(),
            ],
            [
                Button("返回主菜单", "/dg", action_type=1, permission=0, expires_after_seconds=600),
            ]
        ]
        return Card("图片尺寸与偏好", content, rows=rows)

    def _handle_size(self, context: MessageContext, args: list[str]) -> str | Card:
        if not args:
            return self._size_and_quality_card(context)
        target = args[0].strip().lower()
        ratio_aliases = {
            "1:1": "1:1", "正方形": "1:1", "方图": "1:1",
            "16:9": "16:9", "横屏": "16:9", "宽屏": "16:9",
            "9:16": "9:16", "竖屏": "9:16", "手机": "9:16",
            "4:3": "4:3", "3:4": "3:4",
            "3:2": "3:2", "2:3": "2:3",
            "21:9": "21:9",
            "auto": "auto", "自动": "auto",
        }
        is_interaction = getattr(context, "message_type", None) == "interaction"
        if target in ratio_aliases:
            resolved = ratio_aliases[target]
            self._entry(context)["image_size"] = resolved
            self._save_usage()
            if is_interaction:
                return self._size_and_quality_card(context, f"已成功切换画面比例为：{resolved}")
            return f"生图尺寸已设置为：`{_format_size_display(resolved)}`。"
        if re.fullmatch(r"\d{3,4}x\d{3,4}", target):
            self._entry(context)["image_size"] = target
            self._save_usage()
            if is_interaction:
                return self._size_and_quality_card(context, f"已成功切换画面尺寸为：{target}")
            return f"生图尺寸已设置为：`{target}`。"
        return "尺寸格式应为常见比例（如 16:9、9:16、1:1、4:3、3:4）或 宽x高（如 1024x1024）或 auto。"

    def _handle_quality(self, context: MessageContext, args: list[str]) -> str | Card:
        if not args:
            return self._size_and_quality_card(context)
        target = args[0].strip().lower()
        quality_aliases = {
            "auto": "auto", "自动": "auto",
            "standard": "standard", "标清": "standard", "标准": "standard",
            "hd": "hd", "高清": "hd", "高品质": "hd",
            "high": "high", "超清": "high",
            "low": "low", "低": "low",
            "medium": "medium", "中": "medium",
        }
        if target in quality_aliases:
            resolved = quality_aliases[target]
            self._entry(context)["image_quality"] = resolved
            self._save_usage()
            if getattr(context, "message_type", None) == "interaction":
                return self._size_and_quality_card(context, f"已成功切换画质为：{_format_quality_display(resolved)}")
            return f"生成质量已设置为：`{_format_quality_display(resolved)}`。"
        return "质量应为 auto、standard、hd、high、low 或 medium。"

    def _handle_transparent(self, context: MessageContext, args: list[str]) -> str | Card:
        cur = self._user_transparent(context)
        is_interaction = getattr(context, "message_type", None) == "interaction"
        if not args or args[0].lower() in {"toggle", "切换"}:
            new_val = not cur
        elif args[0].lower() in {"on", "open", "开启", "1", "true", "开"}:
            new_val = True
        elif args[0].lower() in {"off", "close", "关闭", "0", "false", "关"}:
            new_val = False
        else:
            new_val = not cur
        self._entry(context)["transparent"] = new_val
        self._save_usage()
        state_text = "开启（生成图片自动消除绿幕转为透明底图）" if new_val else "关闭（生成完整背景图片）"
        if is_interaction:
            return self._size_and_quality_card(context, f"已切换透明免抠底图模式为：{'开启' if new_val else '关闭'}")
        return f"透明免抠底图模式已设置为：**{state_text}**。"

    def _handle_prompt_guard(self, context: MessageContext, args: list[str]) -> str | Card:
        cur = self._user_prompt_guard(context)
        is_interaction = getattr(context, "message_type", None) == "interaction"
        if not args or args[0].lower() in {"toggle", "切换"}:
            new_val = not cur
        elif args[0].lower() in {"on", "open", "开启", "1", "true", "开"}:
            new_val = True
        elif args[0].lower() in {"off", "close", "关闭", "0", "false", "关"}:
            new_val = False
        else:
            new_val = not cur
        self._entry(context)["prompt_guard"] = new_val
        self._save_usage()
        state_text = "开启（阻止模型擅自重写或篡改用户提示词）" if new_val else "关闭（允许模型自由优化提示词）"
        if is_interaction:
            return self._size_and_quality_card(context, f"已切换提示词防改写注入为：{'开启' if new_val else '关闭'}")
        return f"提示词防改写注入已设置为：**{state_text}**。"

    def _set_size(self, context: MessageContext, value: str) -> str | Card:
        return self._handle_size(context, [value] if value else [])

    def _set_quality(self, context: MessageContext, value: str) -> str | Card:
        return self._handle_quality(context, [value] if value else [])

    def _history(self, context: MessageContext) -> str | Card:
        return "生图历史功能已关闭，系统不保存任何历史生成记录。"

    async def _resend(self, context: MessageContext, index: int) -> str | None:
        return "历史重发功能已关闭，系统不保存任何历史生成记录。"

    async def _na_bind(self, context: MessageContext, group: str) -> str:
        if not self._is_private(context):
            return "New API 一键绑定只能在私聊中执行。"
        entry = self._entry(context)
        if entry.get("na_token_name"):
            return f"已绑定 New API 令牌（名称 {entry['na_token_name']}）。先 /dg unbind 再重新绑定。"
        if self.na is None:
            return "na 插件尚未加载，无法联动绑定；可手动 /dg bind <Key>。"
        group = group.strip() or str(self._cfg("newapi_group") or "").strip()
        if not group:
            listing = await self.na.svc_list_groups(self._user_key(context))
            if listing.get("ok") and listing.get("groups"):
                names = "、".join(str(g) for g in listing["groups"][:20])
                return (
                    f"请选择包含生图模型的分组，发送 /dg na <分组名>：\n{names}\n\n"
                    "管理员未配置默认分组；也可用 /dg config newapi_group 配置。"
                )
            return f"请发送 /dg na <分组名> 指定包含生图模型的分组。{(listing.get('error') or '')[:100]}"
        result = await self.na.svc_create_token(
            self._user_key(context), f"drawimg-{uuid.uuid4().hex[:6]}", group, self._na_token_quota()
        )
        if not result.get("ok"):
            return f"创建 New API 令牌失败：{result.get('error')}"
        entry["api_key"] = str(result["api_key"])
        entry["base_url"] = str(result.get("base_url") or "")
        entry["na_token_name"] = str(result["token_name"])
        self._save_usage()
        return (
            "已创建 New API 令牌并绑定绘图（分组 " + group + "），无积分与次数限制。\n"
            "完整 Key 仅显示本次，请妥善保存：\n" + str(result["api_key"]) + "\n"
            "可用 /dg model <名称> 切换生图模型；/dg unbind 解绑（会同步删除该令牌）。"
        )

    # ---------- admin commands ----------

    async def _give(self, context: MessageContext, args: list[str]) -> str | Card:
        if not context.is_admin:
            return Card("无权限", "⚠️ 只有管理员可以赠送或调整用户积分。")
        count_text = args[0] if args else ""
        target = args[1] if len(args) > 1 else ""
        try:
            count = int(str(count_text).strip())
        except (TypeError, ValueError):
            return Card("使用帮助", "用法：`/dg give <数量> [@某人|用户编号]`\n@某人直接赠送，或用对方 /dg status 里的用户编号。")
        if count <= 0 or count > 1000000:
            return Card("参数错误", "⚠️ 积分数量需为 1-1000000。")

        target_raw = self._mention_target(context) or target.strip() or self._user_key(context)
        clean_target = _clean_user_key(target_raw)
        if not clean_target:
            return Card("未识别用户", "⚠️ 没有识别到目标用户。可以 @对方，或用其 /dg status 里的用户编号。")

        balance = 0
        if self.points:
            try:
                bal = await self.points.credit(
                    clean_target, str(count), "drawimg.gift", "runtime.drawimg",
                    f"drawimg-gift:{clean_target}:{int(time.time() * 1000)}:{uuid.uuid4().hex[:6]}", POINT_TYPE,
                )
                balance = int(bal)
            except Exception as error:
                return Card("赠送失败", f"赠送积分失败：{error}")

        for p in (
            self.data_dir / "plugin-data" / "plugin.drawimg.service" / "credits.json",
            self.data_dir / "plugins" / "plugin.drawimg.service" / "credits.json",
            self.data_dir / "plugins" / "plugin.drawimg.service" / "data" / "credits.json",
            self.data_dir / "drawimg" / "credits.json",
        ):
            try:
                p.parent.mkdir(parents=True, exist_ok=True)
                d = {}
                if p.is_file():
                    try:
                        d = json.loads(p.read_text("utf-8"))
                    except Exception:
                        d = {}
                d[clean_target] = balance
                p.write_text(json.dumps(d, ensure_ascii=False, indent=2), encoding="utf-8")
            except Exception:
                pass

        notify = self.usage.get(clean_target, {}).get("notify") if isinstance(self.usage, dict) else None
        if isinstance(notify, dict) and self.gateway is not None:
            try:
                await self.gateway.send_text(
                    notify["conversation_id"], notify["scene"],
                    f"管理员为你充值了 {count} 积分（当前 {balance}）。",
                )
            except Exception:
                pass

        return f"已为 {clean_target} 赠送 {count} 积分（当前 {balance}）。"

    async def _top(self, context: MessageContext) -> str:
        if not context.is_admin:
            return "只有管理员可以查看积分排行。"
        ranked = await self.points.top_identities(POINT_TYPE, 10)
        if not ranked:
            return "当前没有用户积分记录。"
        lines = ["积分排行（前 10）：", "", "| 用户编号 | 积分 |", "|---|---:|"]
        lines.extend(f"| {identity} | {int(balance)} |" for identity, balance in ranked)
        return "\n".join(lines)

    async def _blacklist(self, context: MessageContext, args: list[str]) -> str:
        if not context.is_admin:
            return "只有管理员可以管理体验黑名单。"
        action = (args[0] if args else "").strip().lower()
        key = _clean_user_key(args[1] if len(args) > 1 else "")
        if action not in {"add", "remove", "list", "加", "移除", "列表"}:
            return "用法：/dg blacklist add|remove <用户编号>，或 /dg blacklist list"
        items = self._test_blacklist()
        if action in {"list", "列表"}:
            return "体验黑名单：" + ("、".join(items) if items else "（空）")
        if not key:
            return "用法：/dg blacklist add|remove <用户编号>"
        if action == "add" and key not in items:
            items.append(key)
        elif action == "remove" and key in items:
            items.remove(key)
        else:
            return "该用户编号已不在黑名单内。" if action == "remove" else "该用户编号已在黑名单内。"
        await self._set_blacklist(items)
        return f"已{'加入' if action == 'add' else '移出'}黑名单：{key}"

    async def _dgt_rate(self, context: MessageContext, price: str) -> str:
        if not context.is_admin:
            return "只有管理员可以设置积分充值比例。"
        price = price.strip()
        if not price:
            current = self._credit_price()
            return (
                f"当前积分单价：{current:.2f} 元/积分（1 元 ≈ {1 / current:.1f} 积分）。\n"
                "用法：/dgt rate <元每积分>，例如 /dgt rate 0.2"
            )
        try:
            value = float(price)
        except (TypeError, ValueError):
            return "单价必须是数字，例如 /dgt rate 0.2"
        if not (0.01 <= value <= 100):
            return "单价需在 0.01-100 元/积分 之间。"
        await self.set_config("credit_price_yuan", repr(value))
        return f"已设置积分单价：{value:.2f} 元/积分（1 元 ≈ {1 / value:.1f} 积分）。"

    async def _dgt_cost(self, context: MessageContext, spec: str) -> str:
        if not context.is_admin:
            return "只有管理员可以设置模型积分规则。"
        spec = spec.strip()
        if not spec:
            rules = self._credit_rules()
            if rules:
                lines = ["模型积分规则（未命中的用默认）："] + [f"- {name}: {cost} 积分" for name, cost in rules.items()]
                return "\n".join(lines) + f"\n默认：{self._test_credit_cost()} 积分。用法：/dgt cost <模型>:<积分>，或 /dgt cost clear 清空。"
            return f"当前没有分级规则，全部按默认 {self._test_credit_cost()} 积分。用法：/dgt cost <模型>:<积分>，或 /dgt cost clear 清空。"
        if spec.casefold() in {"clear", "清空", "off"}:
            await self.set_config("credit_cost_rules", "{}")
            return "已清空分级规则。"
        rules = self._credit_rules()
        for chunk in re.split(r"[;,，；\n]+", spec):
            if ":" not in chunk and "：" not in chunk:
                continue
            parts = re.split(r"[:：]", chunk, maxsplit=1)
            if len(parts) != 2:
                return f"规则 {chunk.strip()} 无效：格式应为 模型:积分。"
            name, value = parts
            name = name.strip()
            try:
                cost = int(value.strip())
            except (TypeError, ValueError):
                return f"规则 {chunk.strip()} 无效：积分必须是正整数。"
            if not name or cost <= 0:
                return f"规则 {chunk.strip()} 无效。"
            rules[name.casefold()] = cost
        await self.set_config("credit_cost_rules", json.dumps(rules, ensure_ascii=False, sort_keys=True))
        return "已更新模型积分规则：\n" + "\n".join(f"- {name}: {cost} 积分" for name, cost in rules.items())

    async def _dgt_pay(self, context: MessageContext, amount: str) -> str:
        if self.pay is None:
            return "支付插件尚未启用，暂时无法充值。"
        try:
            count = int(str(amount).strip())
        except (TypeError, ValueError):
            return "用法：/dgt pay <积分数量>，例如 /dgt pay 10"
        if count < 1 or count > 100000:
            return "积分数量需为 1-100000。"
        yuan = count * self._credit_price()
        total = f"{yuan:.2f}"
        external_id = f"drawimg:{count}:{self._user_key(context)}:{int(time.time())}"
        try:
            intent = await self.pay.create_payment(
                source_plugin="runtime.drawimg",
                external_id=external_id,
                owner_key=self._user_key(context),
                subject=f"绘图积分 {count} 点",
                amount=total,
                points=str(count),
                point_type=POINT_TYPE,
            )
        except ValueError as error:
            if "active payment limit" in str(error):
                return "你的待支付订单已达上限，请先完成支付或等旧订单过期后再试。"
            if "商户" in str(error):
                return f"创建支付失败：{error}（管理员需先在支付设置中绑定商户）。"
            return f"创建支付失败：{error}"
        except Exception:
            return "创建支付失败，请稍后重试。"
        link = str(intent.get("pay_info") or "")
        text = f"积分 {count} 点，金额 {total} 元，订单 {intent['id']}。支付成功后自动到账。"
        if link:
            text += f"\n支付链接/二维码信息：{link}"
        else:
            text += "\n可稍后用 /pay order " + str(intent["id"]) + " 查询支付状态。"
        return text

    async def _config_command(self, context: MessageContext, rest: list[str]) -> str:
        if not context.is_admin:
            return "只有管理员可以查看或修改插件配置。"
        if not rest:
            lines = ["绘图插件配置（dg.*）："]
            for key in CONFIG_SPEC:
                current = self._config_cache.get(key)
                if current is None:
                    default = CONFIG_DEFAULTS[key]
                    current = ("true" if default else "false") if isinstance(default, bool) else str(default)
                if key == "api_key" and current:
                    current = current[:4] + "..." + current[-4:] if len(current) > 10 else "已保存"
                lines.append(f"{key} = {current}")
            lines.extend(["", "修改：/dg config <键> <值>；黑名单：/dg blacklist add|remove <编号>"])
            return "\n".join(lines)
        if len(rest) == 1:
            key = rest[0].strip()
            if key not in CONFIG_SPEC:
                return f"未知的配置项：{key}"
            current = self._config_cache.get(key)
            if current is None:
                default = CONFIG_DEFAULTS[key]
                current = ("true" if default else "false") if isinstance(default, bool) else str(default)
            return f"{key} = {current}"
        key = rest[0].strip()
        value = " ".join(rest[1:]).strip()
        kind, (low, high) = CONFIG_SPEC[key]
        try:
            if kind == "bool":
                if value.lower() not in {"true", "false", "1", "0", "on", "off", "开", "关"}:
                    raise ValueError
                stored = "true" if value.lower() in {"true", "1", "on", "开"} else "false"
            elif kind == "int":
                number = int(value)
                if not low <= number <= high:
                    return f"{key} 需在 {low:.0f}-{high:.0f} 之间。"
                stored = str(number)
            elif kind == "float":
                number = float(value)
                if not low <= number <= high:
                    return f"{key} 需在 {low} - {high} 之间。"
                stored = repr(number)
            else:
                if not low <= len(value) <= high:
                    return f"{key} 长度需在 {low:.0f}-{high:.0f} 之间。"
                stored = value
        except ValueError:
            return f"{key} 的值无效（需要 {kind}）。"
        await self.set_config(key, stored)
        return f"已设置 {key} = {'（已保存）' if key == 'api_key' else stored}。"

    # ---------- generation ----------

    async def _precheck(self, context: MessageContext, prompt: str, mode: str = "pro") -> str:
        if not self._base_url():
            return "插件尚未配置生图服务地址，请联系管理员使用 /dg config api_base_url <地址>。"
        if not self._is_private(context) and not self._group_enabled():
            return "群聊生图未由管理员启用。"
        prompt = (prompt or "").strip()
        if not prompt and not self._attachment_urls(context):
            return HELP_TEXT
        if mode == "test":
            if not self._api_key():
                return "体验模式未由管理员开启（未配置全局 Key，/dg config api_key <Key>）。"
            if self._user_key(context) in self._test_blacklist():
                return "你已被列入体验生图黑名单。"
            limit = int(self._cfg("test_daily_limit"))
            if limit > 0:
                entry = self._entry(context)
                used = int(entry.setdefault("test_daily", {}).get(self._today(), 0))
                if used >= limit:
                    return f"今日体验次数已达上限（{used}/{limit}），明天再来或绑定自己的 Key。"
            if left := self._cooldown_left(context):
                return f"操作太快啦，请 {left} 秒后重试。"
            if credit_error := await self._credit_error(context):
                return credit_error
        if len(prompt) > int(self._cfg("max_prompt_chars")):
            return "提示词太长了，请精简后再试。"
        return ""

    async def _generate_flow(
        self,
        context: MessageContext,
        prompt: str,
        edit_urls: list[str] | None = None,
        mode: str = "pro",
        announce: str = "生成",
    ) -> str | None:
        await self._announce(context, f"🎨 已收到{announce}请求（模型 {self._model_of(context)}），正在生成，预计 20-120 秒，请稍候……")
        result = await self._generate(context, prompt, edit_urls=edit_urls, mode=mode)
        return result or None

    async def _announce(self, context: MessageContext, text: str) -> None:
        gateway = self.gateway
        if gateway is None:
            return
        try:
            await gateway.send_text(context.conversation_id, self._scene(context), text)
        except Exception:
            pass

    async def _generate(self, context: MessageContext, prompt: str, edit_urls: list[str] | None = None, mode: str = "pro") -> str:
        key = self._bound_key(context) if mode == "pro" else self._api_key()
        base = str(self._entry(context).get("base_url") or "").strip() or self._base_url()
        if not base or not key:
            return "插件尚未配置生图服务或密钥，请联系管理员。"
        if not self._is_private(context) and not self._group_enabled():
            return "群聊生图未由管理员启用。"
        prompt = (prompt or "").strip()
        style = str(self._entry(context).get("style") or "").strip()
        style_text = self._style_presets().get(style, "")
        if prompt and style_text:
            prompt = f"{prompt},{style_text}"
        image_urls = self._attachment_urls(context)
        for url in (edit_urls or []):
            if url not in image_urls:
                image_urls.append(url)
        if not prompt and not image_urls:
            return HELP_TEXT
        cache_key = (self._user_key(context), self._model_of(context), prompt, self._user_size(context), self._user_quality(context))
        cached = self._same_cache.get(cache_key)
        if not image_urls and cached and time.time() - cached[0] <= max(0, int(self._cfg("same_cache_sec"))) and Path(cached[1]).is_file():
            if await self._send_image(context, Path(cached[1])):
                return ""
            self._same_cache.pop(cache_key, None)
        if len(prompt) > int(self._cfg("max_prompt_chars")):
            return "提示词太长了，请精简后再试。"
        images: list[bytes] = []
        if image_urls:
            for url in image_urls[:4]:
                data, error = await self._download_image(url)
                if error:
                    return f"读取图片失败：{error}"
                images.append(_clamp_image_for_api(data))
        if bool(self._cfg("debug_log")):
            print(f"drawimg: mode={mode} model={self._model_of(context)} images={len(images)}")
        self._mark_cooldown(context)

        # 提示词防篡改前缀与免抠绿幕后缀注入
        effective_prompt = prompt
        if self._user_prompt_guard(context):
            effective_prompt = f"{PROMPT_GUARD_PREFIX}{effective_prompt}"
        if not images and self._user_transparent(context):
            effective_prompt = f"{effective_prompt}{CHROMA_KEY_SUFFIX}"

        revised_prompt = ""
        try:
            if images:
                path, error = await self._request_edit(context, effective_prompt, images, key, base)
            else:
                gen_res = await self._request_generate(context, effective_prompt, key, base)
                if len(gen_res) == 3:
                    path, error, revised_prompt = gen_res[0], gen_res[1], gen_res[2]
                else:
                    path, error = gen_res[0], gen_res[1]
        except httpx.TimeoutException:
            return "生图超时了，任务可能仍在后台完成，请稍后再试。"
        except httpx.HTTPError:
            return self._network_error()
        if error:
            return error

        if not images and self._user_transparent(context) and path:
            try:
                trans_path = await asyncio.to_thread(_remove_green_background, Path(path))
                path = str(trans_path)
            except Exception as e:
                logger.warning("Failed to remove green background: %s", e)

        if mode == "test":
            await self._consume_test(context)
        sent = await self._send_image(context, Path(path))
        if sent:
            try:
                gateway = self.gateway
                if gateway:
                    re_cmd = f"/dgt {prompt}" if mode == "test" else f"/dg {prompt}"
                    clean_revised = (revised_prompt or "").strip()
                    for suffix in (CHROMA_KEY_SUFFIX, "pure solid green screen background, chroma key green background", "pure solid green screen background"):
                        if suffix in clean_revised:
                            clean_revised = clean_revised.replace(suffix, "").strip(", ")
                    revised_block = ""
                    card_rows = []
                    if clean_revised and clean_revised.lower() != prompt.strip().lower():
                        short_rev = clean_revised[:100] + ("…" if len(clean_revised) > 100 else "")
                        revised_block = f"\n- **模型优化提示词**：`{short_rev}`"
                        card_rows.append([
                            Button("✨ 用优化词生图", f"/dg {clean_revised[:60]}", action_type=1, permission=2, expires_after_seconds=600),
                            Button("再来一张", re_cmd, action_type=1, permission=2, click_limit=3, expires_after_seconds=600),
                        ])
                    else:
                        card_rows.append([
                            Button("再来一张", re_cmd, action_type=1, permission=2, click_limit=3, expires_after_seconds=600),
                            Button("风格预设", "/dg style", action_type=1, permission=2, expires_after_seconds=600),
                        ])
                    card_rows.append([
                        Button("尺寸比例", "/dg size", action_type=1, permission=2, expires_after_seconds=600),
                        Button("基于此图改图", "/dge ", action_type=2, enter=False, permission=2, expires_after_seconds=600),
                    ])
                    card_rows.append([
                        Button("我的状态", "/dg status", action_type=1, permission=2, expires_after_seconds=600),
                        Button("绘图菜单", "/dg", action_type=1, permission=0, expires_after_seconds=600),
                    ])
                    action_card = Card(
                        "🎨 AI 绘图已完成",
                        f"**模型**：`{self._model_of(context)}` · **模式**：{'体验模式' if mode == 'test' else '自有 Key'}\n\n"
                        f"**提示词**：{prompt or '改图生成'}{revised_block}\n\n"
                        "点击下方按钮可快捷再来一张、调优风格、选择尺寸或改图。",
                        rows=card_rows,
                    )
                    await gateway.send_card(context.conversation_id, self._scene(context), action_card)
            except Exception:
                pass
        Path(path).unlink(missing_ok=True)
        if not sent:
            if mode == "test":
                await self._refund_test(context)
                return "图片已生成但 QQ 发送失败，本次积分已退还；请稍后重试。"
            return "图片已生成但 QQ 发送失败，请稍后重试。"
        return ""

    def _push_history(self, context: MessageContext, src: str) -> None:
        pass

    def _model_of(self, context: MessageContext) -> str:
        return (self._entry(context).get("model") or "").strip() or self._default_model()

    async def _fetch_models(self, key: str = "", base: str = "") -> tuple[list[str], str]:
        cached = self.models_cache
        ttl = max(0, int(self._cfg("models_cache_ttl_sec")))
        if cached and ttl and time.time() - cached[0] < ttl:
            return cached[1], ""
        try:
            async with httpx.AsyncClient(base_url=base or self._base_url(), timeout=self._timeout(), follow_redirects=False, transport=self._transport) as client:
                response = await client.get("/v1/models", headers=self._headers_for(key))
        except httpx.HTTPError:
            return [], self._network_error()
        if response.status_code >= 400:
            return [], f"HTTP {response.status_code}"
        data = self._json(response)
        items = data.get("data") if isinstance(data, dict) else None
        if not isinstance(items, list):
            return [], "响应中没有模型列表"
        names = sorted({str(item.get("id") or "").strip() for item in items if isinstance(item, dict) and item.get("id")})
        if not names:
            return [], "模型列表为空"
        self.models_cache = (time.time(), names)
        return names, ""

    async def _models(self, context: MessageContext, page: int) -> str | Card:
        base = str(self._entry(context).get("base_url") or "").strip() or self._base_url()
        if not base:
            return "插件尚未配置生图服务地址，请联系管理员。"
        models, error = await self._fetch_models(self._bound_key(context) or self._api_key(), base)
        if error:
            return f"获取模型列表失败：{error}"
        image_like = [name for name in models if any(word in name.lower() for word in ("image", "flux", "dall", "sd", "seedream", "banana"))]
        shown = image_like or models
        per_page = 16
        total_pages = max(1, (len(shown) + per_page - 1) // per_page)
        page = max(1, min(page, total_pages))
        chunk = shown[(page - 1) * per_page: (page - 1) * per_page + per_page]
        lines = [f"可用模型（第 {page}/{total_pages} 页，共 {len(shown)} 个）：", "", "| # | 模型 |", "|---|---|"]
        lines.extend(f"| {i} | {name} |" for i, name in enumerate(chunk, start=(page - 1) * per_page + 1))
        text = "\n".join(lines)
        nav_row: list[Button] = []
        if page > 1:
            nav_row.append(_button("上一页", f"/dg models {page - 1}"))
        nav_row.append(_button("跳页", "/dg models ", fill=True))
        if page < total_pages:
            nav_row.append(_button("下一页", f"/dg models {page + 1}"))
        action_row = [
            _button("切换模型", "/dg model ", fill=True),
            _button("返回主菜单", "/dg"),
        ]
        rows = [[_button(f"模型{i + 1}", f"/dg model {name}", fill=True) for i, name in enumerate(chunk[:6])][index : index + 3] for index in range(0, min(6, len(chunk)), 3)]
        if nav_row:
            rows.append(nav_row)
        rows.append(action_row)
        return Card(f"可用模型（第 {page}/{total_pages} 页）", _menu_markdown(f"可用模型（第 {page}/{total_pages} 页）", text + "\n\n切换：/dg model <名称>"), rows)

    async def _request_generate(self, context: MessageContext, prompt: str, key: str = "", base: str = "") -> tuple[str, str, str]:
        user_size = self._user_size(context)
        api_size, aspect_ratio = _resolve_api_size(user_size, self._model_of(context))
        payload: dict[str, Any] = {"model": self._model_of(context), "prompt": prompt, "n": 1}
        if api_size != "auto":
            payload["size"] = api_size
        if aspect_ratio:
            payload["aspect_ratio"] = aspect_ratio
        if self._user_quality(context) != "auto":
            payload["quality"] = self._user_quality(context)
        if bool(self._cfg("prefer_b64_response")) and not self._b64_rejected:
            payload["response_format"] = "b64_json"
        async with httpx.AsyncClient(base_url=base or self._base_url(), timeout=self._timeout(), follow_redirects=False, transport=self._transport) as client:
            response = await client.post("/v1/images/generations", json=payload, headers=self._headers_for(key))
            if response.status_code in {400, 422} and "response_format" in payload:
                self._b64_rejected = True
                payload.pop("response_format", None)
                response = await client.post("/v1/images/generations", json=payload, headers=self._headers_for(key))
            if response.status_code in {400, 422} and "quality" in payload:
                payload.pop("quality", None)
                response = await client.post("/v1/images/generations", json=payload, headers=self._headers_for(key))

        if response.status_code in {400, 404, 405, 422}:
            err_msg = self._error_text(response).lower()
            if any(kw in err_msg for kw in ("not supported on /v1/images/generations", "not supported", "not found", "chat", "unknown model", "route")) or response.status_code in {404, 405}:
                chat_path, chat_err = await self._request_generate_chat(context, prompt, key, base)
                if chat_path or (chat_err and not chat_err.startswith("HTTP 404")):
                    return chat_path, chat_err, ""

        return await self._save_result(response)

    async def _request_generate_chat(self, context: MessageContext, prompt: str, key: str = "", base: str = "") -> tuple[str, str]:
        content_parts: list[dict[str, Any]] = [{"type": "text", "text": prompt}]
        payload = {
            "model": self._model_of(context),
            "messages": [{"role": "user", "content": content_parts}],
            "stream": False,
        }
        if self._size() != "auto":
            payload["size"] = self._size()
        if self._quality() != "auto":
            payload["quality"] = self._quality()
        async with httpx.AsyncClient(base_url=base or self._base_url(), timeout=self._timeout(), follow_redirects=False, transport=self._transport) as client:
            response = await client.post("/v1/chat/completions", json=payload, headers=self._headers_for(key))
        if response.status_code >= 400:
            data = self._json(response)
            message = str(data.get("error", {}).get("message") or data.get("message") or f"HTTP {response.status_code}")[:200] if isinstance(data, dict) else f"HTTP {response.status_code}"
            return "", f"生成失败：{message}"
        data = self._json(response)
        if not data and response.text:
            events: list[dict[str, Any]] = []
            for line in response.text.splitlines():
                candidate = line.strip()
                if candidate.startswith("data:"):
                    candidate = candidate[5:].strip()
                if not candidate or candidate == "[DONE]":
                    continue
                try:
                    item = json.loads(candidate)
                except (TypeError, ValueError):
                    continue
                if isinstance(item, dict):
                    events.append(item)
            if events:
                data = {"output": events}
        saved = await self._save_response_images(data)
        if saved[0]:
            return saved
        choices = data.get("choices") if isinstance(data, dict) else None
        content = ""
        if isinstance(choices, list) and choices and isinstance(choices[0], dict):
            message = choices[0].get("message") or {}
            if isinstance(message, dict):
                saved = await self._save_response_images(message.get("images"))
                if saved[0]:
                    return saved
                content = message.get("content") or ""
        if not content:
            keys = ", ".join(str(k) for k in data.keys()) if isinstance(data, dict) else "无"
            return "", f"生成失败：接口返回了空内容（字段：{keys[:240]}）。请确认当前模型支持图像生成。"
        return await self._save_chat_images(content)

    @staticmethod
    def _image_mime(data: bytes) -> tuple[str, str]:
        if data.startswith(b"\x89PNG\r\n\x1a\n"):
            return "image/png", "png"
        if data.startswith(b"\xff\xd8\xff"):
            return "image/jpeg", "jpg"
        if data[:4] == b"RIFF" and data[8:12] == b"WEBP":
            return "image/webp", "webp"
        if data[:6] in (b"GIF87a", b"GIF89a"):
            return "image/gif", "gif"
        return "application/octet-stream", "png"

    async def _request_edit(self, context: MessageContext, prompt: str, images: list[bytes], key: str = "", base: str = "") -> tuple[str, str]:
        """Run image editing through a conservative protocol cascade.

        ``auto`` tries the native Images Edits endpoint first, then the
        multimodal Chat Completions shape, and finally Responses + the
        ``image_generation`` tool.  A successful response is never retried;
        fallback only happens when the endpoint is unsupported or contains no
        usable image payload.
        """
        protocol = str(self._cfg("edit_protocol") or "auto").strip().lower()
        if protocol not in {"auto", "images", "chat", "responses"}:
            protocol = "auto"
        if protocol in {"auto", "images"}:
            path, error = await self._request_edit_images_api(context, prompt, images, key, base)
            if path or protocol == "images":
                return path, error
        if protocol in {"auto", "chat"}:
            path, error = await self._request_edit_chat(context, prompt, images, key, base)
            if path or protocol == "chat":
                return path, error
        return await self._request_edit_responses(context, prompt, images, key, base)

    async def _request_edit_images_api(self, context: MessageContext, prompt: str, images: list[bytes], key: str = "", base: str = "") -> tuple[str, str]:
        data: dict[str, str] = {"model": self._model_of(context), "prompt": prompt or "优化这张图片", "n": "1"}
        if self._size() != "auto":
            data["size"] = self._size()
        if self._quality() != "auto":
            data["quality"] = self._quality()
        if bool(self._cfg("prefer_b64_response")) and not self._b64_rejected:
            data["response_format"] = "b64_json"
        files = [("image[]", (f"input_{index}.png", image, "image/png")) for index, image in enumerate(images)]
        async with httpx.AsyncClient(base_url=base or self._base_url(), timeout=self._timeout(), follow_redirects=False, transport=self._transport) as client:
            response = await client.post("/v1/images/edits", data=data, files=files, headers=self._headers_for(key))
            if response.status_code == 400 and "response_format" in self._error_text(response).lower():
                data.pop("response_format", None)
                response = await client.post("/v1/images/edits", data=data, files=files, headers=self._headers_for(key))
        if response.status_code in {404, 405, 415, 422}:
            return "", ""
        path, error = await self._save_result(response)
        if path:
            return path, ""
        return "", error

    async def _request_edit_chat(self, context: MessageContext, prompt: str, images: list[bytes], key: str = "", base: str = "") -> tuple[str, str]:
        # 实测多数 new-api 中转站的 /v1/images/edits 解析 multipart 会报 NextPart: EOF，
        # 参考同类插件的写法改走 chat/completions：参考图以 data URL 形式随消息发送，
        # 生成结果从回复 content 的 markdown data URL / 图片链接中提取。
        content_parts: list[dict[str, Any]] = [{"type": "text", "text": prompt or "优化这张图片"}]
        for data in images:
            mime, _ = self._image_mime(data)
            if mime == "application/octet-stream":
                mime = "image/png"
            content_parts.append({
                "type": "image_url",
                "image_url": {"url": f"data:{mime};base64,{base64.b64encode(data).decode()}"},
            })
        payload = {
            "model": self._model_of(context),
            "messages": [{"role": "user", "content": content_parts}],
            "stream": False,
        }
        if self._size() != "auto":
            payload["size"] = self._size()
        if self._quality() != "auto":
            payload["quality"] = self._quality()
        async with httpx.AsyncClient(base_url=base or self._base_url(), timeout=self._timeout(), follow_redirects=False, transport=self._transport) as client:
            response = await client.post("/v1/chat/completions", json=payload, headers=self._headers_for(key))
        if response.status_code >= 400:
            data = self._json(response)
            message = str(data.get("error", {}).get("message") or data.get("message") or f"HTTP {response.status_code}")[:200] if isinstance(data, dict) else f"HTTP {response.status_code}"
            return "", f"生成失败：{message}"
        data = self._json(response)
        if not data and response.text:
            # Some gateways ignore ``stream=false`` for image-capable models
            # and still return JSON-lines/SSE.  Preserve decoded events so a
            # final image_generation result can be recovered.
            events: list[dict[str, Any]] = []
            for line in response.text.splitlines():
                candidate = line.strip()
                if candidate.startswith("data:"):
                    candidate = candidate[5:].strip()
                if not candidate or candidate == "[DONE]":
                    continue
                try:
                    item = json.loads(candidate)
                except (TypeError, ValueError):
                    continue
                if isinstance(item, dict):
                    events.append(item)
            if events:
                data = {"output": events}
        # A number of newer image-capable gateways return the generated image
        # in ``message.images``/structured ``content`` or even a top-level
        # ``data`` array, rather than Markdown text.  Try those typed payloads
        # before falling back to the legacy text extractor.
        saved = await self._save_response_images(data)
        if saved[0]:
            return saved
        choices = data.get("choices") if isinstance(data, dict) else None
        content = ""
        if isinstance(choices, list) and choices and isinstance(choices[0], dict):
            message = choices[0].get("message") or {}
            if isinstance(message, dict):
                saved = await self._save_response_images(message.get("images"))
                if saved[0]:
                    return saved
                content = message.get("content") or ""
        if not content:
            keys = ", ".join(str(key) for key in data.keys()) if isinstance(data, dict) else "无"
            return "", f"生成失败：接口返回了空内容（字段：{keys[:240]}）。请确认当前模型支持图像编辑。"
        return await self._save_chat_images(content)

    async def _request_edit_responses(self, context: MessageContext, prompt: str, images: list[bytes], key: str = "", base: str = "") -> tuple[str, str]:
        content: list[dict[str, str]] = [{"type": "input_text", "text": prompt or "优化这张图片"}]
        for image in images:
            mime, _ = self._image_mime(image)
            if mime == "application/octet-stream":
                mime = "image/png"
            content.append({"type": "input_image", "image_url": f"data:{mime};base64,{base64.b64encode(image).decode()}"})
        payload: dict[str, Any] = {
            "model": self._model_of(context),
            "input": [{"role": "user", "content": content}],
            "tools": [{"type": "image_generation", "action": "edit", "model": self._model_of(context)}],
        }
        async with httpx.AsyncClient(base_url=base or self._base_url(), timeout=self._timeout(), follow_redirects=False, transport=self._transport) as client:
            response = await client.post("/v1/responses", json=payload, headers=self._headers_for(key))
        if response.status_code in {404, 405, 415, 422}:
            return "", "生成失败：当前服务不支持图像编辑协议（images/chat/responses 均不可用）。"
        if response.status_code >= 400:
            return "", f"生成失败：{self._error_text(response) or f'HTTP {response.status_code}'}"
        data = self._json(response)
        saved = await self._save_response_images(data)
        if saved[0]:
            return saved
        return "", "生成失败：Responses 接口未返回图片内容。"

    @staticmethod
    def _image_candidates(value: Any) -> list[tuple[str, str]]:
        """Collect base64/data-URL/remote-URL image candidates recursively."""
        candidates: list[tuple[str, str]] = []
        if isinstance(value, dict):
            for key in (
                "b64_json", "partial_image_b64", "base64", "result", "data", "output",
                "response", "tool_calls", "arguments", "image_generation_call", "url",
                "image_url", "image", "output_text", "content_parts",
            ):
                if key in value:
                    candidates.extend(DrawImgPlugin._image_candidates(value[key]))
            if isinstance(value.get("content"), (list, dict, str)):
                candidates.extend(DrawImgPlugin._image_candidates(value["content"]))
            if isinstance(value.get("text"), str):
                candidates.extend(DrawImgPlugin._image_candidates(value["text"]))
        elif isinstance(value, list):
            for item in value:
                candidates.extend(DrawImgPlugin._image_candidates(item))
        elif isinstance(value, str):
            text = value.strip()
            if text[:1] in {"{", "["}:
                try:
                    parsed = json.loads(text)
                except (TypeError, ValueError):
                    parsed = None
                if parsed is not None:
                    return DrawImgPlugin._image_candidates(parsed)
            if text.startswith("data:image/") and ";base64," in text:
                candidates.append(("data", text))
            elif re.fullmatch(r"https?://[^\s<>\"']+", text, re.IGNORECASE):
                candidates.append(("url", text))
            elif len(text) > 64 and re.fullmatch(r"[A-Za-z0-9+/=\s]+", text):
                candidates.append(("b64", re.sub(r"\s+", "", text)))
        return candidates

    async def _save_response_images(self, value: Any) -> tuple[str, str]:
        output_dir = self.data_dir / "output"
        output_dir.mkdir(parents=True, exist_ok=True)
        for kind, payload in self._image_candidates(value):
            if kind == "url":
                path, error = await self._download_result(payload)
                if not error:
                    return str(path), ""
                continue
            raw = payload
            if kind == "data":
                try:
                    raw = payload.split(",", 1)[1]
                except IndexError:
                    continue
            try:
                decoded = base64.b64decode(raw, validate=False)
            except (ValueError, TypeError):
                continue
            if not decoded or not self._image_mime(decoded)[0].startswith("image/"):
                continue
            path = output_dir / f"dg_{uuid.uuid4().hex}.png"
            path.write_bytes(decoded)
            return str(path), ""
        return "", ""

    async def _save_chat_images(self, content: Any) -> tuple[str, str]:
        if not content:
            return "", "生成失败：接口未返回内容"
        saved = await self._save_response_images(content)
        if saved[0]:
            return saved
        text = content if isinstance(content, str) else json.dumps(content, ensure_ascii=False)
        matches = list(re.finditer(r"data:image/([a-zA-Z0-9.+-]+);base64,([A-Za-z0-9+/=\s]+)", text))
        output_dir = self.data_dir / "output"
        output_dir.mkdir(parents=True, exist_ok=True)
        for match in reversed(matches):
            payload = re.sub(r"\s+", "", match.group(2))
            try:
                raw = base64.b64decode(payload, validate=False)
            except (ValueError, TypeError):
                continue
            if len(raw) <= 0:
                continue
            path = output_dir / f"dg_{uuid.uuid4().hex}.png"
            path.write_bytes(raw)
            return str(path), ""
        for match in reversed(list(re.finditer(r"https?://[^\s)\"'<>]+", text, re.IGNORECASE))):
            path, download_error = await self._download_result(match.group(0))
            if download_error:
                continue
            return str(path), ""
        return "", "生成失败：回复中没有可用的图片内容"

    async def _save_result(self, response: httpx.Response) -> tuple[str, str, str]:
        if response.status_code >= 400:
            data = self._json(response)
            message = str(data.get("error", {}).get("message") or data.get("message") or f"HTTP {response.status_code}")[:200] if isinstance(data, dict) else f"HTTP {response.status_code}"
            return "", f"生成失败：{message}", ""
        data = self._json(response)
        items = data.get("data") if isinstance(data, dict) else None
        if not isinstance(items, list) or not items:
            return "", "生成失败：接口未返回图片", ""
        item = items[0]
        revised_prompt = str(item.get("revised_prompt") or "").strip()
        output_dir = self.data_dir / "output"
        output_dir.mkdir(parents=True, exist_ok=True)
        path = output_dir / f"dg_{uuid.uuid4().hex}.png"
        b64 = item.get("b64_json")
        if isinstance(b64, str) and b64:
            path.write_bytes(base64.b64decode(b64))
        else:
            url = str(item.get("url") or "")
            if not url:
                return "", "生成失败：接口未返回图片内容", ""
            path, download_error = await self._download_result(url)
            if download_error:
                return "", download_error, ""
        if path.stat().st_size <= 0:
            path.unlink(missing_ok=True)
            return "", "生成失败：图片内容为空", ""
        return str(path), "", revised_prompt

    @staticmethod
    def _json(response: httpx.Response) -> dict[str, Any]:
        try:
            data = response.json()
        except ValueError:
            return {}
        return data if isinstance(data, dict) else {}

    def _error_text(self, response: httpx.Response) -> str:
        data = self._json(response)
        if isinstance(data, dict):
            err = data.get("error")
            if isinstance(err, dict):
                return str(err.get("message") or "")
            return str(data.get("message") or "")
        return ""

    async def _download_result(self, url: str) -> tuple[Path, str]:
        output_dir = self.data_dir / "output"
        output_dir.mkdir(parents=True, exist_ok=True)
        path = output_dir / f"dg_{uuid.uuid4().hex}.png"
        headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36",
            "Referer": f"{self._base_url()}/",
        }
        last = ""
        for attempt in range(3):
            try:
                async with httpx.AsyncClient(timeout=20, follow_redirects=True) as client:
                    download = await client.get(url, headers=headers)
                download.raise_for_status()
                if not download.content:
                    raise httpx.HTTPError("empty body")
                path.write_bytes(download.content)
                return path, ""
            except httpx.HTTPStatusError as exc:
                last = f"HTTP {exc.response.status_code}"
            except httpx.HTTPError as exc:
                last = type(exc).__name__
            await asyncio.sleep(1 + attempt)
        return path, f"生成成功但图片下载失败（{last}，可能是图片链接已过期或被网络拦截），请重试或更换模型。"

    async def _download_image(self, url: str) -> tuple[bytes, str]:
        headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36"}
        try:
            async with httpx.AsyncClient(timeout=20, follow_redirects=True) as client:
                response = await client.get(url, headers=headers)
            response.raise_for_status()
        except httpx.HTTPError:
            return b"", "网络下载失败"
        if len(response.content) > 20 * 1024 * 1024:
            return b"", "图片超过 20MB"
        if response.status_code >= 400 or not response.content:
            return b"", f"HTTP {response.status_code}"
        return response.content, ""

    # ---------- media sending ----------

    async def _send_image(self, context: MessageContext, path: Path) -> bool:
        source = Path(path)
        if not source.is_file() or source.stat().st_size <= 0:
            return False
        scene = self._scene(context)
        media = self.media
        gateway = self.gateway
        if media is None or gateway is None:
            return False
        try:
            if scene in {"c2c", "group"}:
                request = await media.prepare(scene, context.conversation_id, 1, source)
                uploaded = await gateway.upload_media_file(request, source)
                file_info = uploaded.get("file_info") if isinstance(uploaded, dict) else None
                if not file_info:
                    return False
                await gateway.send_media(context.conversation_id, scene, file_info)
                return True
            if scene in {"channel", "guild_direct"}:
                await gateway.send_channel_media(context.conversation_id, scene, file_image=source.read_bytes())
                return True
            return False
        except Exception:
            return False

    def _mention_target(self, context: MessageContext) -> str:
        for item in context.mentions:
            if not isinstance(item, dict):
                continue
            identifier = str(item.get("id") or item.get("user_id") or item.get("openid") or "")
            if identifier and identifier not in {context.bot_id, "unknown_selfid"}:
                return f"{context.platform or 'unknown'}:{identifier}"
        mention = re.search(r"<@([A-Za-z0-9_-]{6,64})>", context.text or "")
        if mention:
            return f"{context.platform or 'unknown'}:{mention.group(1)}"
        return ""

    @staticmethod
    def _page_arg(rest: list[str]) -> int:
        try:
            return int(rest[0]) if rest else 1
        except (TypeError, ValueError):
            return 1

    # ---------- management page data (runtime.web /api/drawimg/*) ----------

    def _page_config_data(self) -> dict[str, Any]:
        return {
            "api_base_url": str(self._cfg("api_base_url") or ""),
            "api_key_set": bool(self._cfg("api_key")),
            "default_model": str(self._cfg("default_model") or ""),
            "image_size": str(self._cfg("image_size") or "auto"),
            "image_quality": str(self._cfg("image_quality") or "auto"),
            "max_prompt_chars": int(self._cfg("max_prompt_chars") or 4000),
            "credit_price_yuan": self._credit_price(),
            "test_credit_cost": self._test_credit_cost(),
            "test_daily_limit": int(self._cfg("test_daily_limit")),
            "na_token_quota": self._na_token_quota(),
            "newapi_group": str(self._cfg("newapi_group") or ""),
            "enable_group": self._group_enabled(),
            "same_cache_sec": int(self._cfg("same_cache_sec")),
            "history_keep": int(self._cfg("history_keep")),
            "style_presets": self._style_presets(),
            "credit_cost_rules": self._credit_rules(),
            "test_blacklist": self._test_blacklist(),
        }

    def _read_all_credits(self) -> dict[str, int]:
        res: dict[str, int] = {}
        primary_file = self.data_dir / "plugin-data" / "plugin.drawimg.service" / "credits.json"
        if not primary_file.is_file():
            primary_file = Path("./data/plugin-data/plugin.drawimg.service/credits.json")

        if primary_file.is_file():
            try:
                with open(primary_file, encoding="utf-8") as f:
                    data = json.load(f)
                    if isinstance(data, dict):
                        for k, v in data.items():
                            clean_k = _clean_user_key(k)
                            if clean_k:
                                try:
                                    # 同一用户的裸键与旧前缀键并存时取较大值（积分只能多不能少）
                                    res[clean_k] = max(res.get(clean_k, 0), int(v))
                                except (ValueError, TypeError):
                                    pass
                if res:
                    return res
            except Exception:
                pass

        for p in (
            self.data_dir / "plugins" / "plugin.drawimg.service" / "credits.json",
            self.data_dir / "drawimg" / "credits.json",
            Path("./data/plugins/plugin.drawimg.service/credits.json"),
            Path("./data/drawimg/credits.json"),
        ):
            if p.is_file():
                try:
                    with open(p, encoding="utf-8") as f:
                        data = json.load(f)
                        if isinstance(data, dict):
                            for k, v in data.items():
                                clean_k = _clean_user_key(k)
                                if clean_k and clean_k not in res:
                                    try:
                                        res[clean_k] = int(v)
                                    except (ValueError, TypeError):
                                        pass
                except Exception:
                    pass

        return res

    async def _authoritative_balances(self, keys: set[str] | None = None) -> dict[str, int]:
        """权威积分：通过 points 服务查询或缓存计算。"""
        if not self.points:
            return {}
        balances: dict[str, int] = {}
        if keys:
            for k in keys:
                try:
                    bal = await self.points.balance(k, POINT_TYPE)
                    balances[k] = int(bal)
                except Exception:
                    pass
        else:
            for k in list(self.usage.keys()):
                try:
                    bal = await self.points.balance(k, POINT_TYPE)
                    balances[k] = int(bal)
                except Exception:
                    pass
        return balances

    async def page_overview_data(self) -> dict[str, Any]:
        balances = await self._authoritative_balances()
        users_keys = set(_clean_user_key(k) for k in self.usage.keys()) | set(balances.keys())
        users_keys.discard("")
        config = {key: self._cfg(key) for key in CONFIG_DEFAULTS}
        config["style_presets"] = self._style_presets()
        config["credit_cost_rules"] = self._credit_rules()
        config["test_blacklist"] = self._test_blacklist()

        # Synchronize with plugin.drawimg.service config file if present
        for cfg_file in (
            self.data_dir / "plugin-config" / "plugin.drawimg.service" / "config.json",
            Path("./data/plugin-config/plugin.drawimg.service/config.json"),
        ):
            if cfg_file.is_file():
                try:
                    p_data = json.loads(cfg_file.read_text(encoding="utf-8"))
                    if isinstance(p_data, dict):
                        for k, v in p_data.items():
                            if k in config and (not config[k] or config[k] == CONFIG_DEFAULTS.get(k)):
                                config[k] = v
                        if p_data.get("api_key"):
                            config["api_key_set"] = True
                except Exception:
                    pass

        config["api_key"] = ""
        config["api_key_set"] = bool(config.get("api_key_set") or self._cfg("api_key"))
        config["api_configured"] = bool(config.get("api_base_url") and config.get("api_key_set"))
        return {
            "stats": {
                "users": len(users_keys),
                "total_credits": sum((await self._authoritative_balances()).values()),
                "total_history": 0,
            },
            "config": config,
            "management": {
                "permission": "plugin.dg.manage",
                "requests_per_minute": 20,
                "button_ttl_seconds": 300,
                "admin_source": "Runtime 角色与机器人主人",
            },
            "schema": {
                key: {"type": kind, "min": low, "max": high, "default": CONFIG_DEFAULTS[key]}
                for key, (kind, (low, high)) in CONFIG_SPEC.items()
            },
        }

    async def page_users(self) -> list[dict[str, Any]]:
        blacklist = set(self._test_blacklist())

        # Also load user_prefs and history to discover all active users
        prefs_map: dict[str, dict[str, Any]] = {}
        for p in (
            self.data_dir / "plugin-data" / "plugin.drawimg.service" / "user_prefs.json",
            self.data_dir / "plugins" / "plugin.drawimg.service" / "user_prefs.json",
            self.data_dir / "plugins" / "plugin.drawimg.service" / "data" / "user_prefs.json",
            Path("./data/plugin-data/plugin.drawimg.service/user_prefs.json"),
            Path("./data/plugins/plugin.drawimg.service/user_prefs.json"),
        ):
            if p.is_file():
                try:
                    with open(p, encoding="utf-8") as f:
                        data = json.load(f)
                        if isinstance(data, dict):
                            for k, v in data.items():
                                clean_k = _clean_user_key(k)
                                if clean_k and isinstance(v, dict):
                                    prefs_map.setdefault(clean_k, {}).update(v)
                except Exception:
                    pass

        # 历史用户发现：usage 键 + prefs 键 + 旧 credits 副本键（仅发现存在，
        # 余额一律以 point_accounts 权威账本为准）
        legacy_credit_keys = set(_clean_user_key(k) for k in self._read_all_credits().keys())
        all_keys = sorted(
            set(_clean_user_key(k) for k in self.usage.keys())
            | set(prefs_map.keys())
            | legacy_credit_keys
        )
        balances = await self._authoritative_balances(all_keys)
        users = []
        for key in all_keys:
            if not key or key.startswith("_"):
                continue
            entry = self.usage.get(key, {})
            if not isinstance(entry, dict):
                entry = {}
            pref = prefs_map.get(key, {})
            credits = int(balances.get(key, 0))
            model_name = str(pref.get("model") or entry.get("model") or self._default_model())
            users.append({
                "key": key,
                "credits": credits,
                "model": model_name,
                "source": "统一积分",
                "history": 0,
                "today": int(entry.get("test_daily", {}).get(self._today(), 0)) if isinstance(entry.get("test_daily"), dict) else 0,
                "blacklisted": key in blacklist,
            })
        return users[:200]

    async def page_adjust_credit(self, key: str, credits: int, mode: str) -> dict[str, Any]:
        raw_key = _clean_user_key(key)
        if not raw_key or len(raw_key) > 120:
            raise ValueError("用户编号无效")

        # 权威余额只认 point_accounts 账本；credits.json 已废弃不再读写
        current = 0
        if self.points:
            try:
                current = int(await self.points.balance(raw_key, POINT_TYPE))
            except Exception:
                pass

        if mode == "set":
            if credits < 0:
                raise ValueError("设置为负数无效")
            new_balance = credits
            delta = new_balance - current
        else:
            delta = credits
            new_balance = max(0, current + delta)

        if self.points and delta != 0:
            operation = f"drawimg-admin:{raw_key}:{int(time.time() * 1000)}:{uuid.uuid4().hex[:6]}"
            balance = await self.points.change(
                raw_key, str(delta), "drawimg.admin", "runtime.drawimg", operation, POINT_TYPE,
            )
            new_balance = int(balance)

        if raw_key not in self.usage or not isinstance(self.usage[raw_key], dict):
            self.usage[raw_key] = {}
        self.usage[raw_key]["credits"] = int(new_balance)
        return {"ok": True, "key": raw_key, "credits": float(new_balance)}

    async def page_set_user_model(self, key: str, model: str) -> dict[str, Any]:
        raw_key = str(key or "").strip()
        if not raw_key:
            raise ValueError("用户编号无效")
        clean_key = _clean_user_key(raw_key)
        model_name = str(model or "").strip()

        prefs_paths = [
            self.data_dir / "plugin-data" / "plugin.drawimg.service" / "user_prefs.json",
            self.data_dir / "plugins" / "plugin.drawimg.service" / "user_prefs.json",
            self.data_dir / "plugins" / "plugin.drawimg.service" / "data" / "user_prefs.json",
            self.data_dir / "user_prefs.json",
            Path("./data/plugin-data/plugin.drawimg.service/user_prefs.json"),
            Path("./data/plugins/plugin.drawimg.service/user_prefs.json"),
        ]
        for p in prefs_paths:
            try:
                p.parent.mkdir(parents=True, exist_ok=True)
                data = {}
                if p.is_file():
                    with open(p, encoding="utf-8") as f:
                        data = json.load(f)
                if not isinstance(data, dict):
                    data = {}
                if not model_name or model_name.lower() in {"reset", "default", "auto", "off", "重置", "默认"}:
                    for k in (clean_key, raw_key):
                        if k in data and isinstance(data[k], dict):
                            data[k].pop("model", None)
                else:
                    data.setdefault(clean_key, {})["model"] = model_name
                with open(p, "w", encoding="utf-8") as f:
                    json.dump(data, f, ensure_ascii=False, indent=2)
            except Exception:
                pass

        if clean_key in self.usage and isinstance(self.usage[clean_key], dict):
            if not model_name or model_name.lower() in {"reset", "default", "auto", "off", "重置", "默认"}:
                self.usage[clean_key].pop("model", None)
            else:
                self.usage[clean_key]["model"] = model_name
            self._save_usage()

        return {
            "ok": True,
            "key": clean_key,
            "model": model_name or self._default_model(),
            "is_default": not model_name or model_name.lower() in {"reset", "default", "auto", "off", "重置", "默认"},
        }

    async def page_save_config(self, payload: dict[str, Any]) -> dict[str, Any]:
        updates: dict[str, Any] = {}
        for key, raw in payload.items():
            if key not in CONFIG_SPEC:
                continue
            # A blank password-style field means “keep the current key”.
            if key == "api_key" and str(raw or "") == "" and self._cfg("api_key"):
                continue
            kind, (low, high) = CONFIG_SPEC[key]
            if kind == "bool":
                if isinstance(raw, bool):
                    value = raw
                elif str(raw).lower() in {"true", "1", "on", "开"}:
                    value = True
                elif str(raw).lower() in {"false", "0", "off", "关"}:
                    value = False
                else:
                    raise ValueError(f"{key} 的值无效（需要 bool）")
            elif kind == "int":
                try:
                    value = int(raw)
                except (TypeError, ValueError):
                    raise ValueError(f"{key} 必须是整数") from None
            elif kind == "float":
                try:
                    value = float(raw)
                except (TypeError, ValueError):
                    raise ValueError(f"{key} 必须是数字") from None
            elif key == "test_blacklist":
                if isinstance(raw, str):
                    try:
                        value = json.loads(raw)
                    except (TypeError, ValueError, json.JSONDecodeError):
                        raise ValueError("体验黑名单必须是合法 JSON 数组") from None
                else:
                    value = raw
                if not isinstance(value, list) or any(not isinstance(item, str) for item in value):
                    raise ValueError("体验黑名单必须是 JSON 字符串数组")
                value = [item.strip() for item in value if item.strip()]
            elif key in {"style_presets", "credit_cost_rules"}:
                if isinstance(raw, str):
                    raw_str = raw.strip()
                    if not raw_str:
                        value = {}
                    else:
                        try:
                            value = json.loads(raw_str)
                        except (TypeError, ValueError, json.JSONDecodeError):
                            # Accept the pre-JSON syntax once during upgrade, then
                            # persist the canonical JSON representation below.
                            value = {}
                            for chunk in re.split(r"[;；\n]+", raw_str):
                                if not chunk.strip():
                                    continue
                                parts = re.split(r"[:：]", chunk.strip(), maxsplit=1)
                                if len(parts) != 2 or not parts[0].strip():
                                    raise ValueError(f"{key} 必须是合法 JSON 对象或 key:value 格式") from None
                                value[parts[0].strip()] = parts[1].strip()
                elif isinstance(raw, dict):
                    value = raw
                else:
                    value = {}
                if not isinstance(value, dict):
                    raise ValueError(f"{key} 必须是 JSON 对象")
                normalized: dict[str, Any] = {}
                for name, item in value.items():
                    name = str(name).strip()
                    if not name:
                        raise ValueError(f"{key} 的键不能为空")
                    if key == "credit_cost_rules":
                        try:
                            item = int(item)
                        except (TypeError, ValueError):
                            raise ValueError(f"计费规则 {name} 的积分必须是正整数") from None
                        if item <= 0:
                            raise ValueError(f"计费规则 {name} 的积分必须是正整数")
                    else:
                        item = str(item).strip()
                        if not item:
                            raise ValueError(f"风格预设 {name} 的提示词不能为空")
                    normalized[name] = item
                value = normalized
            else:
                value = str(raw or "")
            if kind in {"int", "float"} and not low <= value <= high:
                raise ValueError(f"{key} 需在 {low}-{high} 之间")
            if kind == "str" and key not in {"test_blacklist", "style_presets", "credit_cost_rules"} and not low <= len(value) <= high:
                raise ValueError(f"{key} 长度需在 {low:.0f}-{high:.0f} 之间")
            updates[key] = value
        for key, value in updates.items():
            if key in {"test_blacklist", "style_presets", "credit_cost_rules"}:
                stored = json.dumps(value, ensure_ascii=False)
            elif isinstance(value, bool):
                stored = "true" if value else "false"
            elif isinstance(value, float):
                stored = repr(value)
            else:
                stored = str(value)
            await self.set_config(key, stored)

        # Also synchronize with plugin.drawimg.service config file
        for target_dir in [
            self.data_dir / "plugin-config" / "plugin.drawimg.service",
            self.data_dir / "plugins" / "plugin.drawimg.service" / "config",
            self.data_dir.parent / "plugins" / "plugin.drawimg.service" / "config",
            Path("./data/plugin-config/plugin.drawimg.service"),
            Path("./data/plugins/plugin.drawimg.service/config"),
        ]:
            try:
                target_dir.mkdir(parents=True, exist_ok=True)
                cfg_file = target_dir / "config.json"
                existing = {}
                if cfg_file.exists():
                    try:
                        existing = json.loads(cfg_file.read_text(encoding="utf-8"))
                    except Exception:
                        existing = {}
                existing.update(updates)
                cfg_file.write_text(json.dumps(existing, ensure_ascii=False, indent=2), encoding="utf-8")
            except Exception:
                pass

        return {"saved": True, "applied": updates, **await self.page_overview_data()}

    async def page_save_presets(self, style_presets: str | dict[str, Any]) -> dict[str, Any]:
        if isinstance(style_presets, dict):
            value = style_presets
        else:
            raw = str(style_presets or "").strip()
            try:
                value = json.loads(raw)
            except (TypeError, ValueError, json.JSONDecodeError):
                value = {}
                for chunk in re.split(r"[;；\n]+", raw):
                    parts = re.split(r"[:：]", chunk.strip(), maxsplit=1)
                    if len(parts) == 2 and parts[0].strip():
                        value[parts[0].strip()] = parts[1].strip()
        if not isinstance(value, dict) or any(not str(k).strip() or not str(v).strip() for k, v in value.items()):
            raise ValueError("风格预设必须是 JSON 对象，值不能为空")
        stored = json.dumps({str(k).strip(): str(v).strip() for k, v in value.items()}, ensure_ascii=False)
        if len(stored) > 100000:
            raise ValueError("预设内容过长")
        await self.set_config("style_presets", stored)
        return {"saved": True, "presets": self._style_presets()}

    async def page_blacklist(self, key: str, action: str) -> dict[str, Any]:
        key = _clean_user_key(str(key or "").strip())
        if not key or len(key) > 120:
            raise ValueError("用户编号无效")
        items = self._test_blacklist()
        if action == "add" and key not in items:
            items.append(key)
        elif action == "remove" and key in items:
            items.remove(key)
        else:
            raise ValueError("action 应为 add 或 remove")
        await self._set_blacklist(items)
        return {"ok": True, "blacklist": items}

    async def page_fetch_models(self, api_base: str = "", api_key: str = "") -> dict[str, Any]:
        base = (api_base or str(self._cfg("api_base_url") or "")).strip().rstrip("/")
        if base.casefold().endswith("/v1"):
            base = base[:-3].rstrip("/")
        key = (api_key or str(self._cfg("api_key") or "")).strip()

        if not base:
            raise ValueError("请先填写 API 地址（api_base_url）")

        headers = {}
        if key:
            headers["Authorization"] = f"Bearer {key}"

        image_keywords = (
            "image", "dall", "flux", "sd", "stable-diffusion", "midjourney",
            "imagen", "recraft", "ideogram", "cogview", "kolors",
            "paint", "draw", "art", "canvas", "diffusion", "kling",
            "sora", "luma", "runway", "seed", "mj", "sdxl", "sd-", "sd_", "wanx", "t2i"
        )

        models: list[str] = []
        async with httpx.AsyncClient(timeout=15.0) as client:
            resp = None
            err_msg = ""
            for url in (f"{base}/v1/models", f"{base}/models"):
                try:
                    resp = await client.get(url, headers=headers)
                    if resp.status_code == 200:
                        break
                except Exception as e:
                    err_msg = str(e)
                    continue
            if resp is None or resp.status_code != 200:
                code = resp.status_code if resp else "timeout"
                err_detail = ""
                if resp:
                    try:
                        err_detail = resp.text[:200]
                    except Exception:
                        pass
                raise ValueError(f"获取模型列表失败 (HTTP {code}): {err_detail or err_msg or '无法连接目标 API'}")

            data = resp.json()
            items = data.get("data", []) if isinstance(data, dict) else (data if isinstance(data, list) else [])
            for item in items:
                mid = str(item.get("id") if isinstance(item, dict) else item).strip()
                if mid and mid not in models:
                    models.append(mid)

        def is_image_model(m: str) -> bool:
            lower = m.lower()
            return any(kw in lower for kw in image_keywords)

        models.sort(key=lambda m: (0 if is_image_model(m) else 1, m.lower()))
        image_models = [m for m in models if is_image_model(m)]
        if not image_models:
            image_models = list(models)

        return {
            "ok": True,
            "models": models,
            "image_models": image_models,
            "total": len(models),
        }



    async def on_page_action(self, *args: Any, **kwargs: Any) -> Any:
        """Handle Action RPC calls from the Runtime management interface."""
        if len(args) >= 2:
            action_name, payload = args[0], args[1]
        elif len(args) == 1:
            if isinstance(args[0], dict) and "action" in args[0]:
                action_name = args[0].get("action")
                payload = args[0].get("payload", args[0])
            else:
                action_name = "save_config"
                payload = args[0]
        else:
            action_name = kwargs.get("action_name", "save_config")
            payload = kwargs.get("payload", {})

        action = str(action_name or "").strip()
        payload = payload if isinstance(payload, dict) else {}

        res = None
        if action in ("save_config", "config"):
            res = await self.page_save_config(payload)
        elif action in ("page_data", "data", "users", "page_users"):
            res = {"users": await self.page_users()}
        elif action in ("overview", "page_overview"):
            res = await self.page_overview_data()
        elif action in ("fetch_models", "models"):
            api_base = str(payload.get("api_base_url") or "")
            api_key = str(payload.get("api_key") or "")
            res = await self.page_fetch_models(api_base, api_key)
        elif action == "user_credit":
            key = str(payload.get("key") or "")
            credits = int(payload.get("credits") or 0)
            mode = str(payload.get("mode") or "add")
            res = await self.page_adjust_credit(key, credits, mode)
        elif action == "user_model":
            key = str(payload.get("key") or "")
            model = str(payload.get("model") or "")
            res = await self.page_set_user_model(key, model)
        elif action == "blacklist":
            key = str(payload.get("key") or "")
            act = str(payload.get("action") or "toggle")
            res = await self.page_blacklist(key, act)
        elif action == "presets":
            presets = payload.get("style_presets", {})
            res = await self.page_save_presets(presets)
        else:
            return {"ok": False, "error": f"未知 Action: {action}"}

        if isinstance(res, dict) and "ok" not in res:
            res["ok"] = True
        return res

async def setup(context: Any) -> DrawImgPlugin:
    plugin = DrawImgPlugin(context)
    if hasattr(context, "register_command"):
        for cmd in ("dg", "dgs", "dge", "dgse", "dgm", "dgsm", "dgt", "dgte", "dgtm"):
            context.register_command(cmd, plugin.command, category="drawimg", description="AI 绘图助手")
    if hasattr(context, "register_event_handler"):
        context.register_event_handler("*", plugin.on_event)
    if hasattr(context, "register_action"):
        for act in ("save_config", "page_data", "users", "page_users", "overview", "page_overview", "fetch_models", "user_credit", "user_model", "blacklist", "presets"):
            context.register_action(act, plugin.on_page_action)
    plugin._write_page_snapshot()
    logger.info("plugin.drawimg %s 初始化成功", PLUGIN_VERSION)
    return plugin
