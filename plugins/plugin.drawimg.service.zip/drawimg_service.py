"""🎨 绘图服务插件 (plugin.drawimg.service)
移植自 AstrBot 绘图服务版插件 (0.09 版本)，为 QQ Runtime 深度定制的原生无 Key 绘图服务系统。

主要功能：
- 管理员统一配置全局 OpenAI 格式画图 API (如 New API / One API / OpenAI / Midjourney 代理)。
- 普通用户无需自备 Key，按积分消耗生成图片。
- 支持 567 在线充值 (对接 runtime.pay 模块)。
- 全套 QQ 原生 Markdown + 交互键盘卡片操作。

支持指令：
- `/dg <提示词>`  — AI 文生图
- `/dge <提示词>`  — 单图改图（参考用户最近发送的图片）
- `/dgm <提示词>`  — 多图融合改图（参考最近 2~3 张图片）
- `/dg style [预设名]`  — 查看或切换风格预设（支持 /dg style add、/dg style rm、/dg style my、/dg style off）
- `/dg size [尺寸]`  — 切换生成尺寸（1024x1024, 1024x1792, 1792x1024, auto）
- `/dg quality [质量]`  — 切换画面质量（standard, hd, auto）
- `/dg models`  — 查看所有可用 AI 绘图模型列表
- `/dg model <名称>`  — 切换当前使用的默认生图模型
- `/dg status`  — 查询个人积分余额与偏好配置
- `/dg pay <积分>`  — 在线充值积分
- `/dg top`  — 查看用户积分排行（管理员）
- `/dg admin`  — 绘图服务管理员面板（管理员）
- `/dg give <@用户或OpenID> <积分>`  — 赠送或调整用户积分（管理员）
- `/dg rate <单价>`  — 设置积分单价（元/积分，管理员）
- `/dg cost <模型>:<积分>`  — 设置各模型计费价格（管理员）
- `/dg blacklist <add/del/list> <用户>`  — 生图服务黑名单（管理员）
"""

from __future__ import annotations

import asyncio
import base64
import inspect
import json
import logging
import os
import re
import socket
import struct
import sys
import time
import urllib.parse
import uuid
from pathlib import Path
from typing import Any

import aiohttp
import httpx

try:
    from PIL import Image, ImageDraw, ImageOps
except ImportError:
    Image = None  # type: ignore
    ImageDraw = None  # type: ignore
    ImageOps = None  # type: ignore

try:
    import numpy as np
except ImportError:
    np = None  # type: ignore

from runtime.models import Button, Card, MessageContext

logger = logging.getLogger("plugin.drawimg.service")

_DNS_CACHE: dict[str, tuple[float, str]] = {}
_NAMESERVERS = ("223.5.5.5", "223.6.6.6", "119.29.29.29", "192.168.1.1", "1.1.1.1")

def _resolve_dns_a(domain: str, ns: str = "223.5.5.5", timeout: float = 1.5) -> list[str]:
    tx_id = 0x1234
    flags = 0x0100
    header = struct.pack("!HHHHHH", tx_id, flags, 1, 0, 0, 0)
    qname = b"".join(bytes([len(p)]) + p.encode("ascii") for p in domain.split(".")) + b"\x00"
    question = qname + struct.pack("!HH", 1, 1)
    packet = header + question

    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    sock.settimeout(timeout)
    try:
        sock.sendto(packet, (ns, 53))
        data, _ = sock.recvfrom(512)
        ips = []
        if len(data) > 12:
            ancount = struct.unpack("!H", data[6:8])[0]
            offset = 12 + len(question)
            for _ in range(ancount):
                if offset >= len(data):
                    break
                if (data[offset] & 0xC0) == 0xC0:
                    offset += 2
                else:
                    while offset < len(data) and data[offset] != 0:
                        offset += data[offset] + 1
                    offset += 1
                if offset + 10 > len(data):
                    break
                atype, aclass, ttl, rdlength = struct.unpack("!HHIH", data[offset:offset+10])
                offset += 10
                if atype == 1 and rdlength == 4:
                    ips.append(socket.inet_ntoa(data[offset:offset+4]))
                offset += rdlength
        return ips
    finally:
        sock.close()

async def _resolve_domain_ip(domain: str) -> str:
    try:
        socket.inet_aton(domain)
        return domain
    except OSError:
        pass

    now = time.time()
    if domain in _DNS_CACHE:
        cached_t, cached_ip = _DNS_CACHE[domain]
        if now - cached_t < 600:
            return cached_ip

    for ns in _NAMESERVERS:
        try:
            loop = asyncio.get_running_loop()
            ips = await loop.run_in_executor(None, _resolve_dns_a, domain, ns, 1.5)
            if ips:
                _DNS_CACHE[domain] = (now, ips[0])
                return ips[0]
        except Exception:
            continue

    try:
        ip = await asyncio.get_running_loop().run_in_executor(None, socket.gethostbyname, domain)
        _DNS_CACHE[domain] = (now, ip)
        return ip
    except Exception:
        return domain

async def _prepare_target(url: str, headers: dict[str, str]) -> tuple[str, dict[str, str], str | None]:
    parsed = urllib.parse.urlparse(url)
    hostname = parsed.hostname or ""
    req_headers = dict(headers)
    if not hostname:
        return url, req_headers, None
    ip = await _resolve_domain_ip(hostname)
    if ip and ip != hostname:
        req_headers["Host"] = hostname
        port_str = f":{parsed.port}" if parsed.port else ""
        target_url = f"{parsed.scheme}://{ip}{port_str}{parsed.path}"
        if parsed.query:
            target_url += f"?{parsed.query}"
        return target_url, req_headers, hostname
    return url, req_headers, None

def _normalize_scene(context: MessageContext) -> str:
    raw = getattr(context, "scene", None) or getattr(context, "conversation_type", None) or "group"
    s = str(raw).lower().strip()
    if s in {"c2c", "private", "friend", "user", "dm", "c2c_message_create"}:
        return "c2c"
    if s in {"channel", "guild", "guild_direct"}:
        return "channel"
    return "group"

PLUGIN_VERSION = "0.8.5"


class ScopedRecentImages(dict):
    """支持以会话隔离键 (scene:scope:uid) 或裸 uid 进行查询与操作的兼容字典"""

    def __getitem__(self, key: str) -> list[tuple[float, str]]:
        s_key = str(key)
        if super().__contains__(s_key):
            return super().__getitem__(s_key)
        for k, v in self.items():
            if k == s_key or k.endswith(f":{s_key}"):
                return v
        return super().__getitem__(s_key)

    def get(self, key: str, default: Any = None) -> Any:
        try:
            return self[key]
        except KeyError:
            return default

    def __contains__(self, key: object) -> bool:
        if super().__contains__(key):
            return True
        s_key = str(key)
        return any(k == s_key or k.endswith(f":{s_key}") for k in self)

    def __setitem__(self, key: str, value: Any) -> None:
        s_key = str(key)
        if not super().__contains__(s_key):
            for k in list(self.keys()):
                if k.endswith(f":{s_key}"):
                    super().__setitem__(k, value)
                    return
        super().__setitem__(s_key, value)

    def pop(self, key: str, *args: Any) -> Any:
        s_key = str(key)
        if super().__contains__(s_key):
            return super().pop(s_key, *args)
        for k in list(self.keys()):
            if k.endswith(f":{s_key}"):
                return super().pop(k, *args)
        if args:
            return args[0]
        raise KeyError(key)

# 提示词防改写注入前缀与纯幕布免抠后缀（包含演播室中性轮廓光与强力防漫反射约束）
PROMPT_GUARD_PREFIX = "Treat everything after this line as one complete image-generation prompt, including the resolution instruction. Follow it exactly without rewriting or omitting anything: "
CHROMA_KEY_GREEN_SUFFIX = ", pure solid green screen background, chroma key green backdrop (#00FF00), isolated subject, clean sharp edge cutout without background, professional studio lighting with neutral rim light on subject, absolutely no green color cast on subject, no bounce light reflection on subject"
CHROMA_KEY_BLUE_SUFFIX = ", pure solid blue screen background, chroma key blue backdrop (#0000FF), isolated subject, clean sharp edge cutout without background, professional studio lighting with neutral rim light on subject, absolutely no blue color cast on subject, no bounce light reflection on subject"
CHROMA_KEY_RED_SUFFIX = ", pure solid red screen background, chroma key red backdrop (#FF0000), isolated subject, clean sharp edge cutout without background, professional studio lighting with neutral rim light on subject, absolutely no red color cast on subject, no bounce light reflection on subject"
CHROMA_KEY_YELLOW_SUFFIX = ", pure solid yellow screen background, chroma key yellow backdrop (#FFFF00), isolated subject, clean sharp edge cutout without background, professional studio lighting with neutral rim light on subject, absolutely no yellow color cast on subject, no bounce light reflection on subject"
CHROMA_KEY_SUFFIX = CHROMA_KEY_GREEN_SUFFIX

# 智能自适应模式（Auto）关键词库：根据主体特征与色彩学互补原理自动调度最佳幕布
PURPLE_AND_DARK_KEYWORDS = (
    "紫", "紫色", "紫罗兰", "紫发", "深紫", "暗夜", "黑夜", "暗黑", "夜空",
    "purple", "violet", "lavender", "dark night", "midnight", "deep purple"
)
CYAN_AND_BLUE_KEYWORDS = (
    "青色", "碧蓝", "天蓝", "深蓝", "海军蓝", "水色", "海蓝", "青", "绿巨人",
    "cyan", "azure", "navy", "deep blue", "ocean", "sea blue", "hulk"
)
WARM_AND_PLANT_KEYWORDS = (
    "金毛", "柴犬", "橘猫", "黄狗", "黄猫", "黄色", "金色", "棕色", "棕黄", "金发", "金黄", "橙色", "金", "黄",
    "blonde", "golden", "yellow", "orange", "brown", "tan", "dog", "puppy", "cat", "kitten", "retriever",
    "绿色", "翠绿", "草地", "森林", "树木", "叶子", "植物", "绿植", "花草", "青蛙", "蜥蜴",
    "green", "emerald", "plant", "tree", "leaf", "leaves", "grass", "forest", "frog"
)
WARM_AND_GREEN_KEYWORDS = WARM_AND_PLANT_KEYWORDS


def _resolve_chroma_mode(user_mode: str, prompt: str = "") -> str:
    """根据用户配置或提示词语义解析最终生效的幕布色彩（green、blue、red、yellow）。"""
    mode = (user_mode or "auto").lower().strip()
    if mode in {"green", "blue", "red", "yellow"}:
        return mode
    if mode == "auto":
        p_lower = (prompt or "").lower()
        for kw in PURPLE_AND_DARK_KEYWORDS:
            if kw in p_lower:
                return "yellow"
        for kw in CYAN_AND_BLUE_KEYWORDS:
            if kw in p_lower:
                return "red"
        for kw in WARM_AND_PLANT_KEYWORDS:
            if kw in p_lower:
                return "blue"
        return "green"
    return "green"


def _remove_chroma_background(image_path: Path, mode: str = "green") -> Path:
    """消除图片中的绿幕、蓝幕、红幕或黄幕背景，将其转换为带透明通道的 RGBA PNG。
    特性：
    1. 色彩纯度过滤 (Chroma Purity)：要求纯色能量占比，彻底避免金毛/浅色毛发因环境微弱反光被当成背景误杀；
    2. 边缘连通域泛洪保护 (Border Flood Fill Connectivity)：仅镂空与外边框直接连通的真实背景，坚决不在主体内打洞穿孔；
    3. 智能溢色压制与毛发修色 (De-spill Calibration)：主体边缘受漫反射影响的像素不降低透明度，而是修剪多余溢色，恢复自然毛色。
    """
    if not Image:
        return image_path
    try:
        with Image.open(image_path) as img:
            rgba = img.convert("RGBA")
            w, h = rgba.size

            # 步骤 1：利用降采样网格计算候选背景掩码并执行边缘泛洪连通性校验
            scale_factor = 4 if (w >= 512 and h >= 512) else 1
            mw = max(1, w // scale_factor)
            mh = max(1, h // scale_factor)
            mask_small = Image.new("L", (mw, mh), 0)

            if np is not None:
                arr = np.array(rgba)
                r = arr[:, :, 0].astype(int)
                g = arr[:, :, 1].astype(int)
                b = arr[:, :, 2].astype(int)
                total = r + g + b + 1e-5

                if mode == "blue":
                    pri = b
                    max_oth = np.maximum(r, g)
                    purity = b / total
                    diff = pri - max_oth
                    mask_candidate = (
                        (pri > 85)
                        & (purity > 0.46)
                        & (b > r * 1.30)
                        & (b > g * 1.30)
                        & (diff > 28)
                    )
                elif mode == "red":
                    pri = r
                    max_oth = np.maximum(g, b)
                    purity = r / total
                    diff = pri - max_oth
                    mask_candidate = (
                        (pri > 85)
                        & (purity > 0.46)
                        & (r > g * 1.30)
                        & (r > b * 1.30)
                        & (diff > 28)
                    )
                elif mode == "yellow":
                    min_rg = np.minimum(r, g)
                    max_rg = np.maximum(r, g)
                    diff = min_rg - b
                    purity = (r + g) / total
                    mask_candidate = (
                        (min_rg > 110)
                        & (b < 80)
                        & (purity > 0.78)
                        & (diff > 40)
                        & (min_rg > b * 1.80)
                        & ((max_rg - min_rg) < 65)
                        & ((min_rg / (max_rg + 1e-5)) > 0.65)
                    )
                else:  # green
                    pri = g
                    max_oth = np.maximum(r, b)
                    purity = g / total
                    diff = pri - max_oth
                    mask_candidate = (
                        (pri > 85)
                        & (purity > 0.46)
                        & (g > r * 1.30)
                        & (g > b * 1.30)
                        & (diff > 28)
                    )

                cand_img = Image.fromarray(mask_candidate.astype(np.uint8) * 255)
                small_cand = cand_img.resize((mw, mh), Image.Resampling.NEAREST)
                small_pix = small_cand.load()
            else:
                arr = None
                pixels = rgba.load()
                small_cand = mask_small
                small_pix = small_cand.load()
                for my in range(mh):
                    sy = min(h - 1, my * scale_factor)
                    for mx in range(mw):
                        sx = min(w - 1, mx * scale_factor)
                        pr, pg, pb, pa = pixels[sx, sy]
                        total = pr + pg + pb + 1e-5
                        if mode == "blue":
                            purity = pb / total
                            diff = pb - max(pr, pg)
                            if pb > 85 and purity > 0.46 and pb > pr * 1.30 and pb > pg * 1.30 and diff > 28:
                                small_pix[mx, my] = 255
                        elif mode == "red":
                            purity = pr / total
                            diff = pr - max(pg, pb)
                            if pr > 85 and purity > 0.46 and pr > pg * 1.30 and pr > pb * 1.30 and diff > 28:
                                small_pix[mx, my] = 255
                        elif mode == "yellow":
                            min_rg = min(pr, pg)
                            max_rg = max(pr, pg)
                            diff = min_rg - pb
                            purity = (pr + pg) / total
                            if (min_rg > 110 and pb < 80 and purity > 0.78 and diff > 40
                                and min_rg > pb * 1.80 and (max_rg - min_rg) < 65
                                and (min_rg / (max_rg + 1e-5)) > 0.65):
                                small_pix[mx, my] = 255
                        else:  # green
                            purity = pg / total
                            diff = pg - max(pr, pb)
                            if pg > 85 and purity > 0.46 and pg > pr * 1.30 and pg > pb * 1.30 and diff > 28:
                                small_pix[mx, my] = 255

            # 步骤 2：从画面四边外边缘向内泛洪填充 (Flood Fill)，仅标记外部连通背景为 128
            if ImageDraw is not None:
                step = max(1, mw // 64)
                for x in range(0, mw, step):
                    if small_pix[x, 0] == 255:
                        ImageDraw.floodfill(small_cand, (x, 0), 128)
                    if small_pix[x, mh - 1] == 255:
                        ImageDraw.floodfill(small_cand, (x, mh - 1), 128)
                for y in range(0, mh, step):
                    if small_pix[0, y] == 255:
                        ImageDraw.floodfill(small_cand, (0, y), 128)
                    if small_pix[mw - 1, y] == 255:
                        ImageDraw.floodfill(small_cand, (mw - 1, y), 128)
            else:
                small_cand = small_cand.point(lambda p: 128 if p == 255 else 0)

            conn_mask = small_cand.resize((w, h), Image.Resampling.NEAREST)

            # 步骤 3：应用透明通道与主体溢色校准 (Spill Suppression)
            if np is not None and arr is not None:
                conn_arr = np.array(conn_mask)
                is_bg_connected = (conn_arr == 128)

                if mode == "blue":
                    pri = b
                    max_oth = np.maximum(r, g)
                    diff = pri - max_oth
                    mask_solid = is_bg_connected & (pri > 85) & (diff > 25)
                    arr[mask_solid, 3] = 0

                    mask_spill = (~mask_solid) & (b > max_oth)
                    if np.any(mask_spill):
                        arr[mask_spill, 2] = max_oth[mask_spill].astype(np.uint8)
                elif mode == "red":
                    pri = r
                    max_oth = np.maximum(g, b)
                    diff = pri - max_oth
                    mask_solid = is_bg_connected & (pri > 85) & (diff > 25)
                    arr[mask_solid, 3] = 0

                    mask_spill = (~mask_solid) & (r > max_oth)
                    if np.any(mask_spill):
                        arr[mask_spill, 0] = max_oth[mask_spill].astype(np.uint8)
                elif mode == "yellow":
                    min_rg = np.minimum(r, g)
                    diff = min_rg - b
                    purity = (r + g) / total
                    mask_solid = is_bg_connected & (min_rg > 100) & (b < 90) & (purity > 0.75) & (diff > 30)
                    arr[mask_solid, 3] = 0

                    mask_spill = (~mask_solid) & (r > b * 1.30) & (g > b * 1.30) & (purity > 0.70)
                    if np.any(mask_spill):
                        arr[mask_spill, 0] = np.maximum(b[mask_spill], (r[mask_spill] * 0.85).astype(int)).astype(np.uint8)
                        arr[mask_spill, 1] = np.maximum(b[mask_spill], (g[mask_spill] * 0.85).astype(int)).astype(np.uint8)
                else:  # green
                    pri = g
                    max_oth = np.maximum(r, b)
                    diff = pri - max_oth
                    mask_solid = is_bg_connected & (pri > 85) & (diff > 25)
                    arr[mask_solid, 3] = 0

                    mask_spill = (~mask_solid) & (g > max_oth)
                    if np.any(mask_spill):
                        warm = mask_spill & (r > b)
                        arr[warm, 1] = np.minimum(g[warm], np.maximum((r[warm] * 0.9).astype(int), b[warm])).astype(np.uint8)
                        cool = mask_spill & (~warm)
                        arr[cool, 1] = max_oth[cool].astype(np.uint8)

                out_img = Image.fromarray(arr)
            else:
                pixels = rgba.load()
                conn_pix = conn_mask.load()
                for y in range(h):
                    for x in range(w):
                        pr, pg, pb, pa = pixels[x, y]
                        is_bg = (conn_pix[x, y] == 128)
                        total = pr + pg + pb + 1e-5

                        if mode == "blue":
                            max_oth = max(pr, pg)
                            diff = pb - max_oth
                            purity = pb / total
                            if is_bg and pb > 85 and purity > 0.46 and diff > 25:
                                pixels[x, y] = (pr, pg, pb, 0)
                            else:
                                if pb > max_oth:
                                    pixels[x, y] = (pr, pg, max_oth, pa)
                        elif mode == "red":
                            max_oth = max(pg, pb)
                            diff = pr - max_oth
                            purity = pr / total
                            if is_bg and pr > 85 and purity > 0.46 and diff > 25:
                                pixels[x, y] = (pr, pg, pb, 0)
                            else:
                                if pr > max_oth:
                                    pixels[x, y] = (max_oth, pg, pb, pa)
                        elif mode == "yellow":
                            min_rg = min(pr, pg)
                            diff = min_rg - pb
                            purity = (pr + pg) / total
                            if is_bg and min_rg > 100 and pb < 90 and purity > 0.75 and diff > 30:
                                pixels[x, y] = (pr, pg, pb, 0)
                            else:
                                if pr > pb * 1.30 and pg > pb * 1.30 and purity > 0.70:
                                    pixels[x, y] = (max(pb, int(pr * 0.85)), max(pb, int(pg * 0.85)), pb, pa)
                        else:  # green
                            max_oth = max(pr, pb)
                            diff = pg - max_oth
                            purity = pg / total
                            if is_bg and pg > 85 and purity > 0.46 and diff > 25:
                                pixels[x, y] = (pr, pg, pb, 0)
                            else:
                                if pg > max_oth:
                                    if pr > pb:
                                        new_g = min(pg, max(int(pr * 0.90), pb))
                                    else:
                                        new_g = min(pg, max_oth)
                                    pixels[x, y] = (pr, new_g, pb, pa)
                out_img = rgba

            output_dir = image_path.parent
            trans_path = output_dir / f"dg_trans_{uuid.uuid4().hex}.png"
            out_img.save(trans_path, format="PNG", optimize=True)
            if trans_path != image_path:
                image_path.unlink(missing_ok=True)
            return trans_path
    except Exception as e:
        logger.warning("Failed to remove chroma background (%s): %s", mode, e)
        return image_path


_remove_green_background = _remove_chroma_background


def _clamp_image_for_api(data: bytes, max_edge: int = 1536, max_bytes: int = 4 * 1024 * 1024) -> bytes:
    """参考图前置规整：纠正 EXIF 方向，限制最大长边，长宽对齐到 16 倍数，超大体积优化压缩。"""
    if not Image or not data:
        return data
    try:
        import io
        img = Image.open(io.BytesIO(data))
        if ImageOps:
            try:
                img = ImageOps.exif_transpose(img)
            except Exception:
                pass
        w, h = img.size
        scale = min(1.0, max_edge / max(w, h)) if max(w, h) > max_edge else 1.0
        target_w = int(w * scale)
        target_h = int(h * scale)
        target_w = max(16, (target_w // 16) * 16)
        target_h = max(16, (target_h // 16) * 16)
        if (target_w, target_h) != (w, h):
            img = img.resize((target_w, target_h), Image.Resampling.LANCZOS)
        buf = io.BytesIO()
        if img.mode in ("RGBA", "LA") or (img.mode == "P" and "transparency" in img.info):
            img.save(buf, format="PNG", optimize=True)
        else:
            img = img.convert("RGB")
            img.save(buf, format="PNG", optimize=True)
        out = buf.getvalue()
        if len(out) > max_bytes:
            buf = io.BytesIO()
            img.convert("RGB").save(buf, format="JPEG", quality=90, optimize=True)
            out = buf.getvalue()
        return out
    except Exception as e:
        logger.warning("Image pre-flight clamping failed: %s", e)
        return data

# 常见比例与尺寸映射（参考 gpt_image_playground）
COMMON_RATIOS: dict[str, dict[str, str]] = {
    "1:1": {"label": "1:1 正方", "size": "1024x1024"},
    "16:9": {"label": "16:9 横屏", "size": "1792x1024"},
    "9:16": {"label": "9:16 竖屏", "size": "1024x1792"},
    "4:3": {"label": "4:3 横板", "size": "1024x768"},
    "3:4": {"label": "3:4 竖板", "size": "768x1024"},
    "3:2": {"label": "3:2 相机横", "size": "1536x1024"},
    "2:3": {"label": "2:3 相机竖", "size": "1024x1536"},
    "21:9": {"label": "21:9 宽画幅", "size": "1280x544"},
    "auto": {"label": "自动尺寸", "size": "auto"},
}

def _format_size_display(size_val: str) -> str:
    s = (size_val or "auto").strip().lower()
    for ratio, info in COMMON_RATIOS.items():
        if s == ratio or s == info["size"].lower():
            return f"{ratio} ({info['label']})"
    return s

def _format_quality_display(quality_val: str) -> str:
    q = (quality_val or "auto").strip().lower()
    zh = {
        "auto": "自动 (auto)",
        "standard": "标准画质 (standard)",
        "hd": "高清模式 (hd)",
        "high": "高画质 (high)",
        "low": "低画质 (low)",
        "medium": "中画质 (medium)",
    }
    return zh.get(q, q)

def _resolve_api_size(size_str: str, model: str = "") -> tuple[str, str | None]:
    """返回用于 API 请求的标准尺寸与宽高比 (size_param, aspect_ratio_param)。

    自动将 16:9, 9:16, 1:1, 4:3, 3:4, 2:3, 3:2, 21:9 等 aspect_ratio 映射为标准的像素尺寸；
    若模型为 DALL-E 3，则自动收敛映射至官方支持的 1024x1024, 1792x1024, 1024x1792。
    """
    s = (size_str or "auto").strip().lower()
    if s == "auto":
        return "auto", None

    model_norm = str(model or "").strip().lower()
    is_dalle3 = "dall-e-3" in model_norm
    is_dalle2 = "dall-e-2" in model_norm

    # 1. 基础映射：比例转像素或直接识别像素
    pixel_size = ""
    ratio: str | None = None
    if s in COMMON_RATIOS:
        pixel_size = COMMON_RATIOS[s]["size"]
        ratio = s
    else:
        match = re.match(r"^(\d{2,4})[:x/](\d{2,4})$", s)
        if match:
            w_str, h_str = match.group(1), match.group(2)
            if int(w_str) >= 128 and int(h_str) >= 128:
                pixel_size = f"{w_str}x{h_str}"
                for r, info in COMMON_RATIOS.items():
                    if info["size"] == pixel_size:
                        ratio = r
                        break
                if not ratio:
                    ratio = f"{w_str}:{h_str}"
            else:
                r_key = f"{w_str}:{h_str}"
                if r_key in COMMON_RATIOS:
                    pixel_size = COMMON_RATIOS[r_key]["size"]
                    ratio = r_key
                else:
                    ratio = r_key
                    w, h = float(w_str), float(h_str)
                    if w > h:
                        pixel_size = "1792x1024"
                    elif h > w:
                        pixel_size = "1024x1792"
                    else:
                        pixel_size = "1024x1024"
        else:
            pixel_size = s

    # 2. 针对特定官方模型的标准尺寸严格规范化
    if is_dalle3 and pixel_size != "auto":
        px_match = re.match(r"^(\d+)x(\d+)$", pixel_size)
        if px_match:
            w, h = int(px_match.group(1)), int(px_match.group(2))
            if w > h:
                pixel_size = "1792x1024"
            elif h > w:
                pixel_size = "1024x1792"
            else:
                pixel_size = "1024x1024"
        else:
            pixel_size = "1024x1024"
    elif is_dalle2 and pixel_size != "auto":
        pixel_size = "1024x1024"

    return pixel_size, ratio

PROTOCOL_AUTO = "auto"
PROTOCOL_EXTRA_BODY = "openai_extra_body"
PROTOCOL_STANDARD_EDITS = "openai_edits"
PROTOCOL_CHAT = "chat_completions"
PROTOCOL_TEXT_ONLY = "text_only"
PROTOCOL_CUSTOM = "custom"

PROTOCOL_LABELS = {
    PROTOCOL_AUTO: "智能探测（自动尝试并记忆）",
    PROTOCOL_EXTRA_BODY: "扩展 JSON（POST /v1/images/generations + extra_body.image，如 Agnes）",
    PROTOCOL_STANDARD_EDITS: "标准 OpenAI 表单（POST /v1/images/edits multipart 表单）",
    PROTOCOL_CHAT: "多模态视觉会话（POST /v1/chat/completions messages）",
    PROTOCOL_TEXT_ONLY: "纯文生图专用（禁止改图，友好提示）",
    PROTOCOL_CUSTOM: "自定义端点（支持指定自定义 URL/路径与请求载荷格式）",
}

BUILTIN_PROTOCOL_RULES = [
    ("agnes-image-*", PROTOCOL_EXTRA_BODY, "Agnes AI 系列图像模型"),
    ("dall-e-3", PROTOCOL_TEXT_ONLY, "DALL-E 3 官方仅支持文生图"),
    ("dall-e-2", PROTOCOL_STANDARD_EDITS, "DALL-E 2 支持标准表单编辑"),
]

def _match_pattern(pattern: str, text: str) -> bool:
    import fnmatch
    p = (pattern or "").strip().lower()
    t = (text or "").strip().lower()
    if not p or p == "*" or p == t:
        return True
    return fnmatch.fnmatch(t, p)

DEFAULT_CONFIG = {
    "api_base_url": "",
    "api_key": "",
    "default_model": "agnes-image-2.5-flash",
    "image_size": "auto",
    "image_quality": "auto",
    "enable_group": True,
    "test_credit_cost": 1,
    "credit_cost_rules": "",
    "model_endpoint_rules": "",
    "credit_price_yuan": 0.1,
    "cooldown_sec": 10,
    "max_prompt_chars": 4000,
    "style_presets": "动漫:动漫风格,赛璐璐,鲜艳色彩;写实:超写实风格,照片级细节,自然光影;赛博朋克:赛博朋克风格,霓虹灯,未来都市;古风:国风水墨,中国传统古风,唯美意境",
    "same_cache_sec": 0,
    "test_daily_limit": 0,
    "test_blacklist": [],
    "prefer_b64_response": True,
    "edit_image_ttl_min": 10,
    "request_timeout_sec": 180,
    "models_cache_ttl_sec": 600,
    "network_error_message": "生图服务当前不可用，请稍后重试。",
}

HELP_TEXT = (
    "【🎨 绘图服务使用指南】\n"
    "1. 发送 /dg models 查看可用生图模型；\n"
    "2. 发送 /dg style 选择画风预设；\n"
    "3. 发送 /dg <提示词> 即可开始文生图创作；\n"
    "4. 先在聊天中发图，再发送 /dge <修改词> 进行单图改图；连发 2~3 张图后用 /dgm <融合词> 进行多图融合改图；\n"
    "5. 积分不足时发送 /dg pay <数量> 在线充值，/dg status 查看当前积分与配置。"
)

GUIDE_TEXT = (
    "【开始使用】\n"
    "1. 先用 /dg models 查看并选择模型；\n"
    "2. 用 /dg style 选择风格预设（可选）；\n"
    "3. 发送 /dg <提示词> 开始文生图；\n"
    "4. 先发图片，再发送 /dge <提示词> 编辑单图；连发 2~3 张图后用 /dgm <提示词> 编辑多图。\n\n"
    "积分不足时使用 /dg pay <数量> 充值。/dg status 查看余额与当前设置。"
)


def _btn(
    label: str,
    command: str,
    *,
    fill: bool = False,
    action_type: int | None = None,
    permission: int | None = None,
    expires_after_seconds: int = 600,
    click_limit: int | None = 30,
    style: str = "normal",
) -> Button:
    cmd = command.strip()
    is_input = fill or command.endswith(" ")
    if action_type is None:
        action_type = 2 if is_input else 1
    enter = False if action_type == 2 else True

    if permission is None:
        if any(cmd.startswith(p) for p in ("/dg admin", "/dg rate", "/dg cost", "/dg give", "/dg blacklist", "/dg top", "/dg config")):
            permission = 1
        else:
            permission = 2

    return Button(
        label[:10],
        command,
        style=style,
        action_type=action_type,
        enter=enter,
        permission=permission,
        click_limit=click_limit,
        expires_after_seconds=expires_after_seconds,
        expired_message="此按钮已过期，请重新打开菜单。",
        permission_message="此操作需要管理员权限。" if permission == 1 else "此操作为专属用户操作。",
    )


def _clean_user_id(raw: Any) -> str:
    s = str(raw or "").strip()
    if not s or s.startswith("_") or s in {"default_user", "null", "undefined"}:
        return "default_user"
    if s.startswith("<@") and s.endswith(">"):
        s = s[2:-1]
        if s.startswith("!") or s.startswith("&"):
            s = s[1:]
    s = s.lstrip("@").strip()
    if s.startswith("qq_official:"):
        s = s[len("qq_official:"):].strip()
    return s or "default_user"


def _extract_mention_target(context: MessageContext) -> str:
    for item in getattr(context, "mentions", []):
        if not isinstance(item, dict):
            continue
        identifier = str(item.get("id") or item.get("user_id") or item.get("openid") or "").strip()
        bot_id = str(getattr(context, "bot_id", "") or "unknown_selfid").strip()
        if identifier and identifier != bot_id:
            return _clean_user_id(identifier)
    text = str(getattr(context, "text", "") or "")
    m = re.search(r"<@!?([A-Za-z0-9_-]{6,64})>", text)
    if m:
        return _clean_user_id(m.group(1))
    return ""


def _scan_component_or_dict(node: Any, found: list[str], depth: int = 0) -> None:
    if depth > 6 or node is None:
        return
    if isinstance(node, str):
        patterns = (
            r"https?://[^\s\"'<>]+?\.(?:jpg|jpeg|png|webp|gif|bmp)(?:\?[^\s\"'<>]*)?",
            r"https?://multimedia\.nt\.qq\.com\.cn/download\?[^\s\"'<>]+",
            r"https?://[a-zA-Z0-9.-]*qpic\.cn/[^\s\"'<>]+",
        )
        for pat in patterns:
            for match in re.findall(pat, node, re.IGNORECASE):
                if match not in found:
                    found.append(match)
        return
    if isinstance(node, (list, tuple)):
        for item in node:
            _scan_component_or_dict(item, found, depth + 1)
        return
    if isinstance(node, dict):
        url = node.get("url") or node.get("src") or node.get("file_url") or node.get("image_url")
        content_type = str(node.get("content_type") or node.get("type") or "").lower()
        filename = str(node.get("filename") or node.get("name") or "").lower()
        if isinstance(url, str) and url.startswith("http"):
            is_img = (
                content_type.startswith("image/")
                or any(filename.endswith(ext) for ext in (".jpg", ".jpeg", ".png", ".webp", ".gif", ".bmp"))
                or any(node.get(k) for k in ("width", "height", "term", "fileid"))
                or "multimedia.nt.qq.com.cn" in url
                or "qpic.cn" in url
                or re.search(r"\.(?:jpg|jpeg|png|webp|gif|bmp)(?:\?|$)", url, re.I)
                or not content_type
            )
            if is_img and url not in found:
                found.append(url)
        for k, v in node.items():
            if k not in {"url", "src", "file_url", "image_url"}:
                _scan_component_or_dict(v, found, depth + 1)
        return

    for attr in ("url", "file", "path", "attachments", "raw_payload", "text", "message_obj", "raw_message"):
        val = getattr(node, attr, None)
        if val is not None and val != "":
            if isinstance(val, str) and val.startswith("http") and val not in found:
                found.append(val)
            else:
                _scan_component_or_dict(val, found, depth + 1)


def extract_image_urls(context: Any) -> list[str]:
    found: list[str] = []
    attachments = getattr(context, "attachments", None)
    if attachments:
        _scan_component_or_dict(attachments, found, depth=0)
    text = getattr(context, "text", None)
    if text:
        _scan_component_or_dict(text, found, depth=0)
    raw = getattr(context, "raw_payload", None)
    if raw:
        _scan_component_or_dict(raw, found, depth=0)
    return found


def _format_drawimg_error(err: str) -> str:
    """脱敏 IP/地址信息并将常见生图错误本地化为友好中文返回。"""
    if not err:
        return "生成失败：服务未返回具体错误信息。"
    text = str(err).strip()

    # 清理多重“生成失败：”与提醒前缀
    text = re.sub(r"^(?:(?:🎨\s*)?生图提醒[：:]\s*)*", "", text)
    text = re.sub(r"^(?:生成失败[：:]\s*)+", "", text)

    text_lower = text.lower()

    # 0. 模型不支持生图端点或上游服务报错
    if "not supported on /v1/images" in text_lower or "is not supported on /v1/images" in text_lower:
        return "生成失败：当前所选模型未在上游开放生图端点（/v1/images/generations），请发送 /dg models 查看并切换至支持生图的模型。"
    if "quota_exhausted" in text_lower or "exhausted your capacity" in text_lower or "resource_exhausted" in text_lower:
        return "生成失败：上游模型服务配额已耗尽 (QUOTA_EXHAUSTED)，请稍后等待官方配额重置或切换至其他可用模型。"
    if "cloudcode-pa" in text_lower or ("eof" in text_lower and any(k in text_lower for k in ("gemini", "google", "cloudcode"))):
        return "生成失败：上游 Gemini 服务连接中断 (EOF)，可能是模型出图超时或上游断开连接，请稍后重试或切换其他模型。"

    # 1. 常见错误模式精准中文化转译
    # A. 遇到 EOF / 意外断开 / 连接重置
    if "connection reset by peer" in text_lower or "connection reset" in text_lower:
        return "生成失败：上游生图服务连接被重置 (Connection Reset)，可能上游模型服务器临时繁忙或网络抖动，请稍后重试。"
    if "queue is full" in text_lower or "queue full" in text_lower:
        return "生成失败：上游生图/改图任务队列已满，模型服务器处理繁忙，请稍等 1-2 分钟后再试。"
    if re.search(r"\bEOF\b", text, re.I):
        return "生成失败：上游生图模型连接意外中断 (EOF)，请稍后重试或更换模型。"

    # B. 密钥/渠道不可用 (auth_unavailable / no auth available)
    if "auth_unavailable" in text_lower or "no auth available" in text_lower:
        if "tls handshake timeout" in text_lower or "timeout" in text_lower:
            return "生成失败：生图服务渠道或密钥不可用 (auth_unavailable，上游握手超时)，请联系管理员检查配置。"
        return "生成失败：生图服务未配置可用渠道或密钥不可用 (auth_unavailable)，请联系管理员检查配置。"

    # C. TLS 握手超时 / 网络超时
    if "tls handshake timeout" in text_lower:
        return "生成失败：连接上游服务网络握手超时，可能由于海外节点波动或代理中断，请稍后重试。"

    # D. 连接被拒绝
    if "connection refused" in text_lower or "connect: connection refused" in text_lower:
        return "生成失败：无法连接到上游生图服务节点，服务可能未就绪，请稍后重试。"

    # E. 回复中没有可用的图片内容
    if "回复中没有可用的图片内容" in text or "未返回图片内容" in text:
        return "生成失败：模型已返回文本回复但未提取到可用图片，建议微调提示词或确认所选模型支持绘图。"

    # F. 接口返回空内容
    if "接口返回了空内容" in text:
        return "生成失败：上游模型未返回有效图像数据，请确认当前配置的模型是否支持图像生成。"

    # G. 额度不足
    if "insufficient_quota" in text_lower or ("quota" in text_lower and "exceeded" in text_lower):
        return "生成失败：上游生图服务额度已耗尽，请联系管理员处理。"

    # H. 内容违规过滤
    if any(k in text_lower for k in ("content_policy_violation", "safety system", "moderation", "sensitive")):
        return "生成失败：生图提示词可能触发了上游安全合规审查，生成被驳回，请调整提示词后重试。"

    # I. HTTP 401 / 403 鉴权
    if "401" in text and any(k in text_lower for k in ("unauthorized", "token", "key")):
        return "生成失败：生图 API 密钥无效或未授权 (HTTP 401)，请联系管理员更新配置。"

    # J. 上游无可用服务节点 (no available server)
    if "no available server" in text_lower:
        return "生图/改图失败：上游接口暂无可用的服务节点 (no available server)。若您正在执行改图 (/dge)，通常表示当前生图模型仅支持文生图 (/dg)，上游未开放图生图/改图节点。"

    # 2. 通用脱敏处理：遮蔽 IP 地址和接口 URL
    # 脱敏 HTTP/HTTPS IP 链接
    desensitized = re.sub(
        r"https?://(?:\d{1,3}\.){3}\d{1,3}(?::\d+)?(?:/[^\s\"':;,]*)?",
        "[服务节点]",
        text,
    )
    # 脱敏纯 IP[:端口]
    desensitized = re.sub(
        r"\b(?:\d{1,3}\.){3}\d{1,3}(?::\d+)?\b",
        "[服务节点]",
        desensitized,
    )
    # 脱敏公网域名与上游 URL
    desensitized = re.sub(
        r"https?://[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}(?::\d+)?(?:/[^\s\"':;,]*)?",
        "[上游接口]",
        desensitized,
    )

    return f"生成失败：{desensitized}"


class DrawImgServicePlugin:
    def __init__(self, context: Any) -> None:
        self.context = context
        self.is_isolated = "pytest" in sys.modules or "tmp" in str(getattr(context, "data_dir", ""))
        default_data_dir = Path("./data/plugin-data/plugin.drawimg.service")
        default_config_dir = Path("./data/plugin-config/plugin.drawimg.service")
        self.perm_dir = default_data_dir if not self.is_isolated else Path(getattr(context, "data_dir", default_data_dir))
        self.perm_dir.mkdir(parents=True, exist_ok=True)

        self.config_dir = Path(getattr(context, "config_dir", default_config_dir if not self.is_isolated else self.perm_dir))
        self.data_dir = Path(getattr(context, "data_dir", self.perm_dir))
        self.config_dir.mkdir(parents=True, exist_ok=True)
        self.data_dir.mkdir(parents=True, exist_ok=True)

        self.config_path = self.config_dir / "config.json"
        self.credits_path = self.data_dir / "credits.json"
        self.user_prefs_path = self.data_dir / "user_prefs.json"
        self.history_path = self.data_dir / "history.json"

        # Load and merge credits from all known persistent files
        self.credits: dict[str, int] = {}
        candidate_credit_paths = [self.credits_path, self.perm_dir / "credits.json"]
        if not self.is_isolated:
            candidate_credit_paths.extend([
                Path("./data/plugin-data/plugin.drawimg.service/credits.json"),
                Path("./data/plugins/plugin.drawimg.service/credits.json"),
                Path("./data/plugins/plugin.drawimg.service/data/credits.json"),
                Path("./data/drawimg/credits.json"),
            ])
        # Clean up legacy files accidentally written to plugin installation code directory
        if not self.is_isolated:
            legacy_code_dir = Path("./data/plugins/plugin.drawimg.service")
            if legacy_code_dir.exists() and legacy_code_dir.is_dir():
                for legacy_name in ("credits.json", "user_prefs.json", "config.json", "history.json", "recent_images.json"):
                    lp = legacy_code_dir / legacy_name
                    if lp.exists() and lp.is_file():
                        try:
                            lp.unlink()
                        except Exception:
                            pass
                for sub in ("data", "config"):
                    sub_p = legacy_code_dir / sub
                    if sub_p.exists() and sub_p.is_dir():
                        try:
                            import shutil
                            shutil.rmtree(sub_p, ignore_errors=True)
                        except Exception:
                            pass
        for p in candidate_credit_paths:
            loaded = self._load_json(p, {})
            if isinstance(loaded, dict):
                for k, v in loaded.items():
                    if k not in self.credits or self.credits[k] == 0:
                        try:
                            self.credits[str(k)] = int(v)
                        except (ValueError, TypeError):
                            pass

        # Load and merge config from all known persistent files & SQLite
        self.config: dict[str, Any] = dict(DEFAULT_CONFIG)
        if not self.is_isolated:
            try:
                db_file = Path("data/runtime.sqlite3")
                if db_file.exists():
                    import sqlite3
                    with sqlite3.connect(str(db_file), timeout=2.0) as conn:
                        cur = conn.cursor()
                        cur.execute("SELECT key, value FROM settings WHERE key LIKE 'dg.%'")
                        for k, v in cur.fetchall():
                            short_k = k[3:]
                            if short_k and v not in (None, ""):
                                self.config[short_k] = v
            except Exception:
                pass

        candidate_config_paths = [self.config_path, self.perm_dir / "config.json"]
        if not self.is_isolated:
            candidate_config_paths.extend([
                Path("./data/plugin-config/plugin.drawimg.service/config.json"),
                Path("./data/plugins/plugin.drawimg.service/config.json"),
                Path("./data/plugins/plugin.drawimg.service/config/config.json"),
            ])
        for p in candidate_config_paths:
            loaded = self._load_json(p, {})
            if isinstance(loaded, dict):
                for k, v in loaded.items():
                    if v not in (None, ""):
                        self.config[k] = v

        # Load and merge user_prefs
        self.user_prefs: dict[str, Any] = {}
        candidate_pref_paths = [self.user_prefs_path, self.perm_dir / "user_prefs.json"]
        if not self.is_isolated:
            candidate_pref_paths.extend([
                Path("./data/plugin-data/plugin.drawimg.service/user_prefs.json"),
                Path("./data/plugins/plugin.drawimg.service/user_prefs.json"),
                Path("./data/plugins/plugin.drawimg.service/data/user_prefs.json"),
            ])
        for p in candidate_pref_paths:
            loaded = self._load_json(p, {})
            if isinstance(loaded, dict):
                for k, v in loaded.items():
                    if k not in self.user_prefs:
                        self.user_prefs[k] = v

        # Only retain _processed_orders from history (for payment idempotency), no user generation history
        self.history: dict[str, Any] = {}
        candidate_hist_paths = [self.history_path, self.perm_dir / "history.json"]
        if not self.is_isolated:
            candidate_hist_paths.extend([
                Path("./data/plugin-data/plugin.drawimg.service/history.json"),
                Path("./data/plugins/plugin.drawimg.service/history.json"),
                Path("./data/plugins/plugin.drawimg.service/data/history.json"),
            ])
        for p in candidate_hist_paths:
            loaded = self._load_json(p, {})
            if isinstance(loaded, dict) and "_processed_orders" in loaded:
                self.history["_processed_orders"] = loaded["_processed_orders"]
                break

        self.recent_images: ScopedRecentImages = ScopedRecentImages()
        self.recent_images_path = self.data_dir / "recent_images.json"
        self._load_recent_images()
        self.same_cache: dict[str, tuple[float, str]] = {}
        self.models_cache: tuple[float, list[str]] | None = None
        self.last_action_time: dict[str, float] = {}
        self.pending_pay_orders_file = self.data_dir / "pending_orders.json"
        loaded_pending = self._load_json(self.pending_pay_orders_file, {})
        self.pending_pay_orders: dict[str, dict[str, Any]] = loaded_pending if isinstance(loaded_pending, dict) else {}
        self.learned_protocols_path = self.data_dir / "learned_protocols.json"
        loaded_protocols = self._load_json(self.learned_protocols_path, {})
        self.learned_protocols: dict[str, dict[str, Any]] = loaded_protocols if isinstance(loaded_protocols, dict) else {}
        self._b64_rejected = False

        try:
            pay_api = getattr(self.context, "builtin", lambda name: None)("runtime.pay")
            if pay_api and hasattr(pay_api, "subscribe"):
                res = pay_api.subscribe("plugin.drawimg.service", self.on_payment_success)
                if inspect.isawaitable(res):
                    try:
                        import asyncio
                        loop = asyncio.get_running_loop()
                        if loop.is_running():
                            loop.create_task(res)
                    except RuntimeError:
                        if hasattr(res, "close"):
                            res.close()
        except Exception:
            pass

        try:
            from .credit_service import set_credit_service
            set_credit_service(self)
        except Exception:
            pass

    def _load_json(self, path: Path, default: Any) -> Any:
        try:
            if path.exists():
                return json.loads(path.read_text(encoding="utf-8"))
        except Exception as e:
            logger.warning("Failed to load JSON from %s: %s", path, e)
        return default.copy() if isinstance(default, (dict, list)) else default

    def _save_json(self, path: Path, data: Any) -> None:
        try:
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
        except Exception as e:
            logger.error("Failed to save JSON to %s: %s", path, e)
        # Also backup to permanent storage folders in data/ so re-uploading ZIP never loses data
        if not self.is_isolated:
            try:
                fname = path.name
                target_paths = [
                    self.perm_dir / fname,
                    Path(f"./data/plugin-data/plugin.drawimg.service/{fname}"),
                    Path(f"./data/plugin-config/plugin.drawimg.service/{fname}"),
                ]
                for tp in target_paths:
                    if tp.resolve() == path.resolve():
                        continue
                    try:
                        tp.parent.mkdir(parents=True, exist_ok=True)
                        tp.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
                    except Exception:
                        pass
            except Exception:
                pass

    def _save_pending_orders(self) -> None:
        try:
            self._save_json(self.pending_pay_orders_file, self.pending_pay_orders)
        except Exception as e:
            logger.warning("Failed to save pending orders: %s", e)

    def _load_recent_images(self) -> None:
        try:
            candidate_paths = [self.recent_images_path, self.perm_dir / "recent_images.json"]
            if not self.is_isolated:
                candidate_paths.extend([
                    Path("./data/plugin-data/plugin.drawimg.service/recent_images.json"),
                    Path("./data/plugins/plugin.drawimg.service/recent_images.json"),
                    Path("./data/plugins/plugin.drawimg.service/data/recent_images.json"),
                ])
            now = time.time()
            ttl = max(1, int(self._get_cfg("edit_image_ttl_min", 10) or 10)) * 60
            for p in candidate_paths:
                loaded = self._load_json(p, {})
                if isinstance(loaded, dict):
                    for uid, items in loaded.items():
                        if isinstance(items, list):
                            fresh = [(float(t), str(u)) for (t, u) in items if isinstance(u, str) and now - float(t) <= ttl]
                            if fresh:
                                cur = self.recent_images.setdefault(str(uid), [])
                                existing_urls = {u for (_, u) in cur}
                                for t, u in fresh:
                                    if u not in existing_urls:
                                        cur.append((t, u))
                                cur.sort(key=lambda x: x[0])
                                self.recent_images[str(uid)] = cur[-10:]
        except Exception as e:
            logger.debug("Failed to load recent images: %s", e)

    def _save_recent_images(self) -> None:
        try:
            self._save_json(self.recent_images_path, self.recent_images)
        except Exception as e:
            logger.debug("Failed to save recent images: %s", e)

    def _image_scope_key(self, context: Any) -> str:
        """根据场景（群聊/私聊/频道）及会话 ID + 用户 ID 生成专属隔离键，彻底杜绝跨群或私聊串图。"""
        scene = _normalize_scene(context)
        uid = self._user_id(context)
        if scene == "c2c":
            return f"c2c:{uid}"
        conv_id = (
            getattr(context, "group_id", None)
            or getattr(context, "channel_id", None)
            or getattr(context, "conversation_id", None)
            or ""
        )
        conv_clean = _clean_user_id(conv_id)
        if conv_clean:
            return f"{scene}:{conv_clean}:{uid}"
        return f"{scene}:{uid}"

    def _recent_urls_within_ttl(self, context: Any, limit: int = 3) -> list[str]:
        scope_key = self._image_scope_key(context)
        now = time.time()
        ttl = max(1, int(self._get_cfg("edit_image_ttl_min", 10) or 10)) * 60
        user_imgs = self.recent_images.get(scope_key, [])
        fresh = [u for (t, u) in user_imgs if now - t <= ttl]
        self.recent_images[scope_key] = [(t, u) for (t, u) in user_imgs if now - t <= ttl]
        return fresh[-limit:]

    def _clear_recent_images(self, scope_key: str, urls: list[str] | None = None) -> None:
        """清空或移除特定会话作用域暂存的参考图片（多图编辑生成后清空）。"""
        if scope_key not in self.recent_images:
            return
        if urls:
            remove_set = set(urls)
            self.recent_images[scope_key] = [
                (t, u) for (t, u) in self.recent_images.get(scope_key, [])
                if u not in remove_set
            ]
            if not self.recent_images[scope_key]:
                self.recent_images.pop(scope_key, None)
        else:
            self.recent_images.pop(scope_key, None)
        self._save_recent_images()

    def _reload_config_if_changed(self) -> None:
        try:
            mtime = self.config_path.stat().st_mtime if self.config_path.exists() else 0
            if getattr(self, "_config_mtime", 0) != mtime:
                self._config_mtime = mtime
                loaded = self._load_json(self.config_path, {})
                if isinstance(loaded, dict) and loaded:
                    for k, v in loaded.items():
                        if v not in (None, ""):
                            self.config[k] = v
        except Exception:
            pass

    def _get_cfg(self, key: str, default: Any = "") -> Any:
        self._reload_config_if_changed()
        val = self.config.get(key)
        if val not in (None, ""):
            return val
        disk_cfg = self._load_json(self.config_path, {})
        if disk_cfg.get(key) not in (None, ""):
            self.config[key] = disk_cfg[key]
            return disk_cfg[key]
        if not self.is_isolated:
            perm_cfg = self._load_json(self.perm_dir / "config.json", {}) or self._load_json(self.perm_dir / "config" / "config.json", {})
            if perm_cfg.get(key) not in (None, ""):
                self.config[key] = perm_cfg[key]
                return perm_cfg[key]
        runtime = getattr(self.context, "_runtime", None) or getattr(self.context, "runtime", None)
        if runtime:
            if hasattr(runtime, "drawimg") and hasattr(runtime.drawimg, "_cfg"):
                drawimg_val = runtime.drawimg._cfg(key)
                if drawimg_val not in (None, ""):
                    return drawimg_val
            if hasattr(runtime, "database"):
                db_cache = getattr(runtime.database, "_settings_cache", {}) or getattr(runtime.database, "settings_cache", {})
                db_val = db_cache.get(f"dg.{key}")
                if db_val not in (None, ""):
                    return db_val
        if not self.is_isolated:
            try:
                db_file = Path("data/runtime.sqlite3")
                if db_file.exists():
                    import sqlite3
                    with sqlite3.connect(str(db_file), timeout=2.0) as conn:
                        cur = conn.cursor()
                        cur.execute("SELECT value FROM settings WHERE key = ?", (f"dg.{key}",))
                        row = cur.fetchone()
                        if row and row[0] not in (None, ""):
                            return row[0]
            except Exception:
                pass
        env_val = os.environ.get(f"DG_{key.upper()}") or os.environ.get(f"DRAWIMG_{key.upper()}")
        if env_val:
            return env_val
        return DEFAULT_CONFIG.get(key, default)

    def _save_config(self) -> None:
        self.models_cache = None
        self._save_json(self.config_path, self.config)
        runtime = getattr(self.context, "_runtime", None)
        if runtime and hasattr(runtime, "drawimg") and hasattr(runtime.drawimg, "config"):
            for k, v in self.config.items():
                runtime.drawimg.config[k] = v
        if not self.is_isolated:
            try:
                db_file = Path("data/runtime.sqlite3")
                if db_file.exists():
                    import sqlite3
                    with sqlite3.connect(str(db_file), timeout=2.0) as conn:
                        cur = conn.cursor()
                        for k, v in self.config.items():
                            val_str = json.dumps(v, ensure_ascii=False) if isinstance(v, (dict, list)) else str(v)
                            cur.execute(
                                "INSERT INTO settings(key, value, updated_at) VALUES(?, ?, CURRENT_TIMESTAMP) "
                                "ON CONFLICT(key) DO UPDATE SET value=excluded.value, updated_at=CURRENT_TIMESTAMP",
                                (f"dg.{k}", val_str)
                            )
                        conn.commit()
            except Exception:
                pass

    def _points(self) -> Any:
        return getattr(self.context, "points", None)

    def _save_credits(self) -> None:
        self._save_json(self.credits_path, self.credits)

    def _save_user_prefs(self) -> None:
        self._save_json(self.user_prefs_path, self.user_prefs)

    def _save_history(self) -> None:
        self._save_json(self.history_path, self.history)

    def _api_base_url(self) -> str:
        base = str(self._get_cfg("api_base_url") or "").strip().rstrip("/")
        if base.casefold().endswith("/v1"):
            base = base[:-3].rstrip("/")
        return base

    def _api_key(self) -> str:
        return str(self._get_cfg("api_key") or "").strip()

    def _today(self) -> str:
        return time.strftime("%Y-%m-%d", time.localtime())

    def _get_user_today_experience(self, user_id: str) -> int:
        uid = _clean_user_id(user_id)
        pref = self.user_prefs.get(uid) or {}
        daily = pref.get("test_daily")
        if isinstance(daily, dict):
            return int(daily.get(self._today(), 0))
        return 0

    def _inc_user_today_experience(self, user_id: str, count: int = 1) -> int:
        uid = _clean_user_id(user_id)
        pref = self.user_prefs.setdefault(uid, {})
        daily = pref.setdefault("test_daily", {})
        today = self._today()
        if len(daily) > 7:
            for k in list(daily.keys()):
                if k != today:
                    daily.pop(k, None)
        daily[today] = int(daily.get(today, 0)) + count
        self._save_user_prefs()
        return daily[today]

    def _user_id(self, context: MessageContext) -> str:
        raw = getattr(context, "member_openid", None) or getattr(context, "sender_id", None) or getattr(context, "user_id", None) or "default_user"
        return _clean_user_id(raw)

    async def _get_balance(self, user_id: str) -> float:
        uid = _clean_user_id(user_id)
        points = self._points()
        if points is not None and hasattr(points, "balance"):
            try:
                bal = await points.balance(uid, "drawimg")
                bal_float = round(float(bal), 2)
                self.credits[uid] = bal_float
                self.credits.pop(f"<@{uid}>", None)
                self.credits.pop(f"qq_official:{uid}", None)
                return bal_float
            except Exception as e:
                logger.warning("Failed to query points via context.points for %s: %s", uid, e)

        for candidate in (uid, f"<@{uid}>", f"qq_official:{uid}"):
            if candidate in self.credits:
                val = round(float(self.credits[candidate]), 2)
                if candidate != uid:
                    self.credits[uid] = max(round(float(self.credits.get(uid, 0.0)), 2), val)
                    self.credits.pop(candidate, None)
                    self._save_credits()
                return round(float(self.credits[uid]), 2)

        for p in (Path("data/runtime.sqlite3"), Path("/app/data/runtime.sqlite3")):
            if p.is_file():
                try:
                    import sqlite3
                    with sqlite3.connect(str(p), timeout=2.0) as conn:
                        row = conn.execute(
                            "SELECT balance_minor FROM point_accounts WHERE identity = ? AND point_type = 'drawimg'",
                            (uid,)
                        ).fetchone()
                        if row:
                            bal_float = round(float(row[0]) / 100.0, 2)
                            self.credits[uid] = bal_float
                            return bal_float
                    break
                except Exception:
                    pass

        return 0.0

    async def _change_balance(self, user_id: str, delta: float, reason: str = "") -> float:
        uid = _clean_user_id(user_id)
        current = await self._get_balance(uid)
        delta = round(float(delta), 2)
        if abs(delta) < 1e-6:
            return current

        points = self._points()
        if points is not None and hasattr(points, "credit") and hasattr(points, "debit"):
            try:
                op_id = f"dgs:{uid}:{int(time.time() * 1000)}:{uuid.uuid4().hex[:6]}"
                amount_val = abs(delta)
                amount_str = str(int(amount_val)) if amount_val == int(amount_val) else f"{amount_val:.2f}".rstrip("0").rstrip(".")
                if delta > 0:
                    new_bal = await points.credit(
                        uid, amount_str, reason or "drawimg.credit",
                        point_type="drawimg", operation_id=op_id,
                    )
                else:
                    new_bal = await points.debit(
                        uid, amount_str, reason or "drawimg.debit",
                        point_type="drawimg", operation_id=op_id,
                    )
                bal_float = round(float(new_bal), 2)
                self.credits[uid] = bal_float
                self.credits.pop(f"<@{uid}>", None)
                self.credits.pop(f"qq_official:{uid}", None)
                return bal_float
            except Exception as e:
                logger.warning("Failed to change points via context.points for %s: %s", uid, e)

        new_balance = round(max(0.0, current + delta), 2)
        self.credits.pop(f"<@{uid}>", None)
        self.credits.pop(f"qq_official:{uid}", None)
        self.credits[uid] = new_balance
        self._save_credits()
        return new_balance

    # ---------- Inter-plugin Credit Interface ----------

    def get_balance(self, user_id: str) -> float:
        uid = _clean_user_id(user_id)
        for candidate in (uid, f"<@{uid}>", f"qq_official:{uid}"):
            if candidate in self.credits:
                return round(float(self.credits[candidate]), 2)
        return 0.0

    def change_balance(self, user_id: str, delta: float, reason: str = "") -> float:
        uid = _clean_user_id(user_id)
        val = round(max(0.0, self.get_balance(uid) + float(delta)), 2)
        self.credits[uid] = val
        self._save_credits()
        return val

    async def get_balance_async(self, user_id: str) -> float:
        return await self._get_balance(user_id)

    async def change_balance_async(self, user_id: str, delta: float, reason: str = "") -> float:
        return await self._change_balance(user_id, float(delta), reason)

    async def reserve_credits(self, user_id: str, amount: float, op_id: str = "") -> bool:
        bal = await self._get_balance(user_id)
        if bal < float(amount):
            return False
        await self._change_balance(user_id, -float(amount), reason=f"reserve:{op_id}")
        return True

    async def settle_credits(self, user_id: str, amount: float, op_id: str = "") -> bool:
        return True

    async def refund_credits(self, user_id: str, amount: float, op_id: str = "") -> bool:
        await self._change_balance(user_id, float(amount), reason=f"refund:{op_id}")
        return True

    def _model_cost(self, model: str) -> float:
        rules_raw = self._get_cfg("credit_cost_rules", "")
        model_norm = str(model).strip().lower()
        if isinstance(rules_raw, dict):
            for k, v in rules_raw.items():
                if str(k).strip().lower() == model_norm:
                    try:
                        return max(0.0, round(float(v), 2))
                    except (ValueError, TypeError):
                        pass
        elif isinstance(rules_raw, str) and rules_raw.strip():
            raw_str = rules_raw.strip()
            if raw_str.startswith("{") and raw_str.endswith("}"):
                try:
                    loaded = json.loads(raw_str)
                    if isinstance(loaded, dict):
                        for k, v in loaded.items():
                            if str(k).strip().lower() == model_norm:
                                try:
                                    return max(0.0, round(float(v), 2))
                                except (ValueError, TypeError):
                                    pass
                except Exception:
                    pass
            for rule in re.split(r"[;,\n]+", raw_str):
                parts = rule.strip().split(":", 1)
                if len(parts) == 2:
                    k = parts[0].strip().strip('"').strip("'").strip("{").strip("}")
                    if k.lower() == model_norm:
                        try:
                            v = parts[1].strip().strip('"').strip("'").strip("{").strip("}")
                            return max(0.0, round(float(v), 2))
                        except (ValueError, TypeError):
                            pass
        try:
            return max(0.0, round(float(self._get_cfg("test_credit_cost", 1)), 2))
        except (ValueError, TypeError):
            return 1.0

    @staticmethod
    def _format_cost(cost: float) -> str:
        if cost <= 0:
            return "免费 (体验模型)"
        if cost == int(cost):
            return f"{int(cost)} 积分"
        return f"{cost:g} 积分"

    def _default_model(self) -> str:
        return str(self._get_cfg("default_model", "agnes-image-2.5-flash"))

    def _user_model(self, user_id: str) -> str:
        uid = _clean_user_id(user_id)
        for cand in (uid, f"qq_official:{uid}"):
            if cand in self.user_prefs and isinstance(self.user_prefs[cand], dict) and self.user_prefs[cand].get("model"):
                return str(self.user_prefs[cand]["model"])
        return self._default_model()

    def is_pure_image_model(self, model: str = "", err_msg: str = "") -> bool:
        """判断是否为纯生图专用模型（避免在改图时误降级到 chat 端点，或在生图遇到特定错误时误降级）"""
        model_lower = (model or "").lower()
        err_lower = (err_msg or "").lower()
        # 注意：包含 gemini 的模型即使带有 image 后缀（如 gemini-3.1-flash-image），往往只是带有图像理解/多模态输入能力的对话模型，并非纯生图模型
        if "gemini" in model_lower:
            return False
        if any(kw in model_lower for kw in ("image", "dall-e", "flux", "midjourney", "sd-", "stable-diffusion", "imagen")):
            return True
        if any(kw in err_lower for kw in (
            "is an image model", "only supports image generation",
            "openai-compatibility image model",
        )):
            return True
        return False

    def is_agnes_image_model(self, model: str = "") -> bool:
        """兼容别名：判断是否为 Agnes 系列图像模型"""
        proto, _ = self.resolve_model_protocol(model)
        return proto == PROTOCOL_EXTRA_BODY or "agnes" in (model or "").lower()

    def _save_learned_protocols(self) -> None:
        self._save_json(self.learned_protocols_path, self.learned_protocols)

    def _record_learned_protocol(self, model: str, protocol: str, note: str = "") -> None:
        m = (model or "").strip()
        if not m or protocol not in PROTOCOL_LABELS:
            return
        self.learned_protocols[m] = {
            "protocol": protocol,
            "updated_at": time.strftime("%Y-%m-%d %H:%M:%S"),
            "note": note or "自动探测成功",
        }
        self._save_learned_protocols()

    def _parse_endpoint_rules(self) -> list[dict[str, str]]:
        raw = self._get_cfg("model_endpoint_rules", "")
        if isinstance(raw, list):
            res = []
            for item in raw:
                if isinstance(item, dict) and item.get("pattern") and item.get("protocol"):
                    res.append({
                        "pattern": str(item["pattern"]).strip(),
                        "protocol": str(item["protocol"]).strip(),
                        "custom_endpoint": str(item.get("custom_endpoint") or item.get("endpoint") or "").strip(),
                        "custom_format": str(item.get("custom_format") or item.get("format") or "").strip(),
                        "note": str(item.get("note") or "").strip(),
                    })
            if res:
                return res
        elif isinstance(raw, str) and raw.strip():
            lines = [item.strip() for item in raw.strip().splitlines() if item.strip() and not item.startswith("#")]
            rules = []
            for line in lines:
                parts = line.split(":", 4)
                if len(parts) >= 2:
                    rules.append({
                        "pattern": parts[0].strip(),
                        "protocol": parts[1].strip(),
                        "custom_endpoint": parts[2].strip() if len(parts) >= 3 else "",
                        "custom_format": parts[3].strip() if len(parts) >= 4 else "",
                        "note": parts[4].strip() if len(parts) >= 5 else "",
                    })
            if rules:
                return rules
        return [
            {"pattern": p, "protocol": proto, "custom_endpoint": "", "custom_format": "", "note": note}
            for p, proto, note in BUILTIN_PROTOCOL_RULES
        ]

    def resolve_model_rule(self, model: str) -> dict[str, Any]:
        """决议指定模型的生图/改图完整规则与端点配置。"""
        model_name = (model or "").strip()
        if not model_name:
            return {"protocol": PROTOCOL_AUTO, "source": "default", "custom_endpoint": "", "custom_format": "", "pattern": ""}

        # 1. 管理员显式配置规则优先
        for rule in self._parse_endpoint_rules():
            if _match_pattern(rule["pattern"], model_name):
                proto = rule.get("protocol", PROTOCOL_AUTO)
                if proto in PROTOCOL_LABELS and proto != PROTOCOL_AUTO:
                    return {
                        "protocol": proto,
                        "source": "rule",
                        "custom_endpoint": rule.get("custom_endpoint", ""),
                        "custom_format": rule.get("custom_format", ""),
                        "pattern": rule.get("pattern", ""),
                    }

        # 2. 查已学习的记忆库
        if model_name in self.learned_protocols:
            mem_data = self.learned_protocols[model_name]
            mem_proto = mem_data.get("protocol")
            if mem_proto in PROTOCOL_LABELS and mem_proto != PROTOCOL_AUTO:
                return {
                    "protocol": mem_proto,
                    "source": "memory",
                    "custom_endpoint": mem_data.get("custom_endpoint", ""),
                    "custom_format": mem_data.get("custom_format", ""),
                    "pattern": model_name,
                }

        # 3. 内置规则兜底
        for pattern, proto, _ in BUILTIN_PROTOCOL_RULES:
            if _match_pattern(pattern, model_name):
                return {
                    "protocol": proto,
                    "source": "builtin",
                    "custom_endpoint": "",
                    "custom_format": "",
                    "pattern": pattern,
                }

        return {"protocol": PROTOCOL_AUTO, "source": "auto", "custom_endpoint": "", "custom_format": "", "pattern": ""}

    def resolve_model_protocol(self, model: str) -> tuple[str, str]:
        """决议指定模型的生图/改图协议驱动（兼容旧版元组接口）。"""
        rule = self.resolve_model_rule(model)
        return rule["protocol"], rule["source"]

    async def probe_model_endpoint(
        self,
        model: str,
        api_base: str = "",
        api_key: str = "",
        target_endpoint: str = "",
        target_format: str = "",
    ) -> dict[str, Any]:
        """轻量极速在线探测某个模型的生图/改图协议支持情况。
        
        严格控制单次 HTTP 探测超时为 5.0 秒，并发诊断，
        避免长时间阻塞 worker，杜绝超时崩溃。
        """
        key = (api_key or self._api_key()).strip()
        base = (api_base or self._api_base_url()).strip()
        if not key or not base:
            return {"ok": False, "error": "插件未配置 API 地址或 API 令牌，无法执行在线探测"}

        m = model.strip()
        if not m:
            return {"ok": False, "error": "请输入需要探测的模型名称"}

        tiny_png = b"\x89PNG\r\n\x1a\n\x00\x00\x00\rIHDR\x00\x00\x00\x01\x00\x00\x00\x01\x08\x06\x00\x00\x00\x1f\x15c4\x00\x00\x00\rIDATx\x9cc\xf8\xcf\xc0\x00\x00\x03\x01\x01\x00\x18\xdd\x8d\xb0\x00\x00\x00\x00IEND\xaeB`\x82"
        b64_tiny = base64.b64encode(tiny_png).decode("ascii")
        tiny_data_uri = f"data:image/png;base64,{b64_tiny}"

        PROBE_TIMEOUT = 5.0

        async def _test_extra_body() -> dict[str, Any]:
            t0 = time.monotonic()
            payload = {
                "model": m,
                "prompt": "probe",
                "extra_body": {"image": [tiny_data_uri]},
            }
            headers = {"Authorization": f"Bearer {key}", "Content-Type": "application/json"}
            try:
                async with httpx.AsyncClient(base_url=base, timeout=PROBE_TIMEOUT, follow_redirects=False) as client:
                    resp = await client.post("/v1/images/generations", json=payload, headers=headers)
                elapsed = round(time.monotonic() - t0, 2)
                if resp.status_code == 200:
                    return {"protocol": PROTOCOL_EXTRA_BODY, "endpoint": "/v1/images/generations", "ok": True, "status": 200, "duration": elapsed, "msg": "200 OK (支持扩展 extra_body 改图)"}
                err_text = resp.text[:150]
                err_lower = err_text.lower()
                if any(kw in err_lower for kw in ("extra_body.image", "image base64", "not a valid image", "image dimension", "invalid image")):
                    return {"protocol": PROTOCOL_EXTRA_BODY, "endpoint": "/v1/images/generations", "ok": True, "status": resp.status_code, "duration": elapsed, "msg": f"端点特征匹配成功（上游识别 extra_body.image 参数，耗时 {elapsed}s）"}
                return {"protocol": PROTOCOL_EXTRA_BODY, "endpoint": "/v1/images/generations", "ok": False, "status": resp.status_code, "duration": elapsed, "msg": f"HTTP {resp.status_code}: {err_text}"}
            except TimeoutError:
                return {"protocol": PROTOCOL_EXTRA_BODY, "endpoint": "/v1/images/generations", "ok": False, "status": 408, "duration": PROBE_TIMEOUT, "msg": "请求超时 (5s 未响应)"}
            except Exception as ex:
                return {"protocol": PROTOCOL_EXTRA_BODY, "endpoint": "/v1/images/generations", "ok": False, "status": 599, "duration": round(time.monotonic() - t0, 2), "msg": f"连接异常: {ex}"}

        async def _test_standard_edits() -> dict[str, Any]:
            t0 = time.monotonic()
            data = {"model": m, "prompt": "probe", "n": "1"}
            files = [("image", ("image.png", tiny_png, "image/png"))]
            headers = {"Authorization": f"Bearer {key}"}
            try:
                async with httpx.AsyncClient(base_url=base, timeout=PROBE_TIMEOUT, follow_redirects=False) as client:
                    resp = await client.post("/v1/images/edits", data=data, files=files, headers=headers)
                elapsed = round(time.monotonic() - t0, 2)
                if resp.status_code == 200:
                    return {"protocol": PROTOCOL_STANDARD_EDITS, "endpoint": "/v1/images/edits", "ok": True, "status": 200, "duration": elapsed, "msg": "200 OK (支持标准 edits 表单改图)"}
                err_text = resp.text[:150]
                err_lower = err_text.lower()
                if any(kw in err_lower for kw in ("invalid_image", "unsupported image", "image is required", "must be a valid image")):
                    return {"protocol": PROTOCOL_STANDARD_EDITS, "endpoint": "/v1/images/edits", "ok": True, "status": resp.status_code, "duration": elapsed, "msg": f"端点特征匹配成功（上游识别 edits 表单参数，耗时 {elapsed}s）"}
                return {"protocol": PROTOCOL_STANDARD_EDITS, "endpoint": "/v1/images/edits", "ok": False, "status": resp.status_code, "duration": elapsed, "msg": f"HTTP {resp.status_code}: {err_text}"}
            except TimeoutError:
                return {"protocol": PROTOCOL_STANDARD_EDITS, "endpoint": "/v1/images/edits", "ok": False, "status": 408, "duration": PROBE_TIMEOUT, "msg": "请求超时 (5s 未响应)"}
            except Exception as ex:
                return {"protocol": PROTOCOL_STANDARD_EDITS, "endpoint": "/v1/images/edits", "ok": False, "status": 599, "duration": round(time.monotonic() - t0, 2), "msg": f"连接异常: {ex}"}

        async def _test_chat_completions() -> dict[str, Any]:
            t0 = time.monotonic()
            payload = {
                "model": m,
                "messages": [
                    {
                        "role": "user",
                        "content": [
                            {"type": "text", "text": "probe"},
                            {"type": "image_url", "image_url": {"url": tiny_data_uri}},
                        ],
                    }
                ],
                "max_tokens": 5,
            }
            headers = {"Authorization": f"Bearer {key}", "Content-Type": "application/json"}
            try:
                async with httpx.AsyncClient(base_url=base, timeout=PROBE_TIMEOUT, follow_redirects=False) as client:
                    resp = await client.post("/v1/chat/completions", json=payload, headers=headers)
                elapsed = round(time.monotonic() - t0, 2)
                if resp.status_code == 200:
                    return {"protocol": PROTOCOL_CHAT, "endpoint": "/v1/chat/completions", "ok": True, "status": 200, "duration": elapsed, "msg": "200 OK (支持多模态 Chat 视觉/改图)"}
                err_text = resp.text[:150]
                return {"protocol": PROTOCOL_CHAT, "endpoint": "/v1/chat/completions", "ok": False, "status": resp.status_code, "duration": elapsed, "msg": f"HTTP {resp.status_code}: {err_text}"}
            except TimeoutError:
                return {"protocol": PROTOCOL_CHAT, "endpoint": "/v1/chat/completions", "ok": False, "status": 408, "duration": PROBE_TIMEOUT, "msg": "请求超时 (5s 未响应)"}
            except Exception as ex:
                return {"protocol": PROTOCOL_CHAT, "endpoint": "/v1/chat/completions", "ok": False, "status": 599, "duration": round(time.monotonic() - t0, 2), "msg": f"连接异常: {ex}"}

        async def _test_custom(endpoint: str, fmt: str) -> dict[str, Any]:
            t0 = time.monotonic()
            headers = {"Authorization": f"Bearer {key}"}
            is_absolute = endpoint.startswith(("http://", "https://"))
            target_url = endpoint
            client_base = None if is_absolute else base
            try:
                async with httpx.AsyncClient(base_url=client_base, timeout=PROBE_TIMEOUT, follow_redirects=False) as client:
                    if fmt in ("openai_edits", "form_data"):
                        resp = await client.post(target_url, data={"model": m, "prompt": "probe"}, files=[("image", ("image.png", tiny_png, "image/png"))], headers=headers)
                    else:
                        payload = {"model": m, "prompt": "probe", "extra_body": {"image": [tiny_data_uri]}}
                        headers["Content-Type"] = "application/json"
                        resp = await client.post(target_url, json=payload, headers=headers)
                elapsed = round(time.monotonic() - t0, 2)
                if resp.status_code == 200:
                    return {"protocol": PROTOCOL_CUSTOM, "endpoint": endpoint, "ok": True, "status": 200, "duration": elapsed, "msg": f"200 OK (自定义端点 {endpoint} 探测成功)"}
                return {"protocol": PROTOCOL_CUSTOM, "endpoint": endpoint, "ok": False, "status": resp.status_code, "duration": elapsed, "msg": f"HTTP {resp.status_code}: {resp.text[:150]}"}
            except TimeoutError:
                return {"protocol": PROTOCOL_CUSTOM, "endpoint": endpoint, "ok": False, "status": 408, "duration": PROBE_TIMEOUT, "msg": "请求超时 (5s 未响应)"}
            except Exception as ex:
                return {"protocol": PROTOCOL_CUSTOM, "endpoint": endpoint, "ok": False, "status": 599, "duration": round(time.monotonic() - t0, 2), "msg": f"连接异常: {ex}"}

        tasks = []
        if target_endpoint:
            tasks.append(_test_custom(target_endpoint, target_format))
        tasks.extend([_test_extra_body(), _test_standard_edits(), _test_chat_completions()])

        diagnostics = await asyncio.gather(*tasks, return_exceptions=False)
        diagnostics = list(diagnostics)

        matched = next((item for item in diagnostics if item.get("ok")), None)
        if matched:
            matched_proto = matched["protocol"]
            self._record_learned_protocol(m, matched_proto, f"在线探测成功 ({matched['endpoint']})")
            return {
                "ok": True,
                "model": m,
                "matched_protocol": matched_proto,
                "matched_label": PROTOCOL_LABELS.get(matched_proto, matched_proto),
                "details": f"端点「{matched['endpoint']}」探测成功 (耗时 {matched['duration']}s)",
                "diagnostics": diagnostics,
            }

        hint = ""
        for d in diagnostics:
            msg = d.get("msg", "").lower()
            if "is an image model" in msg or "use /v1/images/generations" in msg:
                hint = "上游反馈该模型为生图模型（需使用 /v1/images/generations 扩展或仅文生图）"
            elif "does not support image edits" in msg or "only text-to-image" in msg:
                hint = "上游明确提示该模型仅支持文生图，不支持改图"

        return {
            "ok": False,
            "model": m,
            "error": f"未能通过改图协议探测。{hint}" if hint else "未能通过改图协议探测，请查看详细诊断结果。",
            "diagnostics": diagnostics,
        }


    def _handle_model(self, context: MessageContext, args: list[str]) -> str | Card:
        uid = self._user_id(context)
        if not args:
            cur_model = self._user_model(uid)
            def_model = self._default_model()
            cost = self._model_cost(cur_model)
            cost_str = self._format_cost(cost)
            is_custom = bool(self.user_prefs.get(uid, {}).get("model"))
            custom_hint = "（个人偏好锁定）" if is_custom else "（跟随全局默认）"
            return Card(
                "生图模型设置",
                f"当前使用模型：`{cur_model}` {custom_hint}\n"
                f"- 每次生图消耗：**{cost_str}**\n"
                f"- 全局默认模型：`{def_model}`\n\n"
                "可用指令：\n"
                "- `/dg model <模型名称>` — 切换个人生图模型\n"
                "- `/dg model reset` — 恢复跟随全局默认模型\n"
                "- `/dg models` — 查看可用模型列表",
                rows=[
                    [_btn("重置为默认", "/dg model reset"), _btn("查看可用模型", "/dg models")],
                    [_btn("查看当前状态", "/dg status"), _btn("返回主菜单", "/dg")],
                ],
            )

        target = args[0].strip()
        if target.lower() in {"reset", "default", "auto", "off", "重置", "默认", "清除"}:
            if len(args) > 1 and context.is_admin:
                second = args[1].strip()
                if second.lower() in {"all", "全员", "所有"}:
                    count = 0
                    for k in list(self.user_prefs.keys()):
                        if isinstance(self.user_prefs[k], dict) and "model" in self.user_prefs[k]:
                            self.user_prefs[k].pop("model", None)
                            count += 1
                    self._save_user_prefs()
                    def_model = self._default_model()
                    return f"✅ 已成功重置所有用户（共 {count} 人）的模型偏好，全员已恢复为全局默认模型 `{def_model}`。"
                else:
                    target_user = _clean_user_id(second)
                    for cand in (target_user, f"qq_official:{target_user}"):
                        if cand in self.user_prefs and isinstance(self.user_prefs[cand], dict):
                            self.user_prefs[cand].pop("model", None)
                    self._save_user_prefs()
                    def_model = self._default_model()
                    return f"✅ 已重置用户 `{target_user}` 的模型设置，恢复跟随全局默认模型 `{def_model}`。"

            for cand in (uid, f"qq_official:{uid}"):
                if cand in self.user_prefs and isinstance(self.user_prefs[cand], dict):
                    self.user_prefs[cand].pop("model", None)
            self._save_user_prefs()
            def_model = self._default_model()
            cost = self._model_cost(def_model)
            return Card(
                "模型重置成功",
                f"已重置您的生图模型偏好，当前跟随时下全局默认模型：`{def_model}`\n\n- 每次生图消耗：**{self._format_cost(cost)}**",
                rows=[
                    [_btn("立即生图", "/dg ", fill=True), _btn("查看可用模型", "/dg models")],
                    [_btn("查看当前状态", "/dg status"), _btn("返回主菜单", "/dg")],
                ],
            )

        model_name = target
        if len(args) > 1 and context.is_admin:
            target_user = _clean_user_id(args[1].strip())
            self.user_prefs.setdefault(target_user, {})["model"] = model_name
            self._save_user_prefs()
            cost = self._model_cost(model_name)
            return f"✅ 管理员已将用户 `{target_user}` 的生图模型设置为 `{model_name}`（单次消耗 {self._format_cost(cost)}）。"

        self.user_prefs.setdefault(uid, {})["model"] = model_name
        self._save_user_prefs()
        cost = self._model_cost(model_name)
        return Card(
            "模型切换成功",
            f"已将您的生图模型切换为：`{model_name}`\n\n- 每次生图消耗：**{self._format_cost(cost)}**\n- 随时发送 `/dg model reset` 可恢复跟随全局默认",
            rows=[
                [_btn("立即生图", "/dg ", fill=True), _btn("重置为默认", "/dg model reset")],
                [_btn("查看当前状态", "/dg status"), _btn("返回主菜单", "/dg")],
            ],
        )

    def _user_size(self, user_id: str) -> str:
        return self.user_prefs.get(user_id, {}).get("size") or str(self._get_cfg("image_size", "auto"))

    def _user_quality(self, user_id: str) -> str:
        return self.user_prefs.get(user_id, {}).get("quality") or str(self._get_cfg("image_quality", "auto"))

    def _user_style(self, user_id: str) -> str:
        return self.user_prefs.get(user_id, {}).get("style", "")

    def _user_transparent_mode(self, user_id: str) -> str:
        pref = self.user_prefs.get(user_id, {})
        if "transparent_mode" in pref:
            mode = str(pref["transparent_mode"]).lower().strip()
            if mode in {"green", "blue", "red", "yellow", "auto", "off"}:
                return mode
        if bool(pref.get("transparent", False)):
            return "auto"
        return "off"

    def _user_transparent(self, user_id: str) -> bool:
        return self._user_transparent_mode(user_id) != "off"

    def _user_prompt_guard(self, user_id: str) -> bool:
        return bool(self.user_prefs.get(user_id, {}).get("prompt_guard", True))

    # ---------- Event listener ----------

    async def on_event(self, context: MessageContext) -> None:
        # 指令消息与按钮交互事件无需提取图片，直接快速返回避免阻塞 worker
        if getattr(context, "message_type", None) == "interaction":
            return
        text_val = (getattr(context, "text", "") or "").strip()
        if text_val.startswith("/"):
            return

        urls = extract_image_urls(context)
        if not urls:
            return

        scope_key = self._image_scope_key(context)
        now = time.time()
        ttl = max(1, int(self._get_cfg("edit_image_ttl_min", 10) or 10)) * 60
        user_imgs = self.recent_images.setdefault(scope_key, [])
        user_imgs = [(t, u) for (t, u) in user_imgs if now - t <= ttl]
        for u in urls:
            user_imgs.append((now, u))
        self.recent_images[scope_key] = user_imgs[-10:]
        self._save_recent_images()

    # ---------- Periodic task ----------

    async def cleanup(self) -> None:
        now = time.time()
        ttl = max(1, int(self._get_cfg("edit_image_ttl_min", 10) or 10)) * 60
        changed = False
        for uid in list(self.recent_images.keys()):
            orig_len = len(self.recent_images[uid])
            self.recent_images[uid] = [(t, u) for (t, u) in self.recent_images[uid] if now - t <= ttl]
            if len(self.recent_images[uid]) != orig_len:
                changed = True
            if not self.recent_images[uid]:
                self.recent_images.pop(uid, None)
                changed = True
        if changed:
            self._save_recent_images()

    # ---------- Commands entry ----------

    async def handle_dg(self, context: MessageContext, args: list[str]) -> str | Card:
        if not args:
            return await self._main_menu_card(context)
        sub = args[0].lower()
        if sub in {"help", "帮助", "教程", "guide"}:
            return Card("使用教程", GUIDE_TEXT, rows=[
                [_btn("文生图", "/dg ", fill=True), _btn("单图编辑", "/dge ", fill=True)],
                [_btn("多图编辑", "/dgm ", fill=True), _btn("选择模型", "/dg models")],
                [_btn("选择预设", "/dg style"), _btn("充值积分", "/dg pay ", fill=True)],
                [_btn("返回主菜单", "/dg")],
            ])
        if sub in {"menu", "菜单"}:
            page = args[1].lower() if len(args) > 1 else ""
            return await self._menu_card(context, page)
        if sub in {"status", "状态", "余额", "credit", "credits"}:
            return await self._status_card(context)
        if sub in {"style", "风格", "preset", "预设"}:
            return await self._handle_style(context, args[1:])
        if sub in {"size", "尺寸"}:
            return self._handle_size(context, args[1:])
        if sub in {"quality", "质量", "画质"}:
            return self._handle_quality(context, args[1:])
        if sub in {"bg", "transparent", "抠图", "透明", "免抠", "绿幕", "蓝幕"}:
            passed_args = [sub] + args[1:] if sub in {"绿幕", "蓝幕"} else args[1:]
            return self._handle_transparent(context, passed_args)
        if sub in {"guard", "rewrite", "防改写", "防篡改"}:
            return self._handle_prompt_guard(context, args[1:])
        if sub in {"models", "模型", "模型列表"}:
            return await self._handle_models(context, args[1:])
        if sub in {"model", "切模型", "切换模型"}:
            return self._handle_model(context, args[1:])
        if sub in {"pay", "充值", "buy"}:
            return await self._handle_pay(context, args[1:])
        if sub in {"give", "赠送", "转账"}:
            return await self._handle_give(context, args[1:])
        if sub in {"top", "排行", "排行榜"}:
            return await self._handle_top(context)
        if sub in {"rate", "比例", "单价"}:
            return self._handle_rate(context, args[1:])
        if sub in {"cost", "计费", "价格"}:
            return self._handle_cost(context, args[1:])
        if sub in {"history", "历史"}:
            return self._handle_history(context)
        if sub in {"resend", "重发"}:
            return self._handle_resend(context, args[1:])
        if sub in {"admin", "管理", "面板"}:
            return self._handle_admin(context)
        if sub in {"blacklist", "黑名单"}:
            return self._handle_blacklist(context, args[1:])

        prompt = " ".join(args).strip()
        return await self._generate_flow(context, prompt, mode="txt2img", announce="生图")

    async def handle_dge(self, context: MessageContext, args: list[str]) -> str | Card:
        prompt = " ".join(args).strip()
        scope_key = self._image_scope_key(context)
        # 1. 优先检查当前消息本身是否带有图片
        current_urls = extract_image_urls(context)
        if current_urls:
            urls = current_urls[-1:]
            now = time.time()
            user_imgs = self.recent_images.setdefault(scope_key, [])
            for u in current_urls:
                user_imgs.append((now, u))
            self.recent_images[scope_key] = user_imgs[-10:]
            self._save_recent_images()
        else:
            urls = self._recent_urls_within_ttl(context, limit=1)

        ttl_min = max(1, int(self._get_cfg("edit_image_ttl_min", 10) or 10))
        if not urls:
            return (
                f"未找到您最近发送的图片（当前聊天中未检测到可用图片）。请先在当前聊天中发送一张图片，然后在 {ttl_min} 分钟内执行 `/dge <修改要求>`。\n"
                f"多图改图：连发 2~3 张图后发送 `/dgm <修改要求>`。"
            )

        if not prompt:
            return Card("单图改图说明", f"已识别到您最近发送的 1 张图片（当前聊天中有效，{ttl_min} 分钟内）。\n\n发送 `/dge <修改要求>` 即可立即开始改图。\n例如：`/dge 把它变成赛博朋克风格`", rows=[
                [_btn("改图输入", "/dge ", fill=True), _btn("选择模型", "/dg models")],
                [_btn("返回主菜单", "/dg")],
            ])

        return await self._generate_flow(context, prompt, edit_urls=urls, mode="img2img_single", announce="改图")

    async def handle_dgm(self, context: MessageContext, args: list[str]) -> str | Card:
        prompt = " ".join(args).strip()
        scope_key = self._image_scope_key(context)
        # 优先检查当前消息是否带图，若有则保存到当前会话并与最近历史合并
        current_urls = extract_image_urls(context)
        if current_urls:
            now = time.time()
            user_imgs = self.recent_images.setdefault(scope_key, [])
            for u in current_urls:
                user_imgs.append((now, u))
            self.recent_images[scope_key] = user_imgs[-10:]
            self._save_recent_images()

        recent_urls = self._recent_urls_within_ttl(context, limit=3)
        # 仅取网络图片（用户主动发送的参考图片），排除系统本地生成的缓存图片
        user_recent = [u for u in recent_urls if u.startswith("http://") or u.startswith("https://")]
        combined = []
        for u in user_recent:
            if u not in combined:
                combined.append(u)
        for u in current_urls:
            if u not in combined:
                combined.append(u)
        urls = combined[-3:]

        ttl_min = max(1, int(self._get_cfg("edit_image_ttl_min", 10) or 10))
        if len(urls) < 2:
            return (
                f"多图改图需要至少 2 张参考图片。当前会话中，当前仅识别到 {len(urls)} 张。\n"
                f"请在 {ttl_min} 分钟内在当前聊天中连发 2~3 张图片后，再发送 `/dgm <融合或修改要求>`。"
            )

        if not prompt:
            return Card("多图改图说明", f"已识别到您最近发送的 {len(urls)} 张图片（当前聊天中有效，{ttl_min} 分钟内）。\n\n发送 `/dgm <融合或修改要求>` 即可开始多图改图。\n例如：`/dgm 将图一的人物融入图二的背景`", rows=[
                [_btn("多图改图", "/dgm ", fill=True), _btn("选择模型", "/dg models")],
                [_btn("返回主菜单", "/dg")],
            ])

        return await self._generate_flow(context, prompt, edit_urls=urls, mode="img2img_multi", announce="多图改图")

    # ---------- Core Image Generation (ported from runtime.drawimg) ----------

    async def _send_text_notice(self, context: MessageContext, text: str) -> None:
        qq = getattr(self.context, "qq", None)
        if qq is None:
            return
        conv_id = (
            getattr(context, "conversation_id", "")
            or getattr(context, "group_id", "")
            or getattr(context, "sender_id", "")
        )
        if not conv_id:
            return
        scene = _normalize_scene(context)
        msg_id = getattr(context, "message_id", None)
        try:
            if msg_id:
                try:
                    await qq.send_text(conv_id, scene, text, msg_id=msg_id)
                    return
                except Exception as send_err:
                    logger.warning("Sending text notice with msg_id failed (%s), retrying without msg_id...", send_err)
            await qq.send_text(conv_id, scene, text)
        except Exception as e:
            logger.warning("Failed to send text notice to %s: %s", conv_id, e)

    async def _async_generate_job(
        self,
        context: MessageContext,
        prompt: str,
        edit_urls: list[str] | None = None,
        mode: str = "txt2img",
        cost: float = 1.0,
    ) -> None:
        try:
            err = await self._generate(context, prompt, edit_urls=edit_urls, mode=mode, cost=cost)
            if err:
                formatted_err = _format_drawimg_error(err)
                await self._send_text_notice(context, f"🎨 生图提醒：{formatted_err}")
        except Exception as e:
            logger.exception("Unexpected error in background generation job: %s", e)
            try:
                user_id = self._user_id(context)
                if cost > 0:
                    await self._change_balance(user_id, cost, reason=f"drawimg.refund.{mode}.error")
                    await self._send_text_notice(context, f"🎨 抱歉，生图任务出现异常（{type(e).__name__}），本次积分已退还，请稍后重试。")
                else:
                    await self._send_text_notice(context, f"🎨 抱歉，生图任务出现异常（{type(e).__name__}），请稍后重试。")
            except Exception as notify_err:
                logger.warning("Failed to refund or notify after unexpected error: %s", notify_err)

    async def _generate_flow(
        self,
        context: MessageContext,
        prompt: str,
        edit_urls: list[str] | None = None,
        mode: str = "txt2img",
        announce: str = "生图",
    ) -> str | Card:
        user_id = self._user_id(context)
        blacklist = self._get_cfg("test_blacklist", [])
        if user_id in blacklist:
            return "您已被管理员限制使用生图服务。"

        cooldown = int(self._get_cfg("cooldown_sec", 10))
        now = time.time()
        last_t = self.last_action_time.get(user_id, 0)
        if now - last_t < cooldown:
            return f"生图过于频繁，请等待 {int(cooldown - (now - last_t))} 秒后再试。"

        api_key = self._api_key()
        api_base = self._api_base_url()
        if not api_key or not api_base:
            return "插件尚未配置生图服务或密钥，请联系管理员。"

        model = self._user_model(user_id)
        cost = self._model_cost(model)

        if cost <= 0:
            # 免费体验模型：校验每日体验次数限制
            limit = int(self._get_cfg("test_daily_limit", 0))
            if limit > 0:
                used = self._get_user_today_experience(user_id)
                if used >= limit:
                    return Card(
                        "今日体验次数已达上限",
                        f"模型 **{model}** 为免费体验模型，您今日的体验次数已用尽（**{used}/{limit}** 次）。\n\n"
                        f"明天即可恢复免费体验额度，或切换至扣积分的进阶模型继续生成。",
                        rows=[
                            [_btn("查看支持的模型", "/dg models"), _btn("我的状态", "/dg status")],
                            [_btn("返回主菜单", "/dg")],
                        ],
                    )
        else:
            # 付费积分模型：不限每日体验次数，只校验用户积分余额
            balance = await self._get_balance(user_id)
            if balance < cost:
                price_yuan = float(self._get_cfg("credit_price_yuan", 0.1))
                return Card(
                    "积分余额不足",
                    f"当前生成模型 **{model}** 需要 **{cost:g}** 积分，您当前余额为 **{balance:g}** 积分。\n\n"
                    f"积分单价：**{price_yuan:g}** 元/积分。\n"
                    f"发送 `/dg pay <积分数>` 即可在线充值。",
                    rows=[
                        [
                            _btn("充值 10 积分", "/dg pay 10", action_type=1),
                            _btn("充值 50 积分", "/dg pay 50", action_type=1),
                            _btn("自定义充值", "/dg pay ", fill=True),
                        ],
                        [
                            _btn("我的状态", "/dg status"),
                            _btn("返回主菜单", "/dg"),
                        ],
                    ],
                )

        self.last_action_time[user_id] = time.time()
        if mode == "img2img_multi":
            # 多图编辑确认发起生成，立即清空当时暂存的参考图片，避免重复复用
            self._clear_recent_images(self._image_scope_key(context))

        asyncio.create_task(
            self._async_generate_job(context, prompt, edit_urls=edit_urls, mode=mode, cost=cost)
        )
        return f"🎨 已收到{announce}请求（模型 {model}），正在后台为您生成，预计 20-120 秒，完成后将直接发送到本对话……"

    async def _generate(
        self,
        context: MessageContext,
        prompt: str,
        edit_urls: list[str] | None = None,
        mode: str = "txt2img",
        cost: float = 1.0,
    ) -> str:
        user_id = self._user_id(context)
        key = self._api_key()
        base = self._api_base_url()
        if not base or not key:
            return "插件尚未配置生图服务或密钥，请联系管理员。"

        prompt = (prompt or "").strip()
        style = self._user_style(user_id)
        if prompt and style:
            prompt = f"{prompt},{style}"

        image_urls = []
        for item in getattr(context, "attachments", []):
            if isinstance(item, dict):
                u = str(item.get("url") or item.get("src") or "").strip()
                if u.startswith("http") and u not in image_urls:
                    image_urls.append(u)
        for url in (edit_urls or []):
            if url and url not in image_urls:
                image_urls.append(url)

        if not prompt and not image_urls:
            return "请输入生图提示词，例如：/dg 一只可爱的柴犬"

        max_chars = int(self._get_cfg("max_prompt_chars", 4000))
        if len(prompt) > max_chars:
            return "提示词太长了，请精简后再试。"

        images: list[bytes] = []
        if image_urls:
            for url in image_urls[:4]:
                data, error = await self._download_image(url)
                if error:
                    return f"读取图片失败：{error}"
                clamped = await asyncio.to_thread(_clamp_image_for_api, data)
                images.append(clamped)

        self.last_action_time[user_id] = time.time()
        revised_prompt = ""
        try:
            if images:
                path, error = await self._request_edit(context, prompt, images, key, base)
            else:
                gen_res = await self._request_generate(context, prompt, key, base)
                if isinstance(gen_res, tuple) and len(gen_res) >= 3:
                    path, error, revised_prompt = gen_res[0], gen_res[1], gen_res[2]
                elif isinstance(gen_res, tuple) and len(gen_res) == 2:
                    path, error = gen_res[0], gen_res[1]
                else:
                    path, error = str(gen_res), ""
        except httpx.TimeoutException:
            return _format_drawimg_error("生图超时了，任务可能仍在后台完成，请稍后再试。")
        except httpx.HTTPError as exc:
            return _format_drawimg_error(f"上游绘图服务网络连接异常（{type(exc).__name__}），请稍后重试。")
        except Exception as exc:
            return _format_drawimg_error(f"生成失败：{exc}")

        if error:
            return _format_drawimg_error(error)

        if self._user_transparent(user_id) and path:
            try:
                trans_mode = self._user_transparent_mode(user_id)
                chroma_color = _resolve_chroma_mode(trans_mode, prompt)
                trans_path = await asyncio.to_thread(_remove_chroma_background, Path(path), chroma_color)
                path = str(trans_path)
            except Exception as e:
                logger.warning("Failed to remove chroma background: %s", e)

        # Debit balance for paid models or record experience count for free models
        if cost > 0:
            await self._change_balance(user_id, -cost, reason=f"drawimg.{mode}")
        else:
            self._inc_user_today_experience(user_id)
        source = Path(path)
        sent, send_err = await self._send_image(context, source)
        if sent:
            try:
                scope_key = self._image_scope_key(context)
                recent_dir = Path(self.data_dir) / "recent"
                recent_dir.mkdir(parents=True, exist_ok=True)
                recent_file = recent_dir / f"rec_{user_id[:16]}_{int(time.time())}_{uuid.uuid4().hex[:6]}.png"
                recent_file.write_bytes(source.read_bytes())
                user_imgs = self.recent_images.setdefault(scope_key, [])
                user_imgs.append((time.time(), str(recent_file)))
                self.recent_images[scope_key] = user_imgs[-5:]
                self._save_recent_images()
            except Exception:
                pass
            if mode == "img2img_multi" and edit_urls:
                self._clear_recent_images(self._image_scope_key(context), edit_urls)
            try:
                qq = getattr(self.context, "qq", None)
                if qq:
                    action_card = await self._build_result_card(
                        context,
                        prompt,
                        str(source),
                        self._user_model(user_id),
                        cost,
                        cached=False,
                        revised_prompt=revised_prompt,
                    )
                    msg_id = getattr(context, "message_id", None)
                    await qq.send_card(context.conversation_id, _normalize_scene(context), action_card, msg_id=msg_id)
            except Exception as e:
                logger.warning("Failed to send action card: %s", e)

        source.unlink(missing_ok=True)
        if not sent:
            await self._change_balance(user_id, cost, reason=f"drawimg.refund.{mode}")  # refund
            err_suffix = f"（原因：{send_err}）" if send_err else ""
            return f"图片已生成但 QQ 发送失败{err_suffix}，本次积分已退还；请稍后重试。"
        return ""

    @staticmethod
    def _image_mime(data: bytes) -> tuple[str, str]:
        if data.startswith(b"\x89PNG\r\n\x1a\n"):
            return "image/png", "png"
        if data.startswith(b"\xff\xd8\xff"):
            return "image/jpeg", "jpg"
        if data[:4] == b"RIFF" and data[8:12] == b"WEBP":
            return "image/webp", "webp"
        if data[:6] in (b"GIF87a", b"GIF89a"):
            return "image/gif", "gif"
        return "application/octet-stream", "png"

    @staticmethod
    def _image_candidates(value: Any) -> list[tuple[str, str]]:
        candidates: list[tuple[str, str]] = []
        if isinstance(value, dict):
            for key in (
                "b64_json", "partial_image_b64", "base64", "result", "data", "output",
                "response", "tool_calls", "arguments", "image_generation_call", "url",
                "image_url", "image", "images", "choices", "items", "candidates",
                "output_text", "content_parts",
            ):
                if key in value:
                    candidates.extend(DrawImgServicePlugin._image_candidates(value[key]))
            if isinstance(value.get("content"), (list, dict, str)):
                candidates.extend(DrawImgServicePlugin._image_candidates(value["content"]))
            if isinstance(value.get("text"), str):
                candidates.extend(DrawImgServicePlugin._image_candidates(value["text"]))
        elif isinstance(value, list):
            for item in value:
                candidates.extend(DrawImgServicePlugin._image_candidates(item))
        elif isinstance(value, str):
            text = value.strip()
            if text[:1] in {"{", "["}:
                try:
                    parsed = json.loads(text)
                except (TypeError, ValueError):
                    parsed = None
                if parsed is not None:
                    return DrawImgServicePlugin._image_candidates(parsed)
            if text.startswith("data:image/") and ";base64," in text:
                candidates.append(("data", text))
            elif re.fullmatch(r"https?://[^\s<>\"']+", text, re.IGNORECASE):
                candidates.append(("url", text))
            elif len(text) > 64 and re.fullmatch(r"[A-Za-z0-9+/=\s]+", text):
                candidates.append(("b64", re.sub(r"\s+", "", text)))
        return candidates

    async def _save_response_images(self, value: Any) -> tuple[str, str]:
        output_dir = Path(self.data_dir) / "output"
        output_dir.mkdir(parents=True, exist_ok=True)
        for kind, payload in self._image_candidates(value):
            if kind == "url":
                path, error = await self._download_result(payload)
                if not error:
                    return str(path), ""
                continue
            raw = payload
            if kind == "data":
                try:
                    raw = payload.split(",", 1)[1]
                except IndexError:
                    continue
            try:
                decoded = base64.b64decode(raw, validate=False)
            except (ValueError, TypeError):
                continue
            if not decoded or not self._image_mime(decoded)[0].startswith("image/"):
                continue
            path = output_dir / f"dg_{uuid.uuid4().hex}.png"
            path.write_bytes(decoded)
            return str(path), ""
        return "", ""

    async def _save_chat_images(self, content: Any) -> tuple[str, str]:
        if not content:
            return "", "生成失败：接口未返回内容"
        saved = await self._save_response_images(content)
        if saved[0]:
            return saved
        text = content if isinstance(content, str) else json.dumps(content, ensure_ascii=False)
        matches = list(re.finditer(r"data:image/([a-zA-Z0-9.+-]+);base64,([A-Za-z0-9+/=\s]+)", text))
        output_dir = Path(self.data_dir) / "output"
        output_dir.mkdir(parents=True, exist_ok=True)
        for match in reversed(matches):
            payload = re.sub(r"\s+", "", match.group(2))
            try:
                raw = base64.b64decode(payload, validate=False)
            except (ValueError, TypeError):
                continue
            if len(raw) <= 0:
                continue
            path = output_dir / f"dg_{uuid.uuid4().hex}.png"
            path.write_bytes(raw)
            return str(path), ""
        for match in reversed(list(re.finditer(r"https?://[^\s)\"'<>]+", text, re.IGNORECASE))):
            path, download_error = await self._download_result(match.group(0))
            if download_error:
                continue
            return str(path), ""
        return "", "生成失败：回复中没有可用的图片内容"

    async def _save_result(self, response: httpx.Response) -> tuple[str, str, str]:
        if response.status_code >= 400:
            data = self._json(response)
            message = str(data.get("error", {}).get("message") or data.get("message") or f"HTTP {response.status_code}")[:200] if isinstance(data, dict) else f"HTTP {response.status_code}"
            return "", f"生成失败：{message}", ""
        data = self._json(response)
        items = data.get("data") if isinstance(data, dict) else None
        if not isinstance(items, list) or not items:
            return "", "生成失败：接口未返回图片", ""
        item = items[0]
        output_dir = Path(self.data_dir) / "output"
        output_dir.mkdir(parents=True, exist_ok=True)
        path = output_dir / f"dg_{uuid.uuid4().hex}.png"
        b64 = item.get("b64_json")
        if isinstance(b64, str) and b64:
            path.write_bytes(base64.b64decode(b64))
        else:
            url = str(item.get("url") or "")
            if not url:
                return "", "生成失败：接口未返回图片内容", ""
            path, download_error = await self._download_result(url)
            if download_error:
                return "", download_error, ""
        if not path.is_file() or path.stat().st_size <= 0:
            path.unlink(missing_ok=True)
            return "", "生成失败：图片内容为空", ""
        revised = str(item.get("revised_prompt") or "") if isinstance(item, dict) else ""
        return str(path), "", revised

    @staticmethod
    def _json(response: httpx.Response) -> dict[str, Any]:
        try:
            data = response.json()
        except ValueError:
            return {}
        return data if isinstance(data, dict) else {}

    def _error_text(self, response: httpx.Response) -> str:
        data = self._json(response)
        if isinstance(data, dict):
            err = data.get("error")
            if isinstance(err, dict):
                return str(err.get("message") or "")
            return str(data.get("message") or "")
        return ""

    async def _download_result(self, url: str) -> tuple[Path, str]:
        output_dir = Path(self.data_dir) / "output"
        output_dir.mkdir(parents=True, exist_ok=True)
        path = output_dir / f"dg_{uuid.uuid4().hex}.png"
        headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36",
            "Referer": f"{self._api_base_url()}/",
        }
        last = ""
        for attempt in range(3):
            try:
                async with httpx.AsyncClient(timeout=20, follow_redirects=True) as client:
                    download = await client.get(url, headers=headers)
                download.raise_for_status()
                if not download.content:
                    raise httpx.HTTPError("empty body")
                path.write_bytes(download.content)
                return path, ""
            except httpx.HTTPStatusError as exc:
                last = f"HTTP {exc.response.status_code}"
            except httpx.HTTPError as exc:
                last = type(exc).__name__
            await asyncio.sleep(1 + attempt)
        return path, f"生成成功但图片下载失败（{last}，可能是图片链接已过期或被网络拦截），请重试或更换模型。"

    async def _download_image(self, url: str) -> tuple[bytes, str]:
        if not url:
            return b"", "图片链接为空"
        if url.startswith("data:image/"):
            try:
                _, encoded = url.split(",", 1)
                return base64.b64decode(encoded), ""
            except Exception as e:
                return b"", f"Base64 解析失败: {e}"
        local_p = Path(url)
        try:
            if local_p.is_file():
                return local_p.read_bytes(), ""
        except Exception:
            pass
        headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36"}
        try:
            async with httpx.AsyncClient(timeout=20, follow_redirects=True) as client:
                response = await client.get(url, headers=headers)
            response.raise_for_status()
        except httpx.HTTPError:
            return b"", "网络下载失败"
        if len(response.content) > 20 * 1024 * 1024:
            return b"", "图片超过 20MB"
        if response.status_code >= 400 or not response.content:
            return b"", f"HTTP {response.status_code}"
        return response.content, ""

    def _prepare_effective_prompt(self, user_id: str, prompt: str) -> str:
        effective_prompt = (prompt or "优化这张图片").strip()
        if self._user_prompt_guard(user_id):
            effective_prompt = f"{PROMPT_GUARD_PREFIX}{effective_prompt}"
        trans_mode = self._user_transparent_mode(user_id)
        if trans_mode != "off":
            effective_chroma = _resolve_chroma_mode(trans_mode, effective_prompt)
            if effective_chroma == "blue":
                suffix = CHROMA_KEY_BLUE_SUFFIX
            elif effective_chroma == "red":
                suffix = CHROMA_KEY_RED_SUFFIX
            elif effective_chroma == "yellow":
                suffix = CHROMA_KEY_YELLOW_SUFFIX
            else:
                suffix = CHROMA_KEY_GREEN_SUFFIX
            effective_prompt = f"{effective_prompt}{suffix}"
        return effective_prompt

    async def _request_generate(self, context: MessageContext, prompt: str, key: str = "", base: str = "") -> tuple[str, str, str]:
        user_id = self._user_id(context)
        model = self._user_model(user_id)
        size_raw = self._user_size(user_id)
        api_size, aspect_ratio = _resolve_api_size(size_raw, model)
        quality = self._user_quality(user_id)
        timeout_sec = float(self._get_cfg("request_timeout_sec", 180))

        effective_prompt = self._prepare_effective_prompt(user_id, prompt)

        payload: dict[str, Any] = {"model": model, "prompt": effective_prompt, "n": 1}
        if api_size != "auto":
            payload["size"] = api_size
        if quality != "auto":
            payload["quality"] = quality
        if bool(self._get_cfg("prefer_b64_response", True)) and not self._b64_rejected:
            payload["response_format"] = "b64_json"

        headers = {"Authorization": f"Bearer {key}", "Content-Type": "application/json"}
        async with httpx.AsyncClient(base_url=base, timeout=timeout_sec, follow_redirects=False) as client:
            response = await client.post("/v1/images/generations", json=payload, headers=headers)
            if response.status_code in {400, 422} and "response_format" in payload:
                self._b64_rejected = True
                payload.pop("response_format", None)
                response = await client.post("/v1/images/generations", json=payload, headers=headers)
            if response.status_code in {400, 422} and "quality" in payload:
                payload.pop("quality", None)
                response = await client.post("/v1/images/generations", json=payload, headers=headers)

        if response.status_code in {400, 404, 405, 422}:
            err_msg = self._error_text(response).lower()
            # 当上游/网关已明确告知是生图模型（如 Model ... is an image model）或模型名显式包含生图特征时，禁止降级到 chat；否则允许平滑降级到对话补全端点出图
            if not self.is_pure_image_model(model, err_msg) and (
                any(kw in err_msg for kw in ("not supported on /v1/images/generations", "not supported", "not found", "chat", "unknown model", "route"))
                or response.status_code in {404, 405}
            ):
                chat_path, chat_err = await self._request_generate_chat(context, effective_prompt, key, base)
                if chat_path or (chat_err and not chat_err.startswith("HTTP 404")):
                    return chat_path, chat_err, ""

        return await self._save_result(response)

    async def _request_generate_chat(self, context: MessageContext, prompt: str, key: str = "", base: str = "") -> tuple[str, str]:
        user_id = self._user_id(context)
        model = self._user_model(user_id)
        size_raw = self._user_size(user_id)
        api_size, aspect_ratio = _resolve_api_size(size_raw, model)
        quality = self._user_quality(user_id)
        timeout_sec = float(self._get_cfg("request_timeout_sec", 180))

        content_parts: list[dict[str, Any]] = [{"type": "text", "text": prompt}]
        payload: dict[str, Any] = {
            "model": model,
            "messages": [{"role": "user", "content": content_parts}],
            "stream": False,
        }
        if api_size != "auto":
            payload["size"] = api_size
        if aspect_ratio:
            payload["aspect_ratio"] = aspect_ratio
        if quality != "auto":
            payload["quality"] = quality
        headers = {"Authorization": f"Bearer {key}", "Content-Type": "application/json"}
        async with httpx.AsyncClient(base_url=base, timeout=timeout_sec, follow_redirects=False) as client:
            response = await client.post("/v1/chat/completions", json=payload, headers=headers)
            if response.status_code in {400, 422} and any(k in payload for k in ("size", "aspect_ratio", "quality")):
                payload.pop("size", None)
                payload.pop("aspect_ratio", None)
                payload.pop("quality", None)
                response = await client.post("/v1/chat/completions", json=payload, headers=headers)
        if response.status_code >= 400:
            data = self._json(response)
            message = str(data.get("error", {}).get("message") or data.get("message") or f"HTTP {response.status_code}")[:200] if isinstance(data, dict) else f"HTTP {response.status_code}"
            return "", f"生成失败：{message}"
        data = self._json(response)
        if not data and response.text:
            events: list[dict[str, Any]] = []
            for line in response.text.splitlines():
                candidate = line.strip()
                if candidate.startswith("data:"):
                    candidate = candidate[5:].strip()
                if not candidate or candidate == "[DONE]":
                    continue
                try:
                    item = json.loads(candidate)
                except (TypeError, ValueError):
                    continue
                if isinstance(item, dict):
                    events.append(item)
            if events:
                data = {"output": events}
        saved = await self._save_response_images(data)
        if saved[0]:
            return saved
        choices = data.get("choices") if isinstance(data, dict) else None
        content = ""
        if isinstance(choices, list) and choices and isinstance(choices[0], dict):
            message = choices[0].get("message") or {}
            if isinstance(message, dict):
                saved = await self._save_response_images(message.get("images"))
                if saved[0]:
                    return saved
                content = message.get("content") or ""
        if not content:
            keys = ", ".join(str(k) for k in data.keys()) if isinstance(data, dict) else "无"
            return "", f"生成失败：接口返回了空内容（字段：{keys[:240]}）。请确认当前模型支持图像生成。"
        return await self._save_chat_images(content)

    async def _request_edit_extra_body(
        self, context: MessageContext, prompt: str, images: list[bytes], key: str = "", base: str = "", endpoint: str = ""
    ) -> tuple[str, str]:
        user_id = self._user_id(context)
        model = self._user_model(user_id)
        size_raw = self._user_size(user_id)
        api_size, aspect_ratio = _resolve_api_size(size_raw, model)
        timeout_sec = float(self._get_cfg("request_timeout_sec", 180))

        image_uris: list[str] = []
        for img_bytes in images:
            if not img_bytes:
                continue
            mime = "image/png"
            if img_bytes.startswith(b"\xff\xd8\xff"):
                mime = "image/jpeg"
            elif img_bytes.startswith(b"RIFF") and b"WEBP" in img_bytes[:16]:
                mime = "image/webp"
            b64_str = base64.b64encode(img_bytes).decode("ascii")
            image_uris.append(f"data:{mime};base64,{b64_str}")

        if not image_uris:
            return "", "改图失败：未检测到有效的输入图片"

        effective_prompt = self._prepare_effective_prompt(user_id, prompt)

        payload: dict[str, Any] = {
            "model": model,
            "prompt": effective_prompt,
            "extra_body": {
                "image": image_uris,
                "response_format": "b64_json",
            },
        }
        if api_size != "auto":
            payload["size"] = api_size
        if aspect_ratio:
            payload["ratio"] = aspect_ratio

        headers = {"Authorization": f"Bearer {key}", "Content-Type": "application/json"}
        target_path = (endpoint or "").strip() or "/v1/images/generations"
        client_base = None if target_path.startswith(("http://", "https://")) else base
        async with httpx.AsyncClient(base_url=client_base, timeout=timeout_sec, follow_redirects=False) as client:
            response = await client.post(target_path, json=payload, headers=headers)
            if response.status_code in {400, 422} and "extra_body" in payload and "response_format" in payload["extra_body"]:
                payload["extra_body"].pop("response_format", None)
                response = await client.post(target_path, json=payload, headers=headers)

        path, error, _ = await self._save_result(response)
        if path:
            return path, ""
        return "", error or f"改图失败：当前模型「{model}」使用扩展 extra_body 协议未返回有效图像。"

    # 别名兼容
    _request_edit_agnes = _request_edit_extra_body

    async def _request_edit_custom(
        self,
        context: MessageContext,
        prompt: str,
        images: list[bytes],
        key: str = "",
        base: str = "",
        endpoint: str = "",
        format_type: str = "",
    ) -> tuple[str, str]:
        """通过用户自定义端点或格式发起改图请求"""
        ep = (endpoint or "").strip()
        fmt = (format_type or "").strip().lower()

        if not ep:
            if fmt in ("openai_edits", "form_data"):
                ep = "/v1/images/edits"
            elif fmt in ("chat_completions", "chat"):
                ep = "/v1/chat/completions"
            else:
                ep = "/v1/images/generations"

        if not fmt:
            if "edits" in ep:
                fmt = "openai_edits"
            elif "chat" in ep:
                fmt = "chat_completions"
            else:
                fmt = "openai_extra_body"

        if fmt in ("openai_edits", "form_data"):
            return await self._request_edit_images_api(context, prompt, images, key, base, endpoint=ep)
        elif fmt in ("chat_completions", "chat"):
            return await self._request_edit_chat(context, prompt, images, key, base, endpoint=ep)
        else:
            return await self._request_edit_extra_body(context, prompt, images, key, base, endpoint=ep)

    async def _request_edit(self, context: MessageContext, prompt: str, images: list[bytes], key: str = "", base: str = "") -> tuple[str, str]:
        user_id = self._user_id(context)
        model = self._user_model(user_id)

        rule_meta = self.resolve_model_rule(model)
        protocol = rule_meta.get("protocol", PROTOCOL_AUTO)
        source = rule_meta.get("source", "auto")
        custom_endpoint = rule_meta.get("custom_endpoint", "")
        custom_format = rule_meta.get("custom_format", "")
        logger.info(
            "Resolving edit protocol for model '%s': protocol=%s (source=%s, custom_endpoint=%s, custom_format=%s)",
            model, protocol, source, custom_endpoint, custom_format
        )

        if protocol == PROTOCOL_TEXT_ONLY:
            return "", f"改图失败：当前生图模型「{model}」配置为纯文生图模型，不支持单图/多图改图（/dge、/dgm）。如需改图请切换至支持改图的模型。"

        if protocol == PROTOCOL_CUSTOM or custom_endpoint:
            path, error = await self._request_edit_custom(
                context, prompt, images, key, base, endpoint=custom_endpoint, format_type=custom_format
            )
            if path:
                return path, ""
            return "", error or f"改图失败：当前模型「{model}」使用自定义端点未返回有效图像。"

        if protocol == PROTOCOL_EXTRA_BODY:
            path, error = await self._request_edit_extra_body(context, prompt, images, key, base)
            if path:
                return path, ""
            return "", error or f"改图失败：当前模型「{model}」使用扩展 JSON 协议未返回有效图像。"

        if protocol == PROTOCOL_STANDARD_EDITS:
            path, error = await self._request_edit_images_api(context, prompt, images, key, base)
            if path:
                return path, ""
            return "", error or f"改图失败：当前模型「{model}」使用标准表单协议未返回有效图像。"

        if protocol == PROTOCOL_CHAT:
            path, error = await self._request_edit_chat(context, prompt, images, key, base)
            if path:
                return path, ""
            return "", error or f"改图失败：当前模型「{model}」使用多模态视觉协议未返回有效图像。"

        return await self._request_edit_auto_pipeline(context, prompt, images, key, base, model)

    async def _request_edit_auto_pipeline(
        self, context: MessageContext, prompt: str, images: list[bytes], key: str = "", base: str = "", model: str = ""
    ) -> tuple[str, str]:
        user_id = self._user_id(context)
        m = model or self._user_model(user_id)

        path, error1 = await self._request_edit_extra_body(context, prompt, images, key, base)
        if path:
            self._record_learned_protocol(m, PROTOCOL_EXTRA_BODY, "初次改图自动探测命中")
            logger.info("Auto-probe succeeded for model '%s': learned protocol -> %s", m, PROTOCOL_EXTRA_BODY)
            return path, ""

        path, error2 = await self._request_edit_images_api(context, prompt, images, key, base)
        if path:
            self._record_learned_protocol(m, PROTOCOL_STANDARD_EDITS, "初次改图自动探测命中")
            logger.info("Auto-probe succeeded for model '%s': learned protocol -> %s", m, PROTOCOL_STANDARD_EDITS)
            return path, ""

        path, error3 = await self._request_edit_chat(context, prompt, images, key, base)
        if path:
            self._record_learned_protocol(m, PROTOCOL_CHAT, "初次改图自动探测命中")
            logger.info("Auto-probe succeeded for model '%s': learned protocol -> %s", m, PROTOCOL_CHAT)
            return path, ""

        return "", f"改图探测失败：模型「{m}」未能匹配到可用的改图端点协议。排查详情：extra_body({error1[:60]}); edits({error2[:60]}); chat({error3[:60]})。您可在管理台「模型端点」分页手动为该模型指定协议。"

    async def _request_edit_images_api(
        self, context: MessageContext, prompt: str, images: list[bytes], key: str = "", base: str = "", endpoint: str = ""
    ) -> tuple[str, str]:
        user_id = self._user_id(context)
        model = self._user_model(user_id)
        size = self._user_size(user_id)
        quality = self._user_quality(user_id)
        timeout_sec = float(self._get_cfg("request_timeout_sec", 180))

        effective_prompt = self._prepare_effective_prompt(user_id, prompt)
        data: dict[str, str] = {"model": model, "prompt": effective_prompt, "n": "1"}
        if size != "auto":
            data["size"] = size
        if quality != "auto":
            data["quality"] = quality
        if bool(self._get_cfg("prefer_b64_response", True)) and not self._b64_rejected:
            data["response_format"] = "b64_json"
        if len(images) == 1:
            files = [("image", ("image.png", images[0], "image/png"))]
        else:
            files = [("image", (f"input_{index}.png", image, "image/png")) for index, image in enumerate(images)]
        headers = {"Authorization": f"Bearer {key}"}
        target_path = (endpoint or "").strip() or "/v1/images/edits"
        client_base = None if target_path.startswith(("http://", "https://")) else base
        async with httpx.AsyncClient(base_url=client_base, timeout=timeout_sec, follow_redirects=False) as client:
            response = await client.post(target_path, data=data, files=files, headers=headers)
            if response.status_code == 400 and "response_format" in self._error_text(response).lower():
                data.pop("response_format", None)
                response = await client.post(target_path, data=data, files=files, headers=headers)
        if response.status_code in {404, 405, 415, 422}:
            return "", ""
        path, error, _ = await self._save_result(response)
        if path:
            return path, ""
        return "", error

    async def _request_edit_chat(
        self, context: MessageContext, prompt: str, images: list[bytes], key: str = "", base: str = "", endpoint: str = ""
    ) -> tuple[str, str]:
        user_id = self._user_id(context)
        model = self._user_model(user_id)
        size = self._user_size(user_id)
        quality = self._user_quality(user_id)
        timeout_sec = float(self._get_cfg("request_timeout_sec", 180))

        effective_prompt = self._prepare_effective_prompt(user_id, prompt)
        content_parts: list[dict[str, Any]] = [{"type": "text", "text": effective_prompt}]
        for data in images:
            mime, _ = self._image_mime(data)
            if mime == "application/octet-stream":
                mime = "image/png"
            content_parts.append({
                "type": "image_url",
                "image_url": {"url": f"data:{mime};base64,{base64.b64encode(data).decode()}"},
            })
        payload = {
            "model": model,
            "messages": [{"role": "user", "content": content_parts}],
            "stream": False,
        }
        if size != "auto":
            payload["size"] = size
        if quality != "auto":
            payload["quality"] = quality
        headers = {"Authorization": f"Bearer {key}", "Content-Type": "application/json"}
        target_path = (endpoint or "").strip() or "/v1/chat/completions"
        client_base = None if target_path.startswith(("http://", "https://")) else base
        async with httpx.AsyncClient(base_url=client_base, timeout=timeout_sec, follow_redirects=False) as client:
            response = await client.post(target_path, json=payload, headers=headers)
        if response.status_code >= 400:
            data = self._json(response)
            message = str(data.get("error", {}).get("message") or data.get("message") or f"HTTP {response.status_code}")[:200] if isinstance(data, dict) else f"HTTP {response.status_code}"
            return "", f"生成失败：{message}"
        data = self._json(response)
        if not data and response.text:
            events: list[dict[str, Any]] = []
            for line in response.text.splitlines():
                candidate = line.strip()
                if candidate.startswith("data:"):
                    candidate = candidate[5:].strip()
                if not candidate or candidate == "[DONE]":
                    continue
                try:
                    item = json.loads(candidate)
                except (TypeError, ValueError):
                    continue
                if isinstance(item, dict):
                    events.append(item)
            if events:
                data = {"output": events}
        saved = await self._save_response_images(data)
        if saved[0]:
            return saved
        choices = data.get("choices") if isinstance(data, dict) else None
        content = ""
        if isinstance(choices, list) and choices and isinstance(choices[0], dict):
            message = choices[0].get("message") or {}
            if isinstance(message, dict):
                saved = await self._save_response_images(message.get("images"))
                if saved[0]:
                    return saved
                content = message.get("content") or ""
        if not content:
            keys = ", ".join(str(k) for k in data.keys()) if isinstance(data, dict) else "无"
            return "", f"生成失败：接口返回了空内容（字段：{keys[:240]}）。请确认当前模型支持图像编辑。"
        return await self._save_chat_images(content)

    async def _request_edit_responses(self, context: MessageContext, prompt: str, images: list[bytes], key: str = "", base: str = "") -> tuple[str, str]:
        user_id = self._user_id(context)
        model = self._user_model(user_id)
        timeout_sec = float(self._get_cfg("request_timeout_sec", 180))

        content: list[dict[str, str]] = [{"type": "input_text", "text": prompt or "优化这张图片"}]
        for image in images:
            mime, _ = self._image_mime(image)
            if mime == "application/octet-stream":
                mime = "image/png"
            content.append({"type": "input_image", "image_url": f"data:{mime};base64,{base64.b64encode(image).decode()}"})
        payload: dict[str, Any] = {
            "model": model,
            "input": [{"role": "user", "content": content}],
            "tools": [{"type": "image_generation", "action": "edit", "model": model}],
        }
        headers = {"Authorization": f"Bearer {key}", "Content-Type": "application/json"}
        async with httpx.AsyncClient(base_url=base, timeout=timeout_sec, follow_redirects=False) as client:
            response = await client.post("/v1/responses", json=payload, headers=headers)
        if response.status_code in {404, 405, 415, 422}:
            return "", "生成失败：当前服务不支持图像编辑协议（images/chat/responses 均不可用）。"
        if response.status_code >= 400:
            return "", f"生成失败：{self._error_text(response) or f'HTTP {response.status_code}'}"
        data = self._json(response)
        saved = await self._save_response_images(data)
        if saved[0]:
            return saved
        return "", "生成失败：Responses 接口未返回图片内容。"

    async def _send_image(self, context: MessageContext, path: Path) -> tuple[bool, str]:
        source = Path(path)
        if not source.is_file():
            return False, f"本地图片不存在: {source}"
        if source.stat().st_size <= 0:
            return False, "本地图片文件为空"
        scene = _normalize_scene(context)
        media = getattr(self.context, "media", None)
        qq = getattr(self.context, "qq", None)
        conv_id = (
            getattr(context, "conversation_id", "")
            or getattr(context, "group_id", "")
            or getattr(context, "sender_id", "")
        )
        if media is None or qq is None or not conv_id:
            return False, f"服务未就绪 (media={bool(media)}, qq={bool(qq)}, conv_id={bool(conv_id)})"
        try:
            msg_id = getattr(context, "message_id", None)
            if scene in {"c2c", "group"}:
                request = await media.prepare(scene, conv_id, 1, source)
                uploaded = await qq.upload_media_file(request, source)
                file_info = uploaded.get("file_info") if isinstance(uploaded, dict) else None
                if not file_info:
                    return False, f"上传媒体接口未返回 file_info: {uploaded}"
                try:
                    if msg_id:
                        await qq.send_media(conv_id, scene, str(file_info), msg_id=msg_id)
                    else:
                        await qq.send_media(conv_id, scene, str(file_info))
                except (TypeError, Exception) as send_err:
                    if msg_id:
                        logger.warning("Sending media with msg_id failed (%s), retrying without msg_id...", send_err)
                        await qq.send_media(conv_id, scene, str(file_info))
                    else:
                        raise
                return True, ""
            if scene in {"channel", "guild_direct"}:
                try:
                    if msg_id:
                        await qq.send_channel_media(conv_id, scene, file_image=source.read_bytes(), msg_id=msg_id)
                    else:
                        await qq.send_channel_media(conv_id, scene, file_image=source.read_bytes())
                except (TypeError, Exception) as send_err:
                    if msg_id:
                        logger.warning("Sending channel media with msg_id failed (%s), retrying without msg_id...", send_err)
                        await qq.send_channel_media(conv_id, scene, file_image=source.read_bytes())
                    else:
                        raise
                return True, ""
            return False, f"不支持的消息场景: {scene}"
        except Exception as e:
            logger.exception("Failed to send image media via QQ: %s", e)
            return False, f"{type(e).__name__}: {e}"


    def _record_history(self, user_id: str, prompt: str, url: str, model: str) -> None:
        return

    async def _build_result_card(
        self, context: MessageContext, prompt: str, image_url: str, model: str, cost: int, cached: bool = False, revised_prompt: str = ""
    ) -> Card:
        uid = self._user_id(context)
        rem = await self._get_balance(uid)
        cached_tag = "（⚡ 命中秒回缓存）" if cached else ""
        short_prompt = prompt[:60] + ("…" if len(prompt) > 60 else "")
        img_md = f"![生成的图片 #1024px #1024px]({image_url})\n\n" if image_url.startswith("http") else ""

        revised_block = ""
        clean_revised = (revised_prompt or "").strip()
        for suffix in (
            CHROMA_KEY_GREEN_SUFFIX,
            CHROMA_KEY_BLUE_SUFFIX,
            CHROMA_KEY_RED_SUFFIX,
            CHROMA_KEY_YELLOW_SUFFIX,
            "pure solid green screen background, chroma key green backdrop (#00FF00)",
            "pure solid blue screen background, chroma key blue backdrop (#0000FF)",
            "pure solid red screen background, chroma key red backdrop (#FF0000)",
            "pure solid yellow screen background, chroma key yellow backdrop (#FFFF00)",
            "pure solid green screen background, chroma key green background",
            "pure solid green screen background",
            "pure solid blue screen background",
            "pure solid red screen background",
            "pure solid yellow screen background",
        ):
            if suffix in clean_revised:
                clean_revised = clean_revised.replace(suffix, "").strip(", ")
        if clean_revised and clean_revised.lower() != prompt.strip().lower():
            short_rev = clean_revised[:100] + ("…" if len(clean_revised) > 100 else "")
            revised_block = f"\n- **模型优化提示词**：`{short_rev}`"

        markdown = (
            f"### 🎨 AI 绘图已生成 {cached_tag}\n\n"
            f"{img_md}"
            f"- **提示词**：`{short_prompt}`\n"
            f"- **模型**：`{model}`（本次扣除 **{cost}** 积分）\n"
            f"- **剩余余额**：**{rem}** 积分{revised_block}\n\n"
            f"点击下方按钮可快捷改图、调优风格或充值。"
        )
        rows = [
            [
                _btn("再来一张", f"/dg {prompt}", action_type=1, click_limit=3),
                _btn("基于此图改图", "/dge ", fill=True),
            ]
        ]
        if clean_revised and clean_revised.lower() != prompt.strip().lower():
            rows.append([
                _btn("✨ 用优化词生图", f"/dg {clean_revised[:60]}", action_type=1),
                _btn("尺寸与画质", "/dg size"),
            ])
            rows.append([
                _btn("选择预设", "/dg style"),
                _btn("充值积分", "/dg pay ", fill=True),
            ])
            rows.append([
                _btn("我的状态", "/dg status"),
                _btn("返回主菜单", "/dg"),
            ])
        else:
            rows.append([
                _btn("选择预设", "/dg style"),
                _btn("尺寸/质量", "/dg size"),
            ])
            rows.append([
                _btn("我的状态", "/dg status"),
                _btn("充值积分", "/dg pay ", fill=True),
            ])
            rows.append([
                _btn("返回主菜单", "/dg"),
            ])
        return Card("AI 绘图结果", markdown, rows=rows)

    # ---------- UI Cards & Sub-handlers ----------

    async def _main_menu_card(self, context: MessageContext) -> Card:
        uid = self._user_id(context)
        bal = await self._get_balance(uid)
        model = self._user_model(uid)
        markdown = (
            "## 🎨 绘图服务\n\n"
            f"当前默认模型：`{model}`（单次生图消耗 {self._model_cost(model)} 积分）\n"
            f"您的积分余额：**{bal}** 积分\n\n"
            "直接发送 `/dg <提示词>` 开始创作，无需自备 Key！"
        )
        row5 = [_btn("充值积分", "/dg pay ", fill=True)]
        if context.is_admin:
            row5.append(_btn("管理员菜单", "/dg admin", permission=1))
        rows = [
            [
                _btn("文生图", "/dg ", fill=True),
                _btn("单图编辑", "/dge ", fill=True),
            ],
            [
                _btn("多图编辑", "/dgm ", fill=True),
                _btn("选择模型", "/dg models"),
            ],
            [
                _btn("选择预设", "/dg style"),
                _btn("尺寸/质量", "/dg size"),
            ],
            [
                _btn("免抠底图", "/dg bg"),
                _btn("我的状态", "/dg status"),
            ],
            row5,
        ]
        return Card("绘图服务主菜单", markdown, rows=rows[:5])

    async def _menu_card(self, context: MessageContext, page: str = "") -> Card:
        page = (page or "").strip().lower()
        aliases = {
            "生图": "draw",
            "设置": "settings",
            "积分": "credit",
            "管理": "admin",
        }
        page = aliases.get(page, page)
        back = [_btn("返回主菜单", "/dg")]
        pages = {
            "draw": (
                "开始创作",
                "选择一种操作，点击后在指令末尾补充提示词即可。",
                [
                    [
                        _btn("文生图", "/dg ", fill=True),
                        _btn("单图编辑", "/dge ", fill=True),
                    ],
                    [
                        _btn("多图编辑", "/dgm ", fill=True),
                        _btn("选择模型", "/dg models"),
                    ],
                    [
                        _btn("选择预设", "/dg style"),
                        _btn("尺寸/质量", "/dg size"),
                    ],
                    [
                        _btn("我的状态", "/dg status"),
                        _btn("充值积分", "/dg pay ", fill=True),
                    ],
                    back,
                ],
            ),
            "settings": (
                "个性化设置",
                "设置会自动保存，下次使用继续生效。",
                [
                    [
                        _btn("选择模型", "/dg models"),
                        _btn("选择预设", "/dg style"),
                    ],
                    [
                        _btn("图片尺寸", "/dg size"),
                        _btn("图片质量", "/dg quality"),
                    ],
                    [
                        _btn("免抠底图", "/dg bg"),
                        _btn("我的状态", "/dg status"),
                    ],
                    [
                        _btn("充值积分", "/dg pay ", fill=True),
                    ],
                    back,
                ],
            ),
        }
        if page in pages:
            title, text, rows = pages[page]
            return Card(title, f"### {title}\n\n{text}", rows=rows)
        return await self._main_menu_card(context)

    async def _status_card(self, context: MessageContext) -> Card:
        uid = self._user_id(context)
        bal = await self._get_balance(uid)
        model = self._user_model(uid)
        model_price = self._model_cost(model)
        rate = float(self._get_cfg("credit_price_yuan", 0.1))
        display_size = _format_size_display(self._user_size(uid))
        display_quality = _format_quality_display(self._user_quality(uid))
        cur_mode = self._user_transparent_mode(uid)
        cur_guard = self._user_prompt_guard(uid)
        mode_status_map = {
            "auto": "✅ 开启 (智能自适应)",
            "blue": "✅ 开启 (纯净蓝幕)",
            "green": "✅ 开启 (经典绿幕)",
            "red": "✅ 开启 (热烈红幕)",
            "yellow": "✅ 开启 (明亮黄幕)",
            "off": "❌ 关闭",
        }
        trans_status = mode_status_map.get(cur_mode, "❌ 关闭")

        markdown = (
            "| 项目 | 当前值 |\n"
            "|---|---|\n"
            f"| 用户编号 | `{uid}` |\n"
            "| 当前模式 | 积分模式 |\n"
            f"| 积分余额 | {bal} |\n"
            f"| 当前模型 | {model} |\n"
            f"| 当前模型单价 | {model_price} 积分/次 |\n"
            f"| 尺寸与画质 | `{display_size}` / `{display_quality}` |\n"
            f"| 免抠透明底 | {trans_status} |\n"
            f"| 提示词防改写 | {'✅ 开启' if cur_guard else '❌ 关闭'} |\n"
            f"| 当前积分单价 | {rate:.2f} 元/积分 |\n"
        )
        rows = [
            [
                _btn("选择模型", "/dg models"),
                _btn("选择预设", "/dg style"),
            ],
            [
                _btn("充值积分", "/dg pay ", fill=True),
                _btn("开始生图", "/dg ", fill=True),
            ],
            [
                _btn("尺寸/质量", "/dg size"),
                _btn("返回主菜单", "/dg"),
            ],
            [
                _btn("充值 10 积分", "/dg pay 10", action_type=1),
                _btn("充值 50 积分", "/dg pay 50", action_type=1),
                _btn("充值 100 积分", "/dg pay 100", action_type=1),
            ],
        ]
        return Card("个人绘图状态", markdown, rows=rows)

    async def _handle_top(self, context: MessageContext) -> str | Card:
        if not context.is_admin:
            return "只有管理员可以查看积分排行。"
        points = self._points()
        if points is not None and hasattr(points, "top_identities"):
            try:
                top_items = await points.top_identities("drawimg", 10)
                ranked = [(str(k), int(v)) for k, v in top_items]
            except Exception:
                ranked = []
        else:
            ranked = []
        if not ranked:
            ranked = sorted(
                (
                    (key, int(credits))
                    for key, credits in self.credits.items()
                    if not key.startswith("_")
                ),
                key=lambda item: item[1],
                reverse=True,
            )[:10]
        if not ranked:
            return "当前没有用户积分记录。"
        lines = ["### 🏆 积分排行（前 10 名）\n", "| 用户编号 | 积分余额 |", "|---|---:|"]
        lines.extend(f"| `{key}` | **{credits}** |" for key, credits in ranked)
        rows = [
            [
                _btn("赠送积分", "/dg give ", fill=True, permission=1),
                _btn("管理员菜单", "/dg admin", permission=1),
            ],
            [
                _btn("返回主菜单", "/dg"),
            ],
        ]
        return Card("积分排行榜", "\n".join(lines), rows=rows)

    async def _handle_style(self, context: MessageContext, args: list[str]) -> str | Card:
        uid = self._user_id(context)
        presets_raw = self._get_cfg("style_presets", DEFAULT_CONFIG["style_presets"])
        parsed_presets: dict[str, str] = {}
        if isinstance(presets_raw, dict) and presets_raw:
            parsed_presets = {str(k): str(v) for k, v in presets_raw.items()}
        elif isinstance(presets_raw, str) and presets_raw.strip():
            if presets_raw.strip().startswith("{"):
                try:
                    obj = json.loads(presets_raw)
                    if isinstance(obj, dict):
                        parsed_presets = {str(k): str(v) for k, v in obj.items()}
                except Exception:
                    pass
            if not parsed_presets:
                for item in presets_raw.split(";"):
                    parts = item.strip().split(":", 1)
                    if len(parts) == 2:
                        parsed_presets[parts[0].strip()] = parts[1].strip()

        if not parsed_presets:
            for item in DEFAULT_CONFIG["style_presets"].split(";"):
                parts = item.strip().split(":", 1)
                if len(parts) == 2:
                    parsed_presets[parts[0].strip()] = parts[1].strip()

        if not args:
            current = self._user_style(uid)
            lines = [
                "### 🎨 风格预设列表\n",
                "| 预设名称 | 提示词预览 | 状态 |",
                "| :--- | :--- | :---: |",
            ]
            for name, val in parsed_presets.items():
                is_active = (val == current or name == current)
                status = "✅ 已选" if is_active else "-"
                clean_val = " ".join(val.replace("|", "｜").replace("\r", " ").replace("\n", " ").split())
                preview = clean_val[:38] + "..." if len(clean_val) > 40 else clean_val
                lines.append(f"| **{name}** | {preview} | {status} |")
            lines.append("\n点击下方预设一键应用，或发送 `/dg style off` 取消预设。")
            lines.append("💡 发送 `/dg style view <预设名>` 可查看该预设的完整提示词。")
            rows = []
            btn_row = []
            for name in list(parsed_presets.keys())[:6]:
                label = f"✓ {name[:8]}" if parsed_presets[name] == current or name == current else name[:10]
                btn_row.append(_btn(label, f"/dg style {name}", action_type=1))
                if len(btn_row) == 3:
                    rows.append(btn_row)
                    btn_row = []
            if btn_row:
                rows.append(btn_row)
            rows.append([
                _btn("我的预设", "/dg style my"),
                _btn("添加预设", "/dg style add ", fill=True),
                _btn("删除预设", "/dg style rm ", fill=True),
            ])
            rows.append([
                _btn("取消风格", "/dg style off", action_type=1),
                _btn("返回主菜单", "/dg"),
            ])
            return Card("风格预设", "\n".join(lines), rows=rows)

        action = args[0].strip()
        if action in {"off", "取消", "关闭", "clear"}:
            self.user_prefs.setdefault(uid, {})["style"] = ""
            self._save_user_prefs()
            return "已取消风格预设，后续将使用原生提示词生图。"
        if action in {"my", "mine", "我的", "我的预设"}:
            user_style = self._user_style(uid) or "未设置"
            return Card("我的风格预设", f"您当前的风格预设附加词为：`{user_style}`", rows=[[
                _btn("选择预设", "/dg style"),
                _btn("取消风格", "/dg style off", action_type=1),
                _btn("返回主菜单", "/dg"),
            ]])
        if action in {"view", "查看", "detail", "详情"}:
            if len(args) < 2:
                return "用法：`/dg style view <预设名>`"
            target = args[1].strip()
            found_val = parsed_presets.get(target)
            if not found_val:
                for k, v in parsed_presets.items():
                    if k.lower() == target.lower():
                        target, found_val = k, v
                        break
            if found_val:
                return Card(
                    f"风格预设：{target}",
                    f"**预设名称**：{target}\n\n**完整提示词**：\n```\n{found_val}\n```",
                    rows=[[
                        _btn("应用此预设", f"/dg style {target}", action_type=1),
                        _btn("返回预设列表", "/dg style"),
                    ]],
                )
            return f"未找到名为 `{target}` 的风格预设。"
        if action in {"add", "新增", "添加"}:
            if len(args) < 2:
                return "用法：`/dg style add <预设名>:<提示词>`"
            rule_str = " ".join(args[1:]).strip()
            parts = rule_str.split(":", 1)
            if len(parts) != 2:
                return "格式错误，请使用：`/dg style add <预设名>:<提示词>`"
            p_name, p_val = parts[0].strip(), parts[1].strip()
            parsed_presets[p_name] = p_val
            self.config["style_presets"] = json.dumps(parsed_presets, ensure_ascii=False)
            self._save_config()
            return f"已成功添加全局预设：**{p_name}** (`{p_val}`)。"
        if action in {"rm", "del", "remove", "删除"}:
            if len(args) < 2:
                return "用法：`/dg style rm <预设名>`"
            p_name = args[1].strip()
            if p_name in parsed_presets:
                del parsed_presets[p_name]
                self.config["style_presets"] = json.dumps(parsed_presets, ensure_ascii=False)
                self._save_config()
                return f"已删除风格预设：**{p_name}**。"
            return f"未找到名为 `{p_name}` 的预设。"
        if action in parsed_presets:
            self.user_prefs.setdefault(uid, {})["style"] = parsed_presets[action]
            self._save_user_prefs()
            clean_val = " ".join(parsed_presets[action].replace("\r", " ").replace("\n", " ").split())
            preview = clean_val[:48] + "..." if len(clean_val) > 50 else clean_val
            return f"已成功应用风格预设：**{action}**\n附加词：`{preview}`"

        # Try case-insensitive lookup
        for k, v in parsed_presets.items():
            if k.lower() == action.lower():
                self.user_prefs.setdefault(uid, {})["style"] = v
                self._save_user_prefs()
                clean_val = " ".join(v.replace("\r", " ").replace("\n", " ").split())
                preview = clean_val[:48] + "..." if len(clean_val) > 50 else clean_val
                return f"已成功应用风格预设：**{k}**\n附加词：`{preview}`"

        custom_style = " ".join(args).strip()
        self.user_prefs.setdefault(uid, {})["style"] = custom_style
        self._save_user_prefs()
        return f"已成功应用自定义风格预设：`{custom_style}`。"

    def _size_and_quality_card(self, context: MessageContext, notice: str = "") -> Card:
        uid = self._user_id(context)
        current_size = self._user_size(uid).lower()
        current_quality = self._user_quality(uid).lower()
        cur_mode = self._user_transparent_mode(uid)
        cur_guard = self._user_prompt_guard(uid)

        selected_ratio = "auto"
        for ratio, info in COMMON_RATIOS.items():
            if current_size == ratio or current_size == info["size"].lower():
                selected_ratio = ratio
                break
        if selected_ratio == "auto" and current_size != "auto":
            selected_ratio = current_size

        display_size = _format_size_display(current_size)
        display_quality = _format_quality_display(current_quality)
        mode_display_map = {
            "auto": "✅ 开启 (智能自适应)",
            "blue": "✅ 开启 (纯净蓝幕)",
            "green": "✅ 开启 (经典绿幕)",
            "red": "✅ 开启 (热烈红幕)",
            "yellow": "✅ 开启 (明亮黄幕)",
            "off": "❌ 关闭",
        }
        trans_display = mode_display_map.get(cur_mode, "❌ 关闭")
        guard_display = "✅ 开启 (锁定原意)" if cur_guard else "❌ 关闭"

        notice_text = f"✨ **{notice}**\n\n" if notice else ""
        content = (
            f"{notice_text}"
            f"⚙️ **当前生图参数与偏好预设：**\n"
            f"• **画面尺寸/比例**：`{display_size}`\n"
            f"• **画面生成画质**：`{display_quality}`\n"
            f"• **免抠透明底图**：`{trans_display}`\n"
            f"• **提示词防改写**：`{guard_display}`\n\n"
            f"💡 *点击按钮一键切换比例与画质（更多比例可发送 `/dg size 3:2`、`2:3` 或 `21:9`）：*"
        )

        def ratio_btn(key: str, text: str) -> Button:
            checked = (selected_ratio == key or current_size == key)
            label = f"✓{text}" if checked else text
            return _btn(label, f"/dg size {key}", action_type=1)

        def quality_btn(key: str, text: str) -> Button:
            checked = (current_quality == key)
            label = f"✓{text}" if checked else text
            return _btn(label, f"/dg quality {key}", action_type=1)

        def trans_btn() -> Button:
            btn_labels = {
                "auto": "免抠设置 (智能)",
                "blue": "免抠设置 (蓝幕)",
                "green": "免抠设置 (绿幕)",
                "red": "免抠设置 (红幕)",
                "yellow": "免抠设置 (黄幕)",
                "off": "免抠底图设置",
            }
            label = btn_labels.get(cur_mode, "免抠底图设置")
            return _btn(label, "/dg bg", action_type=1)

        def guard_btn() -> Button:
            label = "✓ 提示词防改写" if cur_guard else "提示词防改写"
            return _btn(label, "/dg guard toggle", action_type=1)

        rows = [
            [
                ratio_btn("1:1", "1:1 正方"),
                ratio_btn("16:9", "16:9 宽屏"),
                ratio_btn("9:16", "9:16 竖屏"),
            ],
            [
                ratio_btn("4:3", "4:3 横版"),
                ratio_btn("3:4", "3:4 竖版"),
                ratio_btn("auto", "自适应"),
            ],
            [
                quality_btn("auto", "自动画质"),
                quality_btn("standard", "标准质量"),
                quality_btn("hd", "高清 HD"),
            ],
            [
                trans_btn(),
                guard_btn(),
            ],
            [
                _btn("🎨 立即生图", "/dg ", fill=True),
                _btn("返回主菜单", "/dg"),
            ],
        ]
        return Card("尺寸与画质设置", content, rows=rows)

    def _handle_size(self, context: MessageContext, args: list[str]) -> str | Card:
        uid = self._user_id(context)
        if not args:
            return self._size_and_quality_card(context)
        target = args[0].strip().lower()
        if target in {"bg", "trans", "transparent"}:
            return self._transparent_card(context)
        if target == "bg_cycle":
            cycle_order = ["auto", "blue", "green", "red", "yellow", "off"]
            cur_mode = self._user_transparent_mode(uid)
            idx = cycle_order.index(cur_mode) if cur_mode in cycle_order else 5
            new_mode = cycle_order[(idx + 1) % len(cycle_order)]
            self.user_prefs.setdefault(uid, {})["transparent_mode"] = new_mode
            self.user_prefs[uid]["transparent"] = (new_mode != "off")
            self._save_user_prefs()
            mode_desc = {
                "auto": "智能自适应",
                "blue": "纯净蓝幕",
                "green": "经典绿幕",
                "red": "热烈红幕",
                "yellow": "明亮黄幕",
                "off": "关闭",
            }
            return self._size_and_quality_card(context, f"已切换免抠模式为：{mode_desc.get(new_mode, new_mode)}")
        ratio_aliases = {
            "1:1": "1:1", "正方形": "1:1", "方图": "1:1",
            "16:9": "16:9", "横屏": "16:9", "宽屏": "16:9",
            "9:16": "9:16", "竖屏": "9:16", "手机": "9:16",
            "4:3": "4:3", "3:4": "3:4",
            "3:2": "3:2", "2:3": "2:3",
            "21:9": "21:9",
            "auto": "auto", "自动": "auto",
        }
        is_interaction = getattr(context, "message_type", None) == "interaction"
        if target in ratio_aliases:
            resolved = ratio_aliases[target]
            self.user_prefs.setdefault(uid, {})["size"] = resolved
            self._save_user_prefs()
            if is_interaction:
                return self._size_and_quality_card(context, f"已成功切换画面比例为：{resolved}")
            return f"生图尺寸已设置为：`{_format_size_display(resolved)}`。"
        if re.fullmatch(r"\d{3,4}x\d{3,4}", target):
            self.user_prefs.setdefault(uid, {})["size"] = target
            self._save_user_prefs()
            if is_interaction:
                return self._size_and_quality_card(context, f"已成功切换画面尺寸为：{target}")
            return f"生图尺寸已设置为：`{target}`。"
        return "尺寸格式应为常见比例（如 16:9、9:16、1:1、4:3、3:4）或 宽x高（如 1024x1024）或 auto。"

    def _handle_quality(self, context: MessageContext, args: list[str]) -> str | Card:
        uid = self._user_id(context)
        if not args:
            return self._size_and_quality_card(context)
        target = args[0].strip().lower()
        quality_aliases = {
            "auto": "auto", "自动": "auto",
            "standard": "standard", "标清": "standard", "标准": "standard",
            "hd": "hd", "高清": "hd", "高品质": "hd",
            "high": "high", "超清": "high",
            "low": "low", "低": "low",
            "medium": "medium", "中": "medium",
        }
        if target in quality_aliases:
            resolved = quality_aliases[target]
            self.user_prefs.setdefault(uid, {})["quality"] = resolved
            self._save_user_prefs()
            if getattr(context, "message_type", None) == "interaction":
                return self._size_and_quality_card(context, f"已成功切换画质为：{_format_quality_display(resolved)}")
            return f"生成质量已设置为：`{_format_quality_display(resolved)}`。"
        return "质量应为 auto、standard、hd、high、low 或 medium。"

    def _transparent_card(self, context: MessageContext, notice: str = "") -> Card:
        uid = self._user_id(context)
        cur_mode = self._user_transparent_mode(uid)

        mode_display_map = {
            "auto": "✅ 开启 (智能自适应)",
            "blue": "✅ 开启 (纯净蓝幕)",
            "green": "✅ 开启 (经典绿幕)",
            "red": "✅ 开启 (热烈红幕)",
            "yellow": "✅ 开启 (明亮黄幕)",
            "off": "❌ 已关闭",
        }
        mode_desc_map = {
            "auto": "根据提示词主体色彩智能调度红/绿/黄/蓝四色演播室幕布，实现最佳互补与无痕消融。",
            "blue": "纯净蓝幕（#0000FF），黄色是蓝色的互补色，最适合金毛、暖色主体、动物毛发及绿色植物。",
            "green": "经典绿幕（#00FF00），最适合冷色系主体、人物立绘、黑色/白色肖像及常规摄影。",
            "red": "热烈红幕（#FF0000），青色/蓝色是红色的互补色，适合青蓝服饰、碧海生物、冷银机甲与绿色主体。",
            "yellow": "明亮黄幕（#FFFF00），紫色是黄色的互补色，最适合紫色礼服、紫发魔女、藏青大衣与暗夜主体。",
            "off": "生成包含完整背景的常规图片，不执行透明化消融。",
        }

        notice_text = f"✨ **{notice}**\n\n" if notice else ""
        content = (
            f"{notice_text}"
            f"🖼️ **透明免抠底图设置（红绿黄蓝四原色）**\n\n"
            f"• **当前状态**：`{mode_display_map.get(cur_mode, '❌ 已关闭')}`\n"
            f"• **当前说明**：{mode_desc_map.get(cur_mode, '')}\n\n"
            f"💡 **幕布色彩科学选型指引：**\n"
            f"• **智能自适应**：智能识别主体色彩并全自动调度幕布\n"
            f"• **纯净蓝幕**：金毛犬、柴犬、橘猫、金发角色、绿植花草\n"
            f"• **经典绿幕**：常规立绘、冷色系服饰、日常肖像摄影\n"
            f"• **热烈红幕**：青蓝长裙、冷光机甲、海洋生物、绿巨人\n"
            f"• **明亮黄幕**：紫发角色、紫色礼服、藏青服饰、暗夜主体\n\n"
            f"👇 *点击下方按钮一键切换免抠幕布模式：*"
        )

        def mode_btn(key: str, text: str) -> Button:
            checked = (cur_mode == key)
            label = f"✓ {text}" if checked else text
            return _btn(label, f"/dg bg {key}", action_type=1)

        rows = [
            [
                mode_btn("auto", "智能自适应 (推荐)"),
                mode_btn("off", "关闭免抠底图"),
            ],
            [
                mode_btn("blue", "纯净蓝幕"),
                mode_btn("green", "经典绿幕"),
            ],
            [
                mode_btn("red", "热烈红幕"),
                mode_btn("yellow", "明亮黄幕"),
            ],
            [
                _btn("尺寸/画质", "/dg size"),
                _btn("返回主菜单", "/dg"),
            ],
            [
                _btn("🎨 立即生图", "/dg ", fill=True),
            ],
        ]
        return Card("免抠底图设置", content, rows=rows)

    def _handle_transparent(self, context: MessageContext, args: list[str]) -> Card:
        uid = self._user_id(context)
        cur_mode = self._user_transparent_mode(uid)

        cycle_order = ["auto", "blue", "green", "red", "yellow", "off"]
        arg = (args[0].lower().strip() if args else "")

        if not arg or arg in {"menu", "菜单"}:
            return self._transparent_card(context)

        if arg in {"toggle", "切换", "cycle"}:
            idx = cycle_order.index(cur_mode) if cur_mode in cycle_order else 5
            new_mode = cycle_order[(idx + 1) % len(cycle_order)]
        elif arg in {"auto", "智能", "自适应", "smart"}:
            new_mode = "auto"
        elif arg in {"blue", "蓝幕", "蓝底", "蓝色", "blue_screen"}:
            new_mode = "blue"
        elif arg in {"green", "绿幕", "绿底", "绿色", "green_screen"}:
            new_mode = "green"
        elif arg in {"red", "红幕", "红底", "红色", "red_screen"}:
            new_mode = "red"
        elif arg in {"yellow", "黄幕", "黄底", "黄色", "yellow_screen"}:
            new_mode = "yellow"
        elif arg in {"on", "open", "开启", "1", "true", "开"}:
            new_mode = "auto" if cur_mode == "off" else cur_mode
        elif arg in {"off", "close", "关闭", "0", "false", "关"}:
            new_mode = "off"
        else:
            idx = cycle_order.index(cur_mode) if cur_mode in cycle_order else 5
            new_mode = cycle_order[(idx + 1) % len(cycle_order)]

        self.user_prefs.setdefault(uid, {})["transparent_mode"] = new_mode
        self.user_prefs[uid]["transparent"] = (new_mode != "off")
        self._save_user_prefs()

        mode_desc = {
            "auto": "智能自适应",
            "blue": "纯净蓝幕",
            "green": "经典绿幕",
            "red": "热烈红幕",
            "yellow": "明亮黄幕",
            "off": "关闭",
        }
        notice = f"已成功切换免抠模式为：{mode_desc.get(new_mode, new_mode)}"
        return self._transparent_card(context, notice)

    def _handle_prompt_guard(self, context: MessageContext, args: list[str]) -> str | Card:
        uid = self._user_id(context)
        cur = self._user_prompt_guard(uid)
        is_interaction = getattr(context, "message_type", None) == "interaction"
        if not args or args[0].lower() in {"toggle", "切换"}:
            new_val = not cur
        elif args[0].lower() in {"on", "open", "开启", "1", "true", "开"}:
            new_val = True
        elif args[0].lower() in {"off", "close", "关闭", "0", "false", "关"}:
            new_val = False
        else:
            new_val = not cur
        self.user_prefs.setdefault(uid, {})["prompt_guard"] = new_val
        self._save_user_prefs()
        state_text = "开启（阻止模型擅自重写或篡改用户提示词）" if new_val else "关闭（允许模型自由优化提示词）"
        if is_interaction:
            return self._size_and_quality_card(context, f"已切换提示词防改写注入为：{'开启' if new_val else '关闭'}")
        return f"提示词防改写注入已设置为：**{state_text}**。"

    async def _fetch_remote_models(self) -> list[str]:
        api_base = self._api_base_url()
        api_key = self._api_key()
        if not api_base:
            return []
        base = api_base.rstrip("/")
        if base.casefold().endswith("/v1"):
            base = base[:-3].rstrip("/")
        headers = {"Authorization": f"Bearer {api_key}"} if api_key else {}
        image_keywords = (
            "image", "dall", "flux", "sd", "stable-diffusion", "midjourney",
            "imagen", "recraft", "ideogram", "cogview", "kolors",
            "paint", "draw", "art", "canvas", "diffusion", "kling",
            "sora", "luma", "runway", "seed", "mj", "sdxl", "sd-", "sd_", "wanx", "t2i"
        )
        def is_image_model(m: str) -> bool:
            lower = str(m).lower()
            return any(kw in lower for kw in image_keywords)

        fetched_models: list[str] = []
        try:
            timeout = aiohttp.ClientTimeout(total=8.0)
            connector = aiohttp.TCPConnector(ttl_dns_cache=600)
            async with aiohttp.ClientSession(timeout=timeout, connector=connector) as session:
                for raw_url in (f"{base}/v1/models", f"{base}/models"):
                    try:
                        url, req_headers, sni = await _prepare_target(raw_url, headers)
                        async with session.get(url, headers=req_headers, server_hostname=sni) as resp:
                            if resp.status == 200:
                                data = await resp.json()
                                items = data.get("data", []) if isinstance(data, dict) else (data if isinstance(data, list) else [])
                                fetched = [str(item.get("id") if isinstance(item, dict) else item).strip() for item in items if item]
                                if fetched:
                                    img_fetched = [m for m in fetched if is_image_model(m)]
                                    fetched_models = img_fetched or list(fetched)
                                    break
                    except Exception:
                        continue
        except Exception as e:
            logger.warning("Failed to fetch remote models: %s", e)
        return fetched_models

    async def _handle_models(self, context: MessageContext, args: list[str]) -> str | Card:
        base_url = self._api_base_url()
        api_key = self._api_key()
        if not base_url or not api_key:
            return Card(
                "可用生图模型",
                "⚠️ **生图服务暂未配置接口**\n\n管理员暂未设置生图 API 接口地址与 API Key。\n请管理员前往后台管理面板「🧩 插件管理 - 绘图服务」配置接口后再使用。",
                rows=[[_btn("返回主菜单", "/dg")]],
            )

        now = time.time()
        ttl = int(self._get_cfg("models_cache_ttl_sec", 60))
        models: list[str] = []
        if self.models_cache and (now - self.models_cache[0]) < ttl and self.models_cache[1]:
            models = list(self.models_cache[1])
        else:
            models = await self._fetch_remote_models()
            if models:
                self.models_cache = (now, models)

        def _is_valid_model_name(name: str) -> bool:
            name = str(name).strip()
            if not name or len(name) < 2 or name.startswith("{") or name.endswith("}"):
                return False
            try:
                float(name)
                return False
            except ValueError:
                return True

        default_m = str(self._get_cfg("default_model", "")).strip()
        if default_m and _is_valid_model_name(default_m) and default_m not in models:
            models.append(default_m)

        cost_rules_raw = self._get_cfg("credit_cost_rules", "")
        if isinstance(cost_rules_raw, dict):
            for k in cost_rules_raw.keys():
                if _is_valid_model_name(str(k)) and str(k) not in models:
                    models.append(str(k))
        elif isinstance(cost_rules_raw, str) and cost_rules_raw.strip():
            try:
                loaded = json.loads(cost_rules_raw)
                if isinstance(loaded, dict):
                    for k in loaded.keys():
                        if _is_valid_model_name(str(k)) and str(k) not in models:
                            models.append(str(k))
            except Exception:
                for item in cost_rules_raw.split(";"):
                    parts = item.split(":", 1)
                    name = parts[0].strip()
                    if _is_valid_model_name(name) and name not in models:
                        models.append(name)

        if not models:
            return Card(
                "可用生图模型",
                "⚠️ **暂无可用的画图模型**\n\n当前接口未返回可用的画图模型列表，且管理员未配置模型规则。请联系管理员在后台检查接口状态或配置模型。",
                rows=[[_btn("返回主菜单", "/dg")]],
            )

        page = max(1, int(args[0])) if args and args[0].isdigit() else 1
        per_page = 6
        total_pages = max(1, (len(models) + per_page - 1) // per_page)
        page = min(page, total_pages)
        current = models[(page - 1) * per_page : page * per_page]

        lines = [
            f"### 🤖 可用模型列表（第 {page}/{total_pages} 页，共 {len(models)} 个）\n",
            "| # | 模型名称 | 单次消耗 |",
            "|---|---|---|",
        ]
        for idx, m in enumerate(current, (page - 1) * per_page + 1):
            cost = self._model_cost(m)
            lines.append(f"| {idx} | `{m}` | **{cost}** 积分/次 |")
        lines.append("\n切换模型发送：`/dg model <名称>`。")

        rows = []
        model_btns = []
        for i, m in enumerate(current):
            idx = (page - 1) * per_page + i + 1
            model_btns.append(_btn(f"模型 {idx}", f"/dg model {m}", fill=True))
            if len(model_btns) == 3:
                rows.append(model_btns)
                model_btns = []
        if model_btns:
            rows.append(model_btns)

        nav_row = []
        if page > 1:
            nav_row.append(_btn("◀ 上一页", f"/dg models {page - 1}", action_type=1))
        nav_row.append(_btn("跳页", "/dg models ", fill=True))
        if page < total_pages:
            nav_row.append(_btn("下一页 ▶", f"/dg models {page + 1}", action_type=1))
        if nav_row:
            rows.append(nav_row)

        rows.append([
            _btn("切换模型", "/dg model ", fill=True),
            _btn("返回主菜单", "/dg"),
        ])

        return Card("可用生图模型", "\n".join(lines), rows=rows)

    async def _notify_user_balance(self, user_id: str, delta: int, new_balance: int, reason: str = "充值") -> None:
        if not user_id:
            return
        qq = getattr(self.context, "qq", None)
        if qq and hasattr(qq, "send_text"):
            action_desc = f"已成功{reason}" if reason.startswith("在线") or "充值" in reason else f"管理员已为您的账户{reason}"
            msg = (
                f"🎉 **积分{reason}到账通知**\n\n"
                f"{action_desc} **{abs(delta)}** 积分。\n"
                f"当前最新余额：**{new_balance}** 积分。\n"
                f"发送 `/dg` 可打开绘图主菜单开始创作。"
            )
            try:
                await qq.send_text(user_id, msg)
            except Exception:
                pass

    async def on_payment_success(self, intent: dict[str, Any]) -> None:
        if intent.get("local_status") != "paid":
            return
        user_id = str(intent.get("owner_key") or "")
        if not user_id:
            return
        points_minor = int(intent.get("points_minor") or 0)
        points = int(points_minor // 100) if points_minor else int(intent.get("points") or 0)
        if points <= 0:
            return

        order_id = str(intent.get("id") or "")
        processed_orders = self.history.setdefault("_processed_orders", [])
        if order_id in processed_orders:
            return
        processed_orders.append(order_id)
        if len(processed_orders) > 2000:
            del processed_orders[:1000]
        self._save_history()
        if order_id and order_id in self.pending_pay_orders:
            self.pending_pay_orders.pop(order_id, None)
            self._save_pending_orders()

        uid = _clean_user_id(user_id)
        points_api = self._points()
        if points_api is not None:
            # 权威账本已由 runtime.pay 的 _fulfill_paid 统一入账，无需重复增加 points，仅需读取最新余额并同步本地缓存
            new_bal = await self._get_balance(uid)
            self.credits[uid] = new_bal
        else:
            # 仅在全局无 points 模块的降级模式下直接操作本地 credits 字典，绝不调用 points.credit
            current = int(self.credits.get(uid, 0))
            new_bal = current + points
            self.credits[uid] = new_bal
            self.credits.pop(f"<@{uid}>", None)
            self.credits.pop(f"qq_official:{uid}", None)
            self._save_credits()

        logger.info("Payment success for %s: +%d points, current balance %d", user_id, points, new_bal)
        await self._notify_user_balance(user_id, points, new_bal, reason="在线支付充值")

    async def poll_pending_payments(self) -> None:
        if not self.pending_pay_orders:
            return
        try:
            pay_api = getattr(self.context, "builtin", lambda name: None)("runtime.pay")
        except Exception:
            pay_api = None
        if not pay_api or not hasattr(pay_api, "query_payment"):
            return

        try:
            # 严格控制单次轮询全局耗时不超过 3.0 秒，避免阻塞沙箱 Worker 锁引发主进程 10s 超时杀死 Worker
            await asyncio.wait_for(self._do_poll_payments(pay_api), timeout=3.0)
        except TimeoutError:
            logger.debug("Payment polling timed out, skipped to protect worker lock")
        except Exception as exc:
            logger.debug("Payment polling encountered error: %s", exc)

    async def _do_poll_payments(self, pay_api: Any) -> None:
        finished_ids = []
        now = time.time()
        # 优先只轮询最近创建的未完成订单，超过 30 分钟（1800 秒）的自动清理
        items = list(self.pending_pay_orders.items())
        active_items = []
        for order_id, info in items:
            if now - info.get("time", now) > 1800:
                finished_ids.append(order_id)
            else:
                active_items.append((order_id, info))

        # 按时间倒序（最新的在前），每次最多只轮询 2 笔，避免集中突发请求卡死沙箱
        active_items.sort(key=lambda x: x[1].get("time", 0), reverse=True)
        for order_id, _info in active_items[:2]:
            try:
                res = await asyncio.wait_for(pay_api.query_payment(order_id), timeout=2.0)
                status = str(res.get("local_status") or "")
                if status == "paid":
                    await self.on_payment_success(res)
                    finished_ids.append(order_id)
                elif status in {"closed", "refunded", "create_failed", "polling_stopped"}:
                    finished_ids.append(order_id)
            except TimeoutError:
                logger.debug("Single query for order %s timed out during polling", order_id)
            except Exception as e:
                logger.debug("Failed to poll payment %s: %s", order_id, e)

        if finished_ids:
            for fid in finished_ids:
                self.pending_pay_orders.pop(fid, None)
            self._save_pending_orders()

    async def _send_pay_qr_image(self, context: MessageContext, pay_url: str, order_id: str) -> tuple[bool, str]:
        if not pay_url:
            return False, "缺少支付链接"
        try:
            import qrcode
        except ImportError:
            return False, "系统未安装 qrcode 模块"
        tmp_dir = Path(self.data_dir) / "temp"
        tmp_dir.mkdir(parents=True, exist_ok=True)
        tmp_qr = tmp_dir / f"drawimg_pay_qr_{order_id[:16]}_{uuid.uuid4().hex[:6]}.png"
        try:
            img = qrcode.make(pay_url)
            img.save(tmp_qr)
            sent, send_err = await self._send_image(context, tmp_qr)
            return sent, send_err
        except Exception as exc:
            logger.warning("Failed to generate/send pay qr code image: %s", exc)
            return False, str(exc)
        finally:
            tmp_qr.unlink(missing_ok=True)

    async def _handle_pay(self, context: MessageContext, args: list[str]) -> str | Card:
        user_id = self._user_id(context)
        rate_val = float(self._get_cfg("credit_price_yuan", 0.1))
        if not args:
            cur_bal = await self._get_balance(user_id)
            return Card(
                "充值积分",
                f"# 💳 绘图积分充值中心\n\n"
                f"> 当前账户积分余额：**{cur_bal}** 积分\n\n"
                f"* 充值比例：**1 积分 = ￥{rate_val:.2f} 元**\n"
                f"* 到账时效：付款后系统秒级自动入账\n"
                f"* 支持渠道：微信支付 / 支付宝扫码\n\n"
                f"---\n"
                f"💡 *点击下方常用面额快速创建订单，或点击【自定义充值】输入数量：*",
                rows=[
                    [
                        _btn("充 10 积分", "/dg pay 10", action_type=1, style="primary"),
                        _btn("充 50 积分", "/dg pay 50", action_type=1),
                        _btn("充 100 积分", "/dg pay 100", action_type=1),
                    ],
                    [
                        _btn("✏️ 自定义充值", "/dg pay ", fill=True),
                        _btn("💰 查余额", "/dg status", action_type=1),
                        _btn("🎨 绘图主菜单", "/dg", action_type=1),
                    ]
                ]
            )

        sub = args[0].lower()
        if sub in {"link", "qr", "qrcode", "二维码"}:
            order_id = args[1].strip() if len(args) > 1 else ""
            if not order_id:
                for oid, info in reversed(list(self.pending_pay_orders.items())):
                    if info.get("user_id") == user_id:
                        order_id = oid
                        break
            if not order_id:
                pay_api = getattr(self.context, "builtin", lambda name: None)("runtime.pay")
                if pay_api and hasattr(pay_api, "get_latest_intent"):
                    try:
                        latest = await pay_api.get_latest_intent(user_id)
                        if latest and latest.get("local_status") in {"pending", "creating"}:
                            order_id = str(latest.get("id") or latest.get("trade_no") or "")
                    except Exception as e:
                        logger.debug("Failed to get latest intent for %s: %s", user_id, e)
            if not order_id:
                return Card("支付二维码", "未找到待支付的订单。您可以发送 `/dg pay 10` 创建新的充值订单。")

            pay_url = ""
            if order_id in self.pending_pay_orders:
                pay_url = self.pending_pay_orders[order_id].get("pay_url", "")
            if not pay_url:
                pay_api = getattr(self.context, "builtin", lambda name: None)("runtime.pay")
                if pay_api and hasattr(pay_api, "query_payment"):
                    try:
                        qres = await pay_api.query_payment(order_id)
                        pay_url = qres.get("pay_info") or qres.get("pay_url") or qres.get("qrcode") or ""
                    except Exception:
                        pass
            if not pay_url:
                return Card("支付二维码", f"订单 `{order_id}` 未找到有效的支付链接，或订单已过期。")

            sent, send_err = await self._send_pay_qr_image(context, pay_url, order_id)
            row1 = []
            if pay_url and pay_url.startswith(("http://", "https://")):
                row1.append(_btn("💳 立即跳转付款", pay_url, action_type=0, style="primary"))
            row1.append(_btn("🔍 查询订单", f"/dg pay check {order_id}", action_type=1))

            if sent:
                return Card(
                    "支付二维码",
                    f"# 📱 支付二维码已发送\n\n"
                    f"> 订单号：`{order_id}`\n\n"
                    f"* 请使用手机微信或支付宝长按/扫描上方二维码付款；\n"
                    f"* 或直接点击下方【💳 立即跳转付款】打开支付页面。\n\n"
                    f"✨ *付款完成后系统将自动秒级入账，或点击【🔍 查询订单】立即对账。*",
                    rows=[
                        row1,
                        [_btn("🖼️ 获取二维码", f"/dg pay link {order_id}", action_type=1), _btn("💰 查余额", "/dg status", action_type=1)],
                        [_btn("🎨 绘图主菜单", "/dg", action_type=1)],
                    ]
                )
            err_msg = f"（原因：{send_err}）" if send_err else ""
            return Card(
                "支付二维码",
                f"# ⚠️ 二维码图片发送异常\n\n"
                f"> 订单编号：`{order_id}`\n\n"
                f"* 二维码图片发送暂未成功{err_msg}；\n"
                f"* 您可直接点击下方【💳 立即跳转付款】打开收银台完成支付！",
                rows=[
                    row1,
                    [_btn("🖼️ 获取二维码", f"/dg pay link {order_id}", action_type=1), _btn("💰 查余额", "/dg status", action_type=1)],
                    [_btn("🎨 绘图主菜单", "/dg", action_type=1)],
                ]
            )

        if sub in {"check", "order", "status", "query", "查询"}:
            order_id = args[1].strip() if len(args) > 1 else ""
            if not order_id:
                for oid, info in reversed(list(self.pending_pay_orders.items())):
                    if info.get("user_id") == user_id:
                        order_id = oid
                        break
            if not order_id:
                pay_api = getattr(self.context, "builtin", lambda name: None)("runtime.pay")
                if pay_api and hasattr(pay_api, "get_latest_intent"):
                    try:
                        latest = await pay_api.get_latest_intent(user_id)
                        if latest:
                            order_id = str(latest.get("id") or latest.get("trade_no") or "")
                    except Exception as e:
                        logger.debug("Failed to get latest intent for %s: %s", user_id, e)
            if not order_id:
                return Card("查询订单", "未指定订单号，且未找到最近的未完成订单。您可以发送 `/dg pay 10` 创建新的充值订单。")

            pay_api = getattr(self.context, "builtin", lambda name: None)("runtime.pay")
            if not pay_api or not hasattr(pay_api, "query_payment"):
                return Card("查询订单", "支付查询接口不可用。")

            try:
                res = await asyncio.wait_for(pay_api.query_payment(order_id), timeout=5.0)
                status = str(res.get("local_status") or "")
                if status == "paid":
                    await self.on_payment_success(res)
                    self.pending_pay_orders.pop(order_id, None)
                    self._save_pending_orders()
                    return Card(
                        "订单已支付",
                        f"# ✅ 充值支付成功\n\n"
                        f"> 订单号 `{order_id}` 已成功到账！\n\n"
                        f"* 充值状态：**已入账**\n"
                        f"* 当前总余额：**{await self._get_balance(user_id)}** 积分\n\n"
                        f"🎨 祝您创作愉快，点击下方按钮即可立即开始绘图！",
                        rows=[
                            [_btn("🎨 立即去绘图", "/dg", style="primary"), _btn("💰 查余额", "/dg status")],
                            [_btn("🏠 绘图主菜单", "/dg")]
                        ]
                    )
                status_text = "待支付" if status in {"pending", "creating"} else status
                row1 = []
                pay_url = (self.pending_pay_orders.get(order_id) or {}).get("pay_url", "")
                if not pay_url:
                    pay_url = res.get("pay_info") or res.get("pay_url") or res.get("qrcode") or ""
                if pay_url and pay_url.startswith(("http://", "https://")):
                    row1.append(_btn("💳 立即跳转付款", pay_url, action_type=0, style="primary"))
                row1.append(_btn("🔍 刷新订单", f"/dg pay check {order_id}", action_type=1))
                return Card(
                    "订单待支付",
                    f"# ⏳ 订单待支付中\n\n"
                    f"> 订单编号：`{order_id}`\n\n"
                    f"* 当前状态：**{status_text}**\n"
                    f"* 若您已付款，请稍候 2~3 秒后点击【🔍 刷新订单】自动对账；\n"
                    f"* 若未完成付款，请点击下方【💳 立即跳转付款】或【🖼️ 获取二维码】。",
                    rows=[
                        row1,
                        [_btn("🖼️ 获取二维码", f"/dg pay link {order_id}", action_type=1), _btn("💰 查余额", "/dg status", action_type=1)],
                        [_btn("🎨 绘图主菜单", "/dg", action_type=1)]
                    ]
                )
            except TimeoutError:
                row1 = []
                pay_url = (self.pending_pay_orders.get(order_id) or {}).get("pay_url", "")
                if pay_url and pay_url.startswith(("http://", "https://")):
                    row1.append(_btn("💳 立即跳转付款", pay_url, action_type=0, style="primary"))
                row1.append(_btn("🔍 刷新重试", f"/dg pay check {order_id}", action_type=1))
                return Card(
                    "查询订单",
                    f"# ⏳ 订单查询稍有延迟\n\n"
                    f"> 订单编号：`{order_id}`\n\n"
                    f"* 上游支付平台对账稍有延迟，请稍候 2~3 秒后点击下方【🔍 刷新重试】；\n"
                    f"* 若您已完成付款，系统后台轮询检测到后会自动秒级入账。",
                    rows=[
                        row1,
                        [_btn("🖼️ 获取二维码", f"/dg pay link {order_id}", action_type=1), _btn("💰 查余额", "/dg status", action_type=1)],
                        [_btn("🎨 绘图主菜单", "/dg", action_type=1)]
                    ]
                )
            except Exception as exc:
                return Card("查询订单", f"查询订单 `{order_id}` 失败：{exc}")

        try:
            points = int(args[0])
            if points <= 0 or points > 100000:
                return "充值积分数量需在 1 ~ 100,000 之间。"
        except ValueError:
            return "积分数值必须为正整数。"

        yuan_amount = round(points * rate_val, 2)
        if yuan_amount < 0.01:
            yuan_amount = 0.01

        pay_api = getattr(self.context, "pay_api", None)
        if not pay_api:
            try:
                pay_api = getattr(self.context, "builtin", lambda name: None)("runtime.pay")
            except Exception:
                pay_api = None

        if pay_api and (hasattr(pay_api, "create_payment") or hasattr(pay_api, "create_trade")):
            try:
                if hasattr(pay_api, "create_payment"):
                    ext_id = f"drawimg_{user_id}_{int(time.time())}_{uuid.uuid4().hex[:8]}"
                    order_info = await asyncio.wait_for(
                        pay_api.create_payment(
                            source_plugin="plugin.drawimg.service",
                            external_id=ext_id,
                            owner_key=user_id,
                            subject=f"绘图服务积分充值 - {points} 积分",
                            amount=str(yuan_amount),
                            points=str(points),
                            point_type="drawimg",
                            user_id=user_id,
                            amount_yuan=yuan_amount,
                            point_count=points,
                            description=f"绘图服务积分充值 - {points} 积分",
                        ),
                        timeout=8.0,
                    )
                else:
                    order_info = await asyncio.wait_for(
                        pay_api.create_trade(
                            owner_key=user_id,
                            amount_yuan=yuan_amount,
                            point_type="drawimg",
                            points=points,
                        ),
                        timeout=8.0,
                    )
                qrcode_url = order_info.get("qrcode") or ""
                order_id = str(order_info.get("order_id") or order_info.get("trade_no") or order_info.get("id") or "")
                real_amount = order_info.get("amount") or str(yuan_amount)
                pay_url = order_info.get("pay_url") or order_info.get("url") or order_info.get("pay_info") or qrcode_url

                if order_id and order_id != "-":
                    self.pending_pay_orders[order_id] = {
                        "user_id": user_id,
                        "points": points,
                        "time": time.time(),
                        "pay_url": pay_url,
                    }
                    self._save_pending_orders()

                markdown = (
                    f"# 💳 绘图积分充值订单\n\n"
                    f"> 订单已生成，30分钟内有效，支持微信与支付宝扫码。\n\n"
                    f"* 充值数量：`{points}` 积分\n"
                    f"* 应付金额：**￥{real_amount}** 元\n"
                    f"* 订单号：`{order_id}`\n"
                    f"* 订单状态：⏳ **待支付**\n\n"
                    f"---\n"
                    f"📱 **快捷付款指南**：\n"
                    f"1. **方式一（推荐）**：点击下方【💳 立即跳转付款】打开收银台直接支付；\n"
                    f"2. **方式二（扫码）**：若需微信或支付宝扫码，请点击下方【🖼️ 获取二维码】。\n\n"
                    f"✨ *付款完成后系统将自动秒级充值到账，无需手动确认。*"
                )

                row1 = []
                if pay_url and pay_url.startswith(("http://", "https://")):
                    row1.append(_btn("💳 立即跳转付款", pay_url, action_type=0, style="primary"))
                row1.append(_btn("🔍 查询订单", f"/dg pay check {order_id}", action_type=1))

                row2 = [
                    _btn("🖼️ 获取二维码", f"/dg pay link {order_id}", action_type=1),
                    _btn("💰 查余额", "/dg status", action_type=1),
                ]
                row3 = [
                    _btn("🎨 绘图主菜单", "/dg", action_type=1),
                ]
                rows = [row1, row2, row3]
                return Card("积分充值", markdown, rows=rows)
            except TimeoutError:
                return Card(
                    "积分充值",
                    "# ⏳ 创建充值订单稍有延迟\n\n"
                    "* 上游支付平台网关响应稍慢，可能订单已在生成处理中。\n"
                    "* 请点击下方【🔍 检查最近订单】尝试认领，或稍候点击【重试充值】。",
                    rows=[
                        [_btn("🔍 检查最近订单", "/dg pay check", action_type=1), _btn(f"重试充 {points} 积分", f"/dg pay {points}", action_type=1)],
                        [_btn("💰 查余额", "/dg status", action_type=1), _btn("🎨 绘图主菜单", "/dg", action_type=1)]
                    ]
                )
            except Exception as e:
                err_str = str(e)
                logger.error("Pay API failed: %s", err_str)
                if "active payment limit" in err_str:
                    latest_oid = ""
                    pay_url = ""
                    try:
                        pay_api = getattr(self.context, "builtin", lambda name: None)("runtime.pay")
                        if pay_api and hasattr(pay_api, "get_latest_intent"):
                            latest = await pay_api.get_latest_intent(user_id)
                            if latest:
                                latest_oid = str(latest.get("id") or latest.get("trade_no") or "")
                                pay_url = latest.get("pay_info") or latest.get("pay_url") or latest.get("qrcode") or ""
                    except Exception:
                        pass
                    if not latest_oid:
                        for oid, info in reversed(list(self.pending_pay_orders.items())):
                            if info.get("user_id") == user_id:
                                latest_oid = oid
                                pay_url = info.get("pay_url", "")
                                break
                    if latest_oid and not pay_url:
                        if latest_oid in self.pending_pay_orders:
                            pay_url = self.pending_pay_orders[latest_oid].get("pay_url", "")
                        if not pay_url and pay_api and hasattr(pay_api, "query_payment"):
                            try:
                                qres = await pay_api.query_payment(latest_oid)
                                pay_url = qres.get("pay_info") or qres.get("pay_url") or qres.get("qrcode") or ""
                            except Exception:
                                pass

                    link_cmd = f"/dg pay link {latest_oid}".strip() if latest_oid else "/dg pay link"
                    check_cmd = f"/dg pay check {latest_oid}".strip() if latest_oid else "/dg pay check"

                    row1 = []
                    if pay_url and pay_url.startswith(("http://", "https://")):
                        row1.append(_btn("💳 立即跳转付款", pay_url, action_type=0, style="primary"))
                    row1.append(_btn("🔍 刷新订单", check_cmd, action_type=1))

                    rows = [
                        row1,
                        [
                            _btn("🖼️ 获取二维码", link_cmd, action_type=1),
                            _btn("💰 查余额", "/dg status", action_type=1),
                        ],
                        [
                            _btn("🎨 绘图主菜单", "/dg", action_type=1),
                        ]
                    ]
                    oid_tip = f"（最新订单：`{latest_oid}`）" if latest_oid else ""
                    return Card(
                        "未完成订单提醒",
                        f"# ⚠️ 待支付订单提示\n\n"
                        f"> 您当前尚有未完成的待支付订单{oid_tip}，最多保留 3 笔。\n\n"
                        f"* 若您刚刚已完成付款，请点击【🔍 刷新订单】自动秒级入账；\n"
                        f"* 若需继续付款，可点击【💳 立即跳转付款】或【🖼️ 获取二维码】；\n"
                        f"* 超过 30 分钟未支付的旧订单会自动关闭失效，届时可重新创建。\n\n"
                        f"💡 *无需担心重复扣费，系统支持实时对账并自动累加积分。*",
                        rows=rows
                    )
                if "unavailable" in err_str or "not available" in err_str or "Built-in plugin API" in err_str:
                    if context.is_admin:
                        return "⚠️ 567 在线支付功能当前未开启。请在后台管理面板「🧩 插件管理」中启用「567 支付」插件并配置商户密钥；管理员也可以直接使用 `/dg give <用户> <积分>` 赠送积分。"
                    return "⚠️ 在线支付渠道维护中或未开启。如需充值积分，请联系机器人管理员。"
                return f"创建支付订单失败（{err_str}），请稍后重试或联系管理员。"

        if context.is_admin:
            await self._change_balance(user_id, points, reason="管理员直接充值")
            return f"【管理员直接充值】已成功为您的账户增加 **{points}** 积分，当前总余额：**{await self._get_balance(user_id)}** 积分。"
        return "⚠️ 当前机器人未开启 567 在线支付功能。如需充值积分，请联系机器人管理员。"

    async def _handle_give(self, context: MessageContext, args: list[str]) -> str | Card:
        if not context.is_admin:
            return Card("无权限", "⚠️ 只有管理员可以赠送或调整用户积分。")
        if not args:
            return Card("使用帮助", "用法：`/dg give <数量> [用户编号/艾特用户]` 或 `/dg give <用户编号/艾特用户> <数量>`")

        delta = 0
        target = ""
        mention_target = _extract_mention_target(context)

        if len(args) == 1:
            try:
                delta = int(args[0])
                target = mention_target or self._user_id(context)
            except ValueError:
                target = _clean_user_id(args[0])
                delta = 0
        else:
            if args[0].lstrip("-+").isdigit():
                delta = int(args[0])
                target = _clean_user_id(args[1]) or mention_target
            else:
                target = _clean_user_id(args[0]) or mention_target
                try:
                    delta = int(args[1])
                except ValueError:
                    return Card("格式错误", "⚠️ 积分数值必须为整数。例如 `/dg give 10 @用户`")

        if not target or target == "default_user":
            target = mention_target or self._user_id(context)

        new_bal = await self._change_balance(target, delta, reason="管理员赠送/充值")
        action_name = "增加" if delta >= 0 else "扣除"
        if delta > 0:
            try:
                import asyncio
                loop = asyncio.get_running_loop()
                loop.create_task(self._notify_user_balance(target, delta, new_bal, reason="管理员赠送/充值"))
            except RuntimeError:
                pass

        markdown = (
            f"### 💳 积分调整成功\n\n"
            f"- **目标用户**：`{target}`\n"
            f"- **操作类型**：{action_name}积分\n"
            f"- **变动积分**：**{'+' if delta > 0 else ''}{delta}**\n"
            f"- **当前余额**：**{new_bal}** 积分\n"
        )
        rows = [
            [_btn("查积分", "/dg status"), _btn("充值菜单", "/dg pay")],
            [_btn("返回主菜单", "/dg")]
        ]
        return Card("积分调整", markdown, rows=rows)

    def _handle_rate(self, context: MessageContext, args: list[str]) -> str:
        if not context.is_admin:
            return "只有管理员可以设置充值比例。"
        if not args:
            return f"当前充值比例为：`{self._get_cfg('credit_price_yuan', 0.1)}` 元/积分。修改：`/dg rate <单价>`。"
        try:
            rate = float(args[0])
            if rate <= 0:
                raise ValueError()
            self.config["credit_price_yuan"] = rate
            self._save_config()
            return f"充值比例已设置为：**{rate}** 元/积分。"
        except ValueError:
            return "单价必须为大于 0 的数值。"

    def _handle_cost(self, context: MessageContext, args: list[str]) -> str:
        if not context.is_admin:
            return "只有管理员可以修改模型计费规则。"
        if not args:
            rules = self._get_cfg("credit_cost_rules") or "未单独配置（默认 1 积分）"
            return f"当前模型计费规则：`{rules}`。\n修改格式：`/dg cost <模型>:<积分>;<模型2>:<积分>`。"
        self.config["credit_cost_rules"] = " ".join(args).strip()
        self._save_config()
        return "模型计费规则已更新。"

    def _handle_admin(self, context: MessageContext) -> str | Card:
        if not context.is_admin:
            return "此操作需要管理员权限。"
        rate = self._get_cfg("credit_price_yuan", 0.1)
        model = self._get_cfg("default_model", "dall-e-3")
        user_count = len(self.credits)
        total_credits = sum(self.credits.values())

        markdown = (
            "### ⚙️ 绘图服务管理员菜单\n\n"
            f"- **插件版本**：`v{PLUGIN_VERSION}`\n"
            f"- **默认模型**：`{model}`\n"
            f"- **充值比例**：`{rate}` 元/积分\n"
            f"- **用户总数**：**{user_count}** 人\n"
            f"- **积分总池**：**{total_credits}** 积分\n\n"
            "常用指令：\n"
            "- `/dg rate <元每积分>` — 设置充值比例\n"
            "- `/dg give <数量> [用户]` — 赠送积分\n"
            "- `/dg cost <模型>:<积分>` — 设置模型单价\n"
            "- `/dg top` — 查看积分排行\n"
        )
        rows = [
            [
                _btn("充值比例", "/dg rate"),
                _btn("模型计费", "/dg cost ", fill=True, permission=1),
            ],
            [
                _btn("赠送积分", "/dg give ", fill=True, permission=1),
                _btn("积分排行", "/dg top", permission=1),
            ],
            [
                _btn("模型列表", "/dg models"),
                _btn("返回主菜单", "/dg"),
            ],
        ]
        return Card("管理员菜单", markdown, rows=rows)

    def _handle_blacklist(self, context: MessageContext, args: list[str]) -> str:
        if not context.is_admin:
            return "只有管理员可以管理黑名单。"
        bl = self.config.setdefault("test_blacklist", [])
        if not args or args[0].lower() == "list":
            return f"黑名单用户列表（共 {len(bl)} 人）：\n" + ("\n".join(f"- `{u}`" for u in bl) if bl else "暂无黑名单用户。")
        act = args[0].lower()
        if len(args) < 2:
            return "用法：/dg blacklist <add/del> <用户OpenID>"
        target = args[1].strip()
        if act == "add":
            if target not in bl:
                bl.append(target)
                self._save_config()
            return f"已将 `{target}` 加入黑名单。"
        if act in {"del", "remove", "rm"}:
            if target in bl:
                bl.remove(target)
                self._save_config()
            return f"已将 `{target}` 移出黑名单。"
        return "未知操作，可选：`list`、`add`、`del`。"

    def _handle_history(self, context: MessageContext) -> str | Card:
        return "生图历史功能已关闭，系统不保存任何历史生成记录。"

    def _handle_resend(self, context: MessageContext, args: list[str]) -> str | Card:
        return "历史重发功能已关闭，系统不保存任何历史生成记录。"

    # Backward compatible aliases
    handle_dgs = handle_dg
    handle_dgse = handle_dge
    handle_dgsm = handle_dgm

    def _parse_presets(self, presets_raw: Any) -> dict[str, str]:
        parsed_presets: dict[str, str] = {}
        if isinstance(presets_raw, dict) and presets_raw:
            return {str(k): str(v) for k, v in presets_raw.items()}
        if isinstance(presets_raw, str) and presets_raw.strip():
            raw = presets_raw.strip()
            if raw.startswith("{"):
                try:
                    obj = json.loads(raw)
                    if isinstance(obj, dict):
                        return {str(k): str(v) for k, v in obj.items()}
                except Exception:
                    pass
            for item in raw.split(";"):
                parts = item.split(":", 1)
                if len(parts) == 2 and parts[0].strip():
                    parsed_presets[parts[0].strip()] = parts[1].strip()
        if not parsed_presets:
            for item in DEFAULT_CONFIG["style_presets"].split(";"):
                parts = item.split(":", 1)
                if len(parts) == 2 and parts[0].strip():
                    parsed_presets[parts[0].strip()] = parts[1].strip()
        return parsed_presets

    async def _authoritative_balances(self, keys: set[str] | None = None) -> dict[str, int]:
        balances: dict[str, int] = {}
        target_keys = set(keys or ())

        # 1. First, check SQLite point_accounts directly if runtime database is accessible
        for p in (Path("data/runtime.sqlite3"), Path("/app/data/runtime.sqlite3")):
            if p.is_file():
                try:
                    import sqlite3
                    with sqlite3.connect(str(p), timeout=2.0) as conn:
                        rows = conn.execute(
                            "SELECT identity, balance_minor FROM point_accounts WHERE point_type = 'drawimg'"
                        ).fetchall()
                        for ident, bal in rows:
                            cid = _clean_user_id(ident)
                            if cid:
                                balances[cid] = int(round(float(bal) / 100.0))
                                target_keys.add(cid)
                    break
                except Exception:
                    pass

        # 2. Check context.points (proxied or native)
        points = self._points()
        if points is not None:
            if hasattr(points, "top_identities"):
                try:
                    top = await points.top_identities("drawimg", 500)
                    for item in top:
                        ident = item.get("identity") if isinstance(item, dict) else item[0]
                        bal = item.get("balance") if isinstance(item, dict) else item[1]
                        cid = _clean_user_id(ident)
                        if cid:
                            balances[cid] = round(float(bal), 2)
                            target_keys.add(cid)
                except Exception:
                    pass
            for k in target_keys:
                if k not in balances and hasattr(points, "balance"):
                    try:
                        bal = await points.balance(k, "drawimg")
                        balances[k] = round(float(bal), 2)
                    except Exception:
                        pass

        # 3. Fill with self.credits for remaining
        for k in target_keys:
            if k not in balances:
                balances[k] = round(float(self.credits.get(k, 0.0)), 2)
        return balances

    async def page_overview_data(self) -> dict[str, Any]:
        all_balances = await self._authoritative_balances()
        users_keys = (
            set(all_balances.keys())
            | set(_clean_user_id(k) for k in self.credits.keys())
            | set(_clean_user_id(k) for k in self.user_prefs.keys())
        )
        users_keys.discard("")
        config = dict(DEFAULT_CONFIG)
        config.update(self.config)
        presets = self._parse_presets(self._get_cfg("style_presets", DEFAULT_CONFIG["style_presets"]))
        config["style_presets"] = presets
        config["test_blacklist"] = self.config.get("test_blacklist", [])
        config["api_key"] = ""
        config["api_key_set"] = bool(self._get_cfg("api_key"))
        config["api_configured"] = bool(self._get_cfg("api_base_url") and self._get_cfg("api_key"))
        total_credits = round(sum(all_balances.values()), 2)
        return {
            "stats": {
                "users": len(users_keys),
                "total_credits": total_credits,
                "total_history": 0,
            },
            "config": config,
            "management": {
                "permission": "plugin.dg.manage",
                "requests_per_minute": 20,
                "button_ttl_seconds": 300,
                "admin_source": "Runtime 角色与机器人主人",
            },
            "schema": {
                "api_base_url": {"type": "str", "default": ""},
                "api_key": {"type": "str", "default": ""},
                "default_model": {"type": "str", "default": "agnes-image-2.5-flash"},
                "image_size": {"type": "str", "default": "auto"},
                "image_quality": {"type": "str", "default": "auto"},
                "enable_group": {"type": "bool", "default": True},
                "test_credit_cost": {"type": "float", "min": 0, "max": 10000, "default": 1},
                "credit_cost_rules": {"type": "str", "default": ""},
                "credit_price_yuan": {"type": "float", "min": 0.01, "max": 1000.0, "default": 0.1},
                "cooldown_sec": {"type": "int", "min": 0, "max": 3600, "default": 10},
                "max_prompt_chars": {"type": "int", "min": 100, "max": 50000, "default": 4000},
                "style_presets": {"type": "str", "default": ""},
                "test_blacklist": {"type": "str", "default": ""},
            },
        }

    async def page_users(self) -> list[dict[str, Any]]:
        blacklist = set(self.config.get("test_blacklist", []))
        all_balances = await self._authoritative_balances()
        pref_keys = set(_clean_user_id(k) for k in self.user_prefs.keys())
        credit_keys = set(_clean_user_id(k) for k in self.credits.keys())
        all_keys = sorted((set(all_balances.keys()) | pref_keys | credit_keys) - {""})
        users = []
        for k in all_keys:
            if not k or k.startswith("_"):
                continue
            pref = self.user_prefs.get(k, {}) if isinstance(self.user_prefs.get(k), dict) else {}
            credits = all_balances.get(k)
            if credits is None:
                credits = await self._get_balance(k)
            users.append({
                "key": k,
                "credits": round(float(credits), 2),
                "model": str(pref.get("model") or self._default_model()),
                "source": "绘图服务积分",
                "history": 0,
                "today": self._get_user_today_experience(k),
                "blacklisted": k in blacklist,
            })
        return users[:200]

    async def page_save_config(self, payload: dict[str, Any]) -> dict[str, Any]:
        for k, v in payload.items():
            if k == "api_key" and not str(v or "").strip() and self._get_cfg("api_key"):
                continue
            self.config[k] = v
        self._save_config()
        return {"saved": True, "applied": payload, **await self.page_overview_data()}

    async def page_save_presets(self, style_presets: Any) -> dict[str, Any]:
        if isinstance(style_presets, dict):
            presets_str = ";".join(f"{k}:{v}" for k, v in style_presets.items())
        else:
            presets_str = str(style_presets or "")
        self.config["style_presets"] = presets_str
        self._save_config()
        return {"saved": True, "presets": self._parse_presets(presets_str)}

    async def page_blacklist(self, key: str, action: str) -> dict[str, Any]:
        key = _clean_user_id(key)
        items = list(self.config.get("test_blacklist", []))
        if action == "add" and key not in items:
            items.append(key)
        elif action == "remove" and key in items:
            items.remove(key)
        self.config["test_blacklist"] = items
        self._save_config()
        return {"ok": True, "blacklist": items}

    async def page_adjust_credit(self, key: str, credits: float | int, mode: str) -> dict[str, Any]:
        raw_key = _clean_user_id(key)
        if not raw_key:
            raise ValueError("用户标识无效")
        current = await self._get_balance(raw_key)
        credits_val = float(credits)
        if mode == "set":
            if credits_val < 0:
                raise ValueError("设置为负数无效")
            delta = credits_val - current
            new_balance = credits_val
        else:
            delta = credits_val
            new_balance = max(0.0, current + delta)
        if delta != 0:
            await self._change_balance(raw_key, delta, reason="控制台调整积分")
        self.credits[raw_key] = new_balance
        self._save_credits()
        return {"ok": True, "key": raw_key, "credits": float(new_balance)}

    async def page_set_user_model(self, key: str, model: str) -> dict[str, Any]:
        clean_key = _clean_user_id(key)
        model_name = str(model or "").strip()
        if not model_name or model_name.lower() in {"reset", "default", "auto", "off", "重置", "默认"}:
            if clean_key in self.user_prefs and isinstance(self.user_prefs[clean_key], dict):
                self.user_prefs[clean_key].pop("model", None)
        else:
            self.user_prefs.setdefault(clean_key, {})["model"] = model_name
        self._save_user_prefs()
        return {"ok": True, "key": clean_key, "model": model_name or self._default_model()}

    async def page_fetch_models(self, api_base: str = "", api_key: str = "") -> dict[str, Any]:
        base = (api_base or self._api_base_url()).strip().rstrip("/")
        key = (api_key or str(self._get_cfg("api_key") or "")).strip()
        if not base:
            raise ValueError("请先填写 API 地址（api_base_url）")
        headers = {}
        if key:
            headers["Authorization"] = f"Bearer {key}"
        models = []
        async with httpx.AsyncClient(timeout=15.0) as client:
            resp = None
            err_msg = ""
            for url in (f"{base}/v1/models", f"{base}/models"):
                try:
                    resp = await client.get(url, headers=headers)
                    if resp.status_code == 200:
                        break
                except Exception as e:
                    err_msg = str(e)
            if resp is None or resp.status_code != 200:
                code = resp.status_code if resp else "timeout"
                raise ValueError(f"获取模型列表失败 (HTTP {code}): {err_msg or '无法连接目标 API'}")
            data = resp.json()
            items = data.get("data", []) if isinstance(data, dict) else (data if isinstance(data, list) else [])
            for item in items:
                mid = str(item.get("id") if isinstance(item, dict) else item).strip()
                if mid and mid not in models:
                    models.append(mid)
        return {"ok": True, "models": models, "image_models": models, "total": len(models)}

    async def action_overview(self, payload: Any = None) -> Any:
        return await self.page_overview_data()

    async def action_users(self, payload: Any = None) -> Any:
        return {"users": await self.page_users()}

    async def action_save_config(self, payload: Any = None) -> Any:
        return await self.page_save_config(payload if isinstance(payload, dict) else {})

    async def on_page_action(self, *args: Any, **kwargs: Any) -> Any:
        if len(args) >= 2:
            action_name, payload = args[0], args[1]
        elif len(args) == 1:
            if isinstance(args[0], dict) and "action" in args[0]:
                action_name = args[0].get("action")
                payload = args[0].get("payload", args[0])
            else:
                action_name = "save_config"
                payload = args[0]
        else:
            action_name = kwargs.get("action_name", "save_config")
            payload = kwargs.get("payload", {})
        action = str(action_name or "").strip()
        payload = payload if isinstance(payload, dict) else {}
        res = None
        if action in ("save_config", "config"):
            res = await self.page_save_config(payload)
        elif action in ("page_data", "data", "users", "page_users"):
            res = {"users": await self.page_users()}
        elif action in ("overview", "page_overview"):
            res = await self.page_overview_data()
        elif action in ("fetch_models", "models"):
            api_base = str(payload.get("api_base_url") or "")
            api_key = str(payload.get("api_key") or "")
            res = await self.page_fetch_models(api_base, api_key)
        elif action == "user_credit":
            res = await self.page_adjust_credit(str(payload.get("key") or ""), float(payload.get("credits") or 0), str(payload.get("mode") or "add"))
        elif action == "user_model":
            res = await self.page_set_user_model(str(payload.get("key") or ""), str(payload.get("model") or ""))
        elif action == "blacklist":
            res = await self.page_blacklist(str(payload.get("key") or ""), str(payload.get("action") or "toggle"))
        elif action == "presets":
            res = await self.page_save_presets(payload.get("style_presets", {}))
        elif action in ("model_protocols", "protocols"):
            res = {
                "rules": self._parse_endpoint_rules(),
                "learned": [
                    {"model": k, **v} for k, v in self.learned_protocols.items()
                ],
                "protocol_options": [
                    {"value": k, "label": v} for k, v in PROTOCOL_LABELS.items()
                ],
            }
        elif action in ("save_model_protocols", "save_protocols"):
            rules = payload.get("rules", [])
            self.config["model_endpoint_rules"] = rules
            self._save_config()
            res = {
                "saved": True,
                "rules": self._parse_endpoint_rules(),
            }
        elif action in ("clear_learned_protocols", "clear_protocols"):
            target_model = str(payload.get("model") or "").strip()
            if target_model:
                self.learned_protocols.pop(target_model, None)
            else:
                self.learned_protocols.clear()
            self._save_learned_protocols()
            res = {
                "ok": True,
                "learned": [
                    {"model": k, **v} for k, v in self.learned_protocols.items()
                ],
            }
        elif action in ("probe_model_protocol", "probe_protocol"):
            model_name = str(payload.get("model") or "").strip()
            target_endpoint = str(payload.get("custom_endpoint") or payload.get("endpoint") or "").strip()
            target_format = str(payload.get("custom_format") or payload.get("format") or "").strip()
            res = await self.probe_model_endpoint(model_name, target_endpoint=target_endpoint, target_format=target_format)
        else:
            return {"ok": False, "error": f"未知 Action: {action}"}
        if isinstance(res, dict) and "ok" not in res:
            res["ok"] = True
        return res


def setup(context: Any) -> DrawImgServicePlugin:
    plugin = DrawImgServicePlugin(context)
    context.register_command("dg", plugin.handle_dg, category="drawimg", description="绘图服务主入口")
    context.register_command("dgs", plugin.handle_dg, category="drawimg", description="绘图服务主入口")
    context.register_command("dge", plugin.handle_dge, category="drawimg", description="单图改图")
    context.register_command("dgse", plugin.handle_dge, category="drawimg", description="单图改图")
    context.register_command("dgm", plugin.handle_dgm, category="drawimg", description="多图改图")
    context.register_command("dgsm", plugin.handle_dgm, category="drawimg", description="多图改图")
    context.register_event_handler("*", plugin.on_event)
    context.register_task("cleanup", 3600, plugin.cleanup)
    context.register_task("check_payments", 15, plugin.poll_pending_payments)
    if hasattr(context, "register_action"):
        context.register_action("overview", plugin.action_overview)
        context.register_action("page_overview", plugin.action_overview)
        context.register_action("users", plugin.action_users)
        context.register_action("page_users", plugin.action_users)
        context.register_action("save_config", plugin.action_save_config)
        context.register_action("config", plugin.action_save_config)
        for act in (
            "page_data", "data", "fetch_models", "user_credit", "user_model", "blacklist", "presets",
            "model_protocols", "protocols", "save_model_protocols", "clear_learned_protocols", "probe_model_protocol"
        ):
            context.register_action(act, plugin.on_page_action)
    return plugin
