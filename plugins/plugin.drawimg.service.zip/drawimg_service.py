"""🎨 绘图服务插件 (plugin.drawimg.service)
移植自 AstrBot 绘图服务版插件 (0.09 版本)，为 QQ Runtime 深度定制的原生无 Key 绘图服务系统。

主要功能：
- 管理员统一配置全局 OpenAI 格式画图 API (如 New API / One API / OpenAI / Midjourney 代理)。
- 普通用户无需自备 Key，按积分消耗生成图片。
- 支持 567 在线充值 (对接 runtime.pay 模块)。
- 全套 QQ 原生 Markdown + 交互键盘卡片操作。

支持指令：
- `/dg <提示词>`  — AI 文生图
- `/dge <提示词>`  — 单图改图（参考用户最近发送的图片）
- `/dgm <提示词>`  — 多图融合改图（参考最近 2~3 张图片）
- `/dg style [预设名]`  — 查看或切换风格预设（支持 /dg style add、/dg style rm、/dg style my、/dg style off）
- `/dg size [尺寸]`  — 切换生成尺寸（1024x1024, 1024x1792, 1792x1024, auto）
- `/dg quality [质量]`  — 切换画面质量（standard, hd, auto）
- `/dg models`  — 查看所有可用 AI 绘图模型列表
- `/dg model <名称>`  — 切换当前使用的默认生图模型
- `/dg status`  — 查询个人积分余额与偏好配置
- `/dg pay <积分>`  — 在线充值积分
- `/dg top`  — 查看用户积分排行（管理员）
- `/dg admin`  — 绘图服务管理员面板（管理员）
- `/dg give <@用户或OpenID> <积分>`  — 赠送或调整用户积分（管理员）
- `/dg rate <单价>`  — 设置积分单价（元/积分，管理员）
- `/dg cost <模型>:<积分>`  — 设置各模型计费价格（管理员）
- `/dg blacklist <add/del/list> <用户>`  — 生图服务黑名单（管理员）
"""

from __future__ import annotations

import asyncio
import base64
import inspect
import json
import logging
import os
import re
import socket
import struct
import sys
import time
import urllib.parse
import uuid
from pathlib import Path
from typing import Any

import aiohttp
import httpx

from runtime.models import Button, Card, MessageContext

logger = logging.getLogger("plugin.drawimg.service")

_DNS_CACHE: dict[str, tuple[float, str]] = {}
_NAMESERVERS = ("223.5.5.5", "223.6.6.6", "119.29.29.29", "192.168.1.1", "1.1.1.1")

def _resolve_dns_a(domain: str, ns: str = "223.5.5.5", timeout: float = 1.5) -> list[str]:
    tx_id = 0x1234
    flags = 0x0100
    header = struct.pack("!HHHHHH", tx_id, flags, 1, 0, 0, 0)
    qname = b"".join(bytes([len(p)]) + p.encode("ascii") for p in domain.split(".")) + b"\x00"
    question = qname + struct.pack("!HH", 1, 1)
    packet = header + question

    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    sock.settimeout(timeout)
    try:
        sock.sendto(packet, (ns, 53))
        data, _ = sock.recvfrom(512)
        ips = []
        if len(data) > 12:
            ancount = struct.unpack("!H", data[6:8])[0]
            offset = 12 + len(question)
            for _ in range(ancount):
                if offset >= len(data):
                    break
                if (data[offset] & 0xC0) == 0xC0:
                    offset += 2
                else:
                    while offset < len(data) and data[offset] != 0:
                        offset += data[offset] + 1
                    offset += 1
                if offset + 10 > len(data):
                    break
                atype, aclass, ttl, rdlength = struct.unpack("!HHIH", data[offset:offset+10])
                offset += 10
                if atype == 1 and rdlength == 4:
                    ips.append(socket.inet_ntoa(data[offset:offset+4]))
                offset += rdlength
        return ips
    finally:
        sock.close()

async def _resolve_domain_ip(domain: str) -> str:
    try:
        socket.inet_aton(domain)
        return domain
    except OSError:
        pass

    now = time.time()
    if domain in _DNS_CACHE:
        cached_t, cached_ip = _DNS_CACHE[domain]
        if now - cached_t < 600:
            return cached_ip

    for ns in _NAMESERVERS:
        try:
            loop = asyncio.get_running_loop()
            ips = await loop.run_in_executor(None, _resolve_dns_a, domain, ns, 1.5)
            if ips:
                _DNS_CACHE[domain] = (now, ips[0])
                return ips[0]
        except Exception:
            continue

    try:
        ip = await asyncio.get_running_loop().run_in_executor(None, socket.gethostbyname, domain)
        _DNS_CACHE[domain] = (now, ip)
        return ip
    except Exception:
        return domain

async def _prepare_target(url: str, headers: dict[str, str]) -> tuple[str, dict[str, str], str | None]:
    parsed = urllib.parse.urlparse(url)
    hostname = parsed.hostname or ""
    req_headers = dict(headers)
    if not hostname:
        return url, req_headers, None
    ip = await _resolve_domain_ip(hostname)
    if ip and ip != hostname:
        req_headers["Host"] = hostname
        port_str = f":{parsed.port}" if parsed.port else ""
        target_url = f"{parsed.scheme}://{ip}{port_str}{parsed.path}"
        if parsed.query:
            target_url += f"?{parsed.query}"
        return target_url, req_headers, hostname
    return url, req_headers, None

def _normalize_scene(context: MessageContext) -> str:
    raw = getattr(context, "scene", None) or getattr(context, "conversation_type", None) or "group"
    s = str(raw).lower().strip()
    if s in {"c2c", "private", "friend", "user", "dm", "c2c_message_create"}:
        return "c2c"
    if s in {"channel", "guild", "guild_direct"}:
        return "channel"
    return "group"

PLUGIN_VERSION = "0.1.2"

DEFAULT_CONFIG = {
    "api_base_url": "",
    "api_key": "",
    "default_model": "dall-e-3",
    "image_size": "auto",
    "image_quality": "auto",
    "enable_group": True,
    "test_credit_cost": 1,
    "credit_cost_rules": "",
    "credit_price_yuan": 0.1,
    "cooldown_sec": 10,
    "max_prompt_chars": 4000,
    "style_presets": "动漫:动漫风格,赛璐璐,鲜艳色彩;写实:超写实风格,照片级细节,自然光影;赛博朋克:赛博朋克风格,霓虹灯,未来都市;古风:国风水墨,中国传统古风,唯美意境",
    "same_cache_sec": 0,
    "test_daily_limit": 0,
    "test_blacklist": [],
    "prefer_b64_response": True,
    "edit_image_ttl_min": 10,
    "request_timeout_sec": 180,
    "models_cache_ttl_sec": 600,
    "network_error_message": "生图服务当前不可用，请稍后重试。",
}

HELP_TEXT = (
    "【🎨 绘图服务使用指南】\n"
    "1. 发送 /dg models 查看可用生图模型；\n"
    "2. 发送 /dg style 选择画风预设；\n"
    "3. 发送 /dg <提示词> 即可开始文生图创作；\n"
    "4. 先在聊天中发图，再发送 /dge <修改词> 进行单图改图；连发 2~3 张图后用 /dgm <融合词> 进行多图融合改图；\n"
    "5. 积分不足时发送 /dg pay <数量> 在线充值，/dg status 查看当前积分与配置。"
)

GUIDE_TEXT = (
    "【开始使用】\n"
    "1. 先用 /dg models 查看并选择模型；\n"
    "2. 用 /dg style 选择风格预设（可选）；\n"
    "3. 发送 /dg <提示词> 开始文生图；\n"
    "4. 先发图片，再发送 /dge <提示词> 编辑单图；连发 2~3 张图后用 /dgm <提示词> 编辑多图。\n\n"
    "积分不足时使用 /dg pay <数量> 充值。/dg status 查看余额与当前设置。"
)


def _btn(
    label: str,
    command: str,
    *,
    fill: bool = False,
    action_type: int | None = None,
    permission: int | None = None,
    expires_after_seconds: int = 600,
    click_limit: int | None = 30,
    style: str = "normal",
) -> Button:
    cmd = command.strip()
    is_input = fill or command.endswith(" ")
    if action_type is None:
        action_type = 2 if is_input else 1
    enter = False if action_type == 2 else True

    if permission is None:
        if any(cmd.startswith(p) for p in ("/dg admin", "/dg rate", "/dg cost", "/dg give", "/dg blacklist", "/dg top", "/dg config")):
            permission = 1
        else:
            permission = 2

    return Button(
        label[:10],
        command,
        style=style,
        action_type=action_type,
        enter=enter,
        permission=permission,
        click_limit=click_limit,
        expires_after_seconds=expires_after_seconds,
        expired_message="此按钮已过期，请重新打开菜单。",
        permission_message="此操作需要管理员权限。" if permission == 1 else "此操作为专属用户操作。",
    )


def _clean_user_id(raw: Any) -> str:
    s = str(raw or "").strip()
    if not s or s.startswith("_") or s in {"default_user", "null", "undefined"}:
        return "default_user"
    if s.startswith("<@") and s.endswith(">"):
        s = s[2:-1]
        if s.startswith("!") or s.startswith("&"):
            s = s[1:]
    s = s.lstrip("@").strip()
    if s.startswith("qq_official:"):
        s = s[len("qq_official:"):].strip()
    return s or "default_user"


def _extract_mention_target(context: MessageContext) -> str:
    for item in getattr(context, "mentions", []):
        if not isinstance(item, dict):
            continue
        identifier = str(item.get("id") or item.get("user_id") or item.get("openid") or "").strip()
        bot_id = str(getattr(context, "bot_id", "") or "unknown_selfid").strip()
        if identifier and identifier != bot_id:
            return _clean_user_id(identifier)
    text = str(getattr(context, "text", "") or "")
    m = re.search(r"<@!?([A-Za-z0-9_-]{6,64})>", text)
    if m:
        return _clean_user_id(m.group(1))
    return ""


def _scan_component_or_dict(node: Any, found: list[str], depth: int = 0) -> None:
    if depth > 6 or node is None:
        return
    if isinstance(node, str):
        patterns = (
            r"https?://[^\s\"'<>]+?\.(?:jpg|jpeg|png|webp|gif|bmp)(?:\?[^\s\"'<>]*)?",
            r"https?://multimedia\.nt\.qq\.com\.cn/download\?[^\s\"'<>]+",
            r"https?://[a-zA-Z0-9.-]*qpic\.cn/[^\s\"'<>]+",
        )
        for pat in patterns:
            for match in re.findall(pat, node, re.IGNORECASE):
                if match not in found:
                    found.append(match)
        return
    if isinstance(node, (list, tuple)):
        for item in node:
            _scan_component_or_dict(item, found, depth + 1)
        return
    if isinstance(node, dict):
        url = node.get("url") or node.get("src") or node.get("file_url") or node.get("image_url")
        content_type = str(node.get("content_type") or node.get("type") or "").lower()
        filename = str(node.get("filename") or node.get("name") or "").lower()
        if isinstance(url, str) and url.startswith("http"):
            is_img = (
                content_type.startswith("image/")
                or any(filename.endswith(ext) for ext in (".jpg", ".jpeg", ".png", ".webp", ".gif", ".bmp"))
                or any(node.get(k) for k in ("width", "height", "term", "fileid"))
                or "multimedia.nt.qq.com.cn" in url
                or "qpic.cn" in url
                or re.search(r"\.(?:jpg|jpeg|png|webp|gif|bmp)(?:\?|$)", url, re.I)
                or not content_type
            )
            if is_img and url not in found:
                found.append(url)
        for k, v in node.items():
            if k not in {"url", "src", "file_url", "image_url"}:
                _scan_component_or_dict(v, found, depth + 1)
        return

    for attr in ("url", "file", "path", "attachments", "raw_payload", "text", "message_obj", "raw_message"):
        val = getattr(node, attr, None)
        if val is not None and val != "":
            if isinstance(val, str) and val.startswith("http") and val not in found:
                found.append(val)
            else:
                _scan_component_or_dict(val, found, depth + 1)


def extract_image_urls(context: Any) -> list[str]:
    found: list[str] = []
    attachments = getattr(context, "attachments", None)
    if attachments:
        _scan_component_or_dict(attachments, found, depth=0)
    text = getattr(context, "text", None)
    if text:
        _scan_component_or_dict(text, found, depth=0)
    raw = getattr(context, "raw_payload", None)
    if raw:
        _scan_component_or_dict(raw, found, depth=0)
    return found


class DrawImgServicePlugin:
    def __init__(self, context: Any) -> None:
        self.context = context
        self.is_isolated = "pytest" in sys.modules or "tmp" in str(getattr(context, "data_dir", ""))
        default_data_dir = Path("./data/plugin-data/plugin.drawimg.service")
        default_config_dir = Path("./data/plugin-config/plugin.drawimg.service")
        self.perm_dir = default_data_dir if not self.is_isolated else Path(getattr(context, "data_dir", default_data_dir))
        self.perm_dir.mkdir(parents=True, exist_ok=True)

        self.config_dir = Path(getattr(context, "config_dir", default_config_dir if not self.is_isolated else self.perm_dir))
        self.data_dir = Path(getattr(context, "data_dir", self.perm_dir))
        self.config_dir.mkdir(parents=True, exist_ok=True)
        self.data_dir.mkdir(parents=True, exist_ok=True)

        self.config_path = self.config_dir / "config.json"
        self.credits_path = self.data_dir / "credits.json"
        self.user_prefs_path = self.data_dir / "user_prefs.json"
        self.history_path = self.data_dir / "history.json"

        # Load and merge credits from all known persistent files
        self.credits: dict[str, int] = {}
        candidate_credit_paths = [self.credits_path, self.perm_dir / "credits.json"]
        if not self.is_isolated:
            candidate_credit_paths.extend([
                Path("./data/plugin-data/plugin.drawimg.service/credits.json"),
                Path("./data/plugins/plugin.drawimg.service/credits.json"),
                Path("./data/plugins/plugin.drawimg.service/data/credits.json"),
                Path("./data/drawimg/credits.json"),
            ])
        # Clean up legacy files accidentally written to plugin installation code directory
        if not self.is_isolated:
            legacy_code_dir = Path("./data/plugins/plugin.drawimg.service")
            if legacy_code_dir.exists() and legacy_code_dir.is_dir():
                for legacy_name in ("credits.json", "user_prefs.json", "config.json", "history.json", "recent_images.json"):
                    lp = legacy_code_dir / legacy_name
                    if lp.exists() and lp.is_file():
                        try:
                            lp.unlink()
                        except Exception:
                            pass
                for sub in ("data", "config"):
                    sub_p = legacy_code_dir / sub
                    if sub_p.exists() and sub_p.is_dir():
                        try:
                            import shutil
                            shutil.rmtree(sub_p, ignore_errors=True)
                        except Exception:
                            pass
        for p in candidate_credit_paths:
            loaded = self._load_json(p, {})
            if isinstance(loaded, dict):
                for k, v in loaded.items():
                    if k not in self.credits or self.credits[k] == 0:
                        try:
                            self.credits[str(k)] = int(v)
                        except (ValueError, TypeError):
                            pass

        # Load and merge config from all known persistent files & SQLite
        self.config: dict[str, Any] = dict(DEFAULT_CONFIG)
        if not self.is_isolated:
            try:
                db_file = Path("data/runtime.sqlite3")
                if db_file.exists():
                    import sqlite3
                    with sqlite3.connect(str(db_file), timeout=2.0) as conn:
                        cur = conn.cursor()
                        cur.execute("SELECT key, value FROM settings WHERE key LIKE 'dg.%'")
                        for k, v in cur.fetchall():
                            short_k = k[3:]
                            if short_k and v not in (None, ""):
                                self.config[short_k] = v
            except Exception:
                pass

        candidate_config_paths = [self.config_path, self.perm_dir / "config.json"]
        if not self.is_isolated:
            candidate_config_paths.extend([
                Path("./data/plugin-config/plugin.drawimg.service/config.json"),
                Path("./data/plugins/plugin.drawimg.service/config.json"),
                Path("./data/plugins/plugin.drawimg.service/config/config.json"),
            ])
        for p in candidate_config_paths:
            loaded = self._load_json(p, {})
            if isinstance(loaded, dict):
                for k, v in loaded.items():
                    if v not in (None, ""):
                        self.config[k] = v

        # Load and merge user_prefs
        self.user_prefs: dict[str, Any] = {}
        candidate_pref_paths = [self.user_prefs_path, self.perm_dir / "user_prefs.json"]
        if not self.is_isolated:
            candidate_pref_paths.extend([
                Path("./data/plugin-data/plugin.drawimg.service/user_prefs.json"),
                Path("./data/plugins/plugin.drawimg.service/user_prefs.json"),
                Path("./data/plugins/plugin.drawimg.service/data/user_prefs.json"),
            ])
        for p in candidate_pref_paths:
            loaded = self._load_json(p, {})
            if isinstance(loaded, dict):
                for k, v in loaded.items():
                    if k not in self.user_prefs:
                        self.user_prefs[k] = v

        # Only retain _processed_orders from history (for payment idempotency), no user generation history
        self.history: dict[str, Any] = {}
        candidate_hist_paths = [self.history_path, self.perm_dir / "history.json"]
        if not self.is_isolated:
            candidate_hist_paths.extend([
                Path("./data/plugin-data/plugin.drawimg.service/history.json"),
                Path("./data/plugins/plugin.drawimg.service/history.json"),
                Path("./data/plugins/plugin.drawimg.service/data/history.json"),
            ])
        for p in candidate_hist_paths:
            loaded = self._load_json(p, {})
            if isinstance(loaded, dict) and "_processed_orders" in loaded:
                self.history["_processed_orders"] = loaded["_processed_orders"]
                break

        self.recent_images: dict[str, list[tuple[float, str]]] = {}
        self.recent_images_path = self.data_dir / "recent_images.json"
        self._load_recent_images()
        self.same_cache: dict[str, tuple[float, str]] = {}
        self.models_cache: tuple[float, list[str]] | None = None
        self.last_action_time: dict[str, float] = {}
        self.pending_pay_orders_file = self.data_dir / "pending_orders.json"
        loaded_pending = self._load_json(self.pending_pay_orders_file, {})
        self.pending_pay_orders: dict[str, dict[str, Any]] = loaded_pending if isinstance(loaded_pending, dict) else {}
        self._b64_rejected = False

        try:
            pay_api = getattr(self.context, "builtin", lambda name: None)("runtime.pay")
            if pay_api and hasattr(pay_api, "subscribe"):
                res = pay_api.subscribe("plugin.drawimg.service", self.on_payment_success)
                if inspect.isawaitable(res):
                    try:
                        import asyncio
                        loop = asyncio.get_running_loop()
                        if loop.is_running():
                            loop.create_task(res)
                    except RuntimeError:
                        if hasattr(res, "close"):
                            res.close()
        except Exception:
            pass

        try:
            from .credit_service import set_credit_service
            set_credit_service(self)
        except Exception:
            pass

    def _load_json(self, path: Path, default: Any) -> Any:
        try:
            if path.exists():
                return json.loads(path.read_text(encoding="utf-8"))
        except Exception as e:
            logger.warning("Failed to load JSON from %s: %s", path, e)
        return default.copy() if isinstance(default, (dict, list)) else default

    def _save_json(self, path: Path, data: Any) -> None:
        try:
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
        except Exception as e:
            logger.error("Failed to save JSON to %s: %s", path, e)
        # Also backup to permanent storage folders in data/ so re-uploading ZIP never loses data
        if not self.is_isolated:
            try:
                fname = path.name
                target_paths = [
                    self.perm_dir / fname,
                    Path(f"./data/plugin-data/plugin.drawimg.service/{fname}"),
                    Path(f"./data/plugin-config/plugin.drawimg.service/{fname}"),
                ]
                for tp in target_paths:
                    if tp.resolve() == path.resolve():
                        continue
                    try:
                        tp.parent.mkdir(parents=True, exist_ok=True)
                        tp.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
                    except Exception:
                        pass
            except Exception:
                pass

    def _save_pending_orders(self) -> None:
        try:
            self._save_json(self.pending_pay_orders_file, self.pending_pay_orders)
        except Exception as e:
            logger.warning("Failed to save pending orders: %s", e)

    def _load_recent_images(self) -> None:
        try:
            candidate_paths = [self.recent_images_path, self.perm_dir / "recent_images.json"]
            if not self.is_isolated:
                candidate_paths.extend([
                    Path("./data/plugin-data/plugin.drawimg.service/recent_images.json"),
                    Path("./data/plugins/plugin.drawimg.service/recent_images.json"),
                    Path("./data/plugins/plugin.drawimg.service/data/recent_images.json"),
                ])
            now = time.time()
            ttl = max(1, int(self._get_cfg("edit_image_ttl_min", 10) or 10)) * 60
            for p in candidate_paths:
                loaded = self._load_json(p, {})
                if isinstance(loaded, dict):
                    for uid, items in loaded.items():
                        if isinstance(items, list):
                            fresh = [(float(t), str(u)) for (t, u) in items if isinstance(u, str) and now - float(t) <= ttl]
                            if fresh:
                                cur = self.recent_images.setdefault(str(uid), [])
                                existing_urls = {u for (_, u) in cur}
                                for t, u in fresh:
                                    if u not in existing_urls:
                                        cur.append((t, u))
                                cur.sort(key=lambda x: x[0])
                                self.recent_images[str(uid)] = cur[-10:]
        except Exception as e:
            logger.debug("Failed to load recent images: %s", e)

    def _save_recent_images(self) -> None:
        try:
            self._save_json(self.recent_images_path, self.recent_images)
        except Exception as e:
            logger.debug("Failed to save recent images: %s", e)

    def _recent_urls_within_ttl(self, context: Any, limit: int = 3) -> list[str]:
        user_id = self._user_id(context)
        now = time.time()
        ttl = max(1, int(self._get_cfg("edit_image_ttl_min", 10) or 10)) * 60
        user_imgs = self.recent_images.get(user_id, [])
        fresh = [u for (t, u) in user_imgs if now - t <= ttl]
        self.recent_images[user_id] = [(t, u) for (t, u) in user_imgs if now - t <= ttl]
        return fresh[-limit:]

    def _clear_recent_images(self, user_id: str, urls: list[str] | None = None) -> None:
        """清空或移除用户暂存的参考图片（多图编辑生成后清空）。"""
        if user_id not in self.recent_images:
            return
        if urls:
            remove_set = set(urls)
            self.recent_images[user_id] = [
                (t, u) for (t, u) in self.recent_images.get(user_id, [])
                if u not in remove_set
            ]
            if not self.recent_images[user_id]:
                self.recent_images.pop(user_id, None)
        else:
            self.recent_images.pop(user_id, None)
        self._save_recent_images()

    def _reload_config_if_changed(self) -> None:
        try:
            mtime = self.config_path.stat().st_mtime if self.config_path.exists() else 0
            if getattr(self, "_config_mtime", 0) != mtime:
                self._config_mtime = mtime
                loaded = self._load_json(self.config_path, {})
                if isinstance(loaded, dict) and loaded:
                    for k, v in loaded.items():
                        if v not in (None, ""):
                            self.config[k] = v
        except Exception:
            pass

    def _get_cfg(self, key: str, default: Any = "") -> Any:
        self._reload_config_if_changed()
        val = self.config.get(key)
        if val not in (None, ""):
            return val
        disk_cfg = self._load_json(self.config_path, {})
        if disk_cfg.get(key) not in (None, ""):
            self.config[key] = disk_cfg[key]
            return disk_cfg[key]
        if not self.is_isolated:
            perm_cfg = self._load_json(self.perm_dir / "config.json", {}) or self._load_json(self.perm_dir / "config" / "config.json", {})
            if perm_cfg.get(key) not in (None, ""):
                self.config[key] = perm_cfg[key]
                return perm_cfg[key]
        runtime = getattr(self.context, "_runtime", None) or getattr(self.context, "runtime", None)
        if runtime:
            if hasattr(runtime, "drawimg") and hasattr(runtime.drawimg, "_cfg"):
                drawimg_val = runtime.drawimg._cfg(key)
                if drawimg_val not in (None, ""):
                    return drawimg_val
            if hasattr(runtime, "database"):
                db_cache = getattr(runtime.database, "_settings_cache", {}) or getattr(runtime.database, "settings_cache", {})
                db_val = db_cache.get(f"dg.{key}")
                if db_val not in (None, ""):
                    return db_val
        if not self.is_isolated:
            try:
                db_file = Path("data/runtime.sqlite3")
                if db_file.exists():
                    import sqlite3
                    with sqlite3.connect(str(db_file), timeout=2.0) as conn:
                        cur = conn.cursor()
                        cur.execute("SELECT value FROM settings WHERE key = ?", (f"dg.{key}",))
                        row = cur.fetchone()
                        if row and row[0] not in (None, ""):
                            return row[0]
            except Exception:
                pass
        env_val = os.environ.get(f"DG_{key.upper()}") or os.environ.get(f"DRAWIMG_{key.upper()}")
        if env_val:
            return env_val
        return DEFAULT_CONFIG.get(key, default)

    def _save_config(self) -> None:
        self.models_cache = None
        self._save_json(self.config_path, self.config)
        runtime = getattr(self.context, "_runtime", None)
        if runtime and hasattr(runtime, "drawimg") and hasattr(runtime.drawimg, "config"):
            for k, v in self.config.items():
                runtime.drawimg.config[k] = v
        if not self.is_isolated:
            try:
                db_file = Path("data/runtime.sqlite3")
                if db_file.exists():
                    import sqlite3
                    with sqlite3.connect(str(db_file), timeout=2.0) as conn:
                        cur = conn.cursor()
                        for k, v in self.config.items():
                            val_str = json.dumps(v, ensure_ascii=False) if isinstance(v, (dict, list)) else str(v)
                            cur.execute(
                                "INSERT INTO settings(key, value, updated_at) VALUES(?, ?, CURRENT_TIMESTAMP) "
                                "ON CONFLICT(key) DO UPDATE SET value=excluded.value, updated_at=CURRENT_TIMESTAMP",
                                (f"dg.{k}", val_str)
                            )
                        conn.commit()
            except Exception:
                pass

    def _points(self) -> Any:
        return getattr(self.context, "points", None)

    def _save_credits(self) -> None:
        self._save_json(self.credits_path, self.credits)

    def _save_user_prefs(self) -> None:
        self._save_json(self.user_prefs_path, self.user_prefs)

    def _save_history(self) -> None:
        self._save_json(self.history_path, self.history)

    def _api_base_url(self) -> str:
        base = str(self._get_cfg("api_base_url") or "").strip().rstrip("/")
        if base.casefold().endswith("/v1"):
            base = base[:-3].rstrip("/")
        return base

    def _api_key(self) -> str:
        return str(self._get_cfg("api_key") or "").strip()

    def _user_id(self, context: MessageContext) -> str:
        raw = getattr(context, "member_openid", None) or getattr(context, "sender_id", None) or getattr(context, "user_id", None) or "default_user"
        return _clean_user_id(raw)

    async def _get_balance(self, user_id: str) -> int:
        uid = _clean_user_id(user_id)
        points = self._points()
        if points is not None and hasattr(points, "balance"):
            try:
                bal = await points.balance(uid, "drawimg")
                bal_int = int(bal)
                self.credits[uid] = bal_int
                self.credits.pop(f"<@{uid}>", None)
                self.credits.pop(f"qq_official:{uid}", None)
                return bal_int
            except Exception as e:
                logger.warning("Failed to query points via context.points for %s: %s", uid, e)

        for candidate in (uid, f"<@{uid}>", f"qq_official:{uid}"):
            if candidate in self.credits:
                val = int(self.credits[candidate])
                if candidate != uid:
                    self.credits[uid] = max(int(self.credits.get(uid, 0)), val)
                    self.credits.pop(candidate, None)
                    self._save_credits()
                return int(self.credits[uid])

        return 0

    async def _change_balance(self, user_id: str, delta: int, reason: str = "") -> int:
        uid = _clean_user_id(user_id)
        current = await self._get_balance(uid)
        if delta == 0:
            return current

        points = self._points()
        if points is not None and hasattr(points, "credit") and hasattr(points, "debit"):
            try:
                op_id = f"dg:{uid}:{int(time.time() * 1000)}:{uuid.uuid4().hex[:6]}"
                if delta > 0:
                    new_bal = await points.credit(
                        uid, str(delta), reason or "drawimg.credit",
                        point_type="drawimg", operation_id=op_id,
                    )
                else:
                    new_bal = await points.debit(
                        uid, str(abs(delta)), reason or "drawimg.debit",
                        point_type="drawimg", operation_id=op_id,
                    )
                bal_int = int(new_bal)
                self.credits[uid] = bal_int
                self.credits.pop(f"<@{uid}>", None)
                self.credits.pop(f"qq_official:{uid}", None)
                return bal_int
            except Exception as e:
                logger.warning("Failed to change points via context.points for %s: %s", uid, e)

        new_balance = max(0, current + delta)
        self.credits.pop(f"<@{uid}>", None)
        self.credits.pop(f"qq_official:{uid}", None)
        self.credits[uid] = new_balance
        self._save_credits()
        return new_balance

    # ---------- Inter-plugin Credit Interface ----------

    def get_balance(self, user_id: str) -> int:
        uid = _clean_user_id(user_id)
        for candidate in (uid, f"<@{uid}>", f"qq_official:{uid}"):
            if candidate in self.credits:
                return int(self.credits[candidate])
        return 0

    def change_balance(self, user_id: str, delta: int, reason: str = "") -> int:
        uid = _clean_user_id(user_id)
        val = max(0, self.get_balance(uid) + delta)
        self.credits[uid] = val
        self._save_credits()
        return val

    async def get_balance_async(self, user_id: str) -> int:
        return await self._get_balance(user_id)

    async def change_balance_async(self, user_id: str, delta: int, reason: str = "") -> int:
        return await self._change_balance(user_id, delta, reason)

    async def reserve_credits(self, user_id: str, amount: int, op_id: str = "") -> bool:
        bal = await self._get_balance(user_id)
        if bal < amount:
            return False
        await self._change_balance(user_id, -amount, reason=f"reserve:{op_id}")
        return True

    async def settle_credits(self, user_id: str, amount: int, op_id: str = "") -> bool:
        return True

    async def refund_credits(self, user_id: str, amount: int, op_id: str = "") -> bool:
        await self._change_balance(user_id, amount, reason=f"refund:{op_id}")
        return True

    def _model_cost(self, model: str) -> int:
        rules_raw = self._get_cfg("credit_cost_rules", "")
        model_norm = str(model).strip().lower()
        if isinstance(rules_raw, dict):
            for k, v in rules_raw.items():
                if str(k).strip().lower() == model_norm:
                    try:
                        return max(1, int(v))
                    except (ValueError, TypeError):
                        pass
        elif isinstance(rules_raw, str) and rules_raw.strip():
            raw_str = rules_raw.strip()
            if raw_str.startswith("{") and raw_str.endswith("}"):
                try:
                    loaded = json.loads(raw_str)
                    if isinstance(loaded, dict):
                        for k, v in loaded.items():
                            if str(k).strip().lower() == model_norm:
                                try:
                                    return max(1, int(v))
                                except (ValueError, TypeError):
                                    pass
                except Exception:
                    pass
            for rule in re.split(r"[;,\n]+", raw_str):
                parts = rule.strip().split(":", 1)
                if len(parts) == 2:
                    k = parts[0].strip().strip('"').strip("'").strip("{").strip("}")
                    if k.lower() == model_norm:
                        try:
                            v = parts[1].strip().strip('"').strip("'").strip("{").strip("}")
                            return max(1, int(v))
                        except (ValueError, TypeError):
                            pass
        return max(1, int(self._get_cfg("test_credit_cost", 1)))

    def _default_model(self) -> str:
        return str(self._get_cfg("default_model", "gpt-image-1"))

    def _user_model(self, user_id: str) -> str:
        uid = _clean_user_id(user_id)
        for cand in (uid, f"qq_official:{uid}"):
            if cand in self.user_prefs and isinstance(self.user_prefs[cand], dict) and self.user_prefs[cand].get("model"):
                return str(self.user_prefs[cand]["model"])
        return self._default_model()

    def _handle_model(self, context: MessageContext, args: list[str]) -> str | Card:
        uid = self._user_id(context)
        if not args:
            cur_model = self._user_model(uid)
            def_model = self._default_model()
            cost = self._model_cost(cur_model)
            is_custom = bool(self.user_prefs.get(uid, {}).get("model"))
            custom_hint = "（个人偏好锁定）" if is_custom else "（跟随全局默认）"
            return Card(
                "生图模型设置",
                f"当前使用模型：`{cur_model}` {custom_hint}\n"
                f"- 每次生图消耗：**{cost}** 积分/次\n"
                f"- 全局默认模型：`{def_model}`\n\n"
                "可用指令：\n"
                "- `/dg model <模型名称>` — 切换个人生图模型\n"
                "- `/dg model reset` — 恢复跟随全局默认模型\n"
                "- `/dg models` — 查看可用模型列表",
                rows=[
                    [_btn("重置为默认", "/dg model reset"), _btn("查看可用模型", "/dg models")],
                    [_btn("查看当前状态", "/dg status"), _btn("返回主菜单", "/dg")],
                ],
            )

        target = args[0].strip()
        if target.lower() in {"reset", "default", "auto", "off", "重置", "默认", "清除"}:
            if len(args) > 1 and context.is_admin:
                second = args[1].strip()
                if second.lower() in {"all", "全员", "所有"}:
                    count = 0
                    for k in list(self.user_prefs.keys()):
                        if isinstance(self.user_prefs[k], dict) and "model" in self.user_prefs[k]:
                            self.user_prefs[k].pop("model", None)
                            count += 1
                    self._save_user_prefs()
                    def_model = self._default_model()
                    return f"✅ 已成功重置所有用户（共 {count} 人）的模型偏好，全员已恢复为全局默认模型 `{def_model}`。"
                else:
                    target_user = _clean_user_id(second)
                    for cand in (target_user, f"qq_official:{target_user}"):
                        if cand in self.user_prefs and isinstance(self.user_prefs[cand], dict):
                            self.user_prefs[cand].pop("model", None)
                    self._save_user_prefs()
                    def_model = self._default_model()
                    return f"✅ 已重置用户 `{target_user}` 的模型设置，恢复跟随全局默认模型 `{def_model}`。"

            for cand in (uid, f"qq_official:{uid}"):
                if cand in self.user_prefs and isinstance(self.user_prefs[cand], dict):
                    self.user_prefs[cand].pop("model", None)
            self._save_user_prefs()
            def_model = self._default_model()
            cost = self._model_cost(def_model)
            return Card(
                "模型重置成功",
                f"已重置您的生图模型偏好，当前跟随时下全局默认模型：`{def_model}`\n\n- 每次生图消耗：**{cost}** 积分/次",
                rows=[
                    [_btn("立即生图", "/dg ", fill=True), _btn("查看可用模型", "/dg models")],
                    [_btn("查看当前状态", "/dg status"), _btn("返回主菜单", "/dg")],
                ],
            )

        model_name = target
        if len(args) > 1 and context.is_admin:
            target_user = _clean_user_id(args[1].strip())
            self.user_prefs.setdefault(target_user, {})["model"] = model_name
            self._save_user_prefs()
            cost = self._model_cost(model_name)
            return f"✅ 管理员已将用户 `{target_user}` 的生图模型设置为 `{model_name}`（单次消耗 {cost} 积分）。"

        self.user_prefs.setdefault(uid, {})["model"] = model_name
        self._save_user_prefs()
        cost = self._model_cost(model_name)
        return Card(
            "模型切换成功",
            f"已将您的生图模型切换为：`{model_name}`\n\n- 每次生图消耗：**{cost}** 积分/次\n- 随时发送 `/dg model reset` 可恢复跟随全局默认",
            rows=[
                [_btn("立即生图", "/dg ", fill=True), _btn("重置为默认", "/dg model reset")],
                [_btn("查看当前状态", "/dg status"), _btn("返回主菜单", "/dg")],
            ],
        )

    def _user_size(self, user_id: str) -> str:
        return self.user_prefs.get(user_id, {}).get("size") or str(self._get_cfg("image_size", "auto"))

    def _user_quality(self, user_id: str) -> str:
        return self.user_prefs.get(user_id, {}).get("quality") or str(self._get_cfg("image_quality", "auto"))

    def _user_style(self, user_id: str) -> str:
        return self.user_prefs.get(user_id, {}).get("style", "")

    # ---------- Event listener ----------

    async def on_event(self, context: MessageContext) -> None:
        # 指令消息与按钮交互事件无需提取图片，直接快速返回避免阻塞 worker
        if getattr(context, "message_type", None) == "interaction":
            return
        text_val = (getattr(context, "text", "") or "").strip()
        if text_val.startswith("/"):
            return

        urls = extract_image_urls(context)
        if not urls:
            return

        user_id = self._user_id(context)
        now = time.time()
        ttl = max(1, int(self._get_cfg("edit_image_ttl_min", 10) or 10)) * 60
        user_imgs = self.recent_images.setdefault(user_id, [])
        user_imgs = [(t, u) for (t, u) in user_imgs if now - t <= ttl]
        for u in urls:
            user_imgs.append((now, u))
        self.recent_images[user_id] = user_imgs[-10:]
        self._save_recent_images()

    # ---------- Periodic task ----------

    async def cleanup(self) -> None:
        now = time.time()
        ttl = max(1, int(self._get_cfg("edit_image_ttl_min", 10) or 10)) * 60
        changed = False
        for uid in list(self.recent_images.keys()):
            orig_len = len(self.recent_images[uid])
            self.recent_images[uid] = [(t, u) for (t, u) in self.recent_images[uid] if now - t <= ttl]
            if len(self.recent_images[uid]) != orig_len:
                changed = True
            if not self.recent_images[uid]:
                self.recent_images.pop(uid, None)
                changed = True
        if changed:
            self._save_recent_images()

    # ---------- Commands entry ----------

    async def handle_dg(self, context: MessageContext, args: list[str]) -> str | Card:
        if not args:
            return await self._main_menu_card(context)
        sub = args[0].lower()
        if sub in {"help", "帮助", "教程", "guide"}:
            return Card("使用教程", GUIDE_TEXT, rows=[
                [_btn("文生图", "/dg ", fill=True), _btn("单图编辑", "/dge ", fill=True)],
                [_btn("多图编辑", "/dgm ", fill=True), _btn("选择模型", "/dg models")],
                [_btn("选择预设", "/dg style"), _btn("充值积分", "/dg pay ", fill=True)],
                [_btn("返回主菜单", "/dg")],
            ])
        if sub in {"menu", "菜单"}:
            page = args[1].lower() if len(args) > 1 else ""
            return await self._menu_card(context, page)
        if sub in {"status", "状态", "余额", "credit", "credits"}:
            return await self._status_card(context)
        if sub in {"style", "风格", "preset", "预设"}:
            return await self._handle_style(context, args[1:])
        if sub in {"size", "尺寸"}:
            return self._handle_size(context, args[1:])
        if sub in {"quality", "质量", "画质"}:
            return self._handle_quality(context, args[1:])
        if sub in {"models", "模型", "模型列表"}:
            return await self._handle_models(context, args[1:])
        if sub in {"model", "切模型", "切换模型"}:
            return self._handle_model(context, args[1:])
        if sub in {"pay", "充值", "buy"}:
            return await self._handle_pay(context, args[1:])
        if sub in {"give", "赠送", "转账"}:
            return await self._handle_give(context, args[1:])
        if sub in {"top", "排行", "排行榜"}:
            return await self._handle_top(context)
        if sub in {"rate", "比例", "单价"}:
            return self._handle_rate(context, args[1:])
        if sub in {"cost", "计费", "价格"}:
            return self._handle_cost(context, args[1:])
        if sub in {"history", "历史"}:
            return self._handle_history(context)
        if sub in {"resend", "重发"}:
            return self._handle_resend(context, args[1:])
        if sub in {"admin", "管理", "面板"}:
            return self._handle_admin(context)
        if sub in {"blacklist", "黑名单"}:
            return self._handle_blacklist(context, args[1:])

        prompt = " ".join(args).strip()
        return await self._generate_flow(context, prompt, mode="txt2img", announce="生图")

    async def handle_dge(self, context: MessageContext, args: list[str]) -> str | Card:
        prompt = " ".join(args).strip()
        # 1. 优先检查当前消息本身是否带有图片
        current_urls = extract_image_urls(context)
        if current_urls:
            urls = current_urls[-1:]
            user_id = self._user_id(context)
            now = time.time()
            user_imgs = self.recent_images.setdefault(user_id, [])
            for u in current_urls:
                user_imgs.append((now, u))
            self.recent_images[user_id] = user_imgs[-10:]
            self._save_recent_images()
        else:
            urls = self._recent_urls_within_ttl(context, limit=1)

        ttl_min = max(1, int(self._get_cfg("edit_image_ttl_min", 10) or 10))
        if not urls:
            return (
                f"未找到您最近发送的图片。请先发送一张图片，然后在 {ttl_min} 分钟内执行 `/dge <修改要求>`。\n"
                f"多图改图：连发 2~3 张图后发送 `/dgm <修改要求>`。"
            )

        if not prompt:
            return Card("单图改图说明", f"已识别到您最近发送的 1 张图片（{ttl_min} 分钟内有效）。\n\n发送 `/dge <修改要求>` 即可立即开始改图。\n例如：`/dge 把它变成赛博朋克风格`", rows=[
                [_btn("改图输入", "/dge ", fill=True), _btn("选择模型", "/dg models")],
                [_btn("返回主菜单", "/dg")],
            ])

        return await self._generate_flow(context, prompt, edit_urls=urls, mode="img2img_single", announce="改图")

    async def handle_dgm(self, context: MessageContext, args: list[str]) -> str | Card:
        prompt = " ".join(args).strip()
        # 优先检查当前消息是否带图，若有则与最近历史合并
        current_urls = extract_image_urls(context)
        recent_urls = self._recent_urls_within_ttl(context, limit=3)
        # 仅取网络图片（用户主动发送的参考图片），排除系统本地生成的缓存图片
        user_recent = [u for u in recent_urls if u.startswith("http://") or u.startswith("https://")]
        combined = []
        for u in user_recent:
            if u not in combined:
                combined.append(u)
        for u in current_urls:
            if u not in combined:
                combined.append(u)
        urls = combined[-3:]

        ttl_min = max(1, int(self._get_cfg("edit_image_ttl_min", 10) or 10))
        if len(urls) < 2:
            return (
                f"多图改图需要至少 2 张参考图片。当前仅识别到 {len(urls)} 张。\n"
                f"请在 {ttl_min} 分钟内连发 2~3 张图片后，再发送 `/dgm <融合或修改要求>`。"
            )

        if not prompt:
            return Card("多图改图说明", f"已识别到您最近发送的 {len(urls)} 张图片（{ttl_min} 分钟内有效）。\n\n发送 `/dgm <融合或修改要求>` 即可开始多图改图。\n例如：`/dgm 将图一的人物融入图二的背景`", rows=[
                [_btn("多图改图", "/dgm ", fill=True), _btn("选择模型", "/dg models")],
                [_btn("返回主菜单", "/dg")],
            ])

        return await self._generate_flow(context, prompt, edit_urls=urls, mode="img2img_multi", announce="多图改图")

    # ---------- Core Image Generation (ported from runtime.drawimg) ----------

    async def _announce(self, context: MessageContext, text: str) -> None:
        qq = getattr(self.context, "qq", None)
        if qq is None:
            return
        scene = _normalize_scene(context)
        conv_id = (
            getattr(context, "conversation_id", "")
            or getattr(context, "group_id", "")
            or getattr(context, "sender_id", "")
        )
        if not conv_id:
            return
        try:
            await qq.send_text(conv_id, scene, text)
        except Exception:
            pass

    async def _async_generate_job(
        self,
        context: MessageContext,
        prompt: str,
        edit_urls: list[str] | None = None,
        mode: str = "txt2img",
        cost: int = 1,
    ) -> None:
        try:
            err = await self._generate(context, prompt, edit_urls=edit_urls, mode=mode, cost=cost)
            if err:
                try:
                    qq = getattr(self.context, "qq", None)
                    if qq:
                        conv_id = getattr(context, "conversation_id", "")
                        scene = _normalize_scene(context)
                        msg_id = getattr(context, "message_id", None)
                        if conv_id:
                            await qq.send_text(conv_id, scene, err, msg_id=msg_id)
                except Exception as send_e:
                    logger.warning("Failed to send generation failure notice: %s", send_e)
        except Exception as e:
            logger.exception("Unexpected error in background generation job: %s", e)

    async def _generate_flow(
        self,
        context: MessageContext,
        prompt: str,
        edit_urls: list[str] | None = None,
        mode: str = "txt2img",
        announce: str = "生图",
    ) -> str | Card:
        user_id = self._user_id(context)
        blacklist = self._get_cfg("test_blacklist", [])
        if user_id in blacklist:
            return "您已被管理员限制使用生图服务。"

        cooldown = int(self._get_cfg("cooldown_sec", 10))
        now = time.time()
        last_t = self.last_action_time.get(user_id, 0)
        if now - last_t < cooldown:
            return f"生图过于频繁，请等待 {int(cooldown - (now - last_t))} 秒后再试。"

        api_key = self._api_key()
        api_base = self._api_base_url()
        if not api_key or not api_base:
            return "插件尚未配置生图服务或密钥，请联系管理员。"

        model = self._user_model(user_id)
        cost = self._model_cost(model)

        balance = await self._get_balance(user_id)
        if balance < cost:
            price_yuan = float(self._get_cfg("credit_price_yuan", 0.1))
            return Card(
                "积分余额不足",
                f"当前生成需要 **{cost}** 积分，您当前余额为 **{balance}** 积分。\n\n"
                f"积分单价：**{price_yuan}** 元/积分。\n"
                f"发送 `/dg pay <积分数>` 即可在线充值。",
                rows=[
                    [
                        _btn("充值 10 积分", "/dg pay 10", action_type=1),
                        _btn("充值 50 积分", "/dg pay 50", action_type=1),
                        _btn("自定义充值", "/dg pay ", fill=True),
                    ],
                    [
                        _btn("我的状态", "/dg status"),
                        _btn("返回主菜单", "/dg"),
                    ],
                ],
            )

        self.last_action_time[user_id] = time.time()
        if mode == "img2img_multi":
            # 多图编辑确认发起生成，立即清空当时暂存的参考图片，避免重复复用
            self._clear_recent_images(user_id)

        asyncio.create_task(
            self._async_generate_job(context, prompt, edit_urls=edit_urls, mode=mode, cost=cost)
        )
        return f"🎨 已收到{announce}请求（模型 {model}），正在后台为您生成，预计 20-120 秒，完成后将直接发送到本对话……"

    async def _generate(
        self,
        context: MessageContext,
        prompt: str,
        edit_urls: list[str] | None = None,
        mode: str = "txt2img",
        cost: int = 1,
    ) -> str:
        user_id = self._user_id(context)
        key = self._api_key()
        base = self._api_base_url()
        if not base or not key:
            return "插件尚未配置生图服务或密钥，请联系管理员。"

        prompt = (prompt or "").strip()
        style = self._user_style(user_id)
        if prompt and style:
            prompt = f"{prompt},{style}"

        image_urls = []
        for item in getattr(context, "attachments", []):
            if isinstance(item, dict):
                u = str(item.get("url") or item.get("src") or "").strip()
                if u.startswith("http") and u not in image_urls:
                    image_urls.append(u)
        for url in (edit_urls or []):
            if url and url not in image_urls:
                image_urls.append(url)

        if not prompt and not image_urls:
            return "请输入生图提示词，例如：/dg 一只可爱的柴犬"

        max_chars = int(self._get_cfg("max_prompt_chars", 4000))
        if len(prompt) > max_chars:
            return "提示词太长了，请精简后再试。"

        images: list[bytes] = []
        if image_urls:
            for url in image_urls[:4]:
                data, error = await self._download_image(url)
                if error:
                    return f"读取图片失败：{error}"
                images.append(data)

        self.last_action_time[user_id] = time.time()
        try:
            if images:
                path, error = await self._request_edit(context, prompt, images, key, base)
            else:
                path, error = await self._request_generate(context, prompt, key, base)
        except httpx.TimeoutException:
            return "生图超时了，任务可能仍在后台完成，请稍后再试。"
        except httpx.HTTPError as exc:
            return f"上游绘图服务网络连接异常（{type(exc).__name__}），请稍后重试。"
        except Exception as exc:
            return f"生成失败：{exc}"

        if error:
            return error

        # Debit balance
        await self._change_balance(user_id, -cost, reason=f"drawimg.{mode}")
        source = Path(path)
        sent, send_err = await self._send_image(context, source)
        if sent:
            try:
                recent_dir = Path(self.data_dir) / "recent"
                recent_dir.mkdir(parents=True, exist_ok=True)
                recent_file = recent_dir / f"rec_{user_id[:16]}_{int(time.time())}_{uuid.uuid4().hex[:6]}.png"
                recent_file.write_bytes(source.read_bytes())
                user_imgs = self.recent_images.setdefault(user_id, [])
                user_imgs.append((time.time(), str(recent_file)))
                self.recent_images[user_id] = user_imgs[-5:]
                self._save_recent_images()
            except Exception:
                pass
            if mode == "img2img_multi" and edit_urls:
                self._clear_recent_images(user_id, edit_urls)
            try:
                qq = getattr(self.context, "qq", None)
                if qq:
                    action_card = await self._build_result_card(
                        context,
                        prompt,
                        str(source),
                        self._user_model(user_id),
                        cost,
                        cached=False,
                    )
                    msg_id = getattr(context, "message_id", None)
                    await qq.send_card(context.conversation_id, _normalize_scene(context), action_card, msg_id=msg_id)
            except Exception as e:
                logger.warning("Failed to send action card: %s", e)

        source.unlink(missing_ok=True)
        if not sent:
            await self._change_balance(user_id, cost, reason=f"drawimg.refund.{mode}")  # refund
            err_suffix = f"（原因：{send_err}）" if send_err else ""
            return f"图片已生成但 QQ 发送失败{err_suffix}，本次积分已退还；请稍后重试。"
        return ""

    @staticmethod
    def _image_mime(data: bytes) -> tuple[str, str]:
        if data.startswith(b"\x89PNG\r\n\x1a\n"):
            return "image/png", "png"
        if data.startswith(b"\xff\xd8\xff"):
            return "image/jpeg", "jpg"
        if data[:4] == b"RIFF" and data[8:12] == b"WEBP":
            return "image/webp", "webp"
        if data[:6] in (b"GIF87a", b"GIF89a"):
            return "image/gif", "gif"
        return "application/octet-stream", "png"

    @staticmethod
    def _image_candidates(value: Any) -> list[tuple[str, str]]:
        candidates: list[tuple[str, str]] = []
        if isinstance(value, dict):
            for key in (
                "b64_json", "partial_image_b64", "base64", "result", "data", "output",
                "response", "tool_calls", "arguments", "image_generation_call", "url",
                "image_url", "image", "images", "choices", "items", "candidates",
                "output_text", "content_parts",
            ):
                if key in value:
                    candidates.extend(DrawImgServicePlugin._image_candidates(value[key]))
            if isinstance(value.get("content"), (list, dict, str)):
                candidates.extend(DrawImgServicePlugin._image_candidates(value["content"]))
            if isinstance(value.get("text"), str):
                candidates.extend(DrawImgServicePlugin._image_candidates(value["text"]))
        elif isinstance(value, list):
            for item in value:
                candidates.extend(DrawImgServicePlugin._image_candidates(item))
        elif isinstance(value, str):
            text = value.strip()
            if text[:1] in {"{", "["}:
                try:
                    parsed = json.loads(text)
                except (TypeError, ValueError):
                    parsed = None
                if parsed is not None:
                    return DrawImgServicePlugin._image_candidates(parsed)
            if text.startswith("data:image/") and ";base64," in text:
                candidates.append(("data", text))
            elif re.fullmatch(r"https?://[^\s<>\"']+", text, re.IGNORECASE):
                candidates.append(("url", text))
            elif len(text) > 64 and re.fullmatch(r"[A-Za-z0-9+/=\s]+", text):
                candidates.append(("b64", re.sub(r"\s+", "", text)))
        return candidates

    async def _save_response_images(self, value: Any) -> tuple[str, str]:
        output_dir = Path(self.data_dir) / "output"
        output_dir.mkdir(parents=True, exist_ok=True)
        for kind, payload in self._image_candidates(value):
            if kind == "url":
                path, error = await self._download_result(payload)
                if not error:
                    return str(path), ""
                continue
            raw = payload
            if kind == "data":
                try:
                    raw = payload.split(",", 1)[1]
                except IndexError:
                    continue
            try:
                decoded = base64.b64decode(raw, validate=False)
            except (ValueError, TypeError):
                continue
            if not decoded or not self._image_mime(decoded)[0].startswith("image/"):
                continue
            path = output_dir / f"dg_{uuid.uuid4().hex}.png"
            path.write_bytes(decoded)
            return str(path), ""
        return "", ""

    async def _save_chat_images(self, content: Any) -> tuple[str, str]:
        if not content:
            return "", "生成失败：接口未返回内容"
        saved = await self._save_response_images(content)
        if saved[0]:
            return saved
        text = content if isinstance(content, str) else json.dumps(content, ensure_ascii=False)
        matches = list(re.finditer(r"data:image/([a-zA-Z0-9.+-]+);base64,([A-Za-z0-9+/=\s]+)", text))
        output_dir = Path(self.data_dir) / "output"
        output_dir.mkdir(parents=True, exist_ok=True)
        for match in reversed(matches):
            payload = re.sub(r"\s+", "", match.group(2))
            try:
                raw = base64.b64decode(payload, validate=False)
            except (ValueError, TypeError):
                continue
            if len(raw) <= 0:
                continue
            path = output_dir / f"dg_{uuid.uuid4().hex}.png"
            path.write_bytes(raw)
            return str(path), ""
        for match in reversed(list(re.finditer(r"https?://[^\s)\"'<>]+", text, re.IGNORECASE))):
            path, download_error = await self._download_result(match.group(0))
            if download_error:
                continue
            return str(path), ""
        return "", "生成失败：回复中没有可用的图片内容"

    async def _save_result(self, response: httpx.Response) -> tuple[str, str]:
        if response.status_code >= 400:
            data = self._json(response)
            message = str(data.get("error", {}).get("message") or data.get("message") or f"HTTP {response.status_code}")[:200] if isinstance(data, dict) else f"HTTP {response.status_code}"
            return "", f"生成失败：{message}"
        data = self._json(response)
        items = data.get("data") if isinstance(data, dict) else None
        if not isinstance(items, list) or not items:
            return "", "生成失败：接口未返回图片"
        item = items[0]
        output_dir = Path(self.data_dir) / "output"
        output_dir.mkdir(parents=True, exist_ok=True)
        path = output_dir / f"dg_{uuid.uuid4().hex}.png"
        b64 = item.get("b64_json")
        if isinstance(b64, str) and b64:
            path.write_bytes(base64.b64decode(b64))
        else:
            url = str(item.get("url") or "")
            if not url:
                return "", "生成失败：接口未返回图片内容"
            path, download_error = await self._download_result(url)
            if download_error:
                return "", download_error
        if not path.is_file() or path.stat().st_size <= 0:
            path.unlink(missing_ok=True)
            return "", "生成失败：图片内容为空"
        return str(path), ""

    @staticmethod
    def _json(response: httpx.Response) -> dict[str, Any]:
        try:
            data = response.json()
        except ValueError:
            return {}
        return data if isinstance(data, dict) else {}

    def _error_text(self, response: httpx.Response) -> str:
        data = self._json(response)
        if isinstance(data, dict):
            err = data.get("error")
            if isinstance(err, dict):
                return str(err.get("message") or "")
            return str(data.get("message") or "")
        return ""

    async def _download_result(self, url: str) -> tuple[Path, str]:
        output_dir = Path(self.data_dir) / "output"
        output_dir.mkdir(parents=True, exist_ok=True)
        path = output_dir / f"dg_{uuid.uuid4().hex}.png"
        headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36",
            "Referer": f"{self._api_base_url()}/",
        }
        last = ""
        for attempt in range(3):
            try:
                async with httpx.AsyncClient(timeout=20, follow_redirects=True) as client:
                    download = await client.get(url, headers=headers)
                download.raise_for_status()
                if not download.content:
                    raise httpx.HTTPError("empty body")
                path.write_bytes(download.content)
                return path, ""
            except httpx.HTTPStatusError as exc:
                last = f"HTTP {exc.response.status_code}"
            except httpx.HTTPError as exc:
                last = type(exc).__name__
            await asyncio.sleep(1 + attempt)
        return path, f"生成成功但图片下载失败（{last}，可能是图片链接已过期或被网络拦截），请重试或更换模型。"

    async def _download_image(self, url: str) -> tuple[bytes, str]:
        if not url:
            return b"", "图片链接为空"
        if url.startswith("data:image/"):
            try:
                _, encoded = url.split(",", 1)
                return base64.b64decode(encoded), ""
            except Exception as e:
                return b"", f"Base64 解析失败: {e}"
        local_p = Path(url)
        try:
            if local_p.is_file():
                return local_p.read_bytes(), ""
        except Exception:
            pass
        headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36"}
        try:
            async with httpx.AsyncClient(timeout=20, follow_redirects=True) as client:
                response = await client.get(url, headers=headers)
            response.raise_for_status()
        except httpx.HTTPError:
            return b"", "网络下载失败"
        if len(response.content) > 20 * 1024 * 1024:
            return b"", "图片超过 20MB"
        if response.status_code >= 400 or not response.content:
            return b"", f"HTTP {response.status_code}"
        return response.content, ""

    async def _request_generate(self, context: MessageContext, prompt: str, key: str = "", base: str = "") -> tuple[str, str]:
        user_id = self._user_id(context)
        model = self._user_model(user_id)
        size = self._user_size(user_id)
        quality = self._user_quality(user_id)
        timeout_sec = float(self._get_cfg("request_timeout_sec", 180))

        payload: dict[str, Any] = {"model": model, "prompt": prompt, "n": 1}
        if size != "auto":
            payload["size"] = size
        if quality != "auto":
            payload["quality"] = quality
        if bool(self._get_cfg("prefer_b64_response", True)) and not self._b64_rejected:
            payload["response_format"] = "b64_json"

        headers = {"Authorization": f"Bearer {key}", "Content-Type": "application/json"}
        async with httpx.AsyncClient(base_url=base, timeout=timeout_sec, follow_redirects=False) as client:
            response = await client.post("/v1/images/generations", json=payload, headers=headers)
            if response.status_code in {400, 422} and "response_format" in payload:
                self._b64_rejected = True
                payload.pop("response_format", None)
                response = await client.post("/v1/images/generations", json=payload, headers=headers)
            if response.status_code in {400, 422} and "quality" in payload:
                payload.pop("quality", None)
                response = await client.post("/v1/images/generations", json=payload, headers=headers)

        if response.status_code in {400, 404, 405, 422}:
            err_msg = self._error_text(response).lower()
            if any(kw in err_msg for kw in ("not supported on /v1/images/generations", "not supported", "not found", "chat", "unknown model", "route")) or response.status_code in {404, 405}:
                chat_path, chat_err = await self._request_generate_chat(context, prompt, key, base)
                if chat_path or (chat_err and not chat_err.startswith("HTTP 404")):
                    return chat_path, chat_err

        return await self._save_result(response)

    async def _request_generate_chat(self, context: MessageContext, prompt: str, key: str = "", base: str = "") -> tuple[str, str]:
        user_id = self._user_id(context)
        model = self._user_model(user_id)
        size = self._user_size(user_id)
        quality = self._user_quality(user_id)
        timeout_sec = float(self._get_cfg("request_timeout_sec", 180))

        content_parts: list[dict[str, Any]] = [{"type": "text", "text": prompt}]
        payload: dict[str, Any] = {
            "model": model,
            "messages": [{"role": "user", "content": content_parts}],
            "stream": False,
        }
        if size != "auto":
            payload["size"] = size
        if quality != "auto":
            payload["quality"] = quality
        headers = {"Authorization": f"Bearer {key}", "Content-Type": "application/json"}
        async with httpx.AsyncClient(base_url=base, timeout=timeout_sec, follow_redirects=False) as client:
            response = await client.post("/v1/chat/completions", json=payload, headers=headers)
        if response.status_code >= 400:
            data = self._json(response)
            message = str(data.get("error", {}).get("message") or data.get("message") or f"HTTP {response.status_code}")[:200] if isinstance(data, dict) else f"HTTP {response.status_code}"
            return "", f"生成失败：{message}"
        data = self._json(response)
        if not data and response.text:
            events: list[dict[str, Any]] = []
            for line in response.text.splitlines():
                candidate = line.strip()
                if candidate.startswith("data:"):
                    candidate = candidate[5:].strip()
                if not candidate or candidate == "[DONE]":
                    continue
                try:
                    item = json.loads(candidate)
                except (TypeError, ValueError):
                    continue
                if isinstance(item, dict):
                    events.append(item)
            if events:
                data = {"output": events}
        saved = await self._save_response_images(data)
        if saved[0]:
            return saved
        choices = data.get("choices") if isinstance(data, dict) else None
        content = ""
        if isinstance(choices, list) and choices and isinstance(choices[0], dict):
            message = choices[0].get("message") or {}
            if isinstance(message, dict):
                saved = await self._save_response_images(message.get("images"))
                if saved[0]:
                    return saved
                content = message.get("content") or ""
        if not content:
            keys = ", ".join(str(k) for k in data.keys()) if isinstance(data, dict) else "无"
            return "", f"生成失败：接口返回了空内容（字段：{keys[:240]}）。请确认当前模型支持图像生成。"
        return await self._save_chat_images(content)

    async def _request_edit(self, context: MessageContext, prompt: str, images: list[bytes], key: str = "", base: str = "") -> tuple[str, str]:
        protocol = str(self._get_cfg("edit_protocol", "auto") or "auto").strip().lower()
        if protocol not in {"auto", "images", "chat", "responses"}:
            protocol = "auto"
        if protocol in {"auto", "images"}:
            path, error = await self._request_edit_images_api(context, prompt, images, key, base)
            if path or protocol == "images":
                return path, error
        if protocol in {"auto", "chat"}:
            path, error = await self._request_edit_chat(context, prompt, images, key, base)
            if path or protocol == "chat":
                return path, error
        return await self._request_edit_responses(context, prompt, images, key, base)

    async def _request_edit_images_api(self, context: MessageContext, prompt: str, images: list[bytes], key: str = "", base: str = "") -> tuple[str, str]:
        user_id = self._user_id(context)
        model = self._user_model(user_id)
        size = self._user_size(user_id)
        quality = self._user_quality(user_id)
        timeout_sec = float(self._get_cfg("request_timeout_sec", 180))

        data: dict[str, str] = {"model": model, "prompt": prompt or "优化这张图片", "n": "1"}
        if size != "auto":
            data["size"] = size
        if quality != "auto":
            data["quality"] = quality
        if bool(self._get_cfg("prefer_b64_response", True)) and not self._b64_rejected:
            data["response_format"] = "b64_json"
        files = [("image[]", (f"input_{index}.png", image, "image/png")) for index, image in enumerate(images)]
        headers = {"Authorization": f"Bearer {key}"}
        async with httpx.AsyncClient(base_url=base, timeout=timeout_sec, follow_redirects=False) as client:
            response = await client.post("/v1/images/edits", data=data, files=files, headers=headers)
            if response.status_code == 400 and "response_format" in self._error_text(response).lower():
                data.pop("response_format", None)
                response = await client.post("/v1/images/edits", data=data, files=files, headers=headers)
        if response.status_code in {404, 405, 415, 422}:
            return "", ""
        path, error = await self._save_result(response)
        if path:
            return path, ""
        return "", error

    async def _request_edit_chat(self, context: MessageContext, prompt: str, images: list[bytes], key: str = "", base: str = "") -> tuple[str, str]:
        user_id = self._user_id(context)
        model = self._user_model(user_id)
        size = self._user_size(user_id)
        quality = self._user_quality(user_id)
        timeout_sec = float(self._get_cfg("request_timeout_sec", 180))

        content_parts: list[dict[str, Any]] = [{"type": "text", "text": prompt or "优化这张图片"}]
        for data in images:
            mime, _ = self._image_mime(data)
            if mime == "application/octet-stream":
                mime = "image/png"
            content_parts.append({
                "type": "image_url",
                "image_url": {"url": f"data:{mime};base64,{base64.b64encode(data).decode()}"},
            })
        payload = {
            "model": model,
            "messages": [{"role": "user", "content": content_parts}],
            "stream": False,
        }
        if size != "auto":
            payload["size"] = size
        if quality != "auto":
            payload["quality"] = quality
        headers = {"Authorization": f"Bearer {key}", "Content-Type": "application/json"}
        async with httpx.AsyncClient(base_url=base, timeout=timeout_sec, follow_redirects=False) as client:
            response = await client.post("/v1/chat/completions", json=payload, headers=headers)
        if response.status_code >= 400:
            data = self._json(response)
            message = str(data.get("error", {}).get("message") or data.get("message") or f"HTTP {response.status_code}")[:200] if isinstance(data, dict) else f"HTTP {response.status_code}"
            return "", f"生成失败：{message}"
        data = self._json(response)
        if not data and response.text:
            events: list[dict[str, Any]] = []
            for line in response.text.splitlines():
                candidate = line.strip()
                if candidate.startswith("data:"):
                    candidate = candidate[5:].strip()
                if not candidate or candidate == "[DONE]":
                    continue
                try:
                    item = json.loads(candidate)
                except (TypeError, ValueError):
                    continue
                if isinstance(item, dict):
                    events.append(item)
            if events:
                data = {"output": events}
        saved = await self._save_response_images(data)
        if saved[0]:
            return saved
        choices = data.get("choices") if isinstance(data, dict) else None
        content = ""
        if isinstance(choices, list) and choices and isinstance(choices[0], dict):
            message = choices[0].get("message") or {}
            if isinstance(message, dict):
                saved = await self._save_response_images(message.get("images"))
                if saved[0]:
                    return saved
                content = message.get("content") or ""
        if not content:
            keys = ", ".join(str(k) for k in data.keys()) if isinstance(data, dict) else "无"
            return "", f"生成失败：接口返回了空内容（字段：{keys[:240]}）。请确认当前模型支持图像编辑。"
        return await self._save_chat_images(content)

    async def _request_edit_responses(self, context: MessageContext, prompt: str, images: list[bytes], key: str = "", base: str = "") -> tuple[str, str]:
        user_id = self._user_id(context)
        model = self._user_model(user_id)
        timeout_sec = float(self._get_cfg("request_timeout_sec", 180))

        content: list[dict[str, str]] = [{"type": "input_text", "text": prompt or "优化这张图片"}]
        for image in images:
            mime, _ = self._image_mime(image)
            if mime == "application/octet-stream":
                mime = "image/png"
            content.append({"type": "input_image", "image_url": f"data:{mime};base64,{base64.b64encode(image).decode()}"})
        payload: dict[str, Any] = {
            "model": model,
            "input": [{"role": "user", "content": content}],
            "tools": [{"type": "image_generation", "action": "edit", "model": model}],
        }
        headers = {"Authorization": f"Bearer {key}", "Content-Type": "application/json"}
        async with httpx.AsyncClient(base_url=base, timeout=timeout_sec, follow_redirects=False) as client:
            response = await client.post("/v1/responses", json=payload, headers=headers)
        if response.status_code in {404, 405, 415, 422}:
            return "", "生成失败：当前服务不支持图像编辑协议（images/chat/responses 均不可用）。"
        if response.status_code >= 400:
            return "", f"生成失败：{self._error_text(response) or f'HTTP {response.status_code}'}"
        data = self._json(response)
        saved = await self._save_response_images(data)
        if saved[0]:
            return saved
        return "", "生成失败：Responses 接口未返回图片内容。"

    async def _send_image(self, context: MessageContext, path: Path) -> tuple[bool, str]:
        source = Path(path)
        if not source.is_file():
            return False, f"本地图片不存在: {source}"
        if source.stat().st_size <= 0:
            return False, "本地图片文件为空"
        scene = _normalize_scene(context)
        media = getattr(self.context, "media", None)
        qq = getattr(self.context, "qq", None)
        conv_id = (
            getattr(context, "conversation_id", "")
            or getattr(context, "group_id", "")
            or getattr(context, "sender_id", "")
        )
        if media is None or qq is None or not conv_id:
            return False, f"服务未就绪 (media={bool(media)}, qq={bool(qq)}, conv_id={bool(conv_id)})"
        try:
            msg_id = getattr(context, "message_id", None)
            if scene in {"c2c", "group"}:
                request = await media.prepare(scene, conv_id, 1, source)
                uploaded = await qq.upload_media_file(request, source)
                file_info = uploaded.get("file_info") if isinstance(uploaded, dict) else None
                if not file_info:
                    return False, f"上传媒体接口未返回 file_info: {uploaded}"
                try:
                    if msg_id:
                        await qq.send_media(conv_id, scene, str(file_info), msg_id=msg_id)
                    else:
                        await qq.send_media(conv_id, scene, str(file_info))
                except (TypeError, Exception) as send_err:
                    if msg_id:
                        logger.warning("Sending media with msg_id failed (%s), retrying without msg_id...", send_err)
                        await qq.send_media(conv_id, scene, str(file_info))
                    else:
                        raise
                return True, ""
            if scene in {"channel", "guild_direct"}:
                try:
                    if msg_id:
                        await qq.send_channel_media(conv_id, scene, file_image=source.read_bytes(), msg_id=msg_id)
                    else:
                        await qq.send_channel_media(conv_id, scene, file_image=source.read_bytes())
                except (TypeError, Exception) as send_err:
                    if msg_id:
                        logger.warning("Sending channel media with msg_id failed (%s), retrying without msg_id...", send_err)
                        await qq.send_channel_media(conv_id, scene, file_image=source.read_bytes())
                    else:
                        raise
                return True, ""
            return False, f"不支持的消息场景: {scene}"
        except Exception as e:
            logger.exception("Failed to send image media via QQ: %s", e)
            return False, f"{type(e).__name__}: {e}"


    def _record_history(self, user_id: str, prompt: str, url: str, model: str) -> None:
        return

    async def _build_result_card(
        self, context: MessageContext, prompt: str, image_url: str, model: str, cost: int, cached: bool = False
    ) -> Card:
        uid = self._user_id(context)
        rem = await self._get_balance(uid)
        cached_tag = "（⚡ 命中秒回缓存）" if cached else ""
        short_prompt = prompt[:60] + ("…" if len(prompt) > 60 else "")
        img_md = f"![生成的图片 #1024px #1024px]({image_url})\n\n" if image_url.startswith("http") else ""
        markdown = (
            f"### 🎨 AI 绘图已生成 {cached_tag}\n\n"
            f"{img_md}"
            f"- **提示词**：`{short_prompt}`\n"
            f"- **模型**：`{model}`（本次扣除 **{cost}** 积分）\n"
            f"- **剩余余额**：**{rem}** 积分\n\n"
            f"点击下方按钮可快捷改图、调优风格或充值。"
        )
        rows = [
            [
                _btn("再来一张", f"/dg {prompt}", action_type=1, click_limit=3),
                _btn("基于此图改图", "/dge ", fill=True),
            ],
            [
                _btn("选择预设", "/dg style"),
                _btn("尺寸/质量", "/dg size"),
                _btn("充值积分", "/dg pay ", fill=True),
            ],
            [
                _btn("我的状态", "/dg status"),
                _btn("返回主菜单", "/dg"),
            ],
        ]
        return Card("AI 绘图结果", markdown, rows=rows)

    # ---------- UI Cards & Sub-handlers ----------

    async def _main_menu_card(self, context: MessageContext) -> Card:
        uid = self._user_id(context)
        bal = await self._get_balance(uid)
        model = self._user_model(uid)
        markdown = (
            "## 🎨 绘图服务\n\n"
            f"当前默认模型：`{model}`（单次生图消耗 {self._model_cost(model)} 积分）\n"
            f"您的积分余额：**{bal}** 积分\n\n"
            "直接发送 `/dg <提示词>` 开始创作，无需自备 Key！"
        )
        rows = [
            [
                _btn("文生图", "/dg ", fill=True),
                _btn("单图编辑", "/dge ", fill=True),
            ],
            [
                _btn("多图编辑", "/dgm ", fill=True),
                _btn("选择模型", "/dg models"),
            ],
            [
                _btn("选择预设", "/dg style"),
                _btn("尺寸/质量", "/dg size"),
            ],
            [
                _btn("我的状态", "/dg status"),
                _btn("充值积分", "/dg pay ", fill=True),
            ],
        ]
        if context.is_admin:
            rows.append([_btn("管理员菜单", "/dg admin", permission=1)])
        return Card("绘图服务主菜单", markdown, rows=rows)

    async def _menu_card(self, context: MessageContext, page: str = "") -> Card:
        page = (page or "").strip().lower()
        aliases = {
            "生图": "draw",
            "设置": "settings",
            "积分": "credit",
            "管理": "admin",
        }
        page = aliases.get(page, page)
        back = [_btn("返回主菜单", "/dg")]
        pages = {
            "draw": (
                "开始创作",
                "选择一种操作，点击后在指令末尾补充提示词即可。",
                [
                    [
                        _btn("文生图", "/dg ", fill=True),
                        _btn("单图编辑", "/dge ", fill=True),
                    ],
                    [
                        _btn("多图编辑", "/dgm ", fill=True),
                        _btn("选择模型", "/dg models"),
                    ],
                    [
                        _btn("选择预设", "/dg style"),
                        _btn("尺寸/质量", "/dg size"),
                    ],
                    [
                        _btn("我的状态", "/dg status"),
                        _btn("充值积分", "/dg pay ", fill=True),
                    ],
                    back,
                ],
            ),
            "settings": (
                "个性化设置",
                "设置会自动保存，下次使用继续生效。",
                [
                    [
                        _btn("选择模型", "/dg models"),
                        _btn("选择预设", "/dg style"),
                    ],
                    [
                        _btn("图片尺寸", "/dg size"),
                        _btn("图片质量", "/dg quality"),
                    ],
                    [
                        _btn("我的状态", "/dg status"),
                        _btn("充值积分", "/dg pay ", fill=True),
                    ],
                    back,
                ],
            ),
        }
        if page in pages:
            title, text, rows = pages[page]
            return Card(title, f"### {title}\n\n{text}", rows=rows)
        return await self._main_menu_card(context)

    async def _status_card(self, context: MessageContext) -> Card:
        uid = self._user_id(context)
        bal = await self._get_balance(uid)
        model = self._user_model(uid)
        model_price = self._model_cost(model)
        rate = float(self._get_cfg("credit_price_yuan", 0.1))

        markdown = (
            "| 项目 | 当前值 |\n"
            "|---|---|\n"
            f"| 用户编号 | `{uid}` |\n"
            "| 当前模式 | 积分模式 |\n"
            f"| 积分余额 | {bal} |\n"
            f"| 当前模型 | {model} |\n"
            f"| 当前模型单价 | {model_price} 积分/次 |\n"
            f"| 当前积分单价 | {rate:.2f} 元/积分 |\n"
        )
        rows = [
            [
                _btn("选择模型", "/dg models"),
                _btn("选择预设", "/dg style"),
            ],
            [
                _btn("充值积分", "/dg pay ", fill=True),
                _btn("开始生图", "/dg ", fill=True),
            ],
            [
                _btn("尺寸/质量", "/dg size"),
                _btn("返回主菜单", "/dg"),
            ],
            [
                _btn("充值 10 积分", "/dg pay 10", action_type=1),
                _btn("充值 50 积分", "/dg pay 50", action_type=1),
                _btn("充值 100 积分", "/dg pay 100", action_type=1),
            ],
        ]
        return Card("个人绘图状态", markdown, rows=rows)

    async def _handle_top(self, context: MessageContext) -> str | Card:
        if not context.is_admin:
            return "只有管理员可以查看积分排行。"
        points = self._points()
        if points is not None and hasattr(points, "top_identities"):
            try:
                top_items = await points.top_identities("drawimg", 10)
                ranked = [(str(k), int(v)) for k, v in top_items]
            except Exception:
                ranked = []
        else:
            ranked = []
        if not ranked:
            ranked = sorted(
                (
                    (key, int(credits))
                    for key, credits in self.credits.items()
                    if not key.startswith("_")
                ),
                key=lambda item: item[1],
                reverse=True,
            )[:10]
        if not ranked:
            return "当前没有用户积分记录。"
        lines = ["### 🏆 积分排行（前 10 名）\n", "| 用户编号 | 积分余额 |", "|---|---:|"]
        lines.extend(f"| `{key}` | **{credits}** |" for key, credits in ranked)
        rows = [
            [
                _btn("赠送积分", "/dg give ", fill=True, permission=1),
                _btn("管理员菜单", "/dg admin", permission=1),
            ],
            [
                _btn("返回主菜单", "/dg"),
            ],
        ]
        return Card("积分排行榜", "\n".join(lines), rows=rows)

    async def _handle_style(self, context: MessageContext, args: list[str]) -> str | Card:
        uid = self._user_id(context)
        presets_raw = self._get_cfg("style_presets", DEFAULT_CONFIG["style_presets"])
        parsed_presets: dict[str, str] = {}
        if isinstance(presets_raw, dict) and presets_raw:
            parsed_presets = {str(k): str(v) for k, v in presets_raw.items()}
        elif isinstance(presets_raw, str) and presets_raw.strip():
            if presets_raw.strip().startswith("{"):
                try:
                    obj = json.loads(presets_raw)
                    if isinstance(obj, dict):
                        parsed_presets = {str(k): str(v) for k, v in obj.items()}
                except Exception:
                    pass
            if not parsed_presets:
                for item in presets_raw.split(";"):
                    parts = item.strip().split(":", 1)
                    if len(parts) == 2:
                        parsed_presets[parts[0].strip()] = parts[1].strip()

        if not parsed_presets:
            for item in DEFAULT_CONFIG["style_presets"].split(";"):
                parts = item.strip().split(":", 1)
                if len(parts) == 2:
                    parsed_presets[parts[0].strip()] = parts[1].strip()

        if not args:
            current = self._user_style(uid)
            lines = [
                "### 🎨 风格预设列表\n",
                "| 预设名称 | 提示词预览 | 状态 |",
                "| :--- | :--- | :---: |",
            ]
            for name, val in parsed_presets.items():
                is_active = (val == current or name == current)
                status = "✅ 已选" if is_active else "-"
                clean_val = " ".join(val.replace("|", "｜").replace("\r", " ").replace("\n", " ").split())
                preview = clean_val[:38] + "..." if len(clean_val) > 40 else clean_val
                lines.append(f"| **{name}** | {preview} | {status} |")
            lines.append("\n点击下方预设一键应用，或发送 `/dg style off` 取消预设。")
            lines.append("💡 发送 `/dg style view <预设名>` 可查看该预设的完整提示词。")
            rows = []
            btn_row = []
            for name in list(parsed_presets.keys())[:6]:
                label = f"✓ {name[:8]}" if parsed_presets[name] == current or name == current else name[:10]
                btn_row.append(_btn(label, f"/dg style {name}", action_type=1))
                if len(btn_row) == 3:
                    rows.append(btn_row)
                    btn_row = []
            if btn_row:
                rows.append(btn_row)
            rows.append([
                _btn("我的预设", "/dg style my"),
                _btn("添加预设", "/dg style add ", fill=True),
                _btn("删除预设", "/dg style rm ", fill=True),
            ])
            rows.append([
                _btn("取消风格", "/dg style off", action_type=1),
                _btn("返回主菜单", "/dg"),
            ])
            return Card("风格预设", "\n".join(lines), rows=rows)

        action = args[0].strip()
        if action in {"off", "取消", "关闭", "clear"}:
            self.user_prefs.setdefault(uid, {})["style"] = ""
            self._save_user_prefs()
            return "已取消风格预设，后续将使用原生提示词生图。"
        if action in {"my", "mine", "我的", "我的预设"}:
            user_style = self._user_style(uid) or "未设置"
            return Card("我的风格预设", f"您当前的风格预设附加词为：`{user_style}`", rows=[[
                _btn("选择预设", "/dg style"),
                _btn("取消风格", "/dg style off", action_type=1),
                _btn("返回主菜单", "/dg"),
            ]])
        if action in {"view", "查看", "detail", "详情"}:
            if len(args) < 2:
                return "用法：`/dg style view <预设名>`"
            target = args[1].strip()
            found_val = parsed_presets.get(target)
            if not found_val:
                for k, v in parsed_presets.items():
                    if k.lower() == target.lower():
                        target, found_val = k, v
                        break
            if found_val:
                return Card(
                    f"风格预设：{target}",
                    f"**预设名称**：{target}\n\n**完整提示词**：\n```\n{found_val}\n```",
                    rows=[[
                        _btn("应用此预设", f"/dg style {target}", action_type=1),
                        _btn("返回预设列表", "/dg style"),
                    ]],
                )
            return f"未找到名为 `{target}` 的风格预设。"
        if action in {"add", "新增", "添加"}:
            if len(args) < 2:
                return "用法：`/dg style add <预设名>:<提示词>`"
            rule_str = " ".join(args[1:]).strip()
            parts = rule_str.split(":", 1)
            if len(parts) != 2:
                return "格式错误，请使用：`/dg style add <预设名>:<提示词>`"
            p_name, p_val = parts[0].strip(), parts[1].strip()
            parsed_presets[p_name] = p_val
            self.config["style_presets"] = json.dumps(parsed_presets, ensure_ascii=False)
            self._save_config()
            return f"已成功添加全局预设：**{p_name}** (`{p_val}`)。"
        if action in {"rm", "del", "remove", "删除"}:
            if len(args) < 2:
                return "用法：`/dg style rm <预设名>`"
            p_name = args[1].strip()
            if p_name in parsed_presets:
                del parsed_presets[p_name]
                self.config["style_presets"] = json.dumps(parsed_presets, ensure_ascii=False)
                self._save_config()
                return f"已删除风格预设：**{p_name}**。"
            return f"未找到名为 `{p_name}` 的预设。"
        if action in parsed_presets:
            self.user_prefs.setdefault(uid, {})["style"] = parsed_presets[action]
            self._save_user_prefs()
            clean_val = " ".join(parsed_presets[action].replace("\r", " ").replace("\n", " ").split())
            preview = clean_val[:48] + "..." if len(clean_val) > 50 else clean_val
            return f"已成功应用风格预设：**{action}**\n附加词：`{preview}`"

        # Try case-insensitive lookup
        for k, v in parsed_presets.items():
            if k.lower() == action.lower():
                self.user_prefs.setdefault(uid, {})["style"] = v
                self._save_user_prefs()
                clean_val = " ".join(v.replace("\r", " ").replace("\n", " ").split())
                preview = clean_val[:48] + "..." if len(clean_val) > 50 else clean_val
                return f"已成功应用风格预设：**{k}**\n附加词：`{preview}`"

        custom_style = " ".join(args).strip()
        self.user_prefs.setdefault(uid, {})["style"] = custom_style
        self._save_user_prefs()
        return f"已成功应用自定义风格预设：`{custom_style}`。"

    def _handle_size(self, context: MessageContext, args: list[str]) -> str | Card:
        uid = self._user_id(context)
        current = self._user_size(uid)
        size_options = ["1024x1024", "1024x1792", "1792x1024", "auto"]
        if not args:
            rows = [
                [
                    _btn(("✓ " + opt[:8]) if opt == current else opt, f"/dg size {opt}", action_type=1)
                    for opt in size_options
                ],
                [_btn("返回主菜单", "/dg")],
            ]
            return Card("图片尺寸", f"当前尺寸：`{current}`。点击按钮切换：", rows=rows)
        target = args[0].strip().lower()
        if target in size_options or re.fullmatch(r"\d{3,4}x\d{3,4}", target):
            self.user_prefs.setdefault(uid, {})["size"] = target
            self._save_user_prefs()
            return f"生图尺寸已设置为：`{target}`。"
        return "尺寸格式应为 宽x高（如 1024x1024）或 auto。"

    def _handle_quality(self, context: MessageContext, args: list[str]) -> str | Card:
        uid = self._user_id(context)
        current = self._user_quality(uid)
        quality_options = ["auto", "standard", "hd", "low", "medium", "high"]
        zh = {"auto": "自动", "standard": "标准", "hd": "高清", "low": "低", "medium": "中", "high": "高"}
        if not args:
            rows = [
                [
                    _btn(("✓ " + zh.get(opt, opt)) if opt == current else zh.get(opt, opt), f"/dg quality {opt}", action_type=1)
                    for opt in ["auto", "standard", "hd"]
                ],
                [_btn("返回主菜单", "/dg")],
            ]
            return Card("图片质量", f"当前画质：`{zh.get(current, current)}`。点击按钮切换：", rows=rows)
        target = args[0].strip().lower()
        if target in quality_options:
            self.user_prefs.setdefault(uid, {})["quality"] = target
            self._save_user_prefs()
            return f"生成质量已设置为：`{zh.get(target, target)}`。"
        return "质量应为 auto、standard、hd、low、medium 或 high。"

    async def _fetch_remote_models(self) -> list[str]:
        api_base = self._api_base_url()
        api_key = self._api_key()
        if not api_base:
            return []
        base = api_base.rstrip("/")
        if base.casefold().endswith("/v1"):
            base = base[:-3].rstrip("/")
        headers = {"Authorization": f"Bearer {api_key}"} if api_key else {}
        image_keywords = (
            "image", "dall", "flux", "sd", "stable-diffusion", "midjourney",
            "imagen", "recraft", "ideogram", "cogview", "kolors",
            "paint", "draw", "art", "canvas", "diffusion", "kling",
            "sora", "luma", "runway", "seed", "mj", "sdxl", "sd-", "sd_", "wanx", "t2i"
        )
        def is_image_model(m: str) -> bool:
            lower = str(m).lower()
            return any(kw in lower for kw in image_keywords)

        fetched_models: list[str] = []
        try:
            timeout = aiohttp.ClientTimeout(total=8.0)
            connector = aiohttp.TCPConnector(ttl_dns_cache=600)
            async with aiohttp.ClientSession(timeout=timeout, connector=connector) as session:
                for raw_url in (f"{base}/v1/models", f"{base}/models"):
                    try:
                        url, req_headers, sni = await _prepare_target(raw_url, headers)
                        async with session.get(url, headers=req_headers, server_hostname=sni) as resp:
                            if resp.status == 200:
                                data = await resp.json()
                                items = data.get("data", []) if isinstance(data, dict) else (data if isinstance(data, list) else [])
                                fetched = [str(item.get("id") if isinstance(item, dict) else item).strip() for item in items if item]
                                if fetched:
                                    img_fetched = [m for m in fetched if is_image_model(m)]
                                    fetched_models = img_fetched or list(fetched)
                                    break
                    except Exception:
                        continue
        except Exception as e:
            logger.warning("Failed to fetch remote models: %s", e)
        return fetched_models

    async def _handle_models(self, context: MessageContext, args: list[str]) -> str | Card:
        base_url = self._api_base_url()
        api_key = self._api_key()
        if not base_url or not api_key:
            return Card(
                "可用生图模型",
                "⚠️ **生图服务暂未配置接口**\n\n管理员暂未设置生图 API 接口地址与 API Key。\n请管理员前往后台管理面板「🧩 插件管理 - 绘图服务」配置接口后再使用。",
                rows=[[_btn("返回主菜单", "/dg")]],
            )

        now = time.time()
        ttl = int(self._get_cfg("models_cache_ttl_sec", 60))
        models: list[str] = []
        if self.models_cache and (now - self.models_cache[0]) < ttl and self.models_cache[1]:
            models = list(self.models_cache[1])
        else:
            models = await self._fetch_remote_models()
            if models:
                self.models_cache = (now, models)

        def _is_valid_model_name(name: str) -> bool:
            name = str(name).strip()
            if not name or len(name) < 2 or name.startswith("{") or name.endswith("}"):
                return False
            try:
                float(name)
                return False
            except ValueError:
                return True

        default_m = str(self._get_cfg("default_model", "")).strip()
        if default_m and _is_valid_model_name(default_m) and default_m not in models:
            models.append(default_m)

        cost_rules_raw = self._get_cfg("credit_cost_rules", "")
        if isinstance(cost_rules_raw, dict):
            for k in cost_rules_raw.keys():
                if _is_valid_model_name(str(k)) and str(k) not in models:
                    models.append(str(k))
        elif isinstance(cost_rules_raw, str) and cost_rules_raw.strip():
            try:
                loaded = json.loads(cost_rules_raw)
                if isinstance(loaded, dict):
                    for k in loaded.keys():
                        if _is_valid_model_name(str(k)) and str(k) not in models:
                            models.append(str(k))
            except Exception:
                for item in cost_rules_raw.split(";"):
                    parts = item.split(":", 1)
                    name = parts[0].strip()
                    if _is_valid_model_name(name) and name not in models:
                        models.append(name)

        if not models:
            return Card(
                "可用生图模型",
                "⚠️ **暂无可用的画图模型**\n\n当前接口未返回可用的画图模型列表，且管理员未配置模型规则。请联系管理员在后台检查接口状态或配置模型。",
                rows=[[_btn("返回主菜单", "/dg")]],
            )

        page = max(1, int(args[0])) if args and args[0].isdigit() else 1
        per_page = 8
        total_pages = max(1, (len(models) + per_page - 1) // per_page)
        page = min(page, total_pages)
        current = models[(page - 1) * per_page : page * per_page]

        lines = [
            f"### 🤖 可用模型列表（第 {page}/{total_pages} 页，共 {len(models)} 个）\n",
            "| # | 模型名称 | 单次消耗 |",
            "|---|---|---|",
        ]
        for idx, m in enumerate(current, (page - 1) * per_page + 1):
            cost = self._model_cost(m)
            lines.append(f"| {idx} | `{m}` | **{cost}** 积分/次 |")
        lines.append("\n切换模型发送：`/dg model <名称>`。")

        rows = []
        model_btns = []
        for i, m in enumerate(current):
            idx = (page - 1) * per_page + i + 1
            model_btns.append(_btn(f"模型 {idx}", f"/dg model {m}", fill=True))
            if len(model_btns) == 4:
                rows.append(model_btns)
                model_btns = []
        if model_btns:
            rows.append(model_btns)

        nav = []
        if page > 1:
            nav.append(_btn("◀ 上一页", f"/dg models {page - 1}", action_type=1))
        nav.append(_btn("跳页", "/dg models ", fill=True))
        if page < total_pages:
            nav.append(_btn("下一页 ▶", f"/dg models {page + 1}", action_type=1))
        nav.append(_btn("切换模型", "/dg model ", fill=True))
        nav.append(_btn("返回主菜单", "/dg"))
        rows.append(nav)

        return Card("可用生图模型", "\n".join(lines), rows=rows)

    async def _notify_user_balance(self, user_id: str, delta: int, new_balance: int, reason: str = "充值") -> None:
        if not user_id:
            return
        qq = getattr(self.context, "qq", None)
        if qq and hasattr(qq, "send_text"):
            msg = (
                f"🎉 **积分{reason}到账通知**\n\n"
                f"管理员已为您的账户{reason} **{abs(delta)}** 积分。\n"
                f"当前最新余额：**{new_balance}** 积分。\n"
                f"发送 `/dg` 可打开绘图主菜单开始创作。"
            )
            try:
                await qq.send_text(user_id, msg)
            except Exception:
                pass

    async def on_payment_success(self, intent: dict[str, Any]) -> None:
        if intent.get("local_status") != "paid":
            return
        user_id = str(intent.get("owner_key") or "")
        if not user_id:
            return
        points_minor = int(intent.get("points_minor") or 0)
        points = int(points_minor // 100) if points_minor else int(intent.get("points") or 0)
        if points <= 0:
            return

        order_id = str(intent.get("id") or "")
        processed_orders = self.history.setdefault("_processed_orders", [])
        if order_id in processed_orders:
            return
        processed_orders.append(order_id)
        if len(processed_orders) > 2000:
            del processed_orders[:1000]
        self._save_history()
        if order_id and order_id in self.pending_pay_orders:
            self.pending_pay_orders.pop(order_id, None)
            self._save_pending_orders()

        new_bal = await self._change_balance(user_id, points, reason="在线支付充值")
        logger.info("Payment success for %s: +%d points, new balance %d", user_id, points, new_bal)
        await self._notify_user_balance(user_id, points, new_bal, reason="在线支付充值")

    async def poll_pending_payments(self) -> None:
        if not self.pending_pay_orders:
            return
        try:
            pay_api = getattr(self.context, "builtin", lambda name: None)("runtime.pay")
        except Exception:
            pay_api = None
        if not pay_api or not hasattr(pay_api, "query_payment"):
            return

        try:
            # 严格控制单次轮询全局耗时不超过 3.0 秒，避免阻塞沙箱 Worker 锁引发主进程 10s 超时杀死 Worker
            await asyncio.wait_for(self._do_poll_payments(pay_api), timeout=3.0)
        except TimeoutError:
            logger.debug("Payment polling timed out, skipped to protect worker lock")
        except Exception as exc:
            logger.debug("Payment polling encountered error: %s", exc)

    async def _do_poll_payments(self, pay_api: Any) -> None:
        finished_ids = []
        now = time.time()
        # 优先只轮询最近创建的未完成订单，超过 30 分钟（1800 秒）的自动清理
        items = list(self.pending_pay_orders.items())
        active_items = []
        for order_id, info in items:
            if now - info.get("time", now) > 1800:
                finished_ids.append(order_id)
            else:
                active_items.append((order_id, info))

        # 按时间倒序（最新的在前），每次最多只轮询 2 笔，避免集中突发请求卡死沙箱
        active_items.sort(key=lambda x: x[1].get("time", 0), reverse=True)
        for order_id, _info in active_items[:2]:
            try:
                res = await asyncio.wait_for(pay_api.query_payment(order_id), timeout=2.0)
                status = str(res.get("local_status") or "")
                if status == "paid":
                    await self.on_payment_success(res)
                    finished_ids.append(order_id)
                elif status in {"closed", "refunded", "create_failed", "polling_stopped"}:
                    finished_ids.append(order_id)
            except TimeoutError:
                logger.debug("Single query for order %s timed out during polling", order_id)
            except Exception as e:
                logger.debug("Failed to poll payment %s: %s", order_id, e)

        if finished_ids:
            for fid in finished_ids:
                self.pending_pay_orders.pop(fid, None)
            self._save_pending_orders()

    async def _send_pay_qr_image(self, context: MessageContext, pay_url: str, order_id: str) -> tuple[bool, str]:
        if not pay_url:
            return False, "缺少支付链接"
        try:
            import qrcode
        except ImportError:
            return False, "系统未安装 qrcode 模块"
        tmp_dir = Path(self.data_dir) / "temp"
        tmp_dir.mkdir(parents=True, exist_ok=True)
        tmp_qr = tmp_dir / f"drawimg_pay_qr_{order_id[:16]}_{uuid.uuid4().hex[:6]}.png"
        try:
            img = qrcode.make(pay_url)
            img.save(tmp_qr)
            sent, send_err = await self._send_image(context, tmp_qr)
            return sent, send_err
        except Exception as exc:
            logger.warning("Failed to generate/send pay qr code image: %s", exc)
            return False, str(exc)
        finally:
            tmp_qr.unlink(missing_ok=True)

    async def _handle_pay(self, context: MessageContext, args: list[str]) -> str | Card:
        user_id = self._user_id(context)
        rate_val = float(self._get_cfg("credit_price_yuan", 0.1))
        if not args:
            cur_bal = await self._get_balance(user_id)
            return Card(
                "充值积分",
                f"# 💳 绘图积分充值中心\n\n"
                f"> 当前账户积分余额：**{cur_bal}** 积分\n\n"
                f"* 充值比例：**1 积分 = ￥{rate_val:.2f} 元**\n"
                f"* 到账时效：付款后系统秒级自动入账\n"
                f"* 支持渠道：微信支付 / 支付宝扫码\n\n"
                f"---\n"
                f"💡 *点击下方常用面额快速创建订单，或点击【自定义充值】输入数量：*",
                rows=[
                    [
                        _btn("充 10 积分", "/dg pay 10", action_type=1, style="primary"),
                        _btn("充 50 积分", "/dg pay 50", action_type=1),
                        _btn("充 100 积分", "/dg pay 100", action_type=1),
                    ],
                    [
                        _btn("✏️ 自定义充值", "/dg pay ", fill=True),
                        _btn("💰 查余额", "/dg status", action_type=1),
                        _btn("🎨 绘图主菜单", "/dg", action_type=1),
                    ]
                ]
            )

        sub = args[0].lower()
        if sub in {"link", "qr", "qrcode", "二维码"}:
            order_id = args[1].strip() if len(args) > 1 else ""
            if not order_id:
                for oid, info in reversed(list(self.pending_pay_orders.items())):
                    if info.get("user_id") == user_id:
                        order_id = oid
                        break
            if not order_id:
                pay_api = getattr(self.context, "builtin", lambda name: None)("runtime.pay")
                if pay_api and hasattr(pay_api, "get_latest_intent"):
                    try:
                        latest = await pay_api.get_latest_intent(user_id)
                        if latest and latest.get("local_status") in {"pending", "creating"}:
                            order_id = str(latest.get("id") or latest.get("trade_no") or "")
                    except Exception as e:
                        logger.debug("Failed to get latest intent for %s: %s", user_id, e)
            if not order_id:
                return Card("支付二维码", "未找到待支付的订单。您可以发送 `/dg pay 10` 创建新的充值订单。")

            pay_url = ""
            if order_id in self.pending_pay_orders:
                pay_url = self.pending_pay_orders[order_id].get("pay_url", "")
            if not pay_url:
                pay_api = getattr(self.context, "builtin", lambda name: None)("runtime.pay")
                if pay_api and hasattr(pay_api, "query_payment"):
                    try:
                        qres = await pay_api.query_payment(order_id)
                        pay_url = qres.get("pay_info") or qres.get("pay_url") or qres.get("qrcode") or ""
                    except Exception:
                        pass
            if not pay_url:
                return Card("支付二维码", f"订单 `{order_id}` 未找到有效的支付链接，或订单已过期。")

            sent, send_err = await self._send_pay_qr_image(context, pay_url, order_id)
            row1 = []
            if pay_url and pay_url.startswith(("http://", "https://")):
                row1.append(_btn("💳 立即跳转付款", pay_url, action_type=0, style="primary"))
            row1.append(_btn("🔍 查询订单", f"/dg pay check {order_id}", action_type=1))

            if sent:
                return Card(
                    "支付二维码",
                    f"# 📱 支付二维码已发送\n\n"
                    f"> 订单号：`{order_id}`\n\n"
                    f"* 请使用手机微信或支付宝长按/扫描上方二维码付款；\n"
                    f"* 或直接点击下方【💳 立即跳转付款】打开支付页面。\n\n"
                    f"✨ *付款完成后系统将自动秒级入账，或点击【🔍 查询订单】立即对账。*",
                    rows=[
                        row1,
                        [_btn("🖼️ 获取二维码", f"/dg pay link {order_id}", action_type=1), _btn("💰 查余额", "/dg status", action_type=1)],
                        [_btn("🎨 绘图主菜单", "/dg", action_type=1)],
                    ]
                )
            err_msg = f"（原因：{send_err}）" if send_err else ""
            return Card(
                "支付二维码",
                f"# ⚠️ 二维码图片发送异常\n\n"
                f"> 订单编号：`{order_id}`\n\n"
                f"* 二维码图片发送暂未成功{err_msg}；\n"
                f"* 您可直接点击下方【💳 立即跳转付款】打开收银台完成支付！",
                rows=[
                    row1,
                    [_btn("🖼️ 获取二维码", f"/dg pay link {order_id}", action_type=1), _btn("💰 查余额", "/dg status", action_type=1)],
                    [_btn("🎨 绘图主菜单", "/dg", action_type=1)],
                ]
            )

        if sub in {"check", "order", "status", "query", "查询"}:
            order_id = args[1].strip() if len(args) > 1 else ""
            if not order_id:
                for oid, info in reversed(list(self.pending_pay_orders.items())):
                    if info.get("user_id") == user_id:
                        order_id = oid
                        break
            if not order_id:
                pay_api = getattr(self.context, "builtin", lambda name: None)("runtime.pay")
                if pay_api and hasattr(pay_api, "get_latest_intent"):
                    try:
                        latest = await pay_api.get_latest_intent(user_id)
                        if latest:
                            order_id = str(latest.get("id") or latest.get("trade_no") or "")
                    except Exception as e:
                        logger.debug("Failed to get latest intent for %s: %s", user_id, e)
            if not order_id:
                return Card("查询订单", "未指定订单号，且未找到最近的未完成订单。您可以发送 `/dg pay 10` 创建新的充值订单。")

            pay_api = getattr(self.context, "builtin", lambda name: None)("runtime.pay")
            if not pay_api or not hasattr(pay_api, "query_payment"):
                return Card("查询订单", "支付查询接口不可用。")

            try:
                res = await asyncio.wait_for(pay_api.query_payment(order_id), timeout=5.0)
                status = str(res.get("local_status") or "")
                if status == "paid":
                    await self.on_payment_success(res)
                    self.pending_pay_orders.pop(order_id, None)
                    self._save_pending_orders()
                    return Card(
                        "订单已支付",
                        f"# ✅ 充值支付成功\n\n"
                        f"> 订单号 `{order_id}` 已成功到账！\n\n"
                        f"* 充值状态：**已入账**\n"
                        f"* 当前总余额：**{await self._get_balance(user_id)}** 积分\n\n"
                        f"🎨 祝您创作愉快，点击下方按钮即可立即开始绘图！",
                        rows=[
                            [_btn("🎨 立即去绘图", "/dg", style="primary"), _btn("💰 查余额", "/dg status")],
                            [_btn("🏠 绘图主菜单", "/dg")]
                        ]
                    )
                status_text = "待支付" if status in {"pending", "creating"} else status
                row1 = []
                pay_url = (self.pending_pay_orders.get(order_id) or {}).get("pay_url", "")
                if not pay_url:
                    pay_url = res.get("pay_info") or res.get("pay_url") or res.get("qrcode") or ""
                if pay_url and pay_url.startswith(("http://", "https://")):
                    row1.append(_btn("💳 立即跳转付款", pay_url, action_type=0, style="primary"))
                row1.append(_btn("🔍 刷新订单", f"/dg pay check {order_id}", action_type=1))
                return Card(
                    "订单待支付",
                    f"# ⏳ 订单待支付中\n\n"
                    f"> 订单编号：`{order_id}`\n\n"
                    f"* 当前状态：**{status_text}**\n"
                    f"* 若您已付款，请稍候 2~3 秒后点击【🔍 刷新订单】自动对账；\n"
                    f"* 若未完成付款，请点击下方【💳 立即跳转付款】或【🖼️ 获取二维码】。",
                    rows=[
                        row1,
                        [_btn("🖼️ 获取二维码", f"/dg pay link {order_id}", action_type=1), _btn("💰 查余额", "/dg status", action_type=1)],
                        [_btn("🎨 绘图主菜单", "/dg", action_type=1)]
                    ]
                )
            except TimeoutError:
                row1 = []
                pay_url = (self.pending_pay_orders.get(order_id) or {}).get("pay_url", "")
                if pay_url and pay_url.startswith(("http://", "https://")):
                    row1.append(_btn("💳 立即跳转付款", pay_url, action_type=0, style="primary"))
                row1.append(_btn("🔍 刷新重试", f"/dg pay check {order_id}", action_type=1))
                return Card(
                    "查询订单",
                    f"# ⏳ 订单查询稍有延迟\n\n"
                    f"> 订单编号：`{order_id}`\n\n"
                    f"* 上游支付平台对账稍有延迟，请稍候 2~3 秒后点击下方【🔍 刷新重试】；\n"
                    f"* 若您已完成付款，系统后台轮询检测到后会自动秒级入账。",
                    rows=[
                        row1,
                        [_btn("🖼️ 获取二维码", f"/dg pay link {order_id}", action_type=1), _btn("💰 查余额", "/dg status", action_type=1)],
                        [_btn("🎨 绘图主菜单", "/dg", action_type=1)]
                    ]
                )
            except Exception as exc:
                return Card("查询订单", f"查询订单 `{order_id}` 失败：{exc}")

        try:
            points = int(args[0])
            if points <= 0 or points > 100000:
                return "充值积分数量需在 1 ~ 100,000 之间。"
        except ValueError:
            return "积分数值必须为正整数。"

        yuan_amount = round(points * rate_val, 2)
        if yuan_amount < 0.01:
            yuan_amount = 0.01

        pay_api = getattr(self.context, "pay_api", None)
        if not pay_api:
            try:
                pay_api = getattr(self.context, "builtin", lambda name: None)("runtime.pay")
            except Exception:
                pay_api = None

        if pay_api and (hasattr(pay_api, "create_payment") or hasattr(pay_api, "create_trade")):
            try:
                if hasattr(pay_api, "create_payment"):
                    ext_id = f"drawimg_{user_id}_{int(time.time())}_{uuid.uuid4().hex[:8]}"
                    order_info = await asyncio.wait_for(
                        pay_api.create_payment(
                            source_plugin="plugin.drawimg.service",
                            external_id=ext_id,
                            owner_key=user_id,
                            subject=f"绘图服务积分充值 - {points} 积分",
                            amount=str(yuan_amount),
                            points=str(points),
                            point_type="drawimg",
                            user_id=user_id,
                            amount_yuan=yuan_amount,
                            point_count=points,
                            description=f"绘图服务积分充值 - {points} 积分",
                        ),
                        timeout=8.0,
                    )
                else:
                    order_info = await asyncio.wait_for(
                        pay_api.create_trade(
                            owner_key=user_id,
                            amount_yuan=yuan_amount,
                            point_type="drawimg",
                            points=points,
                        ),
                        timeout=8.0,
                    )
                qrcode_url = order_info.get("qrcode") or ""
                order_id = str(order_info.get("order_id") or order_info.get("trade_no") or order_info.get("id") or "")
                real_amount = order_info.get("amount") or str(yuan_amount)
                pay_url = order_info.get("pay_url") or order_info.get("url") or order_info.get("pay_info") or qrcode_url

                if order_id and order_id != "-":
                    self.pending_pay_orders[order_id] = {
                        "user_id": user_id,
                        "points": points,
                        "time": time.time(),
                        "pay_url": pay_url,
                    }
                    self._save_pending_orders()

                markdown = (
                    f"# 💳 绘图积分充值订单\n\n"
                    f"> 订单已生成，30分钟内有效，支持微信与支付宝扫码。\n\n"
                    f"* 充值数量：`{points}` 积分\n"
                    f"* 应付金额：**￥{real_amount}** 元\n"
                    f"* 订单号：`{order_id}`\n"
                    f"* 订单状态：⏳ **待支付**\n\n"
                    f"---\n"
                    f"📱 **快捷付款指南**：\n"
                    f"1. **方式一（推荐）**：点击下方【💳 立即跳转付款】打开收银台直接支付；\n"
                    f"2. **方式二（扫码）**：若需微信或支付宝扫码，请点击下方【🖼️ 获取二维码】。\n\n"
                    f"✨ *付款完成后系统将自动秒级充值到账，无需手动确认。*"
                )

                row1 = []
                if pay_url and pay_url.startswith(("http://", "https://")):
                    row1.append(_btn("💳 立即跳转付款", pay_url, action_type=0, style="primary"))
                row1.append(_btn("🔍 查询订单", f"/dg pay check {order_id}", action_type=1))

                row2 = [
                    _btn("🖼️ 获取二维码", f"/dg pay link {order_id}", action_type=1),
                    _btn("💰 查余额", "/dg status", action_type=1),
                ]
                row3 = [
                    _btn("🎨 绘图主菜单", "/dg", action_type=1),
                ]
                rows = [row1, row2, row3]
                return Card("积分充值", markdown, rows=rows)
            except TimeoutError:
                return Card(
                    "积分充值",
                    "# ⏳ 创建充值订单稍有延迟\n\n"
                    "* 上游支付平台网关响应稍慢，可能订单已在生成处理中。\n"
                    "* 请点击下方【🔍 检查最近订单】尝试认领，或稍候点击【重试充值】。",
                    rows=[
                        [_btn("🔍 检查最近订单", "/dg pay check", action_type=1), _btn(f"重试充 {points} 积分", f"/dg pay {points}", action_type=1)],
                        [_btn("💰 查余额", "/dg status", action_type=1), _btn("🎨 绘图主菜单", "/dg", action_type=1)]
                    ]
                )
            except Exception as e:
                err_str = str(e)
                logger.error("Pay API failed: %s", err_str)
                if "active payment limit" in err_str:
                    latest_oid = ""
                    pay_url = ""
                    try:
                        pay_api = getattr(self.context, "builtin", lambda name: None)("runtime.pay")
                        if pay_api and hasattr(pay_api, "get_latest_intent"):
                            latest = await pay_api.get_latest_intent(user_id)
                            if latest:
                                latest_oid = str(latest.get("id") or latest.get("trade_no") or "")
                                pay_url = latest.get("pay_info") or latest.get("pay_url") or latest.get("qrcode") or ""
                    except Exception:
                        pass
                    if not latest_oid:
                        for oid, info in reversed(list(self.pending_pay_orders.items())):
                            if info.get("user_id") == user_id:
                                latest_oid = oid
                                pay_url = info.get("pay_url", "")
                                break
                    if latest_oid and not pay_url:
                        if latest_oid in self.pending_pay_orders:
                            pay_url = self.pending_pay_orders[latest_oid].get("pay_url", "")
                        if not pay_url and pay_api and hasattr(pay_api, "query_payment"):
                            try:
                                qres = await pay_api.query_payment(latest_oid)
                                pay_url = qres.get("pay_info") or qres.get("pay_url") or qres.get("qrcode") or ""
                            except Exception:
                                pass

                    link_cmd = f"/dg pay link {latest_oid}".strip() if latest_oid else "/dg pay link"
                    check_cmd = f"/dg pay check {latest_oid}".strip() if latest_oid else "/dg pay check"

                    row1 = []
                    if pay_url and pay_url.startswith(("http://", "https://")):
                        row1.append(_btn("💳 立即跳转付款", pay_url, action_type=0, style="primary"))
                    row1.append(_btn("🔍 刷新订单", check_cmd, action_type=1))

                    rows = [
                        row1,
                        [
                            _btn("🖼️ 获取二维码", link_cmd, action_type=1),
                            _btn("💰 查余额", "/dg status", action_type=1),
                        ],
                        [
                            _btn("🎨 绘图主菜单", "/dg", action_type=1),
                        ]
                    ]
                    oid_tip = f"（最新订单：`{latest_oid}`）" if latest_oid else ""
                    return Card(
                        "未完成订单提醒",
                        f"# ⚠️ 待支付订单提示\n\n"
                        f"> 您当前尚有未完成的待支付订单{oid_tip}，最多保留 3 笔。\n\n"
                        f"* 若您刚刚已完成付款，请点击【🔍 刷新订单】自动秒级入账；\n"
                        f"* 若需继续付款，可点击【💳 立即跳转付款】或【🖼️ 获取二维码】；\n"
                        f"* 超过 30 分钟未支付的旧订单会自动关闭失效，届时可重新创建。\n\n"
                        f"💡 *无需担心重复扣费，系统支持实时对账并自动累加积分。*",
                        rows=rows
                    )
                if "unavailable" in err_str or "not available" in err_str or "Built-in plugin API" in err_str:
                    if context.is_admin:
                        return "⚠️ 567 在线支付功能当前未开启。请在后台管理面板「🧩 插件管理」中启用「567 支付」插件并配置商户密钥；管理员也可以直接使用 `/dg give <用户> <积分>` 赠送积分。"
                    return "⚠️ 在线支付渠道维护中或未开启。如需充值积分，请联系机器人管理员。"
                return f"创建支付订单失败（{err_str}），请稍后重试或联系管理员。"

        if context.is_admin:
            await self._change_balance(user_id, points, reason="管理员直接充值")
            return f"【管理员直接充值】已成功为您的账户增加 **{points}** 积分，当前总余额：**{await self._get_balance(user_id)}** 积分。"
        return "⚠️ 当前机器人未开启 567 在线支付功能。如需充值积分，请联系机器人管理员。"

    async def _handle_give(self, context: MessageContext, args: list[str]) -> str | Card:
        if not context.is_admin:
            return Card("无权限", "⚠️ 只有管理员可以赠送或调整用户积分。")
        if not args:
            return Card("使用帮助", "用法：`/dg give <数量> [用户编号/艾特用户]` 或 `/dg give <用户编号/艾特用户> <数量>`")

        delta = 0
        target = ""
        mention_target = _extract_mention_target(context)

        if len(args) == 1:
            try:
                delta = int(args[0])
                target = mention_target or self._user_id(context)
            except ValueError:
                target = _clean_user_id(args[0])
                delta = 0
        else:
            if args[0].lstrip("-+").isdigit():
                delta = int(args[0])
                target = _clean_user_id(args[1]) or mention_target
            else:
                target = _clean_user_id(args[0]) or mention_target
                try:
                    delta = int(args[1])
                except ValueError:
                    return Card("格式错误", "⚠️ 积分数值必须为整数。例如 `/dg give 10 @用户`")

        if not target or target == "default_user":
            target = mention_target or self._user_id(context)

        new_bal = await self._change_balance(target, delta, reason="管理员赠送/充值")
        action_name = "增加" if delta >= 0 else "扣除"
        if delta > 0:
            try:
                import asyncio
                loop = asyncio.get_running_loop()
                loop.create_task(self._notify_user_balance(target, delta, new_bal, reason="管理员赠送/充值"))
            except RuntimeError:
                pass

        markdown = (
            f"### 💳 积分调整成功\n\n"
            f"- **目标用户**：`{target}`\n"
            f"- **操作类型**：{action_name}积分\n"
            f"- **变动积分**：**{'+' if delta > 0 else ''}{delta}**\n"
            f"- **当前余额**：**{new_bal}** 积分\n"
        )
        rows = [
            [_btn("查积分", "/dg status"), _btn("充值菜单", "/dg pay")],
            [_btn("返回主菜单", "/dg")]
        ]
        return Card("积分调整", markdown, rows=rows)

    def _handle_rate(self, context: MessageContext, args: list[str]) -> str:
        if not context.is_admin:
            return "只有管理员可以设置充值比例。"
        if not args:
            return f"当前充值比例为：`{self._get_cfg('credit_price_yuan', 0.1)}` 元/积分。修改：`/dg rate <单价>`。"
        try:
            rate = float(args[0])
            if rate <= 0:
                raise ValueError()
            self.config["credit_price_yuan"] = rate
            self._save_config()
            return f"充值比例已设置为：**{rate}** 元/积分。"
        except ValueError:
            return "单价必须为大于 0 的数值。"

    def _handle_cost(self, context: MessageContext, args: list[str]) -> str:
        if not context.is_admin:
            return "只有管理员可以修改模型计费规则。"
        if not args:
            rules = self._get_cfg("credit_cost_rules") or "未单独配置（默认 1 积分）"
            return f"当前模型计费规则：`{rules}`。\n修改格式：`/dg cost <模型>:<积分>;<模型2>:<积分>`。"
        self.config["credit_cost_rules"] = " ".join(args).strip()
        self._save_config()
        return "模型计费规则已更新。"

    def _handle_admin(self, context: MessageContext) -> str | Card:
        if not context.is_admin:
            return "此操作需要管理员权限。"
        rate = self._get_cfg("credit_price_yuan", 0.1)
        model = self._get_cfg("default_model", "dall-e-3")
        user_count = len(self.credits)
        total_credits = sum(self.credits.values())

        markdown = (
            "### ⚙️ 绘图服务管理员菜单\n\n"
            f"- **插件版本**：`v{PLUGIN_VERSION}`\n"
            f"- **默认模型**：`{model}`\n"
            f"- **充值比例**：`{rate}` 元/积分\n"
            f"- **用户总数**：**{user_count}** 人\n"
            f"- **积分总池**：**{total_credits}** 积分\n\n"
            "常用指令：\n"
            "- `/dg rate <元每积分>` — 设置充值比例\n"
            "- `/dg give <数量> [用户]` — 赠送积分\n"
            "- `/dg cost <模型>:<积分>` — 设置模型单价\n"
            "- `/dg top` — 查看积分排行\n"
        )
        rows = [
            [
                _btn("充值比例", "/dg rate"),
                _btn("模型计费", "/dg cost ", fill=True, permission=1),
            ],
            [
                _btn("赠送积分", "/dg give ", fill=True, permission=1),
                _btn("积分排行", "/dg top", permission=1),
            ],
            [
                _btn("模型列表", "/dg models"),
                _btn("返回主菜单", "/dg"),
            ],
        ]
        return Card("管理员菜单", markdown, rows=rows)

    def _handle_blacklist(self, context: MessageContext, args: list[str]) -> str:
        if not context.is_admin:
            return "只有管理员可以管理黑名单。"
        bl = self.config.setdefault("test_blacklist", [])
        if not args or args[0].lower() == "list":
            return f"黑名单用户列表（共 {len(bl)} 人）：\n" + ("\n".join(f"- `{u}`" for u in bl) if bl else "暂无黑名单用户。")
        act = args[0].lower()
        if len(args) < 2:
            return "用法：/dg blacklist <add/del> <用户OpenID>"
        target = args[1].strip()
        if act == "add":
            if target not in bl:
                bl.append(target)
                self._save_config()
            return f"已将 `{target}` 加入黑名单。"
        if act in {"del", "remove", "rm"}:
            if target in bl:
                bl.remove(target)
                self._save_config()
            return f"已将 `{target}` 移出黑名单。"
        return "未知操作，可选：`list`、`add`、`del`。"

    def _handle_history(self, context: MessageContext) -> str | Card:
        return "生图历史功能已关闭，系统不保存任何历史生成记录。"

    def _handle_resend(self, context: MessageContext, args: list[str]) -> str | Card:
        return "历史重发功能已关闭，系统不保存任何历史生成记录。"

    # Backward compatible aliases
    handle_dgs = handle_dg
    handle_dgse = handle_dge
    handle_dgsm = handle_dgm


def setup(context: Any) -> DrawImgServicePlugin:
    plugin = DrawImgServicePlugin(context)
    context.register_command("dg", plugin.handle_dg, category="drawimg", description="绘图服务主入口")
    context.register_command("dgs", plugin.handle_dg, category="drawimg", description="绘图服务主入口")
    context.register_command("dge", plugin.handle_dge, category="drawimg", description="单图改图")
    context.register_command("dgse", plugin.handle_dge, category="drawimg", description="单图改图")
    context.register_command("dgm", plugin.handle_dgm, category="drawimg", description="多图改图")
    context.register_command("dgsm", plugin.handle_dgm, category="drawimg", description="多图改图")
    context.register_event_handler("*", plugin.on_event)
    context.register_task("cleanup", 3600, plugin.cleanup)
    context.register_task("check_payments", 15, plugin.poll_pending_payments)
    return plugin
