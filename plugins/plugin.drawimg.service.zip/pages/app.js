const bridge = window.AstrBotPluginPage || (() => {
  let reqId = 0;
  const pending = new Map();

  window.addEventListener("message", (event) => {
    const msg = event.data || {};
    if (msg.type === "plugin_bridge_response" && pending.has(msg.requestId)) {
      const { resolve, reject } = pending.get(msg.requestId);
      pending.delete(msg.requestId);
      if (msg.success) resolve(msg.data);
      else reject(new Error(msg.error || "请求失败"));
    }
  });

  function callHost(method, path, body) {
    const p = path.startsWith("page/") ? path : `page/${path}`;
    const fullPath = p.startsWith("/") ? p : `/api/drawimg/${p}`;

    // If opened directly (not in iframe)
    if (window.parent === window || !window.parent) {
      return fetch(fullPath, {
        method,
        headers: { "Content-Type": "application/json" },
        body: body ? (typeof body === "string" ? body : JSON.stringify(body)) : undefined,
      }).then(async (r) => {
        const d = await r.json().catch(() => ({}));
        if (!r.ok) throw new Error(d.detail || `请求失败 (HTTP ${r.status})`);
        return d;
      });
    }

    const requestId = "req_" + (++reqId) + "_" + Math.random().toString(36).slice(2, 8);
    return new Promise((resolve, reject) => {
      pending.set(requestId, { resolve, reject });
      window.parent.postMessage({
        type: "plugin_bridge_request",
        requestId,
        method,
        path: fullPath,
        body
      }, "*");
      setTimeout(() => {
        if (pending.has(requestId)) {
          pending.delete(requestId);
          reject(new Error("请求超时"));
        }
      }, 30000);
    });
  }

  return {
    async ready() { return true; },
    async apiGet(path) { return callHost("GET", path); },
    async apiPost(path, body) { return callHost("POST", path, body); }
  };
})();
const el = (id) => document.getElementById(id);
let toastTimer = null;
function toast(message, kind = "ok") {
  const box = el("toast");
  if (!box) return;
  box.textContent = message;
  box.classList.toggle("err", kind === "err");
  box.classList.add("show");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => box.classList.remove("show"), 2600);
}
const TAB_STATUS = { overview: "status", users: "status", presets: "p-status", config: "cf-status" };
let currentTab = "overview";

function setStatus(text, kind, tab) {
  const box = el(TAB_STATUS[tab || currentTab] || "status");
  if (!box) return;
  box.textContent = text || "";
  box.classList.toggle("ok", kind === "ok");
  box.classList.toggle("err", kind === "err");
}

async function guarded(tab, fn) {
  try {
    await fn();
    return true;
  } catch (e) {
    const message = e.message || String(e);
    setStatus(message, "err", tab);
    toast(message, "err");
    return false;
  }
}

async function loadOverview() {
  const d = await bridge.apiGet("page/overview");
  el("ov-users").textContent = d.stats.users;
  el("ov-credits").textContent = d.stats.total_credits;
  el("ov-price").textContent = `${d.config.credit_price_yuan} 元/积分`;
  el("ov-cost").textContent = `${d.config.test_credit_cost} 积分`;
  el("ov-daily").textContent = d.config.test_daily_limit || "不限";
  el("ov-model").textContent = d.config.default_model || "未配置";
  el("ov-api").textContent = (d.config.api_configured || d.config.api_key_set) ? "已配置" : "未配置";
  el("ov-gengroup").textContent = d.config.enable_group ? "允许" : "禁止";
  el("ov-cache").textContent = `${d.config.same_cache_sec} 秒`;
}

async function loadUsers() {
  const d = await bridge.apiGet("page/users");
  const tbody = el("u-rows");
  tbody.innerHTML = "";
  if (!d.users.length) {
    tbody.innerHTML = '<tr><td colspan="7" class="muted">暂无用户数据</td></tr>';
    return;
  }
  for (const u of d.users) {
    const tr = document.createElement("tr");
    if (u.blacklisted) tr.classList.add("banned");
    const tdKey = document.createElement("td");
    tdKey.className = "mono";
    tdKey.textContent = u.key;
    tr.appendChild(tdKey);
    for (const text of [u.source, u.model, String(u.credits ?? 0), String(u.today ?? 0), u.blacklisted ? "是" : "否"]) {
      const td = document.createElement("td");
      td.textContent = text;
      tr.appendChild(td);
    }
    const tdOps = document.createElement("td");
    const add = (label, fn, title = "") => {
      const b = document.createElement("button");
      b.type = "button";
      b.textContent = label;
      if (title) b.title = title;
      b.onclick = fn;
      tdOps.appendChild(b);
    };
    add("+10", () => adjust(u.key, 10, "add"));
    add("-10", () => adjust(u.key, -10, "add"));
    add("改模型", () => {
      const m = prompt(`请输入用户 [${u.key}] 要使用的生图模型名称（留空或输入 reset 恢复跟随全局默认）：`, u.model || "");
      if (m !== null) changeUserModel(u.key, m.trim());
    }, "修改该用户使用的模型");
    add("重置模型", () => changeUserModel(u.key, "reset"), "重置为跟随时下全局默认模型");
    add(u.blacklisted ? "解黑" : "加黑", () => blacklist(u.key, u.blacklisted ? "remove" : "add"));
    tr.appendChild(tdOps);
    tbody.appendChild(tr);
  }
}

async function changeUserModel(key, model) {
  return guarded("users", async () => {
    await bridge.apiPost("page/user_model", { key, model });
    const isReset = !model || ["reset", "default", "auto", "off", "重置", "默认"].includes(model.toLowerCase());
    const text = isReset ? "已重置为跟随全局默认" : `已设置为 ${model}`;
    setStatus(`已更新 ${key} 模型：${text}`, "ok", "users");
    toast(`已更新 ${key} 模型：${text}`);
    await Promise.all([loadUsers(), loadOverview()]);
  });
}

async function adjust(key, credits, mode) {
  return guarded("users", async () => {
    await bridge.apiPost("page/user_credit", { key, credits, mode });
    const text = mode === "set" ? `设置为 ${credits} 积分` : `${credits > 0 ? "+" : ""}${credits} 积分`;
    setStatus(`已更新 ${key}：${text}`, "ok", "users");
    toast(`已更新 ${key}：${text}`);
    await Promise.all([loadUsers(), loadOverview()]);
  });
}

async function blacklist(key, action) {
  return guarded("users", async () => {
    await bridge.apiPost("page/blacklist", { key, action });
    setStatus(action === "add" ? "已加黑" : "已移出黑名单", "ok", "users");
    toast(`已${action === "add" ? "将 " + key + " 加入" : "把 " + key + " 移出"}黑名单`);
    await Promise.all([loadUsers(), loadOverview()]);
  });
}

function readConfigForm() {
  const cost = collectCostRules();
  const payload = {
    credit_price_yuan: Number(el("cf-price").value),
    test_credit_cost: Number(el("cf-cost").value),
    test_daily_limit: Number(el("cf-daily").value),
    api_base_url: el("cf-api-base").value.trim(),
    default_model: el("cf-model").value.trim(),
    image_size: el("cf-size").value.trim(),
    image_quality: el("cf-quality").value.trim(),
    same_cache_sec: Number(el("cf-cache").value),
    max_prompt_chars: Number(el("cf-prompt").value),
    credit_cost_rules: cost.object || cost.text,
    enable_group: el("cf-gengroup").checked,
  };
  const key = el("cf-api-key").value.trim();
  if (key) {
    payload.api_key = key;
  }
  return payload;
}

function fillConfigForm(c) {
  if (!c) return;
  el("cf-price").value = c.credit_price_yuan ?? 0.1;
  el("cf-cost").value = c.test_credit_cost ?? 1;
  el("cf-daily").value = c.test_daily_limit ?? 0;
  el("cf-api-base").value = c.api_base_url || "";
  el("cf-api-key").value = "";
  el("cf-api-key").placeholder = c.api_key_set ? "●●●●●●●● (已配置，留空保留)" : "sk-...";
  el("cf-model").value = c.default_model || "";
  el("cf-size").value = c.image_size || "";
  el("cf-quality").value = c.image_quality || "";
  el("cf-cache").value = c.same_cache_sec ?? 300;
  el("cf-prompt").value = c.max_prompt_chars || 4000;
  el("cf-gengroup").checked = !!c.enable_group;
  renderCostRows(parsePairRows(c.credit_cost_rules || ""));
}

const TAB_LOADERS = {
  overview: loadOverview,
  users: loadUsers,
  presets: async () => {
    const d = await bridge.apiGet("page/overview");
    renderPresetRows(parsePresetText(d.config.style_presets || ""));
  },
  config: async () => {
    const d = await bridge.apiGet("page/overview");
    fillConfigForm(d.config);
  },
};

for (const tab of document.querySelectorAll(".tab")) {
  tab.onclick = async () => {
    for (const item of document.querySelectorAll(".tab")) item.classList.toggle("active", item === tab);
    for (const pane of document.querySelectorAll(".pane")) pane.classList.toggle("active", pane.id === `pane-${tab.dataset.tab}`);
    currentTab = tab.dataset.tab;
    setStatus("加载中…", "", tab);
    const ok = await guarded(currentTab, TAB_LOADERS[currentTab] || (() => {}));
    if (ok) setStatus("", "ok", tab);
  };
}

el("ov-refresh").onclick = () => guarded("overview", loadOverview);
el("u-refresh").onclick = () => guarded("users", loadUsers);

el("u-give").onclick = () => {
  const key = el("u-key").value.trim();
  const credits = Number(el("u-credits").value);
  if (!key || !credits) { setStatus("请填写用户编号和积分", "err", "users"); return; }
  adjust(key, credits, "add");
};
el("u-set").onclick = () => {
  const key = el("u-key").value.trim();
  const credits = Number(el("u-credits").value);
  if (!key || isNaN(credits)) { setStatus("请填写用户编号和积分", "err", "users"); return; }
  adjust(key, credits, "set");
};
el("u-ban").onclick = () => {
  const key = el("u-key").value.trim();
  if (!key) { setStatus("请填写用户编号", "err", "users"); return; }
  blacklist(key, "add");
};
el("u-unban").onclick = () => {
  const key = el("u-key").value.trim();
  if (!key) { setStatus("请填写用户编号", "err", "users"); return; }
  blacklist(key, "remove");
};

function parsePresetText(raw) {
  const rows = [];
  if (!raw) return rows;
  if (typeof raw === "object") {
    if (Array.isArray(raw)) {
      for (const item of raw) {
        if (item && typeof item === "object") {
          const name = String(item.name || item.key || "").trim();
          const text = String(item.text || item.value || item.prompt || "").trim();
          if (name && text) rows.push({ name, text });
        }
      }
      return rows;
    }
    for (const [name, text] of Object.entries(raw)) {
      const n = String(name).trim();
      const t = String(text).trim();
      if (n && t) rows.push({ name: n, text: t });
    }
    return rows;
  }
  if (typeof raw === "string") {
    const trimmed = raw.trim();
    if (trimmed.startsWith("{") && trimmed.endsWith("}")) {
      try {
        const obj = JSON.parse(trimmed);
        return parsePresetText(obj);
      } catch (e) {}
    }
    for (const chunk of trimmed.split(/[;；\n]+/)) {
      const parts = chunk.split(/[:：]/);
      if (parts.length >= 2 && parts[0].trim() && parts.slice(1).join(":").trim()) {
        rows.push({ name: parts[0].trim(), text: parts.slice(1).join(":").trim() });
      }
    }
  }
  return rows;
}

function renderPresetRows(rows) {
  const box = el("p-rows");
  box.innerHTML = "";
  for (const row of rows) box.appendChild(presetRow(row.name, row.text));
  if (!rows.length) {
    const empty = document.createElement("div");
    empty.className = "muted";
    empty.textContent = "暂无预设，点击下方“新增预设”。";
    box.appendChild(empty);
  }
}

function presetRow(name = "", text = "") {
  const div = document.createElement("div");
  div.className = "preset-row";
  const nameInput = document.createElement("input");
  nameInput.type = "text";
  nameInput.className = "preset-name";
  nameInput.placeholder = "名称（如 动漫）";
  nameInput.value = name;
  nameInput.maxLength = 30;
  const textInput = document.createElement("input");
  textInput.type = "text";
  textInput.className = "preset-text";
  textInput.placeholder = "附加提示词（如 动漫风格,鲜艳色彩）";
  textInput.value = text;
  textInput.maxLength = 20000;
  const del = document.createElement("button");
  del.type = "button";
  del.className = "danger";
  del.textContent = "删除";
  del.onclick = () => div.remove();
  div.append(nameInput, textInput, del);
  return div;
}

function collectPresets() {
  const rows = [];
  const names = new Set();
  let duplicate = null;
  for (const div of document.querySelectorAll("#p-rows .preset-row")) {
    const name = div.querySelector(".preset-name").value.trim();
    const text = div.querySelector(".preset-text").value.trim();
    if (!name && !text) continue;
    const fold = name.toLowerCase();
    if (names.has(fold)) { duplicate = name; }
    names.add(fold);
    rows.push({ name, text });
  }
  return { rows, duplicate };
}

el("p-add").onclick = () => {
  el("p-rows").appendChild(presetRow());
};

el("p-save").onclick = async () => {
  const { rows, duplicate } = collectPresets();
  if (duplicate) { setStatus(`存在重复名称：${duplicate}`, "err", "presets"); return; }
  for (const row of rows) {
    if (!row.name || !row.text) { setStatus("每条预设的名称和附加提示词都要填写", "err", "presets"); return; }
  }
  const ok = await guarded("presets", async () => {
    const payload = {};
    for (const r of rows) payload[r.name] = r.text;
    const res = await bridge.apiPost("page/presets", { style_presets: payload });
    setStatus(`已保存 ${rows.length} 条预设`, "ok", "presets");
    toast(`已保存 ${rows.length} 条风格预设`);
    if (res && res.presets) {
      renderPresetRows(parsePresetText(res.presets));
    }
  });
  if (ok) {
    const d = await bridge.apiGet("page/overview");
    renderPresetRows(parsePresetText(d.config.style_presets || {}));
  }
};

function parsePairRows(raw) {
  const rows = [];
  if (!raw) return rows;
  if (typeof raw === "object") {
    if (Array.isArray(raw)) {
      for (const item of raw) {
        if (item && typeof item === "object") {
          const name = String(item.name || item.model || item.key || "").trim();
          const value = String(item.value || item.cost || item.credits || "").trim();
          if (name && value) rows.push({ name, value });
        }
      }
      return rows;
    }
    for (const [name, value] of Object.entries(raw)) {
      const n = String(name).trim();
      const v = String(value).trim();
      if (n && v) rows.push({ name: n, value: v });
    }
    return rows;
  }
  if (typeof raw === "string") {
    const trimmed = raw.trim();
    if (trimmed.startsWith("{") && trimmed.endsWith("}")) {
      try {
        const obj = JSON.parse(trimmed);
        return parsePairRows(obj);
      } catch (e) {}
    }
    for (const chunk of trimmed.split(/[;；\n]+/)) {
      const parts = chunk.split(/[:：]/);
      if (parts.length >= 2 && parts[0].trim() && parts.slice(1).join(":").trim()) {
        rows.push({ name: parts[0].trim(), value: parts.slice(1).join(":").trim() });
      }
    }
  }
  return rows;
}

let availableModels = [];

function populateModelDatalist(models) {
  availableModels = Array.isArray(models) ? models : [];
  let dl = el("cf-models-datalist");
  if (!dl) {
    dl = document.createElement("datalist");
    dl.id = "cf-models-datalist";
    document.body.appendChild(dl);
  }
  dl.innerHTML = "";
  for (const m of availableModels) {
    const opt = document.createElement("option");
    opt.value = m;
    dl.appendChild(opt);
  }
}

function costRow(name = "", value = "") {
  const div = document.createElement("div");
  div.className = "preset-row";
  div.style.display = "flex";
  div.style.gap = "8px";
  div.style.alignItems = "center";
  div.style.flexWrap = "wrap";

  const modelInput = document.createElement("input");
  modelInput.type = "text";
  modelInput.className = "preset-name";
  modelInput.placeholder = "模型名称（可输入或从右侧下拉选择）";
  modelInput.value = name;
  modelInput.setAttribute("list", "cf-models-datalist");
  modelInput.maxLength = 100;
  modelInput.style.flex = "1 1 200px";

  const select = document.createElement("select");
  select.className = "model-quick-select";
  select.style.maxWidth = "170px";
  select.style.fontSize = "12px";
  select.style.height = "36px";
  select.style.borderRadius = "var(--radius)";
  select.style.border = "1px solid var(--border)";
  select.style.background = "var(--input-bg)";
  select.style.color = "var(--text)";
  select.innerHTML = '<option value="">-- 选择画图模型 --</option>';
  for (const m of availableModels) {
    const opt = document.createElement("option");
    opt.value = m;
    opt.textContent = m;
    if (m === name) opt.selected = true;
    select.appendChild(opt);
  }
  select.onchange = () => {
    if (select.value) {
      modelInput.value = select.value;
    }
  };

  const costInput = document.createElement("input");
  costInput.type = "number";
  costInput.className = "preset-text";
  costInput.placeholder = "积分";
  costInput.min = 1;
  costInput.value = value;
  costInput.style.width = "90px";

  const del = document.createElement("button");
  del.type = "button";
  del.className = "danger";
  del.textContent = "删除";
  del.onclick = () => div.remove();

  div.append(modelInput, select, costInput, del);
  return div;
}

function renderCostRows(rows) {
  const box = el("cf-cost-rows");
  box.innerHTML = "";
  for (const row of rows) box.appendChild(costRow(row.name, row.value));
  if (!rows.length) {
    const empty = document.createElement("div");
    empty.className = "muted";
    empty.textContent = "暂无分级规则，点击下方“新增规则”。";
    box.appendChild(empty);
  }
}

function collectCostRules() {
  const rows = [];
  const names = new Set();
  let invalid = "";
  for (const div of document.querySelectorAll("#cf-cost-rows .preset-row")) {
    const name = div.querySelector(".preset-name")?.value.trim() || "";
    const value = div.querySelector(".preset-text")?.value.trim() || "";
    if (!name && !value) continue;
    const fold = name.toLowerCase();
    if (names.has(fold)) { invalid = `重复的模型：${name}`; break; }
    if (!name || !Number.isInteger(Number(value)) || Number(value) < 1) { invalid = `规则 ${name || "(空)"} 无效：积分必须是正整数`; break; }
    names.add(fold);
    rows.push({ name, value: Number(value) });
  }
  const rulesObj = {};
  for (const r of rows) rulesObj[r.name] = r.value;
  return { text: rows.map((r) => `${r.name}:${r.value}`).join(";"), object: rulesObj, invalid };
}

el("cf-cost-add").onclick = () => {
  el("cf-cost-rows").appendChild(costRow());
};

el("cf-fetch-models").onclick = async () => {
  const statusEl = el("cf-fetch-status");
  statusEl.textContent = "正在连接接口获取画图模型…";
  statusEl.style.color = "var(--muted)";
  try {
    const payload = {
      api_base_url: el("cf-api-base").value.trim(),
      api_key: el("cf-api-key").value.trim()
    };
    const res = await bridge.apiPost("page/fetch_models", payload);
    const imgModels = (res.image_models && res.image_models.length) ? res.image_models : (res.models || []);
    populateModelDatalist(imgModels);
    for (const row of document.querySelectorAll("#cf-cost-rows .preset-row")) {
      const input = row.querySelector(".preset-name");
      const sel = row.querySelector(".model-quick-select");
      if (sel && input) {
        const cur = input.value.trim();
        sel.innerHTML = '<option value="">-- 选择画图模型 --</option>';
        for (const m of imgModels) {
          const opt = document.createElement("option");
          opt.value = m;
          opt.textContent = m;
          if (m === cur) opt.selected = true;
          sel.appendChild(opt);
        }
      }
    }
    statusEl.textContent = `✅ 成功加载 ${imgModels.length} 个画图模型（渠道总模型 ${res.total || 0} 个）`;
    statusEl.style.color = "var(--accent)";
    toast(`已筛选并加载 ${imgModels.length} 个画图模型`);
  } catch (err) {
    statusEl.textContent = `❌ 获取失败: ${err.message || String(err)}`;
    statusEl.style.color = "var(--danger)";
    toast(`获取模型失败: ${err.message || String(err)}`, "err");
  }
};

el("cf-save").onclick = () => guarded("config", async () => {
  const cost = collectCostRules();
  if (cost.invalid) { setStatus(cost.invalid, "err", "config"); toast(cost.invalid, "err"); return; }
  const payload = readConfigForm();
  const d0 = await bridge.apiPost("page/config", payload);
  setStatus(`已保存 ${Object.keys(d0.applied || {}).length} 项配置`, "ok", "config");
  const d = await bridge.apiGet("page/overview");
  fillConfigForm(d.config);
  await loadOverview();
});

(async () => {
  await bridge.ready();
  await guarded("overview", loadOverview);
})();
