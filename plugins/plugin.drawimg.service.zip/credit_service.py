from __future__ import annotations

# Registry module: the active DG service plugin registers its integer-credit service here.
_service = None


def get_credit_service():
    return _service


def set_credit_service(service) -> None:
    global _service
    _service = service
